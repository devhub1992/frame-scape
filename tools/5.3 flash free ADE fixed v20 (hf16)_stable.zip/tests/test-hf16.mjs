#!/usr/bin/env node
/* hf.16 smoke suite — DEBUG LEDGER + HEAD/TAIL TOOLS + GREP 0-HIT PROBE
   + F3 RECONSTRUCTION + STALE-RESUME GUARD.
   Runs the REAL agent.js in a vm sandbox against in-memory VFS stubs. Pins
   the 2026-10-31 round-8 field chain shut (the lost-report transcript):
   · DEBUG LEDGER — every empty response / stall death and every tool ERROR
     auto-records into /ade.debug.flat.txt (dated flat line: the death kind,
     the EXACT tool + query + result head just before it, the agent's
     thoughts); debugSessionText filters the ACTIVE conversation;
   · HEAD/TAIL TOOLS — the dedicated chunked first/last-N-lines reads
     (single + multi-file, FAILED isolation, tail KEEPS THE END on a >30 KB
     file, slice plan riding large tails);
   · GREP 0-HIT PROBE — the field killer "t1[01]\d" vs serials written
     "t:100" now answers with the prefix probe + a sample line (the missing
     ':' separator becomes visible); all-miss falls back honestly;
   · F3 RECONSTRUCTION — a dropped turn's ledger line carries edit arg
     digests (path + find snippet) AND the lost report's head, so a
     recovery run can never again see only "4 code edits";
   · STALE-RESUME GUARD — a continue whose transcript already advanced says
     MAY BE STALE (+ names a trailing tool ERROR) and never invites the
     state-file DONE; a fresh task turn keeps the classic wording.
   Source pins: verified-DONE nudge wording · the BURN 🐛 debug button ·
   build stamps ade-s30-hf16 / ade-sw-vs35.                                    */
import fs from "node:fs";
import vm from "node:vm";
import assert from "node:assert/strict";

const ROOT = decodeURIComponent(new URL("..", import.meta.url).pathname);
const agentSrc = fs.readFileSync(ROOT + "/js/agent.js", "utf8");

const TEXT_RE = /\.(txt|md|markdown|py|js|mjs|ts|tsx|jsx|json|html|htm|css|scss|yml|yaml|xml|svg|sh|bash|zsh|env|ini|cfg|conf|toml|csv|tsv|sql|gitignore|dockerfile|makefile|flat\.txt|log|rb|go|rs|java|c|h|cpp|hpp|cs|php|lua|pl|r|m|bat|ps1)$/i;
const isTextName = (name) => TEXT_RE.test(name || "");

function makeVFS() {
  const files = new Map();
  const dirs = new Set(["/"]);
  const norm = (p) => {
    let s = String(p ?? "/").trim() || "/";
    if (!s.startsWith("/")) s = "/" + s;
    s = s.replace(/\/{2,}/g, "/").replace(/\/+$/, "");
    return s || "/";
  };
  const parent = (p) => norm(p).replace(/\/[^/]*$/, "") || "/";
  const ensureDirs = (p) => { let d = parent(p); const chain = []; while (d !== "/" && !dirs.has(d)) { chain.push(d); d = parent(d); } chain.forEach(x => dirs.add(x)); };
  return {
    files, dirs, norm, base: (p) => norm(p).split("/").pop(), FSA: null,
    async put(p, content, _mirror) { p = norm(p); if (p === "/") throw new Error("put /"); files.set(p, String(content)); ensureDirs(p); },
    async readText(p) { p = norm(p); if (files.has(p)) return isTextName(p) ? files.get(p) : null; return null; },
    async get(p) { p = norm(p); if (files.has(p)) return { path: p, kind: "file", size: files.get(p).length }; if (dirs.has(p)) return { path: p, kind: "dir" }; return null; },
    async exists(p) { p = norm(p); return files.has(p) || dirs.has(p); },
    async isDir(p) { return dirs.has(norm(p)); },
    async list(p) { p = norm(p); const rows = []; for (const d of dirs) if (parent(d) === p && d !== "/") rows.push({ path: d, kind: "dir" }); for (const f of files.keys()) if (parent(f) === p) rows.push({ path: f, kind: "file", size: files.get(f).length }); return rows; },
    async rm(p) { p = norm(p); if (files.has(p)) { files.delete(p); return; } let hit = false; for (const f of [...files.keys()]) if (f.startsWith(p + "/")) { files.delete(f); hit = true; } for (const d of [...dirs]) if (d === p || d.startsWith(p + "/")) { dirs.delete(d); hit = true; } if (!hit) throw new Error("rm: not found " + p); },
    async mv(from, to) { from = norm(from); to = norm(to); if (!files.has(from)) throw new Error("mv: not found " + from); files.set(to, files.get(from)); files.delete(from); return to; },
    async mkdirp(p) { dirs.add(norm(p)); },
    async tree(root) { root = norm(root); const rows = []; for (const d of dirs) if (d !== "/" && (d === root || d.startsWith(root === "/" ? "/" : root + "/"))) rows.push({ path: d, kind: "dir", depth: d.split("/").length - 1 }); for (const f of files.keys()) if (parent(f) === root) rows.push({ path: f, kind: "file", size: files.get(f).length }); return rows; },
    async digestTable() { return "(stub digest table)"; },
    async count() { return { files: files.size, dirs: dirs.size }; },
    onWrite() {},
    async clearAll() { files.clear(); dirs.clear(); dirs.add("/"); }
  };
}

function makeSandbox(vfs) {
  const captured = { copied: null, toasts: [] };
  const sandbox = {
    console, TextEncoder, TextDecoder,
    Date, Math, JSON, RegExp, Number, String, Boolean, Array, Object, Promise, Error, Uint8Array, Map, Set, isNaN, parseInt, parseFloat,
    window: {},
    document: { head: { appendChild() {} }, getElementById: () => null, createElement() { return { set textContent(v) {}, appendChild() {} }; } },
    VFS: vfs,
    WSUI: { editing() {}, fileBurn() {} },
    Exec: { ConsoleUI: { line() {} } },
    DB: { saveMsg: async () => {}, saveConv: async () => {}, getSetting: async () => null },
    State: { msgs: [], activeConvId: "c1", streamingId: null, sessionTokens: 0 },
    U: {
      uid: () => "u" + Math.random().toString(36).slice(2, 8),
      escapeHtml: (s) => String(s),
      fmtTokens: (n) => String(n),
      fmtBytes: (n) => (n = Number(n) || 0) >= 1024 ? (n / 1024).toFixed(1) + " KB" : n + " B",
      estimateTokens: (s) => Math.ceil(String(s).length / 4),
      toast(kind, opts) { captured.toasts.push({ kind, msg: opts && opts.msg }); },
      copyText(s) { captured.copied = String(s); },
      isTextName
    },
    ADE_BUILD: { version: "ade-s30-hf16-test", stamp: "test" },
    sessionStorage: { getItem: () => null, setItem() {} },
    fflate: {},
    __captured: captured
  };
  sandbox.window.VFS = vfs;
  sandbox.window.Exec = sandbox.Exec;
  sandbox.window.Agent = null;
  return sandbox;
}

const sandbox = makeSandbox(makeVFS());
vm.createContext(sandbox);
vm.runInContext(agentSrc, sandbox, { filename: "agent.js" });
const Agent = sandbox.window.Agent;
assert.ok(Agent && Agent.TOOLS, "Agent loaded from agent.js");

let pass = 0, fail = 0;
async function t(name, fn) {
  try { await fn(); pass++; console.log("  ok  " + name); }
  catch (e) { fail++; console.log("FAIL  " + name + "\n      " + (e && e.message)); }
}
const run = (name, args) => Agent.execTool(name, args);
const V = sandbox.VFS;

/* fixtures */
const NUMS = Array.from({ length: 100 }, (_, i) => "L" + (i + 1)).join("\n");
await V.put("/nums.txt", NUMS);
await V.put("/serials.txt", [
  "# ledger header",
  "t:100 noise wash gain .015",
  "t:101 gurgle grains Q10",
  "touch stone clack",
  "the tail row of the fixture"
].join("\n"));
await V.put("/casefile.txt", "Brook v3 lives here\nsecond row\n");
await V.put("/plain.txt", "hello world\n");
const BIG = Array.from({ length: 2200 }, (_, i) => "LINE-" + (i + 1) + " " + "x".repeat(18)).join("\n"); // ≈49 KB
await V.put("/big.txt", BIG);
await V.put("/big2.txt", Array.from({ length: 60 }, (_, i) => "B2-L" + (i + 1)).join("\n"));

/* ── 1. registry + prompt teaching ── */
await t("registry: head/tail are tools #29/#30 — one-word, n param, ARRAY-capable path", () => {
  const names = Agent.TOOLS.map(x => x.name);
  assert.equal(names.length, 30, "TOOLS 28 → 30 (head + tail joined)");
  for (const nm of ["head", "tail"]) {
    const tool = Agent.TOOLS.find(x => x.name === nm);
    assert.ok(tool, nm + " registered");
    assert.ok(tool.parameters.properties.n, nm + " carries n");
    assert.ok(/ARRAY/.test(tool.parameters.properties.path.description), nm + " path teaches ARRAY");
    if (nm === "tail") assert.ok(/KEEPS THE END/.test(tool.description), "tail teaches tail-keeps-the-end");
  }
});
await t("prompt teaches head/tail: TOOLS (30) · files line · ARG NAMES · rule 6", () => {
  const src = agentSrc;
  assert.ok(src.includes("TOOLS (30) — ONE-WORD names"), "TOOLS count bumped");
  assert.ok(src.includes("· head · tail (first/last N lines, MULTI-FILE, any size) · write"), "files line lists head/tail");
  assert.ok(src.includes("head/tail {path, n?} — path may be an ARRAY"), "ARG NAMES carries head/tail");
  assert.ok(src.includes("head/tail {path:[…], n} ship several files' first/last N lines in ONE call"), "rule 6 teaches the batched head/tail");
});

/* ── 2. head/tail single-file ── */
await t("head: first N lines + honest skip note", async () => {
  const r = await run("head", { path: "/nums.txt", n: 3 });
  assert.ok(r.ok, "ok: " + r.content.slice(0, 160));
  assert.ok(r.content.includes("L1") && r.content.includes("L3") && !r.content.includes("L4\n"), "exactly the first 3 lines");
  assert.ok(r.content.includes("lines 1–3 of 100"), "header names the slice: " + r.content.split("\n")[0]);
  assert.ok(r.content.includes("97 lines skipped"), "skip note honest");
});
await t("tail: last N lines — the end is the point", async () => {
  const r = await run("tail", { path: "/nums.txt", n: 2 });
  assert.ok(r.ok);
  assert.ok(r.content.includes("L99") && r.content.includes("L100"), "the last two lines ship");
  assert.ok(!r.content.includes("L1\n"), "the head did not leak in");
});
await t("tail on a ≈49 KB file KEEPS THE END + rides the slice plan", async () => {
  const r = await run("tail", { path: "/big.txt", n: 5 });
  assert.ok(r.ok);
  assert.ok(r.content.includes("LINE-2200"), "the true last line shipped (tail-keeps-end)");
  assert.ok(!r.content.includes("LINE-1 "), "no head leakage");
  assert.ok(r.content.includes("leading line"), "the skip note says how far back to re-read");
});

/* ── 3. head/tail multi-file ── */
await t("head ×2 files in ONE call — per-file sections, shared budget note", async () => {
  const r = await run("head", { path: ["/serials.txt", "/casefile.txt"], n: 2 });
  assert.ok(r.ok, "ok: " + r.content.slice(0, 160));
  assert.ok(r.content.includes("===== /serials.txt =====") && r.content.includes("===== /casefile.txt ====="), "both files shipped");
  assert.ok(r.content.includes("head ×2 file(s) · 2 lines each"), "head counts the call");
  assert.ok(r.content.includes("# ledger header") && r.content.includes("Brook v3 lives here"), "first lines present");
});
await t("tail multi-file: a missing file ships (FAILED) and never blocks its sibling", async () => {
  const r = await run("tail", { path: ["/nope.txt", "/big2.txt"], n: 2 });
  assert.ok(r.ok, "the call still succeeds for the healthy file");
  assert.ok(r.content.includes("===== /nope.txt (FAILED) ====="), "failed file marked");
  assert.ok(r.content.includes("not found: /nope.txt"), "honest reason");
  assert.ok(r.content.includes("B2-L59") && r.content.includes("B2-L60"), "sibling tail shipped");
});

/* ── 4. grep 0-hit probe ── */
await t("grep 0-hit probe: 't1[01]\\d' against 't:100' serials answers with the prefix + sample line", async () => {
  const r = await run("grep", { pattern: "t1[01]\\d", path: "/serials.txt" });
  assert.ok(r.ok, "ok");
  assert.ok(r.content.includes("0 match(es)"), "still an honest zero");
  assert.ok(/shorter prefix “t” hits \d+×/.test(r.content), "the shorter-prefix probe fired: " + r.content.split("\n").slice(-1)[0].slice(0, 160));
  assert.ok(r.content.includes("t:100"), "the sample line shows the file's actual spelling (the ':' separator)");
  assert.ok(r.content.includes("copy the file's actual spelling"), "the teaching clause rides along");
});
await t("grep 0-hit probe: every probe missed → honest fallback with a next move", async () => {
  const r = await run("grep", { pattern: "zzqqxx", path: "/plain.txt" });
  assert.ok(r.content.includes("every probe missed"), "fallback line: " + r.content.split("\n").slice(-1)[0].slice(0, 140));
  assert.ok(r.content.includes("grep a distinctive short word"), "the fallback teaches the next move");
});
await t("grep 0-hit probe: case mismatch found via ignore-case probe", async () => {
  const r = await run("grep", { pattern: "brook", path: "/casefile.txt" });
  assert.ok(/prefix “brook” hits 1× \(ignore-case\)/.test(r.content), "the ignore-case hit is reported: " + r.content.split("\n").slice(-1)[0].slice(0, 150));
  assert.ok(r.content.includes("Brook v3 lives here"), "sample line shows the real casing");
});
await t("grep with real hits does NOT pay for the probe (hint absent)", async () => {
  const r = await run("grep", { pattern: "t:10", path: "/serials.txt" });
  assert.ok(r.content.includes("2 match(es)"), "hits counted");
  assert.ok(!r.content.includes("probe"), "no probe overhead on a hit");
});

/* ── 5. f3 ledger reconstruction (context-cut data loss) ── */
const mk = (role, content, extra = {}) => ({ id: "m" + Math.random().toString(36).slice(2, 8), convId: "c1", role, content, ts: Date.now(), ...extra });
await t("f3 ledger: a dropped turn keeps its edit digests + the lost report's head", async () => {
  sandbox.State.msgs = [
    mk("user", "rework one sound from framescape-lab.js per the flat file instructions and report"),
    mk("tool", "EDIT-RESULT " + "e".repeat(3000), { name: "edit", toolCallId: "call_a", args: { path: "frame-scape-music/framescape-lab.js", find: "brook v2 card text", replace: "brook v3 card text" }, ok: true, ms: 8 }),
    mk("assistant", "BROOKREPORT-MARKER the brook v3 deliverable landed with these numbers"),
    mk("user", "ACTIVETASK-16 verdict dump: keep waveWash, rework pebbleDrag"),
    mk("tool", "NEW-EVIDENCE " + "n".repeat(3000), { name: "read", toolCallId: "call_b" }),
    mk("assistant", "working the verdicts")
  ];
  const api = Agent.buildContext({ contextK: 3 }, {});
  const flat = api.map(m => typeof m.content === "string" ? m.content : JSON.stringify(m.content)).join("\n");
  assert.ok(flat.includes("[f3 ledger"), "the old turn WAS dropped (pressure is real)");
  assert.ok(flat.includes("did: edit(frame-scape-music/framescape-lab.js find=\u201cbrook v2 card text\u201d") || (flat.includes("did: edit(") && flat.includes("brook v2 card text")), "the ledger carries WHICH file + WHICH find-text");
  assert.ok(flat.includes("report:") && flat.includes("BROOKREPORT-MARKER"), "the lost report's head rides the ledger");
  assert.ok(!flat.includes("EDIT-RESULT"), "the dropped turn's tool results are really gone");
});

/* ── 6. stale-RESUME guard ── */
await t("stale-RESUME guard: a continue with live events (trailing tool ERROR) says MAY BE STALE and forbids the state-DONE", async () => {
  sandbox.State.msgs = [
    mk("user", "TASK-RESUME-1 rework the sound and report"),
    mk("tool", "RESULT — ERROR no match in frame-scape-music/framescape-lab.js", { name: "edit", toolCallId: "call_c", args: { path: "frame-scape-music/framescape-lab.js" }, ok: false, ms: 3 }),
    mk("assistant", "")
  ];
  const api = Agent.buildContext({ contextK: 20 }, { stateText: "task = report open audition iterations\ndone = backlog re-verified; report delivered\nnext = await user verdicts\nflags = next serial t114 free" });
  const flat = api.map(m => typeof m.content === "string" ? m.content : JSON.stringify(m.content)).join("\n");
  assert.ok(flat.includes("MAY BE STALE"), "the staleness warning rides the newest task turn");
  assert.ok(flat.includes("ERROR (edit)"), "the trailing tool ERROR is named");
  assert.ok(flat.includes("reply DONE only when THIS task's deliverable is verified in this transcript"), "the state-file DONE is forbidden");
  assert.ok(!flat.includes("execute step_next now"), "the naive execute-step_next wording is gone on a live continue");
});
await t("stale-RESUME guard: a FRESH task turn keeps the classic execute-step_next wording", async () => {
  sandbox.State.msgs = [mk("user", "TASK-RESUME-2 fresh task, no tool events yet")];
  const api = Agent.buildContext({ contextK: 20 }, { stateText: "task = earlier task\ndone = x\nnext = y\nflags = none" });
  const flat = api.map(m => typeof m.content === "string" ? m.content : JSON.stringify(m.content)).join("\n");
  assert.ok(flat.includes("execute step_next now"), "classic wording on a fresh turn");
  assert.ok(!flat.includes("MAY BE STALE"), "no staleness warning without live events");
});

/* ── 7. DEBUG LEDGER ── */
await t("debug ledger: dbg writes the header + lines; debugSessionText filters the ACTIVE conv", async () => {
  await V.rm("/ade.debug.flat.txt").catch(() => {});
  await Agent.dbg("dbg 2026-01-01T00:00:00.000Z · conv c1 · TESTLINE-A");
  await Agent.dbg("dbg 2026-01-01T00:01:00.000Z · conv c2 · TESTLINE-B");
  const file = await V.readText("/ade.debug.flat.txt");
  assert.ok(file.startsWith("# ade.debug.flat.txt"), "header written on first use");
  assert.ok(file.includes("TESTLINE-A") && file.includes("TESTLINE-B"), "both lines appended");
  const sess = Agent.debugSessionText("c1", file);
  assert.ok(sess.includes("TESTLINE-A") && !sess.includes("TESTLINE-B"), "session filter keeps c1 only");
  assert.ok(sess.split("\n").every(L => L.startsWith("dbg ")), "only dbg lines ship");
});
await t("debug ledger: dbgDeath records EMPTY RESPONSE + exact tool/query + thoughts, dated", async () => {
  const dead = mk("assistant", "");
  sandbox.State.msgs = [
    mk("assistant", "irrelevant"),
    mk("assistant", "thinking row", { reasoning: "Serials observed: t:100-113 present in lab. State flags said next serial t114 free." }),
    mk("tool", "[grep hits · 0 match(es)]", { name: "grep", toolCallId: "call_d", args: { pattern: "t1[01]\\d", path: "frame-scape-music/framescape-lab.js", unique: true }, ok: true, ms: 12 }),
    dead
  ];
  await Agent.dbgDeath("Empty response from model.", 2, dead);
  const file = await V.readText("/ade.debug.flat.txt");
  const line = file.split("\n").find(L => L.includes("EMPTY RESPONSE"));
  assert.ok(line, "an EMPTY RESPONSE line landed");
  assert.ok(line.includes("conv c1") && /\d{4}-\d{2}-\d{2}T/.test(line), "dated + conv-scoped");
  assert.ok(line.includes("tool grep"), "the exact tool just before it");
  assert.ok(line.includes("t1[01]") && line.includes("framescape-lab.js"), "the exact query (args)");
  assert.ok(line.includes("Serials observed"), "the agent's thoughts");
  assert.ok(line.includes("attempt 2"), "the auto-continue attempt number");
});
await t("debug ledger: tool errors auto-record; copyDebugSession puts the session on the clipboard", async () => {
  sandbox.__captured.copied = null;
  await Agent.dbgToolError({ name: "edit", args: { path: "frame-scape-music/framescape-lab.js", find: "old text" }, content: "RESULT — ERROR no match", ok: false, ms: 2 });
  const file = await V.readText("/ade.debug.flat.txt");
  const line = file.split("\n").find(L => L.includes("TOOL ERROR"));
  assert.ok(line && line.includes("edit") && line.includes("old text"), "tool error digest landed");
  await Agent.copyDebugSession();
  assert.ok(sandbox.__captured.copied && sandbox.__captured.copied.includes("ADE DEBUG — session c1"), "clipboard carries the session header");
  assert.ok(sandbox.__captured.copied.includes("TESTLINE-A") && !sandbox.__captured.copied.includes("TESTLINE-B"), "clipboard is session-scoped");
  assert.ok(sandbox.__captured.toasts.some(x => /debug line/.test(x.msg)), "a count toast fired");
});

/* ── 8. source pins — nudge wording, 🐛 button, build stamps ── */
await t("nudges: auto/manual continue require the CURRENT task's verified deliverable before DONE", () => {
  const ui = fs.readFileSync(ROOT + "/js/ui-chat.js", "utf8");
  assert.ok(!ui.includes("if the work is complete, reply DONE"), "the stale-DONE clause is gone");
  assert.ok(ui.includes("reply DONE only when the CURRENT task's deliverable is verified in this transcript"), "verified-DONE wording present");
  assert.ok(ui.includes('data-act="copy-debug"'), "the BURN 🐛 debug button exists");
  assert.ok(ui.includes("Agent.copyDebugSession()"), "the button wires the session copy");
  assert.ok(ui.includes("Agent.dbgDeath(death, this._autoChain, row)"), "the auto-continue engine feeds the debug ledger");
});
await t("stamps: main.js / sw.js / index.html / PATCHLOG all say hf16 + vs35 + v20", () => {
  const main = fs.readFileSync(ROOT + "/js/main.js", "utf8");
  assert.match(main, /version: "ade-s30-hf16"/, "ADE_BUILD.version bumped");
  const sw = fs.readFileSync(ROOT + "/sw.js", "utf8");
  assert.match(sw, /ade-sw-vs35/, "SW_CACHE bumped");
  const html = fs.readFileSync(ROOT + "/index.html", "utf8");
  assert.ok(!/ade-s29-hf15/.test(html), "no stale ?v= busting left");
  assert.match(html, /ade-s30-hf16/, "?v= busting on hf16");
  const log = fs.readFileSync(ROOT + "/PATCHLOG.flat.txt", "utf8");
  assert.match(log, /PATCHLOG — 5\.3 flash free ADE fixed v20 \(hf\.16\)/, "PATCHLOG header bumped");
  const rd = fs.readFileSync(ROOT + "/readme.txt", "utf8");
  assert.match(rd, /BUILD STAMP: ade-s30-hf16/, "readme stamp bumped");
});

console.log(`\nhf.16 smoke suite: ${pass} passed · ${fail} failed`);
process.exit(fail ? 1 : 0);

#!/usr/bin/env node
/* hf.13 smoke suite — PER-CHAT clock + composer draft persistence.
   Loads the REAL ui-chat.js + main.js into a vm sandbox with DOM /
   localStorage stubs (no browser needed) and pins the 2026-10-31 field
   report shut:
   · the header clock belongs to the ACTIVE CHAT — a new chat restarts it
     at 0:00, other chats' tokens can never leak into the rate, and the
     hf.11 tab-session anchor (sessionStorage ade_session_start) is gone;
   · tok/min = the chat's own exact usage Σ ÷ chat minutes (1-min floor);
   · #msg-input text survives reloads per conversation (localStorage
     ade_draft_v1_<convId>), follows chat switches, the pre-chat scratch
     draft migrates into the chat it starts, send/delete clean up. */
import fs from "node:fs";
import vm from "node:vm";
import assert from "node:assert/strict";

const ROOT = decodeURIComponent(new URL("..", import.meta.url).pathname);
const CTX = { pass: 0, fail: 0 };
const t = async (name, fn) => {
  try { await fn(); CTX.pass++; console.log(`  ok  ${name}`); }
  catch (e) { CTX.fail++; console.error(`FAIL  ${name}\n      ${e.message}`); }
};

/* ── stubs ── */
const now = Date.now();
const makeLS = () => {
  const m = new Map();
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => m.set(k, String(v)),
    removeItem: (k) => m.delete(k),
    _m: m
  };
};
const makeEl = () => ({ value: "", innerHTML: "", title: "", style: {}, focus() {}, setSelectionRange() {}, addEventListener() {} });

const LS = makeLS();
const sandbox = {
  console, Date, Math, JSON, Number, String, Boolean, Array, Object, RegExp, Promise, Error, isNaN, parseInt, parseFloat,
  localStorage: LS,
  sessionStorage: makeLS(),
  window: { addEventListener() {} },
  navigator: {},
  location: { reload() {} },
  setTimeout: () => 0, clearTimeout() {}, setInterval: () => 0, clearInterval() {},
  document: {
    getElementById: (id) => (sandbox.__els ||= {})[id] ||= makeEl(),
    addEventListener() {}, head: { appendChild() {} }
  },
  SK: { ACTIVE_CONV: "active_conv_id" },
  DB: { saveMsg: async () => {}, saveConv: async () => {}, setSetting: async () => {} },
  U: { fmtTokens: (n) => (n >= 1000 ? (n / 1000).toFixed(1) + "k" : String(n)), toast() {}, escapeHtml: (s) => s, uid: () => "id-" + Math.random().toString(36).slice(2) },
  Agent: { resolveUrl: async () => "" },
  VFS: {}, SchedUI: {}, SettingsUI: {}, WSUI: {}
};
sandbox.State = {
  convs: [], msgs: [], activeConvId: null, streaming: false,
  pendingAtts: [], sessionRequests: 0, sessionTokens: 0,
  activeConfigId: null, corsKey: "", agentMaxSteps: null, agentContextK: null,
  streamingId: null
};
sandbox.__els = {};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(ROOT + "/js/ui-chat.js", "utf8"), sandbox, { filename: "ui-chat.js" });
vm.runInContext(fs.readFileSync(ROOT + "/js/main.js", "utf8"), sandbox, { filename: "main.js" });
const { Main, ChatUI, ADE_BUILD } = vm.runInContext("({ Main, ChatUI, ADE_BUILD })", sandbox); // const = lexical, not a global property
const { State } = sandbox;

/* ── 1. the clock is PER-CHAT (the 4470/min report, pinned shut) ── */
await t("clock: elapsed anchors at the ACTIVE chat's creation — new chat = 0 elapsed", () => {
  const old = { id: "old", ts: now - 57 * 60000 };          // the 57-min tab
  const fresh = { id: "fresh", ts: now - 400 };             // a new chat
  State.convs = [old, fresh];
  State.msgs = [];
  State.activeConvId = "old";
  const a = Main.chatClock();
  assert.ok(Math.abs(a.elapsed - 57 * 60000) < 3000, `old chat elapsed ≈ 57 min, got ${a.elapsed}`);
  State.activeConvId = "fresh";                             // the same tab, ONE new chat later
  const b = Main.chatClock();
  assert.ok(b.elapsed < 5000, `new chat restarts the clock, got ${b.elapsed}`);
  assert.equal(b.tok, 0, "no messages → 0 tok");
  assert.equal(b.perMin, 0, "0 tok over the 1-min floor → 0/min");
});

await t("clock: tokens = Σ usage.t of THIS chat's assistant rows — other chats can never leak in", () => {
  State.activeConvId = "fresh";
  State.convs = [{ id: "fresh", ts: now - 30 * 60000 }]; // a 30-min-old chat
  State.msgs = [
    { role: "user", content: "go", ts: now },
    { role: "assistant", usage: { p: 500, o: 100, r: 20, t: 30000 }, ts: now },
    { role: "assistant", usage: { p: 500, o: 100, r: 0, t: 30000 }, ts: now },
    { role: "assistant", content: "no usage row (estimate-only legacy) — not counted", ts: now }
  ];
  const c = Main.chatClock();
  assert.equal(c.tok, 60000, "exactly the two reported rows");
  assert.ok(Math.abs(c.perMin - 2000) < 40, `60000 tok ÷ 30 min = 2000/min, got ${c.perMin}`);
});

await t("clock: 1-minute floor holds — no absurd first-second spikes", () => {
  State.msgs = [{ role: "assistant", usage: { t: 1000 }, ts: now - 10000 }]; // 1k tok, 10 s old
  State.convs = [{ id: "fresh", ts: now - 10000 }];
  const c = Main.chatClock();
  assert.equal(c.perMin, 1000, "1000 tok ÷ 1-min floor = 1000, not 6000");
});

await t("clock: the hf.11 tab anchor (sessionStorage ade_session_start) is GONE", () => {
  sandbox.sessionStorage.setItem("ade_session_start", String(now - 3 * 60000)); // a 3-min-old tab anchor
  State.convs = [{ id: "old", ts: now - 57 * 60000 }];
  State.msgs = [];
  State.activeConvId = "old";
  const c = Main.chatClock();
  assert.ok(Math.abs(c.elapsed - 57 * 60000) < 3000, "elapsed follows the CHAT, not the sessionStorage anchor");
});

await t("clock: startClock renders the per-chat numbers + honest tooltip", () => {
  const el = sandbox.document.getElementById("hdr-clock");
  Main.startClock();                       // setInterval stubbed → tick ran exactly once
  assert.match(el.innerHTML, /tok · \d+\/min/, "chip renders tok + rate");
  assert.match(el.title, /this chat:/, "tooltip names the per-chat semantics");
  assert.match(el.title, /tab lifetime Σ:/, "tooltip keeps the tab-lifetime figure as secondary");
});

/* ── 2. composer draft persistence ── */
await t("draft: keystrokes land in localStorage under the active conv id", () => {
  State.activeConvId = "c1";
  ChatUI._draftConvId = "c1";
  sandbox.document.getElementById("msg-input").value = "hello draft world";
  ChatUI.saveDraft();
  assert.equal(LS.getItem("ade_draft_v1_c1"), "hello draft world");
});
await t("draft: loadDraft restores the text + pins _draftConvId", () => {
  sandbox.document.getElementById("msg-input").value = "";
  ChatUI.loadDraft("c1");
  assert.equal(sandbox.document.getElementById("msg-input").value, "hello draft world");
  assert.equal(ChatUI._draftConvId, "c1");
});
await t("draft: 48k cap — a giant paste is stored truncated, never throws", () => {
  sandbox.document.getElementById("msg-input").value = "x".repeat(50000);
  ChatUI.saveDraft();
  assert.equal(LS.getItem("ade_draft_v1_c1").length, 48000);
});
await t("draft: emptying the input removes the stored draft", () => {
  sandbox.document.getElementById("msg-input").value = "";
  ChatUI.saveDraft();
  assert.equal(LS.getItem("ade_draft_v1_c1"), null);
});
await t("draft: switching chats swaps drafts (each conv owns its own key)", () => {
  LS.setItem("ade_draft_v1_c1", "conv ONE text");
  LS.setItem("ade_draft_v1_c2", "conv TWO text");
  ChatUI.loadDraft("c1");
  assert.equal(sandbox.document.getElementById("msg-input").value, "conv ONE text");
  ChatUI.loadDraft("c2");
  assert.equal(sandbox.document.getElementById("msg-input").value, "conv TWO text");
});
await t("draft: the pre-chat scratch draft migrates into the chat it starts", () => {
  LS.setItem("ade_draft_v1___new", "typed before any chat existed");
  ChatUI.migrateScratchDraft("c9");
  assert.equal(LS.getItem("ade_draft_v1_c9"), "typed before any chat existed");
  assert.equal(LS.getItem("ade_draft_v1___new"), null, "scratch key cleaned up");
});
await t("draft: migration never overwrites an existing draft of the target chat", () => {
  LS.setItem("ade_draft_v1___new", "scratch");
  LS.setItem("ade_draft_v1_c7", "already there");
  ChatUI.migrateScratchDraft("c7");
  assert.equal(LS.getItem("ade_draft_v1_c7"), "already there");
});
await t("draft: clearDraft removes the key (send + delete paths)", () => {
  LS.setItem("ade_draft_v1_c2", "conv TWO text");
  ChatUI.clearDraft("c2");
  assert.equal(LS.getItem("ade_draft_v1_c2"), null);
});
await t("draft: private mode (throwing localStorage) degrades to in-memory, never throws", () => {
  const oldLS = sandbox.localStorage;
  sandbox.localStorage = { getItem() { throw new Error("blocked"); }, setItem() { throw new Error("blocked"); }, removeItem() { throw new Error("blocked"); } };
  sandbox.document.getElementById("msg-input").value = "survives in memory";
  ChatUI.saveDraft();           // must not throw
  ChatUI.loadDraft("cX");       // must not throw
  assert.equal(sandbox.document.getElementById("msg-input").value, "");
  sandbox.localStorage = oldLS;
});

/* ── 3. finalize still feeds the tab-lifetime Σ (tooltip secondary figure) ── */
await t("finalize: usage.t accumulates into State.sessionTokens + persists on the row", async () => {
  const row = { id: "m1", convId: "c1", role: "assistant", content: "", ts: now };
  await ChatUI.finalize(row, { acc: "done", usage: { p: 10, o: 5, r: 0, t: 123 } });
  assert.equal(State.sessionTokens, 123);
  assert.equal(row.usage.t, 123);
  assert.equal(row.content, "done");
});

/* ── 4. build stamps moved in lockstep (deploy discipline; hf.16 keeps this current) ── */
await t("stamps: main.js / sw.js / index.html all say hf16 + vs35", () => {
  assert.match(ADE_BUILD.version, /hf16$/, "ADE_BUILD.version must bump with the wave");
  const sw = fs.readFileSync(ROOT + "/sw.js", "utf8");
  assert.match(sw, /ade-sw-vs35/, "SW_CACHE bumped");
  const html = fs.readFileSync(ROOT + "/index.html", "utf8");
  assert.ok(!/ade-s29-hf15/.test(html), "no stale ?v= busting left");
  assert.match(html, /ade-s30-hf16/, "?v= busting on hf16");
});

console.log(`\nhf.13 smoke suite: ${CTX.pass} passed · ${CTX.fail} failed`);
process.exit(CTX.fail ? 1 : 0);

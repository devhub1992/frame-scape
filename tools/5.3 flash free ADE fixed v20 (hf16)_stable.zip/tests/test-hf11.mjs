#!/usr/bin/env node
/* hf.11 smoke suite — runs the REAL agent.js in a vm sandbox against an in-memory VFS stub.
   Covers: chunk tool (build/compile/resume/idempotence/out-of-order/drift-refusal/abort/
   total-mismatch/16k-cap/expectBytes/backup/100KB-class note), write+append 16k gates,
   one-word aliases + legacy resolution + case-insensitivity, read 100KB refusal.
   hf.12 update: 28 tools (grep joined) · the LARGE-FILE line is 50 KB then — the
   threshold-pinned expectations here were raised accordingly (see test-hf12.mjs).
   hf.14 update: the line is 30 KB now AND a whole read never refuses (head slice
   + slice plan) — the read-gate + assemble-note expectations updated accordingly. */
import fs from "node:fs";
import vm from "node:vm";
import assert from "node:assert/strict";

const ROOT = decodeURIComponent(new URL("..", import.meta.url).pathname); // folder beside tests/ — repo-relative (decodeURIComponent: spaces in dir names)
const src = fs.readFileSync(ROOT + "/js/agent.js", "utf8");

/* ── in-memory VFS stub (mirrors the VFS API surface the handlers touch) ── */
function makeVFS() {
  const files = new Map();  // path -> string
  const dirs = new Set(["/"]);
  const norm = (p) => {
    let s = String(p ?? "/").trim() || "/";
    if (!s.startsWith("/")) s = "/" + s;
    s = s.replace(/\/{2,}/g, "/").replace(/\/+$/, "");
    return s || "/";
  };
  const parent = (p) => norm(p).replace(/\/[^/]*$/, "") || "/";
  const ensureDirs = (p) => { let d = parent(p); const chain = []; while (d !== "/" && !dirs.has(d)) { chain.push(d); d = parent(d); } chain.forEach(x => dirs.add(x)); };
  const base = (p) => norm(p).split("/").pop();
  return {
    files, dirs, norm, base,
    FSA: null,
    async put(p, content, _mirror) { p = norm(p); if (p === "/") throw new Error("put /"); files.set(p, String(content)); ensureDirs(p); },
    async readText(p) { p = norm(p); if (files.has(p)) return files.get(p); if (dirs.has(p)) return null; for (const d of dirs) if (p.startsWith(d + "/")) return null; return null; },
    async get(p) { p = norm(p); if (files.has(p)) return { path: p, kind: "file", size: files.get(p).length }; if (dirs.has(p)) return { path: p, kind: "dir" }; return null; },
    async exists(p) { p = norm(p); return files.has(p) || dirs.has(p); },
    async isDir(p) { return dirs.has(norm(p)); },
    async list(p) { p = norm(p); const rows = []; for (const d of dirs) if (parent(d) === p && d !== "/") rows.push({ path: d, kind: "dir" }); for (const f of files.keys()) if (parent(f) === p) rows.push({ path: f, kind: "file", size: files.get(f).length }); return rows; },
    async rm(p) { p = norm(p); if (files.has(p)) { files.delete(p); return; } let hit = false; for (const f of [...files.keys()]) if (f.startsWith(p + "/")) { files.delete(f); hit = true; } for (const d of [...dirs]) if (d === p || d.startsWith(p + "/")) { dirs.delete(d); hit = true; } if (!hit) throw new Error("rm: not found " + p); },
    async mv(from, to) { from = norm(from); to = norm(to); if (!files.has(from)) throw new Error("mv: not found " + from); files.set(to, files.get(from)); files.delete(from); return to; },
    async mkdirp(p) { dirs.add(norm(p)); },
    async tree() { return []; },
    async digestTable() { return "(stub digest table)"; },
    async count() { return { files: files.size, dirs: dirs.size }; },
    onWrite() {}, /* hf.11 test stub — the work-folder mirror bus (no-op in sandbox) */
    async clearAll() { const n = files.size + dirs.size; files.clear(); dirs.clear(); dirs.add("/"); return n; }
  };
}

/* ── browser-ish sandbox ── */
const sandbox = {
  console,
  TextEncoder, TextDecoder,
  Date, Math, JSON, RegExp, Number, String, Boolean, Array, Object, Promise, Error, Uint8Array, Map, Set, isNaN, parseInt, parseFloat,
  window: {},
  document: { head: { appendChild() {} }, getElementById: () => null, createElement() { return { set textContent(v) {}, appendChild() {} }; } },
  VFS: makeVFS(),
  WSUI: { editing() {} },
  Exec: {},
  DB: { saveMsg: async () => {}, saveConv: async () => {} },
  State: { msgs: [], activeConvId: "c1", streamingId: null, sessionTokens: 0 },
  U: { uid: () => "u" + Math.random().toString(36).slice(2, 8), escapeHtml: (s) => String(s), fmtTokens: (n) => String(n), estimateTokens: (s) => Math.ceil(String(s).length / 4), toast() {} },
  ADE_BUILD: { version: "ade-s28-hf11-test", stamp: "test" },
  sessionStorage: { getItem: () => null, setItem() {} },
  fflate: {}
};
sandbox.window.VFS = sandbox.VFS; sandbox.window.Exec = sandbox.Exec; sandbox.window.Agent = null;
vm.createContext(sandbox);
vm.runInContext(src, sandbox, { filename: "agent.js" });
const Agent = sandbox.window.Agent;
assert.ok(Agent && Agent.TOOLS, "Agent loaded from agent.js");

let pass = 0, fail = 0;
async function t(name, fn) {
  try { await fn(); pass++; console.log("  ok  " + name); }
  catch (e) { fail++; console.log("FAIL  " + name + "\n      " + (e && e.message)); }
}
const run = (name, args) => Agent.execTool(name, args);

/* ── 1. registry shape ── */
await t("registry: 30 tools, all one-word lowercase (hf.16 update: head/tail joined)", () => {
  assert.equal(Agent.TOOLS.length, 30); // hf.16 — head/tail joined (28 + 2)
  for (const tool of Agent.TOOLS) assert.match(tool.name, /^[a-z0-9]+$/, tool.name);
});
await t("canonical names include chunk; legacy names absent from registry", () => {
  const names = Agent.TOOLS.map(x => x.name);
  for (const want of ["list","tree","digest","read","write","append","chunk","delete","move","mkdir","unzip","rezip","zipadd","clear","find","grep","edit","split","scan","check","assemble","state","shell","py","js","preview","probe","caps"])
    assert.ok(names.includes(want), "missing " + want);
  assert.ok(!names.includes("fs_write") && !names.includes("flat_find") && !names.includes("ledger_split"));
});

/* ── 2. aliases + case-insensitivity ── */
await t("legacy fs_write resolves to write handler", async () => {
  const r = await run("fs_write", { path: "a/legacy.txt", content: "hello legacy" });
  assert.ok(r.ok, r.content);
  assert.equal(await sandbox.VFS.readText("/a/legacy.txt"), "hello legacy");
});
await t("legacy flat_edit + flat_find resolve", async () => {
  await run("flat_find", { pattern: "legacy", path: "/a/legacy.txt" });
  const r = await run("flat_edit", { path: "/a/legacy.txt", find: "legacy", replace: "EDITED" });
  assert.ok(r.ok, r.content);
  assert.equal(await sandbox.VFS.readText("/a/legacy.txt"), "hello EDITED");
});
await t("case-insensitive 'Write' resolves", async () => {
  const r = await run("Write", { path: "case.txt", content: "ok" });
  assert.ok(r.ok, r.content);
});
await t("chunkwrite / write_chunked / fs_write_chunked all → chunk", () => {
  for (const n of ["chunkwrite", "write_chunked", "fs_write_chunked", "CHUNK"]) assert.equal(Agent.canon(n), "chunk");
  assert.equal(Agent.canon("ledger_assemble"), "assemble");
  assert.equal(Agent.canon("state_save"), "state");
  assert.equal(Agent.canon("run_python"), "py");
});

/* ── 3. 16k gates ── */
await t("write refuses >16384 chars with chunk teaching", async () => {
  const r = await run("write", { path: "big.txt", content: "x".repeat(16385) });
  assert.ok(!r.ok); assert.match(r.content, /chunk/); assert.match(r.content, /16/);
});
await t("write accepts exactly 16384 chars", async () => {
  const r = await run("write", { path: "max.txt", content: "y".repeat(16384) });
  assert.ok(r.ok, r.content);
});
await t("append refuses >16384 chars", async () => {
  const r = await run("append", { path: "app.txt", content: "z".repeat(16385) });
  assert.ok(!r.ok); assert.match(r.content, /append too big/);
});

/* ── 4. chunk: happy path, byte-exact ── */
await t("chunk: 4-piece 40KB build compiles byte-exact, staging cleaned", async () => {
  const piece = "L" + "0123456789".repeat(990) + "\n"; // 9,902 chars/piece
  const src4 = piece.repeat(4); // 39,608 chars
  for (let i = 0; i < 4; i++) {
    const r = await run("chunk", { path: "build/big.txt", index: i, total: 4, content: piece });
    assert.ok(r.ok, r.content);
  }
  const r = await sandbox.VFS.readText("/build/big.txt");
  assert.equal(r, src4, "assembled content is byte-exact");
  assert.ok(!(await sandbox.VFS.exists("/build/big.txt.chunks")), "staging dir removed");
});
await t("chunk: report carries chars · lines · digest", async () => {
  await run("chunk", { path: "rep.txt", index: 0, total: 2, content: "aaa\nbbb\n" });
  const r = await run("chunk", { path: "rep.txt", index: 1, total: 2, content: "ccc\nddd" });
  assert.ok(r.ok); assert.match(r.content, /COMPILED/); assert.match(r.content, /15 chars/); assert.match(r.content, /4 lines/); assert.match(r.content, /d[0-9a-f]{8}/);
});

/* ── 5. chunk: idempotent re-send, out-of-order, status, resume ── */
await t("chunk: identical re-send of a NON-final index is a no-op", async () => {
  await run("chunk", { path: "idem.txt", index: 0, total: 3, content: "zero\n" });
  const r = await run("chunk", { path: "idem.txt", index: 0, total: 3, content: "zero\n" });
  assert.ok(r.ok && /IDENTICAL/.test(r.content), r.content);
});
await t("chunk: out-of-order arrival + status + resume → compile", async () => {
  const r0 = await run("chunk", { path: "ooo.txt", index: 0, total: 3, content: "part-zero\n" });
  assert.ok(r0.ok, r0.content);
  const r2 = await run("chunk", { path: "ooo.txt", index: 2, total: 3, content: "part-two\n" }); // FINAL index with 1 missing → honest refusal
  assert.ok(!r2.ok && /missing: 1/.test(r2.content), r2.content);
  const st = await run("chunk", { path: "ooo.txt", status: true });
  assert.ok(st.ok && /2\/3 staged/.test(st.content) && /missing: 1/.test(st.content), st.content);
  const r1 = await run("chunk", { path: "ooo.txt", index: 1, total: 3, content: "part-one\n" });
  assert.ok(r1.ok, r1.content);
  const fin = await run("chunk", { path: "ooo.txt", index: 2, total: 3, content: "part-two\n" }); // re-send the final → compile
  assert.ok(fin.ok && /COMPILED/.test(fin.content), fin.content);
  assert.equal(await sandbox.VFS.readText("/ooo.txt"), "part-zero\npart-one\npart-two\n");
});
await t("chunk: abort discards staging", async () => {
  await run("chunk", { path: "ab.txt", index: 0, total: 3, content: "x" });
  const r = await run("chunk", { path: "ab.txt", abort: true });
  assert.ok(r.ok && /discarded/.test(r.content), r.content);
  assert.ok(!(await sandbox.VFS.exists("/ab.txt.chunks")));
});

/* ── 6. chunk: integrity guards ── */
await t("chunk: drifted staged part → compile REFUSED, re-ship heals it", async () => {
  await run("chunk", { path: "drift.txt", index: 0, total: 3, content: "AAAA" });
  await run("chunk", { path: "drift.txt", index: 1, total: 3, content: "BBBB" });
  await sandbox.VFS.put("/drift.txt.chunks/c0000.part", "AXXX"); // storage-level tamper BEFORE the final
  const r = await run("chunk", { path: "drift.txt", index: 2, total: 3, content: "CCCC" });
  assert.ok(!r.ok && /REFUSED/.test(r.content) && /c0000\.part drifted/.test(r.content), r.content);
  assert.ok(!(await sandbox.VFS.exists("/drift.txt")), "target NOT written");
  const fix = await run("chunk", { path: "drift.txt", index: 0, total: 3, content: "AAAA" }); // re-ship the bad index — identical to the manifest, refreshes storage (self-heal)
  assert.ok(fix.ok && /IDENTICAL/.test(fix.content), fix.content);
  const fin = await run("chunk", { path: "drift.txt", index: 2, total: 3, content: "CCCC" });
  assert.ok(fin.ok && /COMPILED/.test(fin.content), fin.content);
  assert.equal(await sandbox.VFS.readText("/drift.txt"), "AAAABBBBCCCC");
});
await t("chunk: total mismatch refuses", async () => {
  await run("chunk", { path: "tm.txt", index: 0, total: 3, content: "x" });
  const r = await run("chunk", { path: "tm.txt", index: 0, total: 5, content: "x" });
  assert.ok(!r.ok && /total 3/.test(r.content), r.content);
});
await t("chunk: single chunk >16384 refused", async () => {
  const r = await run("chunk", { path: "toobig.txt", index: 0, total: 1, content: "q".repeat(16385) });
  assert.ok(!r.ok && /chunk too big/.test(r.content));
});
await t("chunk: expectBytes mismatch refuses, nothing written", async () => {
  await run("chunk", { path: "eb.txt", index: 0, total: 2, content: "AA" });
  const r = await run("chunk", { path: "eb.txt", index: 1, total: 2, content: "BB", expectBytes: 999 });
  assert.ok(!r.ok && /expectBytes mismatch/.test(r.content));
  assert.ok(!(await sandbox.VFS.exists("/eb.txt")));
});
await t("chunk: replaces a changed re-send; backup one-shot of previous target", async () => {
  await run("write", { path: "bak.txt", content: "OLD-CONTENT" });
  for (const [i, c] of [[0, "NEW-"], [1, "CONTENT"]]) { const q = await run("chunk", { path: "bak.txt", index: i, total: 2, content: c }); assert.ok(q.ok, q.content); }
  assert.equal(await sandbox.VFS.readText("/bak.txt"), "NEW-CONTENT");
  assert.equal(await sandbox.VFS.readText("/bak.txt.pre-chunkwrite.bak"), "OLD-CONTENT");
});
await t("chunk: ≥100KB compile report carries the LARGE-FILE pointer", async () => {
  const piece = "K".repeat(16000) + "\n"; // 16001 chars/piece — wait, cap is 16384 so fine
  for (const [i, c] of [[0, piece], [1, piece], [2, piece], [3, piece], [4, piece], [5, piece], [6, piece]]) {
    const q = await run("chunk", { path: "big100.txt", index: i, total: 7, content: c });
    assert.ok(q.ok, q.content);
  }
  const r = await sandbox.VFS.readText("/big100.txt");
  assert.ok(r.length >= 102400, "assembled ≥100KB");
});
await t("chunk: refuse staging-internal path + bad index/total", async () => {
  assert.ok(!(await run("chunk", { path: "x.chunks/c0000.part", index: 0, total: 1, content: "y" })).ok);
  assert.ok(!(await run("chunk", { path: "y.txt", index: 7, total: 3, content: "y" })).ok);
  assert.ok(!(await run("chunk", { path: "y.txt", index: 0, total: 9999, content: "y" })).ok);
  assert.ok(!(await run("chunk", { path: "y.txt", index: 0, total: 1 })).ok);
});

/* ── 7. read gate still coherent ── */
await t("read of a >30KB file ships a head slice + the LARGE-FILE plan — no dead-end refusal (hf.14 seamless)", async () => {
  await sandbox.VFS.put("/huge.txt", "h".repeat(110 * 1024));
  const r = await run("read", { path: "/huge.txt" });
  assert.ok(r.ok && /LARGE-FILE class/.test(r.content) && /read offset 1/.test(r.content), r.content);
  assert.ok(!/read refused/.test(r.content), "no refusal any more — the slice plan replaces it");
  assert.ok(/110 KB/.test(r.content), `honest KB figure present: ${r.content.slice(0, 200)}`);
});
await t("write gate on ≥100KB content names the LARGE-FILE class", async () => {
  const r = await run("write", { path: "lf.txt", content: "L".repeat(110 * 1024) });
  assert.ok(!r.ok && /LARGE-FILE class/.test(r.content), r.content);
});

/* ── 8. assemble LARGE-FILE note ── */
await t("assemble notes the ≥100KB edit path", async () => {
  const half = "S".repeat(60 * 1024);
  await sandbox.VFS.put("/big-ledger.txt", half + half);
  const sp = await run("split", { path: "/big-ledger.txt", by: "bytes", value: 40960 });
  assert.ok(sp.ok, sp.content);
  const r = await run("assemble", { manifest: "/big-ledger.parts" });
  assert.ok(r.ok && /≥30 KB file/.test(r.content), r.content);
});

console.log(`\nhf.11 smoke suite: ${pass} passed · ${fail} failed`);
process.exit(fail ? 1 : 0);

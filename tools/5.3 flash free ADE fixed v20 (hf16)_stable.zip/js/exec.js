/* ============================================================
   js/exec.js — ADE-04.1 · PyRun  (Pyodide v0.26.4, dedicated worker)
                ADE-04.2 · JSRun  (worker sandbox)
                ADE-04.3 · Preview (sandboxed iframe)
                ADE-04.4 · Shell  (virtual console) + ConsoleUI
   Replaces the CH-01 stub (pure file replacement — the script tag
   sits in its final load-order slot, index.html never moves).
   Runs fully in-browser per routing §06: python = WASM worker,
   js = dedicated worker, html = sandboxed iframe (no same-origin),
   shell = virtual over the VFS only.
   BANDWIDTH (m-23): pyodide is pulled ONCE behind an explicit
   user-approved ask (or self-fetched into vendor/pyodide/), every
   package load announces its size first, nothing downloads silently.
   The AGENT drives Exec.Shell.run() as its `shell` tool (CH-05).
   ============================================================ */
"use strict";

const Exec = {
  ready: true, // full module live since CH-04 (was the CH-01 stub flag)

  /* ── run router — the tree's run/preview action lands here ── */
  async run(path) {
    const ext = VFS.ext(path);
    if (ext === "py") return this.runPython(path);
    if (ext === "js" || ext === "mjs") return this.runJs(path);
    if (ext === "html" || ext === "htm") return this.preview(path);
    return U.toast("Nothing to run", { kind: "info", msg: `${path} — runnable: .py · .js · .html` });
  },

  _timeout(key, def) {
    return new Promise(async (resolve) => {
      try { const v = await DB.getSetting(key); resolve(typeof v === "number" && v > 0 ? v : def); }
      catch { resolve(def); }
    });
  },

  /* console panel styles — injected once (keeps css/ade.css untouched;
     reuses the P1-P20 tokens) */
  _injectStyles() {
    if (document.getElementById("ade-exec-styles")) return;
    const st = document.createElement("style");
    st.id = "ade-exec-styles";
    st.textContent = `
.ws-console { display:none; flex-direction:column; height:0; border-top:1px solid var(--border);
  background:var(--bg2); font-family:var(--font-mono); font-size:10px; overflow:hidden;
  flex-shrink:0; transition:height .15s ease; }
.ws-console.open { display:flex; height:220px; }
.wc-lines { flex:1; overflow:auto; padding:6px 8px; line-height:1.5; }
.wc-line { white-space:pre-wrap; word-break:break-word; color:var(--fg2); }
.wc-line.cmd  { color:var(--fg1); font-weight:600; }
.wc-line.cmd::before { content:"$ "; color:var(--primary,#d4893a); }
.wc-line.out  { color:var(--fg2); }
.wc-line.err  { color:var(--err,#c96f5c); }
.wc-line.sys  { color:var(--fg3); font-style:italic; }
.wc-input-row { display:flex; align-items:center; gap:6px; padding:5px 8px; border-top:1px solid var(--border); }
.wc-prompt { color:var(--primary,#d4893a); font-weight:600; white-space:nowrap; }
.wc-input { flex:1; background:none; border:none; outline:none; color:var(--fg1);
  font-family:var(--font-mono); font-size:10px; }
.wc-head { display:flex; align-items:center; justify-content:space-between; padding:4px 8px 0; }
.wc-title { color:var(--fg3); font-size:9px; letter-spacing:.5px; }
.wc-clear { background:none; border:none; color:var(--fg3); cursor:pointer; font-size:9px; padding:2px; }
.wc-clear:hover { color:var(--fg1); }
.ade-preview-frame { width:100%; height:100%; border:none; background:#fff; }
.ade-preview-body { height:60vh; overflow:hidden; }`;
    document.head.appendChild(st);
  },

  /* ════════════════════════════════════════════════════════════
     ADE-04.1 · PyRun — Pyodide v0.26.4 in a dedicated worker
     acquisition per m-23: self-fetched release in vendor/pyodide/
     wins; otherwise the FIRST run asks (≈10MB core, stated) and a
     yes pulls once from jsDelivr (browser-cached) — never silent.
     Each run: whole-VFS snapshot → worker /ws (4MB/file · 48MB
     total caps; node_modules/.git/__pycache__ skipped) → cwd /ws →
     stdout/stderr streamed → files python wrote are diff-checked
     and synced back into the VFS (write-through fires on its own).
     Timeout (default 120s) kills + reloads the worker.
     ════════════════════════════════════════════════════════════ */
  _py: { worker: null, booting: null, id: 0, pending: new Map() },
  PYODIDE_V: "0.26.4",
  PY_CDN: "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/",
  PY_CAP_FILE: 4 * 1024 * 1024,
  PY_CAP_TOTAL: 48 * 1024 * 1024,
  PY_SKIP: /(^|\/)(node_modules|\.git|__pycache__)(\/|$)/,
  PY_PKGS: { // prebuilt set — announce (m-23) then auto-load when imported
    numpy: "≈ 7 MB", pandas: "≈ 12 MB", matplotlib: "≈ 8 MB",
    scipy: "≈ 16 MB", sympy: "≈ 3 MB"
  },

  async _pyVendorUrl() { // self-fetched release beats the CDN pull (m-23)
    try {
      const u = new URL("vendor/pyodide/pyodide.js", location.href).href;
      const r = await fetch(u, { method: "HEAD" });
      if (r.ok) return { js: u, indexURL: new URL("vendor/pyodide/", location.href).href, local: true };
    } catch { /* file:// or missing — fall through */ }
    return null;
  },

  async _pyEnsure() {
    if (this._py.worker && this._py.booting) await this._py.booting;
    if (this._py.worker) return this._py.worker;
    this.ConsoleUI.show();
    const vendor = await this._pyVendorUrl();
    let target;
    if (vendor) {
      target = vendor;
      this.ConsoleUI.line("sys", `pyodide: using self-fetched release at ${vendor.indexURL}`);
    } else {
      const approved = await DB.getSetting("pyodide_pull");
      if (approved !== "approved") {
        const ok = confirm(
          `Python needs the Pyodide runtime (WASM).\n\n` +
          `Pull ONCE from jsDelivr: pyodide v${this.PYODIDE_V} core ≈ 10 MB\n` +
          `(the browser caches it — one download per browser, ever).\n\n` +
          `OK to pull now?`);
        if (!ok) {
          U.toast("Python not pulled", { kind: "info", ms: 8000, msg:
            `Self-fetch instead: download https://cdn.jsdelivr.net/pyodide/v${this.PYODIDE_V}/full/pyodide.js + pyodide.wasm (+ pyodide.asm.wasm) into vendor/pyodide/ next to index.html — ADE will detect it and skip the pull.` });
          throw new Error("pyodide pull declined (m-23: never a silent pull)");
        }
        await DB.setSetting("pyodide_pull", "approved"); // ask once, ever
      }
      target = { js: this.PY_CDN + "pyodide.js", indexURL: this.PY_CDN, local: false };
      this.ConsoleUI.line("sys", `pyodide v${this.PYODIDE_V}: pulling core ≈ 10 MB from jsDelivr (browser-cached — one download per browser)…`);
    }
    const t0 = Date.now();
    const boot = new Promise((resolve, reject) => {
      const w = new Worker(this._pyWorkerURL());
      this._py.worker = w;
      this._py.pending.set("boot", { resolve, reject });
      w.onmessage = (e) => this._pyOnMsg(e.data);
      w.onerror = (e) => { this._py.worker = null; this._py.booting = null; this._py.pending.delete("boot"); reject(new Error(e.message || "pyodide worker crashed")); };
      w.postMessage({ type: "init", js: target.js, indexURL: target.indexURL });
    });
    this._py.booting = boot.finally(() => { this._py.booting = null; });
    await boot;
    this.ConsoleUI.line("sys", `pyodide ready in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
    return this._py.worker;
  },

  _pyWorkerURL() {
    const src = `
      let py = null;
      const emit = (m) => postMessage(m);
      self.onmessage = async (e) => {
        const m = e.data;
        try {
          if (m.type === "init") {
            importScripts(m.js);
            py = await loadPyodide({ indexURL: m.indexURL });
            py.setStdout({ batched: (s) => emit({ type: "stream", stream: "out", text: s + "\\n" }) });
            py.setStderr({ batched: (s) => emit({ type: "stream", stream: "err", text: s + "\\n" }) });
            emit({ type: "boot-ok" });
            return;
          }
          if (m.type === "run") {
            for (const f of m.files) {
              const p = "/ws" + f.path;
              const dir = p.slice(0, p.lastIndexOf("/"));
              if (dir) py.FS.mkdirTree(dir);
              py.FS.writeFile(p, f.text !== undefined ? f.text : new Uint8Array(f.bin));
            }
            if (m.files.length) py.FS.mkdirTree("/ws");
            py.FS.chdir("/ws");
            let result;
            if (m.pkgs && m.pkgs.length) await py.loadPackage(m.pkgs);
            result = await py.runPythonAsync(m.code);
            // walk /ws — return every file; the main thread diff-checks
            const out = [];
            let total = 0;
            (function walk(p) {
              for (const name of py.FS.readdir(p)) {
                if (name === "." || name === "..") continue;
                const fp = p + "/" + name;
                const st = py.FS.stat(fp);
                if (py.FS.isDir(st.mode)) { walk(fp); continue; }
                if (total + st.size > m.capTotal || st.size > m.capFile) continue;
                const data = py.FS.readFile(fp);
                total += st.size;
                out.push({ path: fp.slice(3), bin: data.buffer, size: st.size });
              }
            })("/ws");
            const r = (result === undefined || result === null) ? String(result)
              : (typeof result === "object" && result.toString) ? result.toString()
              : String(result);
            emit({ type: "run-done", id: m.id, ok: true, result: r, files: out });
            return;
          }
          if (m.type === "pkgs") {
            await py.loadPackage(m.pkgs);
            emit({ type: "pkgs-done", id: m.id, ok: true });
            return;
          }
        } catch (err) {
          emit({ type: m.type === "init" ? "boot-err" : (m.type === "pkgs" ? "pkgs-done" : "run-done"),
                 id: m.id, ok: false, err: String(err && err.message || err) });
        }
      };`;
    return URL.createObjectURL(new Blob([src], { type: "application/javascript" }));
  },

  _pyOnMsg(m) {
    if (m.type === "boot-ok") { const p = this._py.pending.get("boot"); this._py.pending.delete("boot"); p && p.resolve(); return; }
    if (m.type === "boot-err") { const p = this._py.pending.get("boot"); this._py.pending.delete("boot"); this._py.worker = null; p && p.reject(new Error(m.err)); return; }
    if (m.type === "stream") { this.ConsoleUI.line(m.stream, m.text.replace(/\n$/, "")); return; }
    const p = this._py.pending.get(m.id);
    if (!p) return;
    this._py.pending.delete(m.id);
    if (m.type === "run-done" || m.type === "pkgs-done") p.resolve(m);
  },

  /* whole-VFS snapshot for the worker (caps + skips per f1) */
  async _pySnapshot() {
    const rows = await VFS.tree("/");
    const files = [];
    let total = 0;
    for (const r of rows) {
      if (r.kind !== "file") continue;
      if (this.PY_SKIP.test(r.path)) continue;
      if (r.size > this.PY_CAP_FILE || total + r.size > this.PY_CAP_TOTAL) continue;
      const row = await VFS.get(r.path);
      if (!row) continue;
      total += r.size;
      files.push(typeof row.content === "string"
        ? { path: r.path, text: row.content }
        : { path: r.path, bin: row.content });
    }
    return files;
  },

  _pyPickPkgs(code) { // auto-load the prebuilt set when the code imports it (line-based scan)
    const mods = new Set();
    for (const raw of String(code).split("\n")) {
      const line = raw.trim();
      let m = line.match(/^import\s+(.+?)\s*$/);
      if (m) {
        for (const part of m[1].split(",")) {
          const name = part.trim().split(/[\s.]+/)[0];
          if (this.PY_PKGS[name]) mods.add(name);
        }
        continue;
      }
      m = line.match(/^from\s+([\w.]+)/);
      if (m && this.PY_PKGS[m[1]]) mods.add(m[1]);
    }
    return [...mods];
  },

  async runPython(pathOrCode, inline) {
    const code = inline ? pathOrCode : await VFS.readText(pathOrCode);
    if (code == null) { U.toast("Not found", { kind: "err", msg: String(pathOrCode) }); return { ok: false, err: "not found: " + pathOrCode }; }
    this.ConsoleUI.show();
    let worker;
    try { worker = await this._pyEnsure(); }
    catch (e) { this.ConsoleUI.line("err", String(e.message || e)); return null; }

    // m-23: each package load announces its size first
    const pkgs = this._pyPickPkgs(code);
    for (const p of pkgs) this.ConsoleUI.line("sys", `auto-loading ${p} (${this.PY_PKGS[p]}, prebuilt wheel — browser-cached after first pull)…`);

    const files = await this._pySnapshot();
    const snap = new Map(files.map(f => [f.path, f.text !== undefined ? f.text : f.bin]));
    const id = "run" + (++this._py.id);
    const timeoutS = await this._timeout("py_timeout_s", 120);
    const t0 = Date.now();
    const run = new Promise((resolve) => {
      this._py.pending.set(id, { resolve });
      worker.postMessage({ type: "run", id, code, files, pkgs, capFile: this.PY_CAP_FILE, capTotal: this.PY_CAP_TOTAL });
    });
    const killer = setTimeout(() => {
      if (!this._py.pending.has(id)) return;
      this._py.pending.delete(id);
      if (this._py.worker) { this._py.worker.terminate(); this._py.worker = null; }
      resolve({ ok: false, err: `killed after ${timeoutS}s timeout (worker reloaded — runtime state reset)` });
    }, timeoutS * 1000);
    const r = await run;
    clearTimeout(killer);
    const secs = ((Date.now() - t0) / 1000).toFixed(1);

    if (!r.ok) {
      this.ConsoleUI.line("err", `${r.err || "error"}  ·  ${secs}s`);
      return r;
    }
    if (r.result && r.result !== "None" && r.result !== "undefined") this.ConsoleUI.line("out", r.result);

    // diff-check → sync back into VFS (write-through fires via the hook bus)
    let synced = 0;
    for (const f of (r.files || [])) {
      const prev = snap.get(f.path);
      let changed;
      if (prev === undefined) changed = true;
      else if (typeof prev === "string") changed = new TextDecoder().decode(new Uint8Array(f.bin)) !== prev;
      else {
        const a = new Uint8Array(prev), b = new Uint8Array(f.bin);
        changed = a.length !== b.length || a.some((v, i) => v !== b[i]);
      }
      if (!changed) continue;
      const isText = U.isTextName(f.path);
      await VFS.put(f.path, isText ? new TextDecoder().decode(new Uint8Array(f.bin)) : f.bin, isText);
      synced++;
    }
    if (synced) this.ConsoleUI.line("sys", `synced back into workspace: ${synced} file${synced === 1 ? "" : "s"} changed (write-through mirrored them)`);
    this.ConsoleUI.line("sys", `done · ${secs}s`);
    return r;
  },

  /* `pip install <pkg>` → micropip with a size-confirm step (m-23) */
  async pipInstall(pkg) {
    const ok = confirm(`micropip install "${pkg}"\n\nPackage size is unknown until fetched (typically 100 KB – 10 MB).\nThe browser caches what it pulls. Proceed?`);
    if (!ok) { this.ConsoleUI.line("sys", "pip install cancelled (m-23: confirm first)"); return { ok: false }; }
    await this._pyEnsure();
    const worker = this._py.worker;
    this.ConsoleUI.line("sys", `micropip: installing ${pkg}…`);
    try {
      const id = "pip" + (++this._py.id);
      const r = await new Promise((resolve) => {
        this._py.pending.set(id, { resolve });
        worker.postMessage({ type: "pkgs", id, pkgs: ["micropip"] });
        setTimeout(() => { if (this._py.pending.has(id)) { this._py.pending.delete(id); resolve({ ok: false, err: "micropip load timeout" }); } }, 60000);
      });
      if (!r.ok) throw new Error(r.err);
      const res = await this.runPython(
        `import micropip\nawait micropip.install("${pkg}")\nprint("installed", "${pkg}")`, true);
      return { ok: res && res.ok };
    } catch (e) {
      this.ConsoleUI.line("err", `pip ${pkg}: ${String(e.message || e)}`);
      return { ok: false };
    }
  },

  /* ════════════════════════════════════════════════════════════
     ADE-04.2 · JSRun — dedicated worker from a function-source
     blob; console.log/info/warn/error bridged; top-level await
     supported (async wrapper + direct eval of the JSON-embedded
     source, so no escaping pitfalls); timeout terminates.
     ════════════════════════════════════════════════════════════ */
  async runJs(path, files) {
    const code = await VFS.readText(path);
    if (code == null) { U.toast("Not found", { kind: "err", msg: String(path) }); return { ok: false, err: "not found: " + path }; }
    this.ConsoleUI.show();
    this.ConsoleUI.line("sys", `js: running ${path}…${files ? ` (FS preloaded: ${Object.keys(files).length} file(s))` : ""}`);
    const t0 = Date.now();
    const timeoutS = await this._timeout("js_timeout_s", 10);

    const r = await new Promise((resolve) => {
      const w = new Worker(this._jsWorkerURL(code, files || null));
      let settled = false;
      const finish = (v) => { if (!settled) { settled = true; w.terminate(); resolve(v); } };
      w.onmessage = (e) => {
        const m = e.data;
        if (m.type === "log") { this.ConsoleUI.line(m.level === "error" ? "err" : "out", m.args.join(" ")); return; }
        if (m.type === "done") {
          if (m.error) this.ConsoleUI.line("err", m.error);
          else if (m.result !== undefined && m.result !== "undefined") this.ConsoleUI.line("out", String(m.result));
          finish({ ok: !m.error, error: m.error, result: m.result });
        }
      };
      w.onerror = (e) => finish({ ok: false, error: e.message || "worker error" });
      setTimeout(() => finish({ ok: false, error: `killed after ${timeoutS}s timeout` }), timeoutS * 1000);
      w.postMessage({}); // kick
    });
    const secs = ((Date.now() - t0) / 1000).toFixed(1);
    this.ConsoleUI.line(r.ok ? "sys" : "err", r.ok ? `done · ${secs}s` : `${r.error}  ·  ${secs}s`);
    return r;
  },

  _jsWorkerURL(code, files) {
    // the user source travels as a JSON string — no escaping pitfalls;
    // AsyncFunction body = top-level await works, top-level return works.
    // hf.12 — `files` (path → text map) rides in as the global FS map: the
    // sandbox has NO fetch (blob: origin) and NO module imports, so preloaded
    // workspace files are the only way code there sees them.
    const src = `
      const __code = ${JSON.stringify(code)};
      const FS = ${JSON.stringify(files || {})};
      const __safe = (x) => { try { if (x === undefined) return "undefined";
        if (typeof x === "object" && x !== null) return JSON.stringify(x); return String(x); } catch { return String(x); } };
      ["log","info","warn","error"].forEach((k) => {
        const orig = console[k] ? console[k].bind(console) : () => {};
        console[k] = (...a) => { postMessage({ type: "log", level: k, args: a.map(__safe) }); orig(...a); };
      });
      self.onmessage = async () => {
        try {
          const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
          const result = await new AsyncFunction(__code)();
          postMessage({ type: "done", result: __safe(result) });
        } catch (err) {
          postMessage({ type: "done", error: String(err && err.stack ? err.stack.split("\\n").slice(0,3).join(" ") : err) });
        }
      };`;
    return URL.createObjectURL(new Blob([src], { type: "application/javascript" }));
  },

  /* ════════════════════════════════════════════════════════════
     ADE-04.3 · Preview — modal sandboxed iframe (allow-scripts
     allow-forms allow-modals allow-popups, NO allow-same-origin);
     console + window.onerror postMessaged into the run console;
     sibling resolution: <link href> → <style>, <script src> →
     inline, <img src> → data URIs (same-dir VFS files only).
     ════════════════════════════════════════════════════════════ */
  _MIME: { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", svg: "image/svg+xml", bmp: "image/bmp", ico: "image/x-icon" },

  _b64(buf) {
    const b = new Uint8Array(buf);
    let s = "";
    for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
    return btoa(s);
  },

  async preview(path) {
    const html = await VFS.readText(path);
    if (html == null) { U.toast("Not found", { kind: "err", msg: String(path) }); return { ok: false, err: "not found: " + path }; }
    const dir = VFS.parent(path);
    const doc = new DOMParser().parseFromString(html, "text/html");

    for (const link of [...doc.querySelectorAll('link[rel="stylesheet"][href]')]) {
      const css = await VFS.readText(VFS.join(dir, link.getAttribute("href")));
      if (css != null) { const st = doc.createElement("style"); st.textContent = css; link.replaceWith(st); }
    }
    for (const sc of [...doc.querySelectorAll("script[src]")]) {
      const code = await VFS.readText(VFS.join(dir, sc.getAttribute("src")));
      if (code != null) { const ns = doc.createElement("script"); ns.textContent = code; sc.replaceWith(ns); }
    }
    for (const im of [...doc.querySelectorAll("img[src]")]) {
      const row = await VFS.get(VFS.join(dir, im.getAttribute("src")));
      if (row && row.kind === "file" && typeof row.content !== "string") {
        const ext = VFS.ext(row.path);
        im.setAttribute("src", `data:${this._MIME[ext] || "application/octet-stream"};base64,${this._b64(row.content)}`);
      }
    }

    // console + error bridge (prepended so it runs first)
    const bridge = doc.createElement("script");
    bridge.textContent =
      `(function(){var send=function(t,a){try{parent.postMessage({__adePreview:1,level:t,args:a},"*")}catch(e){}};` +
      `["log","info","warn","error"].forEach(function(k){var o=console[k]?console[k].bind(console):function(){};` +
      `console[k]=function(){var a=[].slice.call(arguments).map(function(x){try{return typeof x==="object"&&x!==null?JSON.stringify(x):String(x)}catch(e){return String(x)}});send(k,a);o.apply(null,a)}});` +
      `window.onerror=function(m,s,l){send("error",[String(m)+" ("+String(s).split("/").pop()+":"+l+")"])};})();`;
    doc.head.insertBefore(bridge, doc.head.firstChild);

    this._injectStyles();
    this.ConsoleUI.show();
    this.ConsoleUI.line("sys", `preview: ${path} (sandboxed iframe — console bridged)`);

    document.getElementById("ade-preview-modal")?.remove();
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop open";
    backdrop.id = "ade-preview-modal";
    backdrop.innerHTML = `
      <div class="modal" style="width:min(920px,94vw)">
        <div class="modal-header">
          <h2><i class="fa-brands fa-html5"></i> ${U.escapeHtml(path)}
            <span class="sub">sandboxed preview · no same-origin</span></h2>
          <button class="icon-btn" id="ade-preview-close" title="Close (Esc)"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="ade-preview-body"><iframe class="ade-preview-frame" sandbox="allow-scripts allow-forms allow-modals allow-popups"></iframe></div>
      </div>`;
    document.body.appendChild(backdrop);
    const close = () => { backdrop.remove(); window.removeEventListener("keydown", esc); };
    const esc = (e) => { if (e.key === "Escape") close(); };
    window.addEventListener("keydown", esc);
    backdrop.querySelector("#ade-preview-close").addEventListener("click", close);
    backdrop.addEventListener("mousedown", (e) => { if (e.target === backdrop) close(); });
    backdrop.querySelector("iframe").srcdoc = "<!DOCTYPE html>" + doc.documentElement.outerHTML;
  },

  _previewMsgHandler: null,
  _wirePreviewBridge() { // one listener, installed at init
    if (this._previewMsgHandler) return;
    this._previewMsgHandler = (e) => {
      const m = e.data;
      if (!m || !m.__adePreview) return;
      this.ConsoleUI.show();
      this.ConsoleUI.line(m.level === "error" ? "err" : "out", (m.args || []).join(" "));
    };
    window.addEventListener("message", this._previewMsgHandler);
  }
};

/* ══════════════════════════════════════════════════════════════
   ADE-04.4 · Shell — a VIRTUAL console over the workspace VFS
   (routing §06 verdict: OS access exists only via the CH-07 bridge).
   Quote-aware tokenizer · && chaining · > and >> redirects ·
   25 commands · ↑/↓ history · cwd persists per session.
   THE AGENT drives this same shell as its `shell` tool (CH-05):
   Shell.run(cmd, {silent:true}) → { out, err, code } — pure data.
   ══════════════════════════════════════════════════════════════ */
Exec.Shell = {
  cwd: "/",
  history: [],
  _hIdx: -1,

  async init() { // called from ConsoleUI.bind on first open
    try { this.cwd = VFS.norm((await DB.getSetting("sh_cwd")) || "/"); } catch { this.cwd = "/"; }
  },

  /* quote-aware split of && chains, then quote-aware tokenize each leg,
     then extract > / >> redirects (all outside quotes) */
  _splitChain(raw) {
    /* ADE-S23.2 (ch-21.f8, m-52): `;` is now a sequence separator too — the old
       code split ONLY on &&, so `grep pat file; echo done` reached the tokenizer
       as ONE body and glued `file;` into a single bogus token (the field
       transcript: "the shell glued the ; to the filename"). */
    const legs = []; let cur = ""; let q = null;
    for (let i = 0; i < raw.length; i++) {
      const ch = raw[i];
      if (q) { if (ch === q) q = null; cur += ch; continue; }
      if (ch === '"' || ch === "'") { q = ch; cur += ch; continue; }
      if (ch === "&" && raw[i + 1] === "&") { legs.push(cur); cur = ""; i++; continue; }
      if (ch === ";") { legs.push(cur); cur = ""; continue; }
      cur += ch;
    }
    legs.push(cur);
    return legs.map(s => s.trim()).filter(Boolean);
  },
  _redirect(leg) {
    let q = null, target = null, append = false, body = leg;
    for (let i = 0; i < leg.length; i++) {
      const ch = leg[i];
      if (q) { if (ch === q) q = null; continue; }
      if (ch === '"' || ch === "'") { q = ch; continue; }
      if (ch === ">") {
        append = leg[i + 1] === ">";
        const rest = leg.slice(append ? i + 2 : i + 1).trim();
        target = this._tok(rest)[0] || null;
        body = leg.slice(0, i);
        break;
      }
    }
    return { body: body.trim(), target, append };
  },
  _tok(s) {
    const out = []; let cur = ""; let q = null;
    for (const ch of s) {
      if (q) { if (ch === q) q = null; else cur += ch; continue; }
      if (ch === '"' || ch === "'") { q = ch; continue; }
      if (ch === " ") { if (cur) { out.push(cur); cur = ""; } continue; }
      cur += ch;
    }
    if (cur) out.push(cur);
    return out;
  },
  _p(arg) { // resolve arg against shell cwd (.. -safe via VFS.norm)
    if (!arg || arg === ".") return this.cwd;
    return arg.startsWith("/") ? VFS.norm(arg) : VFS.join(this.cwd, arg);
  },
  /* ADE-HF.8 (ch-33) — CWD→ROOT FALLBACK READ. Field case (2026-10-31 frame-scape
     postmortem): the shell cwd PERSISTS between calls (sh_cwd), so after a `cd`
     every later root-relative path DOUBLED (/proj/proj/file) and the file commands
     answered with the catch-all "text file or pipe input required" — three tools
     looked broken in one session. _rt resolves cwd-first; on a genuine MISS it
     retries the arg against the workspace root and returns a one-line note so the
     model learns the convention instead of burning turns on ghost paths. */
  async _rt(arg) {
    if (arg == null || arg === "") return { t: null, p: "" };
    const p = this._p(arg);
    let t = await VFS.readText(p);
    if (t == null && !arg.startsWith("/") && arg !== ".") {
      const row = await VFS.get(p);
      if (!row || row.kind !== "file") {          // missing cwd-relative → try root-relative
        const alt = VFS.norm("/" + String(arg).replace(/^\/+/, ""));
        if (alt !== p && await VFS.exists(alt)) {
          const row2 = await VFS.get(alt);
          if (row2 && row2.kind === "file") {
            const t2 = await VFS.readText(alt);
            if (t2 != null) return { t: t2, p: alt, note: `[resolved against workspace root — shell cwd is ${this.cwd}; use a leading / for root-relative paths]\n` };
          }
        }
      }
    }
    return { t, p };
  },
  /* ADE-HF.8 — one HONEST error for "could not read as text": names MISSING vs
     DIRECTORY vs BINARY instead of the old catch-all that hid real path bugs. */
  async _noTextErr(p, tool) {
    const row = await VFS.get(p).catch(() => null);
    if (!row) return `${tool}: no such file: ${p}`;
    if (row.kind !== "file") return `${tool}: ${p} is a directory`;
    return `${tool}: binary file (${row.size} bytes) — text file or pipe input required`;
  },

  /* ADE-S13.6 (ch-18.f4, m-33 field report): pipe stages — split one && leg
     on `|` OUTSIDE quotes (the old shell had no pipes at all, so the agent's
     `find . | head -50` ran find with junk args and failed). */
  _splitPipe(raw) {
    const stages = []; let cur = ""; let q = null;
    for (let i = 0; i < raw.length; i++) {
      const ch = raw[i];
      if (q) { if (ch === q) q = null; cur += ch; continue; }
      if (ch === '"' || ch === "'") { q = ch; cur += ch; continue; }
      if (ch === "|") { stages.push(cur); cur = ""; continue; }
      cur += ch;
    }
    stages.push(cur);
    return stages.map(s => s.trim()).filter(Boolean);
  },

  /* ── ADE-S13.8 (ch-19.f1, m-34) · console command journal — every run()
     (user console AND agent `shell` tool calls — silent = agent) appends
     { ts, cmd, source, code, ms } to Shell.log (ring, 200) and notifies
     the CONSOLE HISTORY window via onLog subscribers. */
  log: [],
  _logFns: [],
  onLog(fn) { if (typeof fn === "function") { this._logFns.push(fn); try { fn(this.log, "init"); } catch { /* subscriber errors never break the shell */ } } },
  _logPush(e) {
    this.log.push(e);
    while (this.log.length > 200) this.log.shift();
    for (const fn of this._logFns) { try { fn(e, "push"); } catch { /* never break the shell */ } }
  },
  /* ADE-HF.6 — public journal hook for NON-shell agent tool calls
     (fs_* · run_python · run_js · caps · open_preview): without it the
     Workspace CONSOLE HISTORY panel only ever showed shell lines and
     looked dead while the agent worked. cmd is a one-line summary;
     shell calls keep journaling themselves inside run() — never both. */
  journal(cmd, code = 0, ms = 0, source = "agent") {
    this._logPush({ ts: Date.now(), cmd: String(cmd || "").replace(/\s+/g, " ").trim().slice(0, 200), source, code, ms });
  },

  /* route helpers live at Shell level so command fns reach them via this */
  async _pyRoute(args, raw) {
    const body = raw.replace(/^\s*(python|py)\s*/, "").trim();
    const cm = body.match(/^-c\s*(["'])([\s\S]*)\1/);
    if (cm) { await Exec.runPython(cm[2], true); return {}; }
    if (!args.length) return { err: "python: file.py or -c \"code\" required" };
    const p = this._p(args[0]);
    if (!(await VFS.exists(p))) return { err: `python: not found: ${args[0]}` };
    await Exec.runPython(p);
    return {};
  },
  async _jsRoute(args, raw) {
    /* hf.12 — `js -e "<code>"` runs INLINE code (field case: "js: not found:
       -e" burned a turn). Mirrors python -c; the code lands in /tmp and runs
       through runJs. `js file.js` stays unchanged. */
    const em = raw && raw.match(/^\s*js\s+-e\s*(["'])([\s\S]*)\1\s*$/);
    if (em) {
      const tmp = "/tmp/shell-js-" + Date.now() + ".js";
      await VFS.put(tmp, em[2], true);
      try { await Exec.runJs(tmp); } finally { try { await VFS.rm(tmp); } catch { /* best effort */ } }
      return {};
    }
    if (!args.length) return { err: "js: file.js required (or js -e \"<code>\")" };
    const p = this._p(args[0]);
    if (!(await VFS.exists(p))) return { err: `js: not found: ${args[0]}` };
    await Exec.runJs(p);
    return {};
  },

  /* execute one command string (may chain with && · may pipe stages with |);
     silent → no UI, pure data (the agent's `shell` tool path).
     ADE-S13.6: stdout of stage N feeds STDIN of stage N+1 — text tools
     (head · tail · wc · grep · sort) read stdin when no file arg is given.
     ADE-S13.8: every executed line lands in the Shell.log journal. */
  async run(raw, opts = {}) {
    const t0 = Date.now();
    const chains = this._splitChain(String(raw || "").trim());
    if (!chains.length) return { out: "", err: "", code: 0 };
    if (!opts.silent) { Exec.ConsoleUI.show(); Exec.ConsoleUI.line("cmd", raw.trim()); }
    let outAll = "", errAll = "", code = 0;
    for (const chain of chains) {
      const stages = this._splitPipe(chain); // ADE-S13.6
      let pipeIn = "";                       // stdin flowing into the next stage
      for (let si = 0; si < stages.length; si++) {
        let leg = stages[si];
        if (leg.includes("$?")) leg = leg.split("$?").join(String(code)); // ADE-S23.2 (ch-21.f8): $? = previous leg's exit code
        const isLast = si === stages.length - 1;
        const { body, target, append } = this._redirect(leg);
        const argv = this._tok(body);
        if (!argv.length) continue;
        let name = argv[0], args = argv.slice(1);
        if (name === "cd..") { name = "cd"; args = [".."]; } // ADE-HF.7 — `cd..` (no space) is a real typo users and agents make — accept it
        let out = "", err = "";
        const cmd = this._cmds[name];
        if (!cmd) { this.gap(name, "shell"); err = `unknown command: ${name} — try help (this miss is logged — run gaps)`; code = 127; } // ADE-S23.3 (ch-21.f4)
        else {
          try { const r = await cmd.call(this, args, body, pipeIn) || {}; out = r.out || ""; err = r.err || ""; code = r.code !== undefined ? r.code : (err ? 1 : 0); } // ADE-S23.1: commands may set an honest POSIX exit code (grep 1 = no match, diff 1 = differs)
          catch (e) { err = String(e && e.message || e); code = 1; }
        }
        if (target) { // > / >> — stdout lands in the VFS (write-through mirrors it)
          const p = this._p(target);
          const prev = append ? ((await VFS.readText(p)) || "") : "";
          await VFS.put(p, prev + out, true);
          if (!opts.silent) Exec.ConsoleUI.line("sys", `→ ${p}${append ? " (appended)" : ""}`);
          out = ""; // redirected — nothing flows onward through a pipe
        } else if (!isLast) {
          pipeIn = out; // ADE-S13.6 — feed the next stage
          if (err) { if (!opts.silent) Exec.ConsoleUI.line("err", err); errAll += err + "\n"; }
          continue;
        }
        if (out) { if (!opts.silent) Exec.ConsoleUI.line("out", out.replace(/\n$/, "")); outAll += out; }
        if (err) { if (!opts.silent) Exec.ConsoleUI.line("err", err); errAll += err + "\n"; }
      }
    }
    // ADE-S13.8 (ch-19.f1) — journal the line (agent calls are opts.silent)
    this._logPush({ ts: Date.now(), cmd: String(raw || "").trim(), source: opts.silent ? "agent" : "user", code, ms: Date.now() - t0 });
    return { out: outAll, err: errAll, code };
  },

  /* ══ ADE-S23.3 (ch-21.f4, m-52) · TOOL-GAPS JOURNAL ══
     Every unknown shell command and unknown agent tool lands here (ring, 50,
     session-scoped). `gaps` prints the ranked list — future field reports
     become data instead of chat archaeology. */
  gaps: [],
  gap(cmd, source) {
    const g = this.gaps;
    const last = g[g.length - 1];
    if (last && last.cmd === cmd && last.source === source) { last.n++; last.ts = Date.now(); }
    else g.push({ cmd: String(cmd).slice(0, 80), source, ts: Date.now(), n: 1 });
    while (g.length > 50) g.shift();
  },

  _sedAddr(a, li, total, line) {
    if (!a) return true;
    if (a.kind === "line") return (li + 1) === a.n;
    if (a.kind === "last") return li === total - 1;
    if (a.kind === "re") { try { return new RegExp(a.pat).test(line); } catch { return false; } }
    return false;
  },
  _sedParse(script) {
    const s = String(script); const cmds = []; let i = 0;
    while (i < s.length) {
      if (s[i] === ";" || s[i] === " ") { i++; continue; }
      const parseAddr = () => {
        if (s[i] === "$") { i++; return { kind: "last" }; }
        if (s[i] === "/") {
          let j = i + 1, pat = "";
          while (j < s.length && s[j] !== "/") { if (s[j] === "\\") { pat += s[j] + (s[j + 1] ?? ""); j += 2; } else pat += s[j++]; }
          if (s[j] !== "/") throw new Error("unterminated /pat/ address");
          i = j + 1; return { kind: "re", pat };
        }
        if (/[0-9]/.test(s[i] || "")) { let j = i; while (j < s.length && /[0-9]/.test(s[j])) j++; const n = +s.slice(i, j); i = j; return { kind: "line", n }; }
        return null;
      };
      const a1 = parseAddr();
      let a2 = null;
      if (s[i] === ",") { i++; a2 = parseAddr(); if (!a2) throw new Error("range needs a second address"); }
      const op = s[i];
      if (op === "s") {
        i++;
        const d = s[i] || "/"; i++;
        const read = () => { let b = ""; while (i < s.length && s[i] !== d) { if (s[i] === "\\" && i + 1 < s.length) { b += s[i] + s[i + 1]; i += 2; } else b += s[i++]; } if (s[i] === d) i++; else throw new Error("unterminated s expression (missing " + d + ")"); return b; };
        const pat = read(); const repl = read();
        const flags = [];
        while (i < s.length && /[gip0-9]/.test(s[i])) { if (/[gip]/.test(s[i])) flags.push(s[i]); else throw new Error(`s flag '${s[i]}' not supported (use g i p)`); i++; }
        if (pat === "") throw new Error("empty pattern");
        try { new RegExp(pat); } catch (e) { throw new Error("bad pattern " + pat + ": " + e.message); }
        cmds.push({ a1, a2, op: "s", pat, repl, flags, _on: false });
      } else if (op === "d" || op === "p") {
        i++; cmds.push({ a1, a2, op, _on: false });
      } else if (op === undefined) {
        if (a1) cmds.push({ a1, a2, op: "p", _on: false }); // bare address prints (sed default)
        else break;
      } else {
        throw new Error(`'${op}' not supported in this lean subset (hold space / flow control not supported)`);
      }
    }
    return cmds;
  },
  _sedSub(line, c) {
    const build = function (match, groups) {
      let b = "";
      for (let k = 0; k < c.repl.length; k++) {
        const ch = c.repl[k];
        if (ch === "\\" && k + 1 < c.repl.length) {
          const n = c.repl[++k];
          if (n >= "1" && n <= "9") b += (groups[+n - 1] ?? "");
          else b += n; // \& → &, \\ → \
        } else if (ch === "&") b += match;
        else b += ch;
      }
      return b;
    };
    if (c.flags.includes("g")) {
      let subd = false;
      const rx = new RegExp(c.pat, c.flags.includes("i") ? "gi" : "g");
      const out = line.replace(rx, function (m) { subd = true; return build(m, Array.from(arguments).slice(1, -2)); });
      return [out, subd || c.flags.includes("p")];
    }
    let subd = false;
    const rx1 = new RegExp(c.pat, c.flags.includes("i") ? "i" : "");
    const once = line.replace(rx1, function (m) { subd = true; return build(m, Array.from(arguments).slice(1, -2)); });
    return [once, subd || c.flags.includes("p")];
  },
  _flRanges(spec) {
    const rs = [];
    for (const part of String(spec).split(",")) {
      const m = part.match(/^(\d+)(?:-(\d*))?$/);
      if (!m) return null;
      rs.push({ a: +m[1], b: m[2] === undefined ? +m[1] : (m[2] === "" ? null : +m[2]) });
    }
    return rs;
  },
  _trSet(s) {
    const out = [];
    for (let i = 0; i < s.length; i++) {
      if (s[i] === "\\" && i + 1 < s.length) {
        const c = s[++i];
        out.push(c === "n" ? "\n" : c === "t" ? "\t" : c === "\\" ? "\\" : c);
      } else if (i + 2 < s.length && s[i + 1] === "-" && s[i] !== "-") {
        const a = s.charCodeAt(i), b = s.charCodeAt(i + 2);
        if (b < a) return null;
        for (let c = a; c <= b; c++) out.push(String.fromCharCode(c));
        i += 2;
      } else out.push(s[i]);
    }
    return out;
  },
  _cmds: {
    help() {
      return { out:
`ADE virtual shell — over the workspace VFS (OS access: ch-07 bridge only)
  files   ls (-l/-la) · cat · head · tail (-n/-N/-c) · touch · mkdir (-p) · rm (-r) · cp · mv
          find [dir] [-name pat] [-type f|d] [-maxdepth N]
  text    grep (-i -v -c -l -E -F — literal default, zero-match regex retry) · sed (-n -e;
          s/pat/repl/[g i p] · N,$,/pat/ addresses · d · p — hold space NOT supported)
          cut (-d -f -c) · tr (-d -s) · uniq (-c -d -u) · sort (-r -u) · nl · rev · tee (-a)
          diff f1 f2 (unified) · patch f [patchfile] (atomic verify; --dry-run) · wc
          echo (> >> redirect) · tree · stat · du (-s -h)
  survey  digest [dir] (-h) — one line per file (path · size · lines · preview):
          survey a folder in ONE call instead of reading it file-by-file
  meta    tools — live inventory of agent tools + shell commands (≈300 tokens)
          gaps — ranked journal of unknown commands/tools this session
  run     python/py <file|-c "code"> · js/node <file> · pip install <pkg> · open · download
  nav     pwd · cd · clear · seed · date · whoami · about · help
  chain with && or ; · PIPE with | (stdout feeds the next command's stdin —
  e.g. find . -type f | head -50 · cat file | grep word | wc) · redirect > >>` };
    },
    about() {
      return { out: `${ADE_BUILD.version} · ${ADE_BUILD.stamp}\n${ADE_BUILD.chunk}\nmodel: coding-glm-5.3-flash-free · static-first · keys local-only` };
    },
    async clear() { Exec.ConsoleUI.clearLines(); return {}; },
    pwd() { return { out: this.cwd + "\n" }; },
    async cd(args) {
      const t = args[0] || "/";
      const p = this._p(t);
      if (t === "-") return { err: "cd - not supported" };
      if (!(await VFS.isDir(p))) return { err: `no such directory: ${p}` };
      this.cwd = p;
      try { await DB.setSetting("sh_cwd", p); } catch { /* best effort */ }
      return {};
    },
    async ls(args) {
      // ADE-S13.3 (ch-18.f2, m-33 field report): `ls -la` / `-al` now count as
      // long format (the old exact-match args.includes("-l") missed bundled
      // flags — and `ls /` failed outright until VFS.get learned the root, ADE-S13.2)
      const long = args.some(a => /^-[a-z]*l/i.test(a));
      const p = this._p(args.find(a => !a.startsWith("-")) || "");
      if (!(await VFS.exists(p))) return { err: `no such path: ${p}` };
      if (!(await VFS.isDir(p))) {
        const row = await VFS.get(p);
        return { out: `${row.kind === "dir" ? "d" : "-"}  ${String(row.size || 0).padStart(8)}  ${VFS.base(row.path)}\n` };
      }
      const rows = await VFS.list(p);
      if (long) {
        return { out: rows.map(r => `${r.kind === "dir" ? "d" : "-"}  ${String(r.size || 0).padStart(8)}  ${VFS.base(r.path)}`).join("\n") + (rows.length ? "\n" : "") };
      }
      return { out: rows.map(r => VFS.base(r.path) + (r.kind === "dir" ? "/" : "")).join("  ") + (rows.length ? "\n" : "") };
    },
    async cat(args) {
      if (!args.length) return { err: "cat: file required" };
      const { t, p, note } = await this._rt(args[0]); // ADE-HF.8 — cwd→root fallback
      if (t == null) return { err: await this._noTextErr(p, "cat") };
      return { out: (note || "") + (t.endsWith("\n") ? t : t + "\n") };
    },
    async head(args, raw, stdin) {
      // ADE-S13.6: -N shorthand (head -50) · -n N · ADE-S23.2 (ch-21.f8): -c N bytes · or stdin
      const dash = args.find(a => /^-\d+$/.test(a));
      const cIdx = args.indexOf("-c");
      const cN = cIdx >= 0 ? parseInt(args[cIdx + 1], 10) : null;
      const n = dash ? parseInt(dash.slice(1), 10)
        : args.includes("-n") ? parseInt(args[args.indexOf("-n") + 1]) || 10 : 10;
      const vals = new Set();
      if (args.includes("-n")) vals.add(String(args[args.indexOf("-n") + 1]));
      if (cN !== null && !Number.isNaN(cN)) vals.add(String(args[cIdx + 1]));
      const f = args.find(a => !a.startsWith("-") && !vals.has(a));
      if (!f) {
        if (stdin != null) return { out: cN !== null ? String(stdin || "").slice(0, cN) : (stdin ? stdin.split("\n").slice(0, n).join("\n") + "\n" : "") };
        return { err: "head: text file or pipe input required" };
      }
      const { t, p, note } = await this._rt(f); // ADE-HF.8 — cwd→root fallback
      if (t == null) return { err: await this._noTextErr(p, "head") };
      if (cN !== null && !Number.isNaN(cN)) return { out: (note || "") + t.slice(0, cN) };
      return { out: (note || "") + t.split("\n").slice(0, n).join("\n") + "\n" };
    },
    async tail(args, raw, stdin) {
      const dash = args.find(a => /^-\d+$/.test(a));
      const cIdx = args.indexOf("-c");
      const cN = cIdx >= 0 ? parseInt(args[cIdx + 1], 10) : null; // ADE-S23.2 (ch-21.f8): -c N bytes
      const n = dash ? parseInt(dash.slice(1), 10)
        : args.includes("-n") ? parseInt(args[args.indexOf("-n") + 1]) || 10 : 10;
      const vals = new Set();
      if (args.includes("-n")) vals.add(String(args[args.indexOf("-n") + 1]));
      if (cN !== null && !Number.isNaN(cN)) vals.add(String(args[cIdx + 1]));
      const f = args.find(a => !a.startsWith("-") && !vals.has(a));
      let t = null, note = null, rp = "";
      if (f) { const r = await this._rt(f); t = r.t; note = r.note; rp = r.p; } // ADE-HF.8 — cwd→root fallback
      else if (stdin != null) t = stdin; // ADE-HF.7 — empty pipe = zero lines, never an error
      if (t == null) return { err: f ? await this._noTextErr(rp || this._p(f), "tail") : "tail: text file or pipe input required" };
      if (t === "") return { out: "" };
      if (cN !== null && !Number.isNaN(cN)) return { out: (note || "") + t.slice(-cN) };
      const L = t.replace(/\n$/, "").split("\n");
      return { out: (note || "") + L.slice(Math.max(0, L.length - n)).join("\n") + "\n" };
    },
    async echo(args, raw) {
      // raw body after "echo " — keeps quoted spaces; strip surrounding quotes
      const body = raw.replace(/^\s*echo\s*/, "");
      const m = body.match(/^(["'])([\s\S]*)\1$/);
      return { out: (m ? m[2] : body) + "\n" };
    },
    async touch(args) {
      if (!args.length) return { err: "touch: file required" };
      const p = this._p(args[0]);
      if (!(await VFS.exists(p))) await VFS.put(p, "", true);
      return {};
    },
    async mkdir(args) {
      const p = args.find(a => !a.startsWith("-"));
      if (!p) return { err: "mkdir: name required" };
      await (args.includes("-p") ? VFS.mkdirp(this._p(p)) : VFS.mkdir(this._p(p)));
      return {};
    },
    async rm(args) {
      const p = args.find(a => !a.startsWith("-"));
      if (!p) return { err: "rm: path required" };
      const full = this._p(p);
      if (full === "/") return { err: "rm: refusing to delete the workspace root" };
      if (!await VFS.exists(full)) return { err: `rm: not found: ${p}` };
      await VFS.rm(full);
      return {};
    },
    async cp(args) {
      if (args.length < 2) return { err: "cp: src dst required" };
      const s = this._p(args[0]);
      const row = await VFS.get(s);
      if (!row || row.kind !== "file") return { err: `cp: not a file: ${args[0]}` };
      let d = this._p(args[1]);
      if (await VFS.isDir(d)) d = VFS.join(d, VFS.base(s));
      await VFS.put(d, row.content, row.isText);
      return {};
    },
    async mv(args) {
      if (args.length < 2) return { err: "mv: src dst required" };
      const d = await VFS.mv(this._p(args[0]), this._p(args[1]));
      if (this.cwd === args[0] || this.cwd.startsWith(args[0] + "/")) this.cwd = d;
      return {};
    },
    async find(args) {
      /* ADE-S13.4 (ch-18.f3, m-33 field report): the old find REQUIRED -name
         ("find: -name <pattern> required") and ignored -type/-maxdepth — the
         agent's `find . -maxdepth 3 -type f` failed. POSIX-lean now:
           find [dir]                        → everything under dir
           find . -name "*.js"               → wildcard or substring match
           find / -type f | head -50         → files only, pipeable
           find demo -maxdepth 1 -type d     → dirs, depth-limited         */
      const get = (flag) => { const i = args.indexOf(flag); return i >= 0 ? args[i + 1] : undefined; };
      const consumed = new Set();
      /* hf.12 — FIELD ALIASES from the 2026-10-31 frame-scape log: the run
         guessed `find <file> -E -pattern "…" -max 70` and got three refusals.
         Now: -pattern = -name alias · -E = the name pattern is a REGEX (not
         wildcards) · -max N = -maxdepth N · a FILE root lists that file
         itself (subject to the name filter) instead of refusing. */
      let namePat = get("-name");
      if (namePat !== undefined) { consumed.add(args.indexOf("-name")); consumed.add(args.indexOf("-name") + 1); }
      else if (args.includes("-name")) return { err: "find: -name needs a pattern" };
      if (namePat === undefined && get("-pattern") !== undefined) {
        namePat = get("-pattern");
        consumed.add(args.indexOf("-pattern")); consumed.add(args.indexOf("-pattern") + 1);
      } else if (namePat === undefined && args.includes("-pattern")) return { err: "find: -pattern needs a pattern" };
      const useRe = args.includes("-E"); // hf.12 — extended/regex name matching (JS dialect)
      if (useRe) consumed.add(args.indexOf("-E"));
      const typeArg = get("-type");
      if (typeArg !== undefined) { consumed.add(args.indexOf("-type")); consumed.add(args.indexOf("-type") + 1); }
      if (typeArg !== undefined && !/^[fd]$/i.test(typeArg)) return { err: "find: -type accepts f (file) or d (dir)" };
      let maxRaw = get("-maxdepth");
      if (maxRaw !== undefined) { consumed.add(args.indexOf("-maxdepth")); consumed.add(args.indexOf("-maxdepth") + 1); }
      if (maxRaw === undefined && get("-max") !== undefined) { maxRaw = get("-max"); consumed.add(args.indexOf("-max")); consumed.add(args.indexOf("-max") + 1); } // hf.12 alias
      const maxD = maxRaw !== undefined && Number.isFinite(parseInt(maxRaw, 10)) ? Math.max(0, parseInt(maxRaw, 10)) : Infinity;
      const rootArg = args.find((a, i) => !a.startsWith("-") && !consumed.has(i));
      const root = this._p(rootArg || "");
      const mkRx = () => namePat === undefined ? null : (useRe
        ? new RegExp(String(namePat), "i")
        : new RegExp("^" + String(namePat).replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$", "i"));
      if ((await VFS.exists(root)) && !(await VFS.isDir(root))) { // hf.12 — a FILE root: list the file itself
        const base = VFS.base(root);
        const rx0 = mkRx();
        if (!rx0 || rx0.test(base) || base.toLowerCase().includes(String(namePat).toLowerCase())) return { out: root + "\n" };
        return { out: "", code: 1 };
      }
      if (!(await VFS.isDir(root))) return { err: `find: no such directory: ${rootArg || root}` };
      const rows = await VFS.tree(root);
      const all = [];
      if (typeArg !== "f") all.push({ path: root, kind: "dir", depth: -1 }); // real find lists the start point too
      for (const r of rows) all.push(r);
      const rx = mkRx();
      const hits = all.filter(r => {
        if ((r.depth ?? 0) + 1 > maxD) return false; // children of root are depth 0 → level 1
        if (typeArg === "f" && r.kind !== "file") return false;
        if (typeArg === "d" && r.kind !== "dir") return false;
        if (rx && !rx.test(VFS.base(r.path)) && !VFS.base(r.path).toLowerCase().includes(String(namePat).toLowerCase())) return false;
        return true;
      });
      return { out: hits.map(r => r.path).join("\n") + (hits.length ? "\n" : "") };
    },
    async grep(args, raw, stdin) {
      /* ADE-HF.7 — flag parsing (-i -v -E -e -F, bundled "-nE" expands).
         ADE-S23.1 (ch-21.f7, m-52 — the transcript's biggest burn: 4 silent
         zero-hit greps on BRE patterns like "A\|B" and "═ 0[0-9]\."):
         the LITERAL default stays, but a zero-match scan whose pattern carries
         regex metachars now RETRIES ONCE as a regex (\| → |) and SAYS SO.
         New: -c (count per file) · -l (files-with-matches) · -h/--help.
         Exit code 1 on zero matches (POSIX). */
      if (args.includes("-h") || args.includes("--help"))
        return { out: "grep: usage: grep [-i] [-v] [-c] [-l] [-E|-e regex | -F literal] pat [file|dir] [file|dir …] — literal by default; a zero-match literal scan auto-retries once as a regex (\\| → |); use -F to force literal; MULTIPLE files/dirs allowed (hf.12); pipe input works; exit 1 = no match\n" };
      const flags = new Set(
        args.filter(a => /^-[a-zA-Z]{1,4}$/.test(a)).flatMap(f => f.slice(1).split("").map(c => "-" + c)));
      const rest = args.filter(a => !/^-[a-zA-Z]{1,4}$/.test(a));
      if (!rest.length) return { err: "grep: pattern required — try grep --help" };
      const pat = rest[0];
      /* hf.12 — MULTIPLE TARGETS: grep pat f1 f2 f3 — each a file or a dir
         (dirs expand recursively over text files, deduped). The field log
         burned pipe-gymnastics per file; plain multi-target grep is what the
         muscle memory expects. */
      const restT = rest.slice(1);
      const targets = [];
      const miss0 = [];
      const seenT = new Set();
      for (const t0 of restT) {
        let tp = this._p(t0);
        /* ADE-HF.8 — cwd→root fallback: the persisted cwd doubled root-relative
           paths after a `cd` (field case: grep swore a real file did not exist). */
        if (tp && !t0.startsWith("/") && !(await VFS.exists(tp))) {
          const alt = VFS.norm("/" + t0);
          if (await VFS.exists(alt)) tp = alt;
        }
        if (!tp || !(await VFS.exists(tp))) { miss0.push(t0); continue; }
        if (await VFS.isDir(tp)) {
          for (const r of await VFS.tree(tp)) {
            if (r.kind === "file" && (r.isText || U.isTextName(r.path)) && !seenT.has(r.path)) { seenT.add(r.path); targets.push(r.path); }
          }
        } else if (!seenT.has(tp)) { seenT.add(tp); targets.push(tp); }
      }
      const ci = flags.has("-i"), inv = flags.has("-v");
      const cCount = flags.has("-c"), lList = flags.has("-l");
      const isRe = (flags.has("-E") || flags.has("-e")) && !flags.has("-F");
      const forceLit = flags.has("-F");
      const looksRe = /[\\[().*+?{}|^$]/.test(pat);
      let re;
      try { re = new RegExp(isRe ? pat : pat.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), ci ? "i" : ""); }
      catch { return { err: `grep: bad pattern: ${pat}` }; }
      const targetsAll = targets;
      const miss = miss0; // direct targets that did not resolve (cwd→root fallback already tried)
      let out = "";
      let note = "";
      if (!targetsAll.length && stdin != null) { // ADE-HF.7 — empty pipe = zero matches, never an error
        let hits = stdin.split("\n").filter(line => re.test(line) !== inv);
        if (!hits.length && !forceLit && !isRe && looksRe) {
          try {
            const re2 = new RegExp(pat.replace(/\\\|/g, "|"), ci ? "i" : "");
            const h2 = stdin.split("\n").filter(line => re2.test(line) !== inv);
            if (h2.length) { hits = h2; note = "(grep: 0 literal matches — retried pattern as regex; use -F to force literal)\n"; }
          } catch { /* keep the literal result */ }
        }
        const out = note + (cCount ? (hits.length ? String(hits.length) + "\n" : "") : hits.join("\n") + (hits.length ? "\n" : ""));
        return { out, code: hits.length ? 0 : 1 };
      }
      if (!targetsAll.length) return { err: "grep: pattern + file (or pipe input) required" };
      const scan = async () => {
        let total = 0; const counts = [];
        for (const t of targetsAll) {
          const txt = await VFS.readText(t);
          if (txt == null) { miss.push(t); continue; } // ADE-HF.7 — a missing file is an ERROR, not silence
          let n = 0;
          txt.split("\n").forEach((line, i) => { if (re.test(line) !== inv) { n++; if (!cCount && !lList) out += `${t}:${i + 1}: ${line}\n`; } });
          if (n) counts.push([t, n]);
          total += n;
        }
        return { total, counts };
      };
      let r = await scan();
      if (!r.total && !forceLit && !isRe && looksRe) {
        try {
          re = new RegExp(pat.replace(/\\\|/g, "|"), ci ? "i" : "");
          out = "";
          const r2 = await scan();
          if (r2.total) { r = r2; note = "(grep: 0 literal matches — retried pattern as regex; use -F to force literal)\n"; }
        } catch { /* keep the literal result */ }
      }
      if (cCount) out = r.counts.map(([t, n]) => `${t}:${n}`).join("\n") + (r.counts.length ? "\n" : "");
      if (lList) out = r.counts.map(([t]) => t).join("\n") + (r.counts.length ? "\n" : "");
      return { out: note + out, err: miss.length ? `grep: no such file: ${miss.join(", ")}` : "", code: r.total ? 0 : 1 };
    },
    async wc(args, raw, stdin) {
      /* hf.10 — MULTI-FILE wc. Field trace: `wc -l f1 f2 f3` printed ONLY f1's
         row (args.find takes the first) — the model read 3 file sizes as 1.
         Now: one row per file + a total row, like real wc. */
      const multi = args.filter(a => !a.startsWith("-"));
      if (multi.length > 1) {
        const rows = []; const miss = []; let L = 0, W = 0, B = 0, notes = [];
        for (const f of multi) {
          const r = await this._rt(f);
          if (r.t == null) { miss.push(r.p || f); continue; }
          if (r.note) notes.push(r.note.trim());
          const l = r.t.split("\n").length, w = r.t.split(/\s+/).filter(Boolean).length, b = new Blob([r.t]).size;
          rows.push(`${l}  ${w}  ${b}  ${f}`); L += l; W += w; B += b;
        }
        if (rows.length > 1) rows.push(`${L}  ${W}  ${B}  total`);
        return { out: (notes.length ? notes.join("\n") + "\n" : "") + (rows.length ? rows.join("\n") + "\n" : ""), err: miss.length ? `wc: no such file: ${miss.join(", ")}` : "", code: rows.length ? 0 : 1 };
      }
      const f = args.find(a => !a.startsWith("-"));
      let t = null, label = "", note = null, rp = "";
      if (f) { const r = await this._rt(f); t = r.t; note = r.note; rp = r.p; label = "  " + f; } // ADE-HF.8
      else if (stdin != null) t = stdin; // ADE-S13.6 — wc through a pipe
      if (t == null) return { err: f ? await this._noTextErr(rp || this._p(f), "wc") : "wc: text file or pipe input required" };
      const L = t.split("\n").length, W = t.split(/\s+/).filter(Boolean).length, B = new Blob([t]).size;
      return { out: (note || "") + `${L}  ${W}  ${B}${label}\n` };
    },
    async sort(args, raw, stdin) {
      // ADE-S13.6 — NEW: sort (-r reverse · -u unique) — file or pipe input
      const f = args.find(a => !a.startsWith("-"));
      let t = null, note = null, rp = "";
      if (f) { const r = await this._rt(f); t = r.t; note = r.note; rp = r.p; } // ADE-HF.8
      else if (stdin != null) t = stdin;
      if (t == null) return { err: f ? await this._noTextErr(rp || this._p(f), "sort") : "sort: text file or pipe input required" };
      let L = t.replace(/\n$/, "").split("\n").sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
      if (args.includes("-u")) L = [...new Set(L)];
      if (args.includes("-r")) L.reverse();
      return { out: (note || "") + L.join("\n") + (L.length ? "\n" : "") };
    },
    /* ══ ADE-S14.5/14.6 (ch-21.f1/f2, m-36) + ADE-S23 (ch-21.f7–f9, m-51/m-52) —
       the TEXT-TRANSFORM CORPS + TOOL AUDIT. Everything stdin-aware/pipe-first
       per the ch-18 pattern; every unsupported construct REFUSES honestly
       instead of silently producing wrong output. */
    async sed(args, raw, stdin) {
      const usage = "sed: usage: sed [-n] [-E] [-e script]... [script] [file] [file …] — supported: s/pat/repl/[g i p] · N,$,/pat/,N,M addresses · d · p · patterns are JS regex dialect (hold space h/H/g/G/x, flow b/t/T, y///, w are NOT supported) · MULTIPLE files allowed (hf.12) · -i: use the edit tool instead";
      const scripts = []; let quiet = false; const rest = [];
      for (let i = 0; i < args.length; i++) {
        const a = args[i];
        if (a === "-n") quiet = true;
        else if (a === "-e") { if (++i >= args.length) return { err: "sed: -e needs a script" }; scripts.push(args[i]); }
        else if (a === "-h" || a === "--help") return { out: usage + "\n" };
        else if (a === "-E" || a === "-r") { /* hf.12 — ACCEPTED as a no-op: patterns are the JS regex dialect, already "extended" — the field log's `sed: -E not supported` refusals never needed to happen */ }
        else if (a === "-s") { /* hf.12 — files already process as separate streams */ }
        else if (a === "-i") return { err: `sed: -i not supported — use the edit tool (literal find→replace, multi-file capable): {path, find, replace} — ${usage}` };
        else if (a.startsWith("-") && a !== "-") return { err: `sed: unknown flag ${a} — ${usage}` };
        else rest.push(a);
      }
      if (rest.length && !scripts.length) scripts.push(rest.shift()); // POSIX: a bare positional is the SCRIPT only when no -e scripts exist — otherwise it is the file
      if (!scripts.length) return { err: "sed: no script — " + usage };
      let prog;
      try { prog = scripts.flatMap(s => this._sedParse(s)); } catch (e) { return { err: "sed: " + e.message }; }
      let t = null;
      if (rest.length > 1) { // hf.12 — MULTIPLE files: processed in order, outputs concatenated (Unix sed semantics; line numbers continue across files)
        t = "";
        for (const f of rest) {
          const r = await this._rt(f);
          if (r.t == null) return { err: await this._noTextErr(r.p, "sed") };
          t += r.t + (r.t && !r.t.endsWith("\n") ? "\n" : "");
        }
      }
      else if (rest.length) { const r = await this._rt(rest[0]); t = r.t; if (t == null) return { err: await this._noTextErr(r.p, "sed") }; } // ADE-HF.8
      else if (stdin != null) t = stdin;
      if (t == null) return { err: "sed: text file or pipe input required" };
      const L = t.replace(/\n$/, "").split("\n");
      const out = [];
      for (const c of prog) c._on = false;
      for (let li = 0; li < L.length; li++) {
        let line = L[li], del = false, pflag = false;
        for (const c of prog) {
          let hit;
          if (c.a2) {
            if (!c._on) { if (this._sedAddr(c.a1, li, L.length, line)) { c._on = true; hit = true; } else hit = false; }
            else { hit = true; if (this._sedAddr(c.a2, li, L.length, line)) c._on = false; }
          } else hit = this._sedAddr(c.a1, li, L.length, line);
          if (!hit) continue;
          if (c.op === "d") { del = true; break; }
          if (c.op === "p") { pflag = true; continue; }
          if (c.op === "s") {
            const res = this._sedSub(line, c);
            line = res[0]; if (res[1]) pflag = true;
          }
        }
        if (del) continue;
        if (!quiet || pflag) out.push(line);
      }
      return { out: out.join("\n") + "\n" };
    },
    async cut(args, raw, stdin) {
      let d = "\t", fl = null, cl = null; const rest = [];
      for (let i = 0; i < args.length; i++) {
        const a = args[i];
        if (a === "-d") d = args[++i] ?? "\t";
        else if (a.startsWith("-d") && a.length > 2) d = a.slice(2);
        else if (a === "-f") fl = args[++i];
        else if (a.startsWith("-f") && a.length > 2) fl = a.slice(2);
        else if (a === "-c") cl = args[++i]; // hf.10 — char slices of huge lines (field trace: cut -c1-120 died on "unknown flag")
        else if (a.startsWith("-c") && a.length > 2) cl = a.slice(2);
        else if (a === "--complement" || a === "-s") return { err: `cut: ${a} not supported (lean subset)` };
        else if (a.startsWith("-") && a !== "-") return { err: `cut: unknown flag ${a} — usage: cut -d DELIM -f LIST | cut -c LIST [file]` };
        else rest.push(a);
      }
      if (fl && cl) return { err: "cut: -f and -c are mutually exclusive — pick one (hf.10: -c slices CHARACTERS, e.g. cut -c1-120)" };
      if (cl) { // hf.10 character mode — reuses the same LIST grammar as -f
        const crs = this._flRanges(String(cl));
        if (!crs) return { err: "cut: bad -c list — comma-separated char positions/ranges like 1,3-5 or 1-120" };
        let ct;
        if (rest.length) ct = await VFS.readText(this._p(rest[0]));
        else if (stdin != null) ct = stdin;
        if (ct == null) return { err: "cut: text file or pipe input required" };
        const cout = ct.replace(/\n$/, "").split("\n").map(L => {
          const pick = [];
          for (const r of crs) { const end = Math.min(r.b ?? L.length, L.length); for (let n = r.a; n <= end; n++) pick.push(L.charAt(n - 1)); }
          return pick.join("");
        }).join("\n");
        return { out: cout + "\n" };
      }
      if (!fl) return { err: "cut: -f LIST (fields) or -c LIST (chars) required — usage: cut -d DELIM -f 1,3-5 [file] · cut -c 1-120 [file]" };
      const rs = this._flRanges(fl);
      if (!rs) return { err: "cut: bad -f list — comma-separated fields/ranges like 1,3-5" };
      let t;
      if (rest.length) t = await VFS.readText(this._p(rest[0]));
      else if (stdin != null) t = stdin;
      if (t == null) return { err: "cut: text file or pipe input required" };
      const out = t.replace(/\n$/, "").split("\n").map(L => {
        if (L === "") return "";
        const parts = L.split(d);
        if (parts.length === 1) return L; // hf.10 — POSIX: a line with NO delimiter passes through intact (was: fields ≥2 silently became "")
        const pick = [];
        for (const r of rs) { const end = r.b ?? parts.length; for (let n = r.a; n <= end; n++) pick.push(n); }
        return [...new Set(pick)].sort((x, y) => x - y).map(n => parts[n - 1] ?? "").join(d);
      }).join("\n");
      return { out: out + "\n" };
    },
    async tr(args, raw, stdin) {
      let del = false, squeeze = false; const sets = [];
      for (const a of args) {
        if (a === "-d") del = true;
        else if (a === "-s") squeeze = true;
        else if (a === "-c" || a === "-C") return { err: "tr: -c not supported (lean subset)" };
        else if (a.startsWith("-")) return { err: `tr: unknown flag ${a} — usage: tr [-d] [-s] SET1 [SET2] (reads stdin: cat f | tr a-z A-Z)` };
        else sets.push(a);
      }
      if (!sets.length) return { err: "tr: SET1 required — usage: tr [-d] [-s] SET1 [SET2] (stdin only: cat f | tr …)" };
      if (sets.length > 2) return { err: "tr: reads stdin only — use: cat <file> | tr SET1 SET2" };
      if (stdin == null) return { err: "tr: pipe input required — use: cat <file> | tr SET1 SET2" };
      const S1 = this._trSet(sets[0]);
      if (!S1) return { err: "tr: bad range in SET1 (start-end must ascend)" };
      const S2 = sets[1] ? this._trSet(sets[1]) : null;
      if (sets[1] && !S2) return { err: "tr: bad range in SET2" };
      if (!del && S2 && S2.length < S1.length) return { err: `tr: SET2 (${S2.length}) shorter than SET1 (${S1.length}) — expand the range` };
      let out = "";
      for (const ch of stdin) {
        if (del) {
          if (S1.includes(ch)) continue;
          out += ch;
        } else {
          const k = S1.indexOf(ch);
          out += k >= 0 && S2 ? S2[k] : ch;
        }
      }
      if (squeeze) {
        const sq = S2 || S1; // ADE-S23: GNU semantics — `tr -s SET1` (no SET2) squeezes SET1; with SET2 it squeezes the translation target
        let b = "";
        for (const ch of out) {
          if (sq && sq.includes(ch) && b.endsWith(ch)) continue;
          b += ch;
        }
        out = b;
      }
      return { out };
    },
    async uniq(args, raw, stdin) {
      let mode = null; const rest = [];
      for (const a of args) {
        if (a === "-c" || a === "-d" || a === "-u") mode = a;
        else if (a.startsWith("-")) return { err: `uniq: unknown flag ${a} — usage: uniq [-c|-d|-u] [file] (adjacent dedupe)` };
        else rest.push(a);
      }
      let t;
      if (rest.length) t = await VFS.readText(this._p(rest[0]));
      else if (stdin != null) t = stdin;
      if (t == null) return { err: "uniq: text file or pipe input required" };
      const groups = [];
      for (const l of t.replace(/\n$/, "").split("\n")) {
        const g = groups[groups.length - 1];
        if (g && g.line === l) g.n++;
        else groups.push({ line: l, n: 1 });
      }
      let rows = groups;
      if (mode === "-d") rows = groups.filter(g => g.n > 1);
      if (mode === "-u") rows = groups.filter(g => g.n === 1);
      const text = rows.map(g => mode === "-c" ? String(g.n).padStart(7) + " " + g.line : g.line).join("\n");
      return { out: (text ? text + "\n" : "") };
    },
    async tee(args, raw, stdin) {
      const append = args.includes("-a");
      const f = args.find(a => !a.startsWith("-"));
      if (stdin == null) return { err: "tee: pipe input required — usage: … | tee [-a] file" };
      if (!f) return { err: "tee: file required — usage: … | tee [-a] file" };
      const p = this._p(f);
      if (!append && await VFS.exists(p)) { const r = await VFS.get(p); if (r && r.kind === "dir") return { err: `tee: is a directory: ${f}` }; }
      const prev = append ? ((await VFS.readText(p)) ?? "") : "";
      await VFS.put(p, prev + stdin, true);
      return { out: stdin };
    },
    async nl(args, raw, stdin) {
      const f = args.find(a => !a.startsWith("-"));
      if (args.length && !f) return { err: `nl: unknown flag ${args[0]} — usage: nl [file]` };
      let t;
      if (f) t = await VFS.readText(this._p(f));
      else if (stdin != null) t = stdin;
      if (t == null) return { err: "nl: text file or pipe input required" };
      return { out: t.replace(/\n$/, "").split("\n").map((l, i) => String(i + 1).padStart(6) + "\t" + l).join("\n") + "\n" };
    },
    async rev(args, raw, stdin) {
      const f = args.find(a => !a.startsWith("-"));
      if (args.length && !f) return { err: `rev: unknown flag ${args[0]} — usage: rev [file]` };
      let t;
      if (f) t = await VFS.readText(this._p(f));
      else if (stdin != null) t = stdin;
      if (t == null) return { err: "rev: text file or pipe input required" };
      return { out: t.replace(/\n$/, "").split("\n").map(l => [...l].reverse().join("")).join("\n") + "\n" };
    },
    async basename(args) {
      if (!args.length) return { err: "basename: path required" };
      const p = String(args[0]).replace(/\/+$/, "");
      const b = p.split("/").pop() || "/";
      let out = b;
      if (args[1] && b.endsWith(args[1]) && b !== args[1]) out = b.slice(0, b.length - args[1].length);
      return { out: out + "\n" };
    },
    async dirname(args) {
      if (!args.length) return { err: "dirname: path required" };
      const p = String(args[0]).replace(/\/+$/, "");
      const i = p.lastIndexOf("/");
      if (i < 0) return { out: ".\n" };
      if (i === 0) return { out: "/\n" };
      return { out: p.slice(0, i) + "\n" };
    },
    async diff(args, raw, stdin) {
      // ADE-S14.6 (ch-21.f2) — unified LCS line diff; exit 1 = files differ (POSIX)
      const fl = args.filter(a => !a.startsWith("-"));
      if (args.some(a => a !== "-u" && a.startsWith("-"))) return { err: "diff: unsupported flag — usage: diff [-u] FILE1 FILE2" };
      if (fl.length !== 2) return { err: "diff: FILE1 FILE2 required" };
      const a = await VFS.readText(this._p(fl[0]));
      const b = await VFS.readText(this._p(fl[1]));
      if (a == null) return { err: `diff: not a text file: ${fl[0]}` };
      if (b == null) return { err: `diff: not a text file: ${fl[1]}` };
      if (a === b) return { out: "", code: 0 };
      const A = a.replace(/\n$/, "").split("\n"), B = b.replace(/\n$/, "").split("\n");
      if (A.length * B.length > 4000000) return { err: "diff: files too large for in-browser LCS — split them first" };
      const n = A.length, m = B.length;
      const dp = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
      for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--)
        dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
      const ops = [];
      let i = 0, j = 0;
      while (i < n && j < m) {
        if (A[i] === B[j]) { ops.push({ t: " ", l: A[i] }); i++; j++; }
        else if (dp[i + 1][j] >= dp[i][j + 1]) ops.push({ t: "-", l: A[i++] });
        else ops.push({ t: "+", l: B[j++] });
      }
      while (i < n) ops.push({ t: "-", l: A[i++] });
      while (j < m) ops.push({ t: "+", l: B[j++] });
      const CTX = 3, hunks = [];
      let k = 0;
      while (k < ops.length) {
        if (ops[k].t === " ") { k++; continue; }
        let s = Math.max(0, k - CTX), e = k, run = 0;
        for (let x = k; x < ops.length; x++) {
          if (ops[x].t === " ") { run++; if (run > CTX) break; }
          else { run = 0; e = x; }
        }
        const eEnd = Math.min(ops.length - 1, e + CTX);
        if (hunks.length && s <= hunks[hunks.length - 1][1] + 1) hunks[hunks.length - 1][1] = eEnd;
        else hunks.push([s, eEnd]);
        k = e + 1;
      }
      let out = `--- ${fl[0]}\n+++ ${fl[1]}\n`;
      for (const [s, e] of hunks) {
        const seg = ops.slice(s, e + 1);
        let aS = 1, bS = 1;
        for (let x = 0; x < s; x++) { if (ops[x].t !== "+") aS++; if (ops[x].t !== "-") bS++; }
        const aC = seg.filter(o => o.t !== "+").length, bC = seg.filter(o => o.t !== "-").length;
        out += `@@ -${aS}${aC !== 1 ? "," + aC : ""} +${bS}${bC !== 1 ? "," + bC : ""} @@\n`;
        for (const o of seg) out += o.t + o.l + "\n";
      }
      return { out, code: 1 };
    },
    async patch(args, raw, stdin) {
      // ADE-S14.6 (ch-21.f2) — unified patch, atomic: context verified in memory BEFORE any write
      const dry = args.includes("--dry-run");
      const fl = args.filter(a => !a.startsWith("-"));
      if (!fl.length) return { err: "patch: FILE required — usage: patch FILE [PATCHFILE] (--dry-run to preview)" };
      const target = this._p(fl[0]);
      const cur = await VFS.readText(target);
      if (cur == null) return { err: `patch: not a text file: ${fl[0]}` };
      let patchText = null;
      if (fl[1]) patchText = await VFS.readText(this._p(fl[1]));
      else if (stdin != null) patchText = stdin;
      if (patchText == null) return { err: "patch: a patch file or pipe input is required" };
      const hunks = []; let h = null;
      const rawLines = patchText.split("\n");
      if (rawLines.length > 1 && rawLines[rawLines.length - 1] === "") rawLines.pop(); // trailing-newline artifact, not a context line
      for (const L of rawLines) {
        const mm = L.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
        if (mm) { h = { aStart: +mm[1], body: [] }; hunks.push(h); continue; }
        if (/^(---|\+\+\+|diff |index |\\ No newline)/.test(L)) continue;
        if (h) h.body.push(L === "" ? " " : L);
      }
      if (!hunks.length) return { err: "patch: no @@ hunks found — unified diff expected (diff f1 f2 | patch f2)" };
      const src = cur.replace(/\n$/, "").split("\n");
      let offset = 0, applied = 0;
      for (const hk of hunks) {
        const idx = hk.aStart - 1 + offset;
        let oi = idx;
        for (const l of hk.body) {
          if (l.startsWith("-") || l.startsWith(" ")) {
            if (l.startsWith(" ") && src[oi] !== l.slice(1))
              return { err: `patch: context mismatch at file line ${oi + 1} — expected ${JSON.stringify(l.slice(1))} — refusing (atomic, nothing applied)` };
            oi++;
          }
        }
        const removed = oi - idx;
        const repl = hk.body.filter(l => !l.startsWith("-")).map(l => l.slice(1));
        src.splice(idx, removed, ...repl);
        offset += repl.length - removed;
        applied++;
      }
      const outTxt = src.join("\n") + "\n";
      if (dry) return { out: `patch: dry-run OK — ${applied} hunk(s) would apply cleanly to ${fl[0]} (${cur.length} → ${outTxt.length} chars)\n` };
      await VFS.put(target, outTxt, true);
      return { out: `patch: ${applied} hunk(s) applied to ${fl[0]} (${cur.length} → ${outTxt.length} chars)\n` };
    },
    async tools() {
      // ADE-S14.7 (ch-21.f3, m-37) — the live inventory in ONE cheap call (~300 tokens)
      const T = (window.Agent && Agent.TOOLS) ? Agent.TOOLS : [];
      const shell = Object.keys(this._cmds).filter(k => k !== "help").sort();
      const L = [`ADE ${ADE_BUILD.version} · ${ADE_BUILD.stamp}`];
      L.push(`agent tools (${T.length}):` + T.map(t => {
        const a = t.parameters && t.parameters.properties ? Object.keys(t.parameters.properties).join(", ") : "";
        return `\n  ${t.name}(${a})`;
      }).join(""));
      L.push(`shell commands (${shell.length}):\n  ` + shell.join(" · "));
      L.push("budgets: OUT_CAP caps every tool result · maxSteps/contextK + py/js timeouts = live values in Settings → Agent · audit prompts: routing §08");
      L.push(`gaps this session: ${this.gaps.length} — shell: gaps prints the ranked list`);
      return { out: L.join("\n") + "\n" };
    },
    async gaps() {
      if (!this.gaps.length) return { out: "gaps: none logged this session — every command and tool call resolved\n" };
      const rank = [...this.gaps].sort((a, b) => b.n - a.n);
      return { out: "gaps (session ring, 50) — ranked by misses:\n" + rank.map(x => `  ${String(x.n).padStart(3)}×  ${x.cmd}  [${x.source} · ${new Date(x.ts).toLocaleTimeString()}]`).join("\n") + "\n" };
    },
    async stat(args) {
      const r = await VFS.get(this._p(args[0]));
      if (!r) return { err: `stat: not found: ${args[0]}` };
      return { out: `path:  ${r.path}\nkind:  ${r.kind}\nsize:  ${r.size || 0} bytes\nmtime: ${new Date(r.mtime).toISOString()}\n` };
    },
    async du(args) {
      // ADE-S13.5 (ch-18.f4, m-33 field report): flags like -s / -h / -sh are
      // accepted (human format is the default) — the old code treated "-sh"
      // as a PATH and printed a bogus 0 B line.
      const pArg = args.find(a => !a.startsWith("-"));
      const p = this._p(pArg || "");
      const rows = await VFS.tree(p === "/" ? "/" : p);
      const bytes = rows.filter(r => r.kind === "file").reduce((a, r) => a + (r.size || 0), 0);
      return { out: `${U.fmtBytes(bytes)}  ${p}\n` };
    },
    async tree(args) {
      const p = this._p(args[0] || "");
      const rows = await VFS.tree(p === "/" ? "/" : p);
      if (!rows.length) return { out: "(empty)\n" };
      return { out: rows.map(r => "  ".repeat(r.depth || 0) + VFS.base(r.path) + (r.kind === "dir" ? "/" : "")).join("\n") + "\n" };
    },
    async digest(args) {
      // ADE-S14.1 (ch-20.f1, m-35) + ADE-S23.2 (ch-21.f6, m-49): -h/--help,
      // honest error guard — never a raw throw in the agent turn.
      if (args.includes("-h") || args.includes("--help"))
        return { out: "digest: usage: digest [dir|file] — one line per file (path · size · lines · first-line preview); survey a subtree in ONE call instead of reading it file-by-file; 400-row cap (digest a deeper subfolder for more)\n" };
      const p = this._p(args.find(a => !a.startsWith("-")) || "");
      try {
        if (!(await VFS.exists(p))) return { err: `digest: no such path: ${p}` };
        return { out: (await VFS.digestTable(p)) + "\n" };
      } catch (e) { return { err: `digest failed: ${String((e && e.message) || e)} — try a narrower path` }; }
    },
    async open(args) {
      if (!args.length) return { err: "open: file required" };
      const p = this._p(args[0]);
      const ext = VFS.ext(p);
      if (ext === "html" || ext === "htm") { await Exec.preview(p); return {}; }
      if (ext === "py" || ext === "js" || ext === "mjs") { await Exec.run(p); return {}; }
      const row = await VFS.get(p);
      if (row && (row.isText || U.isTextName(p))) { WSUI.openEditor(p); return {}; }
      return { err: "open: binary file — use download" };
    },
    async download(args) {
      if (!args.length) return { err: "download: file required" };
      await WSUI.download(this._p(args[0]));
      return {};
    },
    async python(args, raw) { return this._pyRoute(args, raw); },
    async py(args, raw) { return this._pyRoute(args, raw); },
    async pip(args) {
      if (args[0] !== "install" || !args[1]) return { err: "pip: install <pkg> (micropip-backed, m-23 confirm)" };
      await Exec.pipInstall(args[1]);
      return {};
    },
    async js(args, raw) { return this._jsRoute(args, raw); },
    async node(args, raw) { return this._jsRoute(args, raw); },
    async seed() { // ADE-06.2 — full auto-seed (flat files + demo set) lives in Main.seedWorkspace
      const r = await Main.seedWorkspace();
      const how = r.fetched ? `${r.fetched} fetched from the site${r.stubbed ? ` · ${r.stubbed} stubbed (file://)` : ""}` : `${r.stubbed} stubbed (file:// — host the zip and re-run)`;
      return { out: r.made ? `seeded ${r.made} file${r.made === 1 ? "" : "s"} (${how} + demo set)\n` : "workspace files already present — nothing to seed\n" };
    },
    date() { return { out: new Date().toString() + "\n" }; },
    whoami() { return { out: "ade (workspace user) — keys stay local, execution sandboxed (WASM/worker/iframe)\n" }; }
  }
};

/* ══════════════════════════════════════════════════════════════
   ADE-04.4 · ConsoleUI — collapsible run console under the tree:
   cmd / out / err / sys line classes · ↑/↓ history · clear ·
   the input row is the human entry; the agent calls Shell.run(silent).
   ══════════════════════════════════════════════════════════════ */
Exec.ConsoleUI = {
  el: null, linesEl: null, inputEl: null, _bound: false,

  ensure() {
    Exec._injectStyles();
    Exec._wirePreviewBridge();
    if (this.el) return this.el;
    const host = document.getElementById("ws-body");
    if (!host) return null;
    const panel = document.createElement("div");
    panel.className = "ws-console";
    panel.id = "ws-console";
    panel.innerHTML = `
      <div class="wc-head">
        <span class="wc-title"><i class="fa-solid fa-terminal"></i> RUN CONSOLE — virtual shell over the workspace</span>
        <button class="wc-clear" id="wc-clear" title="Clear console">clear</button>
      </div>
      <div class="wc-lines" id="wc-lines"></div>
      <div class="wc-input-row">
        <span class="wc-prompt" id="wc-prompt">ws /</span>
        <input class="wc-input" id="wc-input" placeholder="type help — commands run against the VFS" spellcheck="false" />
      </div>`;
    host.insertBefore(panel, document.getElementById("ws-status"));
    this.el = panel;
    this.linesEl = panel.querySelector("#wc-lines");
    this.inputEl = panel.querySelector("#wc-input");
    if (!this._bound) { this._bind(); this._bound = true; }
    return panel;
  },

  _bind() {
    Exec.Shell.init();
    this.inputEl.addEventListener("keydown", async (e) => {
      const S = Exec.Shell;
      if (e.key === "Enter") {
        const raw = this.inputEl.value.trim();
        this.inputEl.value = "";
        if (!raw) return;
        S.history.push(raw); S._hIdx = S.history.length;
        await S.run(raw);
        this.inputEl.focus();
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        const S2 = Exec.Shell;
        if (S2._hIdx > 0) { S2._hIdx--; this.inputEl.value = S2.history[S2._hIdx] || ""; }
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        const S2 = Exec.Shell;
        if (S2._hIdx < S2.history.length - 1) { S2._hIdx++; this.inputEl.value = S2.history[S2._hIdx] || ""; }
        else { S2._hIdx = S2.history.length; this.inputEl.value = ""; }
      }
    });
    document.getElementById("wc-clear").addEventListener("click", () => this.clearLines());
  },

  toggle(force) {
    const panel = this.ensure();
    if (!panel) return;
    const open = force !== undefined ? force : !panel.classList.contains("open");
    panel.classList.toggle("open", open);
    if (open) { this.inputEl && this.inputEl.focus(); this._scroll(); }
  },

  show() { // open for streaming output (runs/previews call this)
    const panel = this.ensure();
    if (panel && !panel.classList.contains("open")) this.toggle(true);
  },

  line(kind, text) {
    this.ensure();
    if (!this.linesEl || text == null || text === "") return;
    for (const l of String(text).split("\n")) {
      if (l === "" && kind !== "out") continue;
      const d = document.createElement("div");
      d.className = "wc-line " + (kind || "out");
      d.textContent = l;
      this.linesEl.appendChild(d);
    }
    while (this.linesEl.children.length > 800) this.linesEl.firstChild.remove(); // ring buffer
    this._scroll();
  },

  clearLines() { if (this.linesEl) this.linesEl.innerHTML = ""; },

  _scroll() { if (this.linesEl) this.linesEl.scrollTop = this.linesEl.scrollHeight; }
};
if (typeof window !== "undefined") window.Exec = Exec; // ADE-S23.3: window.Exec guard support

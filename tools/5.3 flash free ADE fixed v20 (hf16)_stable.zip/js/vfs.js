/* ============================================================
   js/vfs.js — ADE-02.1 · VFS CORE (full, replaces the CH-01 stub)
   Path-keyed rows in the IndexedDB "vfs" store:
     { path, kind:'dir'|'file', parent, isText, content, size, mtime }
   content = string (text rows) | ArrayBuffer (binary rows).
   Helpers are ..-safe and always rooted at /  (no path can
   escape the workspace — routing §07 build.sandbox.rule).
   CH-02.4 adds zip import/export via fflate, VENDORED at
   js/vendor/fflate.min.js (build-time acquired — no runtime
   CDN, m-23).  CH-03 ADDS THE REAL FSA LINKED-FOLDER MODULE
   (ADE-03.1…03.5 below): session-persistent handle + write-
   through on the VFS.onWrite bus + pull/push sync.  CH-06.f2
   seeds the workspace.
   ============================================================ */
"use strict";

const VFS = {
  ready: true, // full core live since CH-02 (was the CH-01 stub flag)

  /* upload / import guards (f5 + zip safety) */
  MAX_FILE: 24 * 1024 * 1024,      // per-file cap for direct uploads
  MAX_ZIP_FILE: 32 * 1024 * 1024,  // per-entry cap inside an imported zip
  MAX_ZIP_TOTAL: 64 * 1024 * 1024, // total decompressed cap per import

  /* ── path helpers (..-safe, always rooted at /) ─────────── */
  norm(p) {
    const parts = String(p || "/").replace(/\\/g, "/").split("/");
    const out = [];
    for (const seg of parts) {
      if (!seg || seg === ".") continue;
      if (seg === "..") { out.pop(); continue; }
      out.push(seg);
    }
    return "/" + out.join("/");
  },
  join(a, b) { return VFS.norm(a + "/" + b); },
  parent(p) {
    const n = VFS.norm(p);
    if (n === "/") return "/";
    return n.slice(0, n.lastIndexOf("/")) || "/";
  },
  base(p) {
    const n = VFS.norm(p);
    return n === "/" ? "" : n.slice(n.lastIndexOf("/") + 1);
  },
  ext(p) {
    const b = VFS.base(p);
    const i = b.lastIndexOf(".");
    return i > 0 ? b.slice(i + 1).toLowerCase() : "";
  },
  isTextName(name, mime) { return U.isTextName(name, mime); },

  /* row factory — the exact row shape since CH-01 (additive-only) */
  _row(path, kind, content, isText) {
    path = VFS.norm(path);
    return {
      path,
      kind,                                  // 'dir' | 'file'
      parent: kind === "dir" && path === "/" ? "" : VFS.parent(path),
      isText: kind === "file" ? !!isText : false,
      content: kind === "file" ? (content ?? "") : "",
      size: kind === "file" ? (content ? (content.byteLength ?? content.length ?? 0) : 0) : 0,
      mtime: Date.now()
    };
  },

  /* change listeners — CH-03 write-through + CH-10 live reload hook here.
     ADE-03.3: listeners receive (type, path, info) — info is optional
     event detail (rm.recursive · mv.from); additive, old listeners fine */
  _listeners: [],
  onWrite(fn) { if (typeof fn === "function") VFS._listeners.push(fn); },
  _emit(type, path, info) { for (const fn of VFS._listeners) { try { fn(type, path, info); } catch { /* hook errors never break the VFS */ } } },

  /* ── existence / type checks ──────────────────────────────
     ADE-S13.2 (ch-18.f1, m-33 field report): the ROOT is synthetic.
     No row for "/" is ever stored (mkdirp skips it), so a plain DB.get
     made exists("/")·isDir("/") false — `ls /` → "no such path: /",
     `cd /` → "no such directory", agent fs_list "/" → "not a folder: /".
     get() now synthesizes the root dir row; every caller (shell ls/cd,
     fs_list, tree, pull, grep, find) heals in one place. */
  _ROOT_ROW: { path: "/", kind: "dir", parent: "", isText: false, content: "", size: 0, mtime: 0 },
  async get(path) {
    const p = VFS.norm(path);
    if (p === "/") return Object.assign({}, VFS._ROOT_ROW); // synthetic root — never stored, never mirrored
    return DB.get(DB.STORES.VFS, p);
  },
  async exists(path) { return !!(await VFS.get(path)); },
  async isDir(path) { const r = await VFS.get(path); return !!r && r.kind === "dir"; },

  /* ── mkdir — single dir row (idempotent) ─────────────────── */
  async mkdir(path) {
    path = VFS.norm(path);
    if (!path || path === "/") return null;
    const ex = await DB.get(DB.STORES.VFS, path);
    if (ex) return ex;
    const row = VFS._row(path, "dir", "");
    await DB.set(DB.STORES.VFS, row);
    VFS._emit("mkdir", path);
    return row;
  },

  /* mkdirp — create every missing dir row along the path.
     ADE-03.3: each row actually CREATED emits "mkdir" so the
     linked work folder mirrors new folders too (idempotent). */
  async mkdirp(path) {
    path = VFS.norm(path);
    if (path === "/" || !path) return;
    const segs = path.split("/").filter(Boolean);
    let cur = "";
    for (const seg of segs) {
      cur += "/" + seg;
      const existing = await DB.get(DB.STORES.VFS, cur);
      if (!existing || existing.kind !== "dir") {
        await DB.set(DB.STORES.VFS, VFS._row(cur, "dir", ""));
        VFS._emit("mkdir", cur);
      }
    }
  },

  /* ── put — write a file row; dirs auto-created ─────────────
     content: string (text) or ArrayBuffer (binary). isText is
     inferred from the extension whitelist when omitted.        */
  async put(path, content, isText) {
    path = VFS.norm(path);
    if (path === "/") throw new Error("cannot write to /");
    await VFS.mkdirp(VFS.parent(path));
    const t = isText === undefined ? VFS.isTextName(path) : !!isText;
    const row = VFS._row(path, "file", content, t);
    await DB.set(DB.STORES.VFS, row);
    VFS._emit("write", path);
    return path;
  },

  /* readText — string content for text rows (null for binary/missing) */
  async readText(path) {
    const row = await VFS.get(path);
    if (!row || row.kind !== "file") return null;
    if (typeof row.content === "string") return row.content;
    try { return new TextDecoder().decode(new Uint8Array(row.content)); }
    catch { return null; }
  },

  /* ── list — children of one dir, dirs-first sort ─────────── */
  async list(path) {
    path = VFS.norm(path);
    const rows = await DB.byIndex(DB.STORES.VFS, "parent", path === "/" ? "/" : path);
    rows.sort(VFS._dirFirst);
    return rows;
  },
  _dirFirst(a, b) {
    const an = VFS.base(a.path).toLowerCase(), bn = VFS.base(b.path).toLowerCase();
    if (a.kind !== b.kind) return a.kind === "dir" ? -1 : 1;
    return an.localeCompare(bn, undefined, { numeric: true });
  },

  /* tree — flat recursive snapshot in tree order (dir before its
     children); rows carry .depth for indent rendering           */
  async tree(root = "/") {
    root = VFS.norm(root);
    const all = await DB.all(DB.STORES.VFS);
    const kids = new Map();
    for (const r of all) {
      if (!kids.has(r.parent)) kids.set(r.parent, []);
      kids.get(r.parent).push(r);
    }
    for (const arr of kids.values()) arr.sort(VFS._dirFirst);
    const out = [];
    (function walk(dir, depth) {
      for (const r of (kids.get(dir) || [])) {
        r.depth = depth;
        out.push(r);
        if (r.kind === "dir") walk(r.path, depth + 1);
      }
    })(root, 0);
    return out;
  },

  /* ══ ADE-S14.1 (ch-20.f1, m-35 field report) · FOLDER DIGEST ══
     The m-35 burn: one "please iterate" over the zip = 130k+ prompt
     tokens + 118MB proxy quota, because the only way to survey a
     folder was reading it file-by-file. digest() renders a whole
     subtree as ONE compact table (path · size · lines · first-line
     preview) straight off the VFS rows — the row already carries
     content + size, so a 200-file survey costs ~1k tokens, not 130k.
     digest() → data · digestTable() → the capped text both the
     `digest` shell command and the fs_digest agent tool print.     */
  async digest(root = "/", previewCap = 48) {
    root = VFS.norm(root || "/");
    const self = await VFS.get(root);
    if (self && self.kind === "file") { // a file arg digests as a one-row table
      let lineCount = 0, preview = "<binary>";
      if (self.isText) { // ADE-S23.2 (ch-21.f6, m-49): decode ArrayBuffer-stored text too (unzip-written UTF-8)
        const txt = typeof self.content === "string" ? self.content : await VFS.readText(root);
        if (txt != null) {
          const nl = txt.split("\n");
          lineCount = nl.length;
          const first = (nl.find(l => l.trim()) || "").trim();
          preview = first ? (first.length > previewCap ? first.slice(0, previewCap) + "…" : first) : "(empty)";
        }
      }
      return { root, rows: [{ path: root, kind: "file", size: self.size || 0, lines: lineCount, preview }], files: 1, dirs: 0, bytes: self.size || 0, lines: lineCount };
    }
    const rows = await VFS.tree(root);
    if (!rows.length) { // ADE-S23.2 (ch-21.f6): an EMPTY dir renders its own row instead of a bare header
      return { root, rows: [{ path: root, kind: "dir", size: 0, lines: 0, preview: "empty" }], files: 0, dirs: 1, bytes: 0, lines: 0 };
    }
    const out = [];
    let files = 0, dirs = 0, bytes = 0, lines = 0;
    for (const r of rows) {
      if (r.kind === "dir") {
        dirs++;
        const kids = rows.filter(x => x.parent === r.path).length;
        out.push({ path: r.path, kind: "dir", size: 0, lines: 0, preview: `${kids} item${kids === 1 ? "" : "s"}` });
        continue;
      }
      files++;
      bytes += r.size || 0;
      let lineCount = 0, preview = "<binary>";
      if (r.isText) { // ADE-S23.2 (ch-21.f6): decode ArrayBuffer-stored text too — lines only count when decoded
        const txt = typeof r.content === "string" ? r.content : await VFS.readText(r.path);
        if (txt != null) {
          const nl = txt.split("\n");
          lineCount = nl.length;
          lines += lineCount;
          const first = (nl.find(l => l.trim()) || "").trim(); // first non-blank line
          preview = first ? (first.length > previewCap ? first.slice(0, previewCap) + "…" : first) : "(empty)";
        }
      }
      out.push({ path: r.path, kind: "file", size: r.size || 0, lines: lineCount, preview });
    }
    return { root, rows: out, files, dirs, bytes, lines };
  },
  async digestTable(root = "/", maxRows = 400, largeBytes = 30720) {
    /* hf.14 — largeBytes flags LARGE-FILE-class rows (default mirrors
       Agent.LARGE_FILE, 30 KB; agent.js passes it explicitly). A survey
       now tells the model WHICH files must be sliced/split — no
       trial-and-error read refusals. 0 disables the flagging. */
    const d = await VFS.digest(root);
    const L = [
      `DIGEST ${d.root} · ${d.files} file${d.files === 1 ? "" : "s"} · ${d.dirs} dir${d.dirs === 1 ? "" : "s"} · ${U.fmtBytes(d.bytes)} · ${d.lines} lines — one line per file; fs_read ONLY what the task names`,
      "  path · size · lines · first-line preview"
    ];
    let flagged = 0;
    const rows = d.rows.slice(0, maxRows);
    for (const r of rows) {
      if (r.kind === "dir") { L.push(`  d ${r.path}/  (${r.preview})`); continue; }
      const big = largeBytes > 0 && (r.size || 0) >= largeBytes;
      if (big) flagged++;
      L.push(`  - ${r.path}  ${U.fmtBytes(r.size)}  ${r.lines}L  ${r.preview}${big ? "  ⚑L" : ""}`);
    }
    if (flagged) L.push(`  ⚑L = ≥${Math.round(largeBytes / 1024)} KB (LARGE-FILE class): read in slices (offset/limit or head/tail — a whole read returns the head slice + the slice plan), or split → scan → edit → assemble; grep/find ship matches at ANY size`);
    if (d.rows.length > maxRows) L.push(`  … ${d.rows.length - maxRows} more rows — digest a deeper subfolder (e.g. digest ${d.root !== "/" ? d.root : ""}/<dir>)`);
    return L.join("\n");
  },

  /* ── rm — delete a file, or a dir recursively ────────────── */
  async rm(path) {
    path = VFS.norm(path);
    if (path === "/") throw new Error("refusing to delete the root");
    const row = await VFS.get(path);
    if (!row) return false;
    const doomed = [];
    if (row.kind === "dir") {
      const all = await DB.all(DB.STORES.VFS);
      const prefix = path + "/";
      for (const r of all) if (r.path === path || r.path.startsWith(prefix)) doomed.push(r.path);
    } else {
      doomed.push(path);
    }
    for (const p of doomed) await DB.del(DB.STORES.VFS, p);
    VFS._emit("rm", path, { recursive: row.kind === "dir" });
    return true;
  },

  /* ── mv — rename, or move into an existing dir ─────────────
     moving a dir re-paths its whole subtree; mtimes preserved. */
  async mv(from, to) {
    from = VFS.norm(from); to = VFS.norm(to);
    if (from === "/" || !from) throw new Error("cannot move the root");
    if (from === to) return to;
    const src = await VFS.get(from);
    if (!src) throw new Error("not found: " + from);

    // file-manager semantics: if the target is an existing dir, move INSIDE it
    const target = await VFS.get(to);
    let dest;
    if (target && target.kind === "dir" && src.kind === "file") {
      dest = VFS.join(to, VFS.base(from));
    } else if (target && target.kind === "dir" && src.kind === "dir") {
      dest = VFS.join(to, VFS.base(from));
    } else {
      dest = to;
    }
    if (src.kind === "dir" && (dest === from || dest.startsWith(from + "/"))) {
      throw new Error("cannot move a folder into itself");
    }
    const existing = await VFS.get(dest);
    if (existing && existing.kind === "file" && src.kind === "dir") {
      throw new Error("target exists as a file: " + dest);
    }

    const all = await DB.all(DB.STORES.VFS);
    const moving = src.kind === "dir"
      ? all.filter(r => r.path === from || r.path.startsWith(from + "/"))
      : [src];
    // write new rows first, then remove sources (no data-loss window)
    for (const r of moving) {
      const np = dest + r.path.slice(from.length); // prefix re-path
      const nr = Object.assign({}, r, { path: VFS.norm(np), parent: VFS.parent(np) });
      if (nr.kind === "dir" && nr.path === "/") continue;
      await DB.set(DB.STORES.VFS, nr);
    }
    for (const r of moving) await DB.del(DB.STORES.VFS, r.path);
    VFS._emit("mv", dest, { from });
    return dest;
  },

  /* ── count / du — usage numbers for the status line ──────── */
  async count() {
    const all = await DB.all(DB.STORES.VFS);
    let files = 0, dirs = 0, bytes = 0;
    for (const r of all) {
      if (r.kind === "dir") dirs++;
      else { files++; bytes += r.size || 0; }
    }
    return { files, dirs, bytes };
  },
  async du() { return (await VFS.count()).bytes; },

  /* ── ADE-HF.8 · clearAll — ws_clear tool support ────────────
     Wipes every row (files + dirs) from the VFS store. The linked
     disk work folder is deliberately NOT touched — the tool reports
     that honestly. Root is synthetic (never stored), so nothing to
     recreate afterwards. */
  async clearAll() {
    const all = await DB.all(DB.STORES.VFS);
    for (const r of all) { try { await DB.del(DB.STORES.VFS, r.path); } catch { /* best effort */ } }
    VFS._emit("clear", "/");
    return all.length;
  },

  /* ══ ADE-02.4 · ZIP IMPORT / EXPORT (fflate, vendored) ═════
     import a .zip preserving folder structure into destDir;
     export the whole workspace (or a subtree) as a zip Blob.   */
  _fflate() {
    if (typeof fflate === "undefined") {
      throw new Error("fflate not loaded — js/vendor/fflate.min.js is missing from the deployment");
    }
    return fflate;
  },

  async importZip(zipData, destDir = "/", opts = {}) {
    const f = VFS._fflate();
    const u8 = zipData instanceof Uint8Array ? zipData : new Uint8Array(zipData);
    const entries = f.unzipSync(u8); // { "path/name": Uint8Array }
    const root = VFS.norm(destDir || "/");
    let imported = 0, skipped = 0, bytes = 0, lastPath = null;

    for (const name of Object.keys(entries)) {
      const data = entries[name];
      const clean = VFS.norm("/" + name.replace(/\\/g, "/")); // .. -safe → no zip-slip
      if (clean === "/") { skipped++; continue; }
      if (/\/__MACOSX(\/|$)|^\/__MACOSX(\/|$)|\/\.DS_Store$/.test(clean)) { skipped++; continue; }
      if (name.endsWith("/")) continue; // explicit dir entry — mkdirp recreates it
      if (data.byteLength > VFS.MAX_ZIP_FILE) { skipped++; continue; }
      if (bytes + data.byteLength > VFS.MAX_ZIP_TOTAL) { skipped++; continue; }

      const target = VFS.join(root, clean.slice(1));
      if (opts.skip && target === VFS.norm(opts.skip)) { skipped++; continue; } // ADE-HF.8 — never unpack a zip onto itself
      if (await VFS.exists(target) && !opts.overwrite) { skipped++; continue; } // HF.8: default keep-existing; opts.overwrite=true = replace (agent unzip tool)
      const isText = VFS.isTextName(target);
      const content = isText
        ? f.strFromU8(data)
        : data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      await VFS.put(target, content, isText);
      bytes += data.byteLength;
      imported++;
      lastPath = target;
    }
    const summary = { imported, skipped, bytes, root, lastPath };
    VFS._emit("zip-import", root);
    return summary;
  },

  async exportZip(subtree = "/") {
    const f = VFS._fflate();
    const root = VFS.norm(subtree || "/");
    const all = await DB.all(DB.STORES.VFS);
    const data = {};
    for (const row of all) {
      if (row.kind !== "file") continue;
      let rel = row.path.replace(/^\//, "");
      if (root !== "/") {
        const prefix = root.slice(1) + "/";
        if (!rel.startsWith(prefix)) continue;
        rel = rel.slice(prefix.length);
      }
      if (!rel) continue;
      data[rel] = typeof row.content === "string" ? f.strToU8(row.content) : new Uint8Array(row.content);
    }
    // preserve empty dirs as explicit entries
    for (const row of all) {
      if (row.kind !== "dir" || row.path === "/") continue;
      let rel = row.path.replace(/^\//, "") + "/";
      if (root !== "/") {
        const prefix = root.slice(1) + "/";
        if (!rel.startsWith(prefix)) continue;
        rel = rel.slice(prefix.length);
      }
      if (!(rel in data)) data[rel] = new Uint8Array(0);
    }
    const zipped = f.zipSync(data, { level: 6 });
    return new Blob([zipped], { type: "application/zip" });
  }
};

/* ══════════════════════════════════════════════════════════════
   ADE-03.1…03.5 · FSA LINKED WORK FOLDER (CH-03)
   A real disk folder mirrors the VFS via File System Access
   (Chromium). The handle persists in IndexedDB 'handles' store
   (id 'wsdir') so the link is SESSION-PERSISTENT: on boot a
   granted permission silently relinks; 'prompt' arms the
   one-click RECONNECT badge (f2).  Write-through hangs off the
   VFS.onWrite bus (installed CH-02): every put · mkdir · rm ·
   mv mirrors to disk while autoSync is ON — subdirs auto-created
   (f3).  Pull imports the folder wholesale (text by extension
   whitelist, binary as ArrayBuffer, skip >8MB, junk skipped —
   f1); Push writes the whole tree back.  Conflict rule (f3
   tooltip, refined ch-11.f1): pull overwrites the VFS · push
   overwrites the disk.  Unsupported (Firefox/Safari/file://) →
   supported() = false and the UI falls back to zip in/export.
   Folder layout honored per m-24 (routing §07 build.fsa.structure):
   root = the 3 flat files + readme (+ configs from ch-09) ·
   imports/ · demo/ · user project files alongside (f5).
   ══════════════════════════════════════════════════════════════ */
VFS.FSA = {
  handle: null,
  state: "none",       // none | linking | linked | reconnect | unsupported
  autoSync: true,      // settings key 'fsa_autosync' (default ON; UI toggle at ch-06.f3)
  _syncing: false,     // ADE-S13.1 — one merge-sync at a time
  MAX_PULL_FILE: 8 * 1024 * 1024,          // f1: skip >8MB binaries on pull
  JUNK: /(^|\/)(__MACOSX|\.DS_Store|Thumbs\.db|desktop\.ini)(\/|$)/,

  _listeners: [],      // badge / buttons re-render on state flips
  onState(fn) { if (typeof fn === "function") this._listeners.push(fn); },
  setState(s) { this.state = s; for (const fn of this._listeners) { try { fn(s); } catch { /* never break state flow */ } } },

  supported() { return typeof window.showDirectoryPicker === "function"; },

  /* ── ADE-03.2 · boot — restore the persisted handle ─────────
     granted → silently linked (+ background wholesale pull) ·
     'prompt' → RECONNECT NEEDED (one click = user gesture) ·
     denied/missing → state cleared + toast.                    */
  async boot() {
    if (!this.supported()) { this.setState("unsupported"); return; }
    this.autoSync = (await DB.getSetting("fsa_autosync")) !== false; // default ON
    let h = null;
    try { h = await DB.getHandle("wsdir"); } catch { /* corrupt handle — treat as missing */ }
    if (!h) { this.setState("none"); return; }
    this.handle = h;
    let perm = "prompt";
    try { perm = await h.queryPermission({ mode: "readwrite" }); } catch { perm = "denied"; }
    if (perm === "granted") {
      this.setState("linked");
      // ADE-S13.1 (ch-17.f2): boot relink now MERGES instead of wholesale pull —
      // folder items land in the workspace, newer VFS edits survive
      this.syncFromFolder({ quiet: true }).then(r =>
        U.toast("Work folder relinked", { kind: "ok", msg: `${h.name} · ${r.added} added · ${r.updated} updated · write-through ON`, ms: 2600 })
      ).catch(() => { /* sync errors already handled */ });
    } else if (perm === "prompt") {
      this.setState("reconnect"); // one click on the badge reconnects
    } else {
      this.handle = null;
      try { await DB.delHandle("wsdir"); } catch { /* best effort */ }
      this.setState("none");
      U.toast("Work folder access denied", { kind: "err", msg: "Link state cleared — link a folder again anytime." });
    }
  },

  /* ── ADE-03.1 · link flow (user gesture) ────────────────────
     showDirectoryPicker(readwrite) → handle persisted ('wsdir')
     → wholesale pull → LINKED ✓.                               */
  async link() {
    if (!this.supported()) {
      return U.toast("File System Access unavailable", { kind: "info", msg: "Needs a Chromium browser (Chrome/Edge/Brave) on https or localhost. Zip import/export remains the work-folder fallback." });
    }
    try {
      this.setState("linking");
      const h = await window.showDirectoryPicker({ mode: "readwrite" });
      this.handle = h;
      await DB.setHandle("wsdir", h);
      // ADE-S13.1 (ch-17.f2): link imports what the folder ALREADY holds —
      // merge-newer, so a re-link never rolls the workspace back
      const r = await this.syncFromFolder();
      this.setState("linked");
      U.toast("Work folder linked", { kind: "ok", msg: `${h.name} · ${r.added} added · ${r.updated} updated${r.skipped ? ` · ${r.skipped} skipped` : ""} · write-through ON`, ms: 4200 });
      return r;
    } catch (e) {
      this.handle = null;
      this.setState("none");
      if (e?.name !== "AbortError") U.toast("Link failed", { kind: "err", msg: e?.message || String(e) });
      return null;
    }
  },

  /* ── ADE-03.2 · one-click reconnect (badge click = gesture) ── */
  async reconnect() {
    if (!this.handle) return this.link();
    try {
      this.setState("linking");
      const p = await this.handle.requestPermission({ mode: "readwrite" });
      if (p !== "granted") {
        this.setState("reconnect");
        U.toast("Permission not granted", { kind: "err", msg: "The work folder stays disconnected — click RECONNECT to try again." });
        return null;
      }
      const r = await this.syncFromFolder(); // ADE-S13.1 — merge, same as link/boot
      this.setState("linked");
      U.toast("Work folder reconnected", { kind: "ok", msg: `${this.handle.name} · ${r.added} added · ${r.updated} updated`, ms: 3400 });
      return r;
    } catch (e) {
      this.setState("reconnect");
      if (e?.name !== "AbortError") U.toast("Reconnect failed", { kind: "err", msg: e?.message || String(e) });
      return null;
    }
  },

  /* ── detach (VFS keeps everything) ─────────────────────────── */
  async unlink() {
    this.handle = null;
    try { await DB.delHandle("wsdir"); } catch { /* best effort */ }
    this.setState("none");
    U.toast("Work folder unlinked", { kind: "info", msg: "The VFS keeps every file — re-link anytime." });
  },

  /* ── ADE-S13.1 · syncFromFolder — folder → VFS, MERGE-NEWER ────
     (ch-17.f1, m-32 field report: "it extends workspace into work
     folder, i need it to also see what is in work folder as well" —
     the AUTO direction must ADD what the folder holds, not clobber
     newer workspace state):
       · file missing in VFS          → imported
       · file exists, disk NEWER      → overwritten (lastModified beats row mtime)
       · file exists, VFS same/newer  → left alone (agent edits survive)
     This is what link(), boot-relink, the 20s poll, visibilitychange
     and the PRE-AGENT-RUN hook all call — the agent therefore always
     sees the folder's present items. The manual Pull button keeps the
     documented wholesale pull() (folder overwrites the VFS).
     Returns { added, updated, skipped }. */
  async syncFromFolder(opts = {}) {
    if (!this.handle || this._syncing) return { added: 0, updated: 0, skipped: 0, busy: true };
    this._syncing = true;
    this._bulk = true; // no re-mirror, no tree-refresh spam while scanning
    const stat = { added: 0, updated: 0, skipped: 0 };
    try {
      await this._syncDir(this.handle, "/", stat);
    } catch (e) {
      if (!opts.quiet) U.toast("Work-folder sync failed", { kind: "err", msg: e?.message || String(e) });
    } finally {
      this._bulk = false;
      this._syncing = false;
    }
    return stat;
  },

  async _syncDir(dirHandle, vfsPath, stat) {
    for await (const [name, entry] of dirHandle.entries()) {
      if (this.JUNK.test("/" + name)) { stat.skipped++; continue; }
      if (entry.kind === "directory") {
        await VFS.mkdirp(VFS.join(vfsPath, name));
        await this._syncDir(entry, VFS.join(vfsPath, name), stat);
      } else {
        try {
          const file = await entry.getFile();
          if (file.size > this.MAX_PULL_FILE) { stat.skipped++; continue; }
          const target = VFS.join(vfsPath, name);
          const row = await VFS.get(target);
          if (row && row.kind === "file" && (file.lastModified || 0) <= (row.mtime || 0)) continue; // VFS is same/newer — leave it
          if (U.isTextName(name, file.type)) await VFS.put(target, await file.text(), true);
          else await VFS.put(target, await file.arrayBuffer(), false);
          row ? stat.updated++ : stat.added++; // put() bumps mtime → next sync skips until disk changes again
        } catch { stat.skipped++; } // unreadable entry — skip, keep syncing
      }
    }
  },

  /* ── ADE-S13.1 (ch-17.f2) · auto-sync triggers — one 20s poll while
     linked + autoSync + tab visible, plus a visibilitychange refresh
     when the user comes back after dropping files into the folder.
     Installed once from Main.init() via FSA.startAutoSync().      */
  _autoTimer: null,
  _lastAuto: 0,
  startAutoSync() {
    if (this._autoTimer) return;
    this._autoTimer = setInterval(() => {
      if (this.state !== "linked" || !this.autoSync) return;         // toggle honored (fsa_autosync, ch-06.f3)
      if (document.visibilityState !== "visible") return;            // never burn disk I/O in a hidden tab
      if (Date.now() - this._lastAuto < 12000) return;               // debounce: pre-run syncs count too
      this._lastAuto = Date.now();
      this.syncFromFolder({ quiet: true }).then(st => {
        if (st.added || st.updated) U.toast("Work folder synced", { kind: "ok", msg: `${st.added} added · ${st.updated} updated ← ${this.handle?.name || "folder"}`, ms: 2600 });
      });
    }, 20000);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState !== "visible") return;
      if (this.state !== "linked" || !this.autoSync) return;
      if (Date.now() - this._lastAuto < 8000) return;                // return-to-tab refresh, debounced harder
      this._lastAuto = Date.now();
      this.syncFromFolder({ quiet: true });
    });
  },

  /* ── ADE-03.1 · pull — folder → VFS, wholesale (m-24 layout) ──
     text by extension whitelist · binary as ArrayBuffer ·
     skip >8MB · junk skipped · count reported.
     MANUAL ACTION ONLY since ADE-S13.1 — the automatic path is the
     merge-newer syncFromFolder() above (never clobbers newer VFS). */
  async pull(opts = {}) {
    if (!this.handle) return { count: 0, skipped: 0 };
    this._bulk = true; // mirror-off + single refresh while importing
    let count = 0, skipped = 0;
    try {
      await this._pullDir(this.handle, "/", (c, s) => { count += c; skipped += s; });
    } catch (e) {
      U.toast("Pull failed", { kind: "err", msg: e?.message || String(e) });
    } finally {
      this._bulk = false;
    }
    return { count, skipped };
  },

  async _pullDir(dirHandle, vfsPath, stat) {
    for await (const [name, entry] of dirHandle.entries()) {
      if (this.JUNK.test("/" + name)) { stat(0, 1); continue; }
      if (entry.kind === "directory") {
        await VFS.mkdirp(VFS.join(vfsPath, name));
        await this._pullDir(entry, VFS.join(vfsPath, name), stat);
      } else {
        try {
          const file = await entry.getFile();
          if (file.size > this.MAX_PULL_FILE) { stat(0, 1); continue; }
          const target = VFS.join(vfsPath, name);
          if (U.isTextName(name, file.type)) await VFS.put(target, await file.text(), true);
          else await VFS.put(target, await file.arrayBuffer(), false);
          stat(1, 0);
        } catch { stat(0, 1); } // unreadable entry — skip, keep pulling
      }
    }
  },

  /* ── ADE-03.3 · push — whole VFS tree → folder ────────────────
     push overwrites the disk (pull overwrites the VFS — the
     documented conflict rule, refined at ch-11.f1).             */
  async push() {
    if (!this.handle) return { written: 0, failed: 0 };
    this._bulk = true;
    let written = 0, failed = 0;
    try {
      const rows = await VFS.tree("/");
      for (const r of rows) {
        try {
          if (r.kind === "dir") { await this._dirHandle(r.path, true); continue; }
          const dh = await this._dirHandle(VFS.parent(r.path), true);
          const fh = await dh.getFileHandle(VFS.base(r.path), { create: true });
          const w = await fh.createWritable();
          await w.write(typeof r.content === "string" ? r.content : new Blob([r.content]));
          await w.close();
          written++;
        } catch { failed++; }
      }
    } finally {
      this._bulk = false;
    }
    return { written, failed };
  },

  /* resolve (and optionally auto-create) a directory handle on disk */
  async _dirHandle(dirPath, create) {
    let dh = this.handle;
    for (const seg of String(dirPath || "/").split("/").filter(Boolean)) {
      dh = await dh.getDirectoryHandle(seg, { create: !!create });
    }
    return dh;
  },

  /* ── ADE-03.3 · write-through handlers (off the onWrite bus) ──
     every VFS write mirrors to disk while autoSync is ON; subdirs
     auto-created; failures toast (throttled) but NEVER break the
     VFS operation itself.  rm/mv keep the disk a true mirror.    */
  _bulk: false,          // true during pull/push — suppress re-mirroring
  _errTimer: null,

  _gate() { return !this.handle || !this.autoSync || this._bulk; },

  async _wtPut(path) {
    if (this._gate()) return;
    try {
      const row = await VFS.get(path);
      if (!row || row.kind !== "file") return;
      const dh = await this._dirHandle(VFS.parent(path), true);
      const fh = await dh.getFileHandle(VFS.base(path), { create: true });
      const w = await fh.createWritable();
      await w.write(typeof row.content === "string" ? row.content : new Blob([row.content]));
      await w.close();
    } catch (e) { this._wtError(e, path); }
  },

  async _wtMkdir(path) {
    if (this._gate()) return;
    try { await this._dirHandle(path, true); }
    catch (e) { this._wtError(e, path); }
  },

  async _wtRm(path, info) {
    if (this._gate()) return;
    try {
      const dh = await this._dirHandle(VFS.parent(path), false);
      await dh.removeEntry(VFS.base(path), { recursive: !!(info && info.recursive) });
    } catch (e) {
      if (e?.name !== "NotFoundError") this._wtError(e, path); // already gone on disk = fine
    }
  },

  async _wtMv(dest, info) {
    if (this._gate()) return;
    const from = info && info.from;
    try {
      if (from) {
        try {
          const dh = await this._dirHandle(VFS.parent(from), false);
          await dh.removeEntry(VFS.base(from), { recursive: true });
        } catch (e) { if (e?.name !== "NotFoundError") throw e; }
      }
      const row = await VFS.get(dest);
      if (row && row.kind === "file") { await this._wtPut(dest); }
      else if (row && row.kind === "dir") {
        await this._dirHandle(dest, true);
        const rows = await VFS.tree(dest);
        for (const r of rows) {
          if (r.kind === "dir") await this._dirHandle(r.path, true);
          else await this._wtPut(r.path);
        }
      }
    } catch (e) { this._wtError(e, dest); }
  },

  _wtError(e, path) {
    if (this._errTimer) return; // throttled — one toast per 4s window
    this._errTimer = setTimeout(() => { this._errTimer = null; }, 4000);
    U.toast("Write-through failed", { kind: "err", msg: `${path} — ${e?.message || e}` });
  }
};

/* ADE-03.3 — write-through hangs off the CH-02 hook bus (fire-and-forget:
   mirroring must never slow or break the VFS operation that triggered it) */
VFS.onWrite((type, path, info) => {
  const F = VFS.FSA;
  if (F._gate()) return;
  if (type === "write") F._wtPut(path);
  else if (type === "mkdir") F._wtMkdir(path);
  else if (type === "rm") F._wtRm(path, info);
  else if (type === "mv") F._wtMv(path, info);
});
if (typeof window !== "undefined") window.VFS = VFS; // ADE-S23.3: window.VFS guard support

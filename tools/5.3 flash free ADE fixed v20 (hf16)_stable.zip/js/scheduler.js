/* ============================================================
   js/scheduler.js — ADE-S18.7 · TASK SCHEDULER (ch-25, m-44)
   "schedule tasks (date time, frequency, how many times, task)
   for the agent workspace and have the agent automatically
   loop/iterate through those"

     ENGINE  — tasks persist in the ade-db v2 'tasks' store
               (db.js ADE-S18.8, additive-only per ai.saves.rule).
               A 15s tick (+ visibilitychange + focus) checks every
               enabled task whose nextRun is due and fires it
               THROUGH THE REAL AGENT: a new conversation titled
               "⟳ <task>" + ChatUI.runTurn (ADE-S18.6) with the
               active config — the full 13-tool agent loop runs,
               unattended, exactly like a typed message.
     SHAPE   — { id, name, prompt, startAt, freq (once · interval
               N-min · hourly · daily · weekly), intervalMin,
               times (0 = unlimited), runs, nextRun, lastRun,
               lastStatus, lastNote, lastConvId, enabled, createdAt }
     CATCH-UP — a recurring task that missed windows while the tab
               was closed collapses them into ONE run at the next
               tick, then re-phases onto its schedule (no burst).
     GUARDS  — one scheduled run at a time (_busy); a user run
               (State.streaming) defers the tick — the user's run
               is never aborted; no config/key = honest err state,
               retried next tick, nextRun unchanged.
     UI      — third window under the workspace tree (NOW EDITING ·
               CONSOLE HISTORY · SCHEDULED TASKS): rows with next-run
               countdown + last status, run-now / pause / edit /
               delete, and an add-edit modal.
   ============================================================ */
"use strict";

const SchedUI = {
  tasks: [],
  _timer: null,
  _busy: false,        // a scheduled run is in flight
  _open: false,        // modal open guard

  FREQS: {
    once:     { label: "Once",            stepMs: null },
    interval: { label: "Every N minutes", stepMs: null }, // N = intervalMin
    hourly:   { label: "Hourly",          stepMs: 3600000 },
    daily:    { label: "Daily",           stepMs: 86400000 },
    weekly:   { label: "Weekly",          stepMs: 604800000 }
  },

  /* ══ boot ══════════════════════════════════════════════ */
  async init() {
    try { this.tasks = await DB.allTasks(); } catch { this.tasks = []; }
    this.render();
    this.wire();
    this.start();
    console.log(`%cADE scheduler %c${this.tasks.length} task(s) · 15s tick`,
      "color:#d4893a;font-weight:bold", "color:#999490");
  },

  wire() {
    // collapse toggle lives with the other two sub-windows (ui-workspace bindSubWindows)
    const add = document.getElementById("ws-sched-add");
    if (add) add.addEventListener("click", e => { e.stopPropagation(); this.openModal(); });
    document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") this.tick(); });
    window.addEventListener("focus", () => this.tick());
    // delegated row actions
    document.getElementById("ws-schedule-body")?.addEventListener("click", async e => {
      const btn = e.target.closest("[data-sact]");
      if (!btn) return;
      const t = this.tasks.find(x => x.id === btn.closest(".ws-sched-row")?.dataset.id);
      if (!t) return;
      const a = btn.dataset.sact;
      if (a === "run") await this.fireTask(t, true);
      else if (a === "toggle") { t.enabled = !t.enabled; await DB.saveTask(t); this.render(); }
      else if (a === "edit") this.openModal(t);
      else if (a === "del") {
        if (btn.dataset.armed !== "1") { // two-step inline confirm (same pattern as conv delete, ADE-S18.1)
          btn.dataset.armed = "1"; btn.classList.add("armed");
          setTimeout(() => { if (btn.isConnected) { btn.dataset.armed = ""; btn.classList.remove("armed"); } }, 3000);
          return;
        }
        await DB.delTask(t.id);
        this.tasks = this.tasks.filter(x => x.id !== t.id);
        this.render();
        U.toast("Task deleted", { kind: "ok" });
      }
    });
  },

  start() {
    if (this._timer) clearInterval(this._timer);
    this._timer = setInterval(() => this.tick(), 15000);
    setTimeout(() => this.tick(), 2500); // first sweep shortly after boot
  },

  /* ══ scheduling math (pure — no DOM) ══════════════════ */
  stepMs(t) {
    if (t.freq === "interval") return Math.max(5, Number(t.intervalMin) || 60) * 60000;
    return this.FREQS[t.freq]?.stepMs || null;
  },

  /* next scheduled fire strictly after `scheduled`, re-phased onto the
     task's own cadence; missed windows collapse (≤3660 re-phase steps,
     then snap to now+step — a task paused for years can't loop the tab) */
  advanceFrom(t, scheduled) {
    const step = this.stepMs(t);
    if (!step) return null; // once
    let next = scheduled + step;
    let guard = 0;
    while (next <= Date.now() && guard++ < 3660) next += step;
    if (next <= Date.now()) next = Date.now() + step;
    return next;
  },

  due(t) {
    return !!t.enabled && t.nextRun != null && t.nextRun <= Date.now() &&
           (Number(t.times) === 0 || (t.runs || 0) < Number(t.times));
  },

  done(t) {
    if (t.freq === "once") return (t.runs || 0) >= 1;
    return Number(t.times) > 0 && (t.runs || 0) >= Number(t.times);
  },

  /* human summary used by the row + modal */
  freqLabel(t) {
    if (t.freq === "once") return "once";
    if (t.freq === "interval") return `every ${t.intervalMin || 60} min`;
    return this.FREQS[t.freq]?.label?.toLowerCase() || t.freq;
  },
  countdown(ms) {
    if (ms == null) return "—";
    const s = Math.max(0, Math.round((ms - Date.now()) / 1000));
    if (s < 60) return `in ${s}s`;
    if (s < 3600) return `in ${Math.round(s / 60)}m`;
    if (s < 86400) return `in ${Math.round(s / 3600)}h`;
    return `in ${Math.round(s / 86400)}d`;
  },

  /* ══ ENGINE — the tick ════════════════════════════════ */
  async tick() {
    if (this._busy || State.streaming) return; // user run in flight — never preempt; retried next sweep
    const t = this.tasks.find(x => this.due(x));
    if (!t) return;
    await this.fireTask(t, false);
    // loop if another task is due right now (rare — sequential, one per sweep)
    if (this.tasks.some(x => this.due(x))) this.tick();
  },

  /* fire ONE task as a real agent run in a fresh conversation */
  async fireTask(t, manual) {
    if (this._busy) { U.toast("Agent busy", { kind: "info", msg: `"${t.name}" deferred — another run is in flight.` }); return false; }
    if (State.streaming) { U.toast("Agent busy", { kind: "info", msg: `"${t.name}" deferred — your own run is streaming; it fires after.` }); return false; }
    const cfg = ChatUI.activeConfig();
    if (!cfg || !cfg.apiKey) {
      t.lastStatus = "err"; t.lastNote = "no active config / no API key";
      await DB.saveTask(t); this.render();
      U.toast("Scheduled task blocked", { kind: "err", msg: `"${t.name}" needs an active config with an AiHubMix key (Settings → Configs).`, ms: 5200 });
      return false;
    }
    this._busy = true;
    const now = Date.now();
    try {
      const conv = { id: U.uid(), title: `⟳ ${t.name}`.slice(0, 60), ts: now, lastTs: now };
      await DB.saveConv(conv);
      const tag = Number(t.times) > 0 ? ` — run ${(t.runs || 0) + 1}/${t.times}` : (t.runs ? ` — run ${(t.runs || 0) + 1}` : "");
      const prompt = `[scheduled task: ${t.name}${tag} — fired ${new Date(now).toLocaleString()}]\n\n${t.prompt}`;
      await ChatUI.runTurn(cfg, conv.id, prompt);
      t.runs = (t.runs || 0) + 1;
      t.lastRun = now;
      t.lastStatus = "ok";
      t.lastNote = "";
      t.lastConvId = conv.id;
      if (this.done(t)) t.nextRun = null;
      else t.nextRun = this.advanceFrom(t, t.nextRun || now);
      await DB.saveTask(t);
      U.toast("Scheduled task ran", { kind: "ok", msg: `"${t.name}" → new conversation "${conv.title}"${t.nextRun ? " · next " + this.countdown(t.nextRun) : " · completed"}`, ms: 4600 });
      return true;
    } catch (e) {
      t.lastStatus = "err";
      t.lastNote = String(e?.message || e).slice(0, 160);
      await DB.saveTask(t);
      U.toast("Scheduled task failed", { kind: "err", msg: `"${t.name}" — ${t.lastNote}`, ms: 5200 });
      return false;
    } finally {
      this._busy = false;
      this.render();
      await ChatUI.renderSidebar();
    }
  },

  /* ══ UI — rows under the workspace tree ═══════════════ */
  render() {
    const body = document.getElementById("ws-schedule-body");
    const count = document.getElementById("ws-schedule-count");
    if (!body) return;
    if (count) {
      const active = this.tasks.filter(t => t.enabled && !this.done(t)).length;
      count.textContent = `${active}/${this.tasks.length}`;
    }
    if (!this.tasks.length) {
      body.innerHTML = `<div class="ws-chist-empty">no scheduled tasks — + adds one (the agent runs it unattended)</div>`;
      return;
    }
    body.innerHTML = this.tasks.map(t => {
      const done = this.done(t);
      const dueNow = this.due(t);
      const state = done ? "done" : (t.enabled ? (t.lastStatus === "err" ? "err" : "ok") : "paused");
      const when = done ? `completed · ${t.runs} run${t.runs === 1 ? "" : "s"}`
        : !t.enabled ? "paused"
        : dueNow ? (this._busy ? "waiting for the agent…" : "due — firing on the next sweep")
        : `next ${this.countdown(t.nextRun)}`;
      const note = t.lastStatus === "err" && t.lastNote ? ` · ${U.escapeHtml(t.lastNote)}` : "";
      return `<div class="ws-sched-row ${state}" data-id="${t.id}" title="${U.escapeHtml(t.prompt)}">
        <span class="ws-sched-dot"></span>
        <div class="ws-sched-main">
          <div class="ws-sched-name">${U.escapeHtml(t.name)} <span class="ws-sched-freq">${this.freqLabel(t)}${Number(t.times) > 0 ? ` · ×${t.times}` : " · ∞"}</span></div>
          <div class="ws-sched-when">${when}${t.lastRun ? ` · last ${U.fmtTime(t.lastRun)}` : ""}${note}</div>
        </div>
        <span class="ws-sched-actions">
          <i class="fa-solid fa-play ws-sched-act" data-sact="run" title="Run now"></i>
          <i class="fa-solid ${t.enabled ? "fa-pause" : "fa-play"} ws-sched-act" data-sact="toggle" title="${t.enabled ? "Pause" : "Enable"}"></i>
          <i class="fa-solid fa-pen ws-sched-act" data-sact="edit" title="Edit"></i>
          <i class="fa-solid fa-trash ws-sched-act danger" data-sact="del" title="Delete (click twice)"></i>
        </span>
      </div>`;
    }).join("");
  },

  /* ══ UI — add / edit modal ════════════════════════════ */
  openModal(t = null) {
    if (this._open) return;
    this._open = true;
    const editing = !!t;
    const base = t || {
      id: U.uid(), name: "", prompt: "", freq: "once", intervalMin: 60,
      startAt: Date.now() + 5 * 60000, times: t ? Number(t.times) : (null), runs: 0,
      nextRun: null, lastRun: null, lastStatus: null, lastNote: "", lastConvId: null,
      enabled: true, createdAt: Date.now()
    };
    if (!editing) {
      base.times = base.freq === "once" ? 1 : 0; // once = 1 run; recurring defaults to unlimited
    }
    const dtLocal = (ms) => {
      const d = new Date(ms);
      const p = (n) => String(n).padStart(2, "0");
      return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
    };
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop open";
    backdrop.id = "ws-sched-modal";
    backdrop.innerHTML = `
      <div class="modal sched-modal">
        <div class="modal-header">
          <h2><i class="fa-solid fa-calendar-days"></i> ${editing ? "Edit scheduled task" : "New scheduled task"}
            <span class="sub">the agent runs this unattended in a fresh conversation</span></h2>
          <button class="icon-btn" id="sched-close" title="Close"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="sched-form">
          <label>task name</label>
          <input id="sched-name" type="text" maxlength="60" placeholder="nightly workspace digest" value="${U.escapeHtml(base.name || "")}" />
          <label>task — what the agent should do each run</label>
          <textarea id="sched-prompt" rows="5" placeholder="e.g. Run digest / — then fs_write the table to /reports/digest-<today>.md and summarize what changed.">${U.escapeHtml(base.prompt || "")}</textarea>
          <div class="sched-grid">
            <div>
              <label>start (date &amp; time)</label>
              <input id="sched-start" type="datetime-local" value="${dtLocal(base.startAt)}" />
            </div>
            <div>
              <label>frequency</label>
              <select id="sched-freq">
                ${Object.entries(this.FREQS).map(([id, f]) => `<option value="${id}" ${base.freq === id ? "selected" : ""}>${f.label}</option>`).join("")}
              </select>
            </div>
            <div id="sched-interval-wrap" style="display:${base.freq === "interval" ? "" : "none"}">
              <label>every … minutes (min 5)</label>
              <input id="sched-interval" type="number" min="5" step="5" value="${Number(base.intervalMin) || 60}" />
            </div>
            <div>
              <label>how many times (0 = until paused)</label>
              <input id="sched-times" type="number" min="0" step="1" value="${Number(base.times) || 0}" />
            </div>
          </div>
          <div class="sched-hint" id="sched-hint"></div>
          <div class="sched-err" id="sched-err" style="display:none"></div>
          <div class="sched-btns">
            <button class="btn" id="sched-cancel">Cancel</button>
            <button class="btn primary" id="sched-save"><i class="fa-solid fa-check"></i> ${editing ? "Save changes" : "Schedule task"}</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(backdrop);

    const q = (id) => backdrop.querySelector(id);
    const err = (msg) => { const el = q("#sched-err"); el.textContent = msg; el.style.display = msg ? "" : "none"; };
    const hint = () => {
      try {
        const startMs = q("#sched-start").value ? new Date(q("#sched-start").value).getTime() : NaN;
        const freq = q("#sched-freq").value;
        const times = Math.max(0, Math.floor(Number(q("#sched-times").value) || 0));
        const cadence = freq === "once" ? "no repeats"
          : `${freq === "interval" ? `every ${Math.max(5, Number(q("#sched-interval").value) || 60)} min` : this.FREQS[freq]?.label?.toLowerCase()} · ${times > 0 ? `×${times} runs` : "until paused"}`;
        q("#sched-hint").textContent = Number.isFinite(startMs)
          ? `first fire: ${startMs <= Date.now() + 15000 ? "on save (start is due — missed windows collapse into one run)" : new Date(startMs).toLocaleString()} · ${cadence}`
          : "";
      } catch { q("#sched-hint").textContent = ""; }
    };
    q("#sched-freq").addEventListener("change", () => {
      q("#sched-interval-wrap").style.display = q("#sched-freq").value === "interval" ? "" : "none";
      const f = q("#sched-freq").value;
      if (f === "once") q("#sched-times").value = 1;
      hint();
    });
    q("#sched-start").addEventListener("input", hint);
    q("#sched-interval").addEventListener("input", hint);
    q("#sched-close").addEventListener("click", () => this._closeModal());
    q("#sched-cancel").addEventListener("click", () => this._closeModal());
    backdrop.addEventListener("click", e => { if (e.target === backdrop) this._closeModal(); });
    q("#sched-save").addEventListener("click", async () => {
      try {
        const rec = this._readForm(q, base, false);
        const saved = { ...(t || base), ...rec };
        if (!editing) { saved.runs = 0; saved.createdAt = Date.now(); saved.enabled = true; }
        else saved.enabled = t.enabled; // editing never flips the row's pause state (the pause toggle owns it)
        saved.nextRun = this.done(saved) ? null : saved.startAt;
        // a recurring task whose start already passed fires on the next sweep (collapsed catch-up), then re-phases
        await DB.saveTask(saved);
        const i = this.tasks.findIndex(x => x.id === saved.id);
        if (i >= 0) this.tasks[i] = saved; else this.tasks.push(saved);
        this.tasks.sort((a, b) => (a.nextRun || Infinity) - (b.nextRun || Infinity));
        this._closeModal();
        this.render();
        U.toast(editing ? "Task updated" : "Task scheduled", { kind: "ok", msg: `"${saved.name}" · ${this.freqLabel(saved)}${saved.enabled ? " · next " + this.countdown(saved.nextRun) : " · paused"}`, ms: 4600 });
      } catch (e) { err(e?.message || String(e)); }
    });
    hint();
    setTimeout(() => q("#sched-name").focus(), 30);
  },

  /* form → record. dry=true only validates + returns the first-fire stamp */
  _readForm(q, base, dry) {
    const name = q("#sched-name").value.trim();
    if (!name) throw new Error("Give the task a name.");
    const prompt = q("#sched-prompt").value.trim();
    if (!prompt) throw new Error("Describe what the agent should do each run.");
    const startMs = q("#sched-start").value ? new Date(q("#sched-start").value).getTime() : NaN;
    if (!Number.isFinite(startMs)) throw new Error("Pick a start date & time.");
    const freq = q("#sched-freq").value;
    if (!this.FREQS[freq]) throw new Error("Unknown frequency.");
    const intervalMin = Math.max(5, Number(q("#sched-interval").value) || 60);
    const times = Math.max(0, Math.floor(Number(q("#sched-times").value) || 0));
    if (dry) return startMs;
    return {
      id: base.id, name, prompt, freq, intervalMin,
      startAt: startMs, times,
      enabled: true // new tasks start enabled; pause happens on the row
    };
  },

  _closeModal() {
    document.getElementById("ws-sched-modal")?.remove();
    this._open = false;
  }
};

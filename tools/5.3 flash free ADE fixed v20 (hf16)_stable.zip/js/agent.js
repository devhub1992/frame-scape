/* ============================================================
   js/agent.js — ADE-05.1…05.5 · THE AGENT (full module — pure
   file replacement of the CH-01 stub; the script tag already
   sits in its final load-order slot, index.html never moves)

     ADE-05.1 · TOOLS — OpenAI-format tools with JSON schemas
                + exec handlers over the REAL CH-02/03/04 stack:
                VFS (write-through) · Exec.Shell · Exec.runPython
                · Exec.runJs · Exec.preview
                ADE-S14.1 adds fs_digest (ch-20.f1) — 13 tools.
     ADE-05.2 · runAgent — streamed /chat/completions tool loop:
                assistant tool_calls accumulated + persisted, each
                executed, results persisted as role:tool, loop
                continues (cap = cfg.maxSteps) · step counter ·
                STOP gates fetch AND tools
     ADE-05.4 · text-protocol fallback — 400/404/422 whose body
                mentions tools/functions (or cfg.forceProto) →
                retry without tools + <<<TOOL {...}>>> appendix;
                result fed back as the next user turn
     ADE-05.5 · buildContext — API context rebuilt from persisted
                msgs; est-token budget = cfg.contextK; trims
                oldest at user-message boundaries only (an
                assistant tool_calls block never loses its tool
                results); system prompt always kept
                ADE-S14.2 adds tool-result EVICTION (ch-20.f2):
                past-segment tool results collapse to stubs at
                ~60% budget pressure — kills the O(steps ×
                folder) re-send burn (m-35) without touching the
                persisted thread.
     ADE-S14.3 · read-economy rule in the system prompt (ch-20.f3)
     ADE-S14.4 · fs_read pagination — offset/limit · head/tail
                (ch-20.f4)
     (ADE-05.3 tool-trace UI + ADE-05.6 thinking viewer live in
      ui-chat.js — the agent feeds them via finalize/noteReasoning)

   HANDOFF ROOM (per planner worklogs 6/8):
     · CH-06 replaces buildSystemPrompt's BODY (ADE-06.1) and
       injects FlatBridge.PHILOSOPHY (ch-06.f7) — keep it the
       single named entry point.
     · CH-12 wraps buildSystemPrompt + buildContext for prompt
       caching (ai.cache.*) — both stay cleanly wrap-able.
   ============================================================ */
"use strict";

/* ══ ADE-06.7 · FLAT-BRIDGE PHILOSOPHY (m-28, session 4) ════════════════════
   The protocol philosophy ships as CODE — a hard-coded JS constant
   injected into EVERY system prompt (any model, any config, any
   endpoint, native tools or <<<TOOL>>> text protocol). It is a
   structured DIGEST of the bridge: the 3 files' roles, the
   request→routed→done lifecycle, the register-never-remember /
   append-only / stable-keys rules, the §01 read order and the
   two-artifact deliverable. Independent of workspace file state:
   when the flat files exist in the workspace, the buildSystemPrompt
   state layer directs the agent to fs_read their LIVE contents on
   top (philosophy = code · state = files). CH-12 prompt caching
   benefits: this block is byte-stable across every turn.            ══ */
const FlatBridge = {
  PHILOSOPHY:
`FLAT-BRIDGE PROTOCOL — PHILOSOPHY LAYER (hard-embedded; governs you even with zero project files present)

THE THREE FILES (flat, root-level, stable keys — a campaign ledger, not prose):
  · routing.flat.txt   — the PROTOCOL: how sessions run (§00 meta → §07 build sections) · the ai-protocol state machine: session types (ROUTING / PLAN / ITERATION / HOTFIX) · plan.next · budget zones · the prompt recipe · save/output rules
  · manifest.flat.txt  — the REQUEST LEDGER: every user request is one m-NN record (m-NN.text / .status / .routed / .note) · §01 session batches + §09 inbox for mid-run interrupts · requests are REGISTERED, never remembered
  · planner.flat.txt   — the WORK PLAN: one ch-NN block per chunk (title · size · est.k · status · deps · files · keywords) with fX feature lines + statuses · meta.cache snapshot registry · §12 append-only worklog

THE LIFECYCLE: user request → REGISTER as m-NN (status = open) → ROUTE to a ch-NN chunk (m-NN.routed) → the chunk's features ship (chNN.fX.status = done) → the request FLIPS done (m-NN.status = done). Worklog lines record every session. plan.next names the next chunk to run.

THE RULES THAT NEVER BEND:
  · register-never-remember — a request not written to manifest.flat.txt does not exist
  · append-only — worklog lines and history are never rewritten; statuses flip IN PLACE
  · stable keys — m-NN / ch-NN / fX ids never move, never renumber; lines never vanish
  · additive-only — schema changes add keys/stores; never rename or drop (ai.saves.rule)
  · read-order — routing §01 (protocol) → planner meta + plan-state → the one chunk block → relevant m-NN lines; read sections, never whole-file dump (ai.read.rule)

THE DELIVERABLE: every session ends with TWO artifacts — the updated flat files (the ledger, reflecting exact current state) and the shipped build (code / zip). Both must agree: the ledger describes what exists, the build proves it.`
};

const Agent = {
  ready: true, // full module live since CH-05 (was the CH-01 stub flag)
  _keyWarned: false, // ADE-HF.2 — empty-{corskey} toast fires once per session
  _autoShrink: 0, // hf.12 — armed by _maybeAutoContinue when a stall smells like payload size; consumed once at the next runAgent start

  /* ══ ADE-05.1 · TOOL REGISTRY — 13 tools, OpenAI JSON-schema format ══
     caps: reads 16k chars, other outputs 12k (truncation notes appended);
     every path passes VFS.norm() so nothing escapes the workspace root;
     every write goes through VFS.put/mkdir/rm/mv → the CH-03 write-through
     bus mirrors it to the linked work folder automatically.
     ADE-S14.1 (ch-20.f1): fs_digest joins — survey a subtree in ONE call
     instead of the file-by-file reads that burned m-35.                */
  READ_CAP: 16000,
  BIG_READ_CAP: 30720, // hf.14 — the LARGE-FILE line is 30 KB (user call, down from hf.12's 50 KB): a whole read above it never refuses any more — it returns the head slice + the slice plan in ONE call (seamless chunking), so oversized file bodies can never pile up in the payload (the 2026-10-31 frame-scape freeze: ~20k-tok tool results stacked into empty-response loops)
  OUT_CAP: 12000,

  /* hf.12 — MULTI-FILE CALLS. read · find · edit · append accept path as a
     STRING (one file — unchanged) or an ARRAY of paths (one call, many files).
     Every per-file result goes through the same caps/slicing as the single
     form, so a multi call can never ship a bigger payload than the sum of its
     single-file equivalents — and the total stays under OUT_CAP. */
  MULTI_PATH_MAX: 12,

  /* hf.14 — models serialize the intended array into a JSON STRING in
     `arguments` (field case, 2026-10-31: grep {path:"[\"a.js\",\"b.js\"]"}
     ran as ONE literal path → "searched 0 text file(s), 1 binary skipped").
     _coerceMulti un-serializes it so the advertised MULTI-FILE behavior
     fires regardless of how the model encoded the array. */
  _coerceMulti(args) {
    for (const k of ["path", "files", "from", "to"]) {
      const v = args[k];
      if (typeof v !== "string") continue;
      const s = v.trim();
      if (s.length < 2 || s[0] !== "[" || s[s.length - 1] !== "]") continue;
      try {
        const arr = JSON.parse(s);
        if (Array.isArray(arr) && arr.length && arr.every(x => typeof x === "string")) args[k] = arr;
      } catch { /* a genuine path that happens to start with [ — treated as one path */ }
    }
    return args;
  },

  _paths(v) { // hf.12 — "path": "a" OR ["a","b"] → normalized, deduped list
    const arr = Array.isArray(v) ? v : (v == null || v === "" ? [] : [v]);
    const out = [];
    for (const x of arr.slice(0, this.MULTI_PATH_MAX + 4)) {
      const p = VFS.norm(String(x ?? ""));
      if (p && p !== "/" && !out.includes(p)) out.push(p);
    }
    return out.slice(0, this.MULTI_PATH_MAX);
  },
  _isMulti(v) { return Array.isArray(v) && v.length > 1; }, // a 1-element array behaves exactly like the single path

  /* ══ hf.15 · FILE TOKEN BURN — the editing panel reflects what the agent's
     prompt/reasoning spend lands on (user call: "editing panel should reflect
     if agent is using prompt/reasoning tokens on a specific file/files").
     fileBurn: path → { intake, output, think, calls, lastTool, lastTs }
       ↑ intake = prompt tokens this file SHIPPED into context (read/grep/
         find results attributed per file — exact per ===== section for reads)
       ↓ output = tokens written back (write/append/edit/chunk)
       ✦ think  = reasoning tokens while the file was NAMED in the step's
         thought (honest attribution: only files this session already touched
         are candidates; no name → no attribution)
     Cosmetic telemetry — every path is try/caught; a missing WSUI or a stub
     U never breaks a tool call. Rendered by WSUI.fileBurn (ui-workspace.js). */
  fileBurn: new Map(),

  _renderFileBurn() {
    try { if (typeof WSUI !== "undefined" && WSUI && typeof WSUI.fileBurn === "function") WSUI.fileBurn(this.fileBurn); } catch { /* panel is cosmetic */ }
  },

  _noteFileUse(name, args, ok, content) {
    try {
      const txt = String(content ?? "");
      const tok = U.estimateTokens(txt);
      if (!tok) return;
      const now = Date.now();
      const touch = (p, share, kind, tool) => {
        p = String(p || "").trim();
        if (!p || p === "/" || share <= 0) return;
        const e = this.fileBurn.get(p) || { intake: 0, output: 0, think: 0, calls: 0, lastTool: "", lastTs: 0 };
        if (kind === "intake") e.intake += share; else e.output += share;
        e.calls++; e.lastTool = tool; e.lastTs = now;
        this.fileBurn.set(p, e);
      };
      if (name === "read") {
        const hdr = /^===== (.+?)( \(FAILED\))? =====$/gm;
        const marks = []; let m2;
        while ((m2 = hdr.exec(txt))) marks.push({ path: m2[1], failed: !!m2[2], start: m2.index, bodyAt: m2.index + m2[0].length });
        if (marks.length) { // multi-file / multi-slice read — EXACT per-section attribution
          for (let i = 0; i < marks.length; i++) {
            if (marks[i].failed) continue;
            const body = txt.slice(marks[i].bodyAt, i + 1 < marks.length ? marks[i + 1].start : txt.length);
            touch(marks[i].path, U.estimateTokens(body), "intake", "read");
          }
        } else if (ok) { // single read — the whole result came from that file
          const ps = this._paths(args.path);
          if (ps.length === 1) touch(ps[0], tok, "intake", "read");
        }
        const specsArr = Array.isArray(args.reads) ? args.reads : (Array.isArray(args.slices) ? args.slices : null);
        const lead = specsArr && specsArr.length
          ? this._paths(specsArr[specsArr.length - 1]?.path !== undefined ? specsArr[specsArr.length - 1].path : specsArr[specsArr.length - 1]?.paths)[0]
          : this._paths(args.path)[0];
        if (lead) { try { WSUI.editing(lead, null, `read · +${U.fmtTokens(tok)} tok`, "agent"); } catch { /* window optional */ } }
      } else if (name === "grep" || name === "find") {
        if (ok) {
          // EXACT attribution: only files whose path:LINE: / path: N rows actually shipped.
          // hf.15 — intersect with the call's roots so count-mode's "TOTAL: N"
          // tail line (and any match text that merely LOOKS like a row) can
          // never invent a fake file entry ("TOTAL" has no "/" — the VFS
          // norm guarantees every real path starts with "/").
          const roots0 = Array.isArray(args.path) ? this._paths(args.path)
            : (args.path ? [VFS.norm(String(args.path))] : ["/"]);
          const realRoot = (p) => roots0.includes("/") || p.startsWith("/") && roots0.some(r => r === "/" ? p.startsWith("/") : (p === r || p.startsWith(r + "/")));
          const hit = new Set(); let rm;
          const reRow = /^([^:\n]+):(?:\d+): /gm;
          while ((rm = reRow.exec(txt))) if (rm[1].includes("/") && realRoot(rm[1])) hit.add(rm[1]);
          const reCnt = /^([^:\n]+): \d+$/gm;
          while ((rm = reCnt.exec(txt))) if (rm[1].includes("/") && realRoot(rm[1])) hit.add(rm[1]);
          if (hit.size) { const per = Math.round(tok / hit.size); for (const p of hit) touch(p, per, "intake", name); }
          const lead = hit.size ? [...hit][hit.size - 1] : null;
          if (lead) { try { WSUI.editing(lead, null, `${name} · +${U.fmtTokens(tok)} tok`, "agent"); } catch { /* window optional */ } }
        }
      } else if (name === "scan") {
        const mf = String(args.manifest || args.dir || args.path || "");
        if (ok && mf) touch(mf, tok, "intake", "scan");
      } else if (name === "write" || name === "append" || name === "edit" || name === "chunk" || name === "split") {
        const ps = this._paths(args.path);
        // hf.15 — output tok measured from what was WRITTEN (args content/replace),
        // not from the one-line report the tool ships back (a 400-char write is
        // 100 output tokens, its "wrote /w.txt (400 chars)" report is ~6)
        const payload = args.content != null ? String(args.content)
          : (name === "edit" && args.replace != null ? String(args.replace) : txt);
        const per = ps.length ? Math.max(1, Math.round(U.estimateTokens(payload) / ps.length)) : 0;
        for (const p of ps) touch(p, per, "output", name); // writes publish their own lead row with line numbers
      }
      this._renderFileBurn();
    } catch { /* telemetry never breaks a tool */ }
  },

  /* reasoning-token attribution — the step's ✦ tokens land on the file the
     thought NAMED LAST among files this session already touched. Honest by
     construction: nothing named → nothing attributed. */
  _noteThink(text, tok) {
    try {
      tok = Number(tok) || 0;
      if (tok <= 0 || !this.fileBurn.size) return;
      const t = String(text || "");
      if (!t) return;
      let best = null, bestAt = -1;
      for (const p of this.fileBurn.keys()) {
        const base = p.split("/").pop();
        let at = t.lastIndexOf(base);
        if (base !== p && t.lastIndexOf(p) > at) at = t.lastIndexOf(p);
        if (at > bestAt) { bestAt = at; best = p; }
      }
      if (!best || bestAt < 0) return;
      const e = this.fileBurn.get(best);
      e.think += tok; e.lastTs = Date.now();
      this._renderFileBurn();
    } catch { /* cosmetic */ }
  },

  /* hf.11 — ONE-WORD TOOL NAMES + the big-file thresholds. The TOOLS registry
     below carries the SHORT canonical spellings the model sees; every legacy
     long name (fs_write, flat_find, ledger_*, …) resolves through ALIAS at
     execTool entry, so old habits, old history and old prompts keep working.
     Thresholds ride the SAME class lines as the read gate: one write/append/
     chunk call ships ≤ BIG_CALL_CAP chars; a file ≥ LARGE_FILE (30 KB — the
     read gate ships it as slices, never whole) is the LARGE-FILE class: build
     it with chunk, edit it via split → scan → edit parts → assemble — never
     whole. */
  BIG_CALL_CAP: 16384, // hf.11 — one write/append/chunk call ships ≤16k chars (fs_read's 16k-char read economy, mirrored onto the write path)
  LARGE_FILE: 30720,   // hf.14 — ≥30 KB = LARGE-FILE class (== BIG_READ_CAP: ships as slices, never whole ⇒ must not be written whole either; append stays the safe incremental edit path)

  ALIAS: { fs_list: "list", fs_tree: "tree", fs_digest: "digest", fs_read: "read", fs_write: "write", fs_append: "append", fs_write_chunked: "chunk", chunkwrite: "chunk", write_chunked: "chunk", chunk_write: "chunk", fs_delete: "delete", fs_move: "move", fs_mkdir: "mkdir", zip_add: "zipadd", ws_clear: "clear", flat_find: "find", flat_edit: "edit", ledger_split: "split", ledger_find: "scan", ledger_check: "check", ledger_assemble: "assemble", state_save: "state", run_python: "py", run_js: "js", open_preview: "preview", image_probe: "probe", grep_o: "grep", grepall: "grep" },

  TOOLS: [
    { name: "list", description: "List the direct children of a workspace folder (name · type · size, dirs first).", parameters: { type: "object", properties: { path: { type: "string", description: "Folder path, / = workspace root (default /)" } } } },
    { name: "tree", description: "Recursive tree snapshot of the workspace (or a subtree) — flat rows with depth indent. For a size/preview survey use digest instead.", parameters: { type: "object", properties: { path: { type: "string", description: "Root of the subtree (default /)" } } } },
    { name: "digest", description: "ADE-S14.1: survey a subtree in ONE cheap call — one line per file (path · size · lines · first-line preview). ALWAYS survey before bulk reading; never read a folder file-by-file. max caps rows.", parameters: { type: "object", properties: { path: { type: "string", description: "Root of the subtree (default /)" }, max: { type: "integer", description: "Max rows (default 400, cap 2000)" } } } },
    { name: "head", description: "hf.16 — first N lines of file(s): the dedicated chunked HEAD read (read mode:'head' as a first-class tool). MULTI-FILE: path accepts ONE path or an ARRAY — per-file sections under ===== path ===== headers sharing one output budget. Any file size: a ≥30 KB LARGE-FILE-class file ships its head slice + the slice plan, never whole. Lines cap at 800 chars with an honest …[+N chars] marker.", parameters: { type: "object", properties: { path: { description: "File path — or an ARRAY of paths (one call, per-file sections)" }, n: { type: "integer", description: "Lines to ship (default 40, cap 400)" } }, required: ["path"] } },
    { name: "tail", description: "hf.16 — last N lines of file(s): the dedicated chunked TAIL read (read mode:'tail' as a first-class tool). TAIL KEEPS THE END: an over-cap tail keeps the LAST chars (line-aligned) and says how far back to re-read — the newest entries always ship. MULTI-FILE: path accepts ONE path or an ARRAY — per-file sections under ===== path ===== headers sharing one output budget. The cheap way to read a ledger's newest entries (no offset math, any file size).", parameters: { type: "object", properties: { path: { description: "File path — or an ARRAY of paths (one call, per-file sections)" }, n: { type: "integer", description: "Lines to ship (default 40, cap 400)" } }, required: ["path"] } },
    { name: "read", description: "Read text file(s) in slices — offset/limit (0-based line numbers) or mode 'head'/'tail'. MULTI-FILE: path accepts ONE path or an ARRAY of paths (a JSON-encoded array string coerces) — each file returns under a ===== path ===== header with its own slice, the whole answer sharing one output budget (each file says '… N lines skipped — re-read with offset' when it has more). MULTI-SLICE (hf.15): reads:[{path, offset?, limit?, mode?}, …] performs SEVERAL chunk-scoped reads in ONE call — several offsets of one file, several files, or a mix (each spec may also carry paths:[…]); batch your slices instead of firing parallel read calls. A whole read NEVER refuses: over the 16k-char cap it returns the head slice + skip note; over the 30 KB LARGE-FILE line it returns the head slice + the slice plan (next offset · ≈slice count · the grep jump). ≥30 KB files are the LARGE-FILE class — they never ship whole. Binary files are refused with their size. Single lines are capped at 800 chars with a …[+N chars] marker.", parameters: { type: "object", properties: { path: { description: "File path — or an ARRAY of paths to read several files in one call" }, reads: { type: "array", description: "MULTI-SLICE — an array of chunk-scoped read specs run in ONE call: {path (or paths:[…]), offset?, limit?, mode?} per entry (cap 12). Use this instead of several parallel read calls", items: { type: "object", properties: { path: { description: "File path — or an ARRAY of paths (the same slice applies to each)" }, offset: { type: "integer", description: "0-based start line" }, limit: { type: "integer", description: "Max lines" }, mode: { type: "string", enum: ["head", "tail"] } } } }, offset: { type: "integer", description: "0-based start line (default 0)" }, limit: { type: "integer", description: "Max lines to return (default 400 when slicing)" }, mode: { type: "string", enum: ["head", "tail"], description: "head = first N lines · tail = last N (offset ignored)" } }, required: ["path"] } },
    { name: "write", description: "Write (create or FULLY replace) a text file; parent folders auto-created; mirrors to the linked work folder. hf.11: one call ships ≤16384 chars — a bigger content is REFUSED: build the file with chunk (one call per ≤16k piece, the final index auto-assembles). ≥30 KB files are the LARGE-FILE class — always the chunk suite, never a whole write.", parameters: { type: "object", properties: { path: { type: "string", description: "File path" }, content: { type: "string", description: "Full file content (≤16384 chars)" } }, required: ["path", "content"] } },
    { name: "append", description: "Append text to file(s) — creates missing files. hf.12 MULTI-FILE: path accepts ONE path or an ARRAY of paths — the same content lands on every file, each result reported per file (a missing file is created, a failed file never blocks the others). hf.11: one call appends ≤16384 chars — bigger: split the append across calls, or build with chunk. Appending is the SAFE edit on a ≥30 KB LARGE-FILE-class file: it never reads the file into the conversation.", parameters: { type: "object", properties: { path: { description: "File path — or an ARRAY of paths (same content appended to each)" }, content: { type: "string", description: "Text to append (≤16384 chars)" } }, required: ["path", "content"] } },
    { name: "chunk", description: "ADE-hf.11 CHUNKED BIG-WRITE — build a large file FROM THE FIRST TOOL CALL: one call ships ONE ≤16k-char chunk to the workstation; the FINAL index auto-assembles + verifies. Start: {path, index:0, total:N, content} opens <path>.chunks/ staging (size + digest recorded per chunk). Continue index 1…N−1 (out-of-order is fine; identical re-sends are idempotent; a cut run resumes — {path, status:true} lists state, {path, abort:true} discards). Final call: every part re-verified from storage, byte-exact target written, one-shot .pre-chunkwrite.bak of a replaced target, staging cleaned; the report carries chars · lines · digest. ANY new file >16k chars — and the ≥30 KB LARGE-FILE class — MUST go through here; never draft a big file in reply text.", parameters: { type: "object", properties: { path: { type: "string", description: "TARGET file path (the <path>.chunks/ staging dir is tool-owned)" }, index: { type: "integer", description: "0-based chunk index (the final index = total−1 triggers the compile)" }, total: { type: "integer", description: "Total chunk count 1–500 — keep it consistent across calls" }, content: { type: "string", description: "This chunk's text (≤16384 chars)" }, expectBytes: { type: "integer", description: "Optional final-call check: refuse the compile unless the assembled length equals this" } }, required: ["path", "index", "total", "content"] } },
    { name: "delete", description: "Delete a file, or a folder recursively.", parameters: { type: "object", properties: { path: { type: "string", description: "File or folder path" } }, required: ["path"] } },
    { name: "move", description: "Rename or move a file/folder (moving a folder re-paths its whole subtree; target dir = move inside).", parameters: { type: "object", properties: { from: { type: "string", description: "Source path" }, to: { type: "string", description: "Destination path (or existing dir to move into)" } }, required: ["from", "to"] } },
    { name: "mkdir", description: "Create a folder (parents auto-created, idempotent).", parameters: { type: "object", properties: { path: { type: "string", description: "Folder path" } }, required: ["path"] } },
    { name: "unzip", description: "ADE-HF.8: unpack a .zip from the workspace into a workspace folder, structure preserved (fflate, pure JS — no python). Existing files are KEPT and counted as skipped unless overwrite:true.", parameters: { type: "object", properties: { path: { type: "string", description: "Zip file path in the workspace" }, dest: { type: "string", description: "Target folder (default / = workspace root)" }, overwrite: { type: "boolean", description: "true = replace existing files (default: keep them)" } }, required: ["path"] } },
    { name: "rezip", description: "ADE-HF.8: pack the workspace (or a subtree) into a .zip INSIDE the workspace (pure JS — no python).", parameters: { type: "object", properties: { path: { type: "string", description: "Zip file to create (default /workspace.zip)" }, src: { type: "string", description: "Subtree to pack (default / = whole workspace)" } } } },
    { name: "zipadd", description: "ADE-HF.8: APPEND the current workspace version into a .zip — workspace files overwrite same-named entries, zip-only entries are KEPT (incremental versioning: pack, edit, pack again). If the zip does not exist it is created (acts like rezip).", parameters: { type: "object", properties: { path: { type: "string", description: "Zip file to create or update" }, src: { type: "string", description: "Subtree to pack (default / = whole workspace)" }, fresh: { type: "boolean", description: "true = ignore existing zip content and rebuild from the workspace only" } }, required: ["path"] } },
    { name: "clear", description: "ADE-HF.8: wipe the workstation — delete EVERY file and folder in the workspace VFS (a linked disk work folder is NOT touched). The call is REFUSED unless confirm is exactly true.", parameters: { type: "object", properties: { confirm: { type: "boolean", description: "Must be exactly true — anything else is refused" } } } },
    { name: "find", description: "ADE-HF.8: search flat text files (.flat.txt, code, logs) for a literal pattern (or regex) — returns capped 'path:LINE: text' hits. Cheap: one call surveys every text file under path. hf.12 MULTI: path accepts a single file, a folder, or an ARRAY of files/folders searched in one call. Use the line numbers with read offset to pull context.", parameters: { type: "object", properties: { pattern: { type: "string", description: "Text to find (literal by default)" }, path: { description: "File, folder — or an ARRAY of files/folders (default / = every text file)" }, regex: { type: "boolean", description: "true = pattern is a JS RegExp" }, ignore_case: { type: "boolean", description: "Case-insensitive match" }, max: { type: "integer", description: "Max hits returned (default 40, cap 200)" } }, required: ["pattern"] } },
    { name: "grep", description: "hf.15 — the DEDICATED -o extractor (grep -o for the VFS): run a REGEX over file(s) and ship ONLY the matches — the file body never enters the conversation. MULTI-FILE + CHUNK-COMPATIBLE: path accepts one file, a folder, or an ARRAY (a JSON-encoded array string coerces) — search many files in ONE call — and files of ANY size (a 30 KB+ LARGE-FILE-class file is its home turf). Capture groups: group:1 ships group 1 · group:'all' joins groups with '·' (no groups → the whole match). Modes: 'hits' (default — path:LINE: match) · 'only' (bare matches) · 'count' (per-file counts + total). unique:true dedupes with per-match counts. CHUNKED OUTPUT: max caps rows per page and offset:N pages forward — a capped result continues with {…, offset:N} instead of a bigger max; context:1-5 ships that many lines around each hit (hits mode). One call lists every id:'…' inventory in a huge file.", parameters: { type: "object", properties: { pattern: { type: "string", description: "JS RegExp (native) — or a plain substring with literal:true" }, path: { description: "File, folder — or an ARRAY of files/folders (default / = every text file)" }, group: { description: "Capture group to ship: 0 = whole match (default) · 1–9 = that group · 'all' = groups joined with '·'" }, mode: { type: "string", enum: ["hits", "only", "count"], description: "hits = path:LINE: match · only = bare matches one per line · count = per-file counts + total" }, unique: { type: "boolean", description: "true = dedupe matches (first-seen order + ×count)" }, context: { type: "integer", description: "hf.15 — 1–5 lines of context shipped around each hit (hits mode; overlapping windows dedupe)" }, offset: { type: "integer", description: "hf.15 — 0-based row skip: page the result (offset:100 ships rows 101+; the tail note names the next offset)" }, literal: { type: "boolean", description: "true = pattern is a literal substring (no regex)" }, ignore_case: { type: "boolean", description: "Case-insensitive" }, max: { type: "integer", description: "Max shipped rows per page (default 100, cap 400)" } }, required: ["pattern"] } },
    { name: "edit", description: "ADE-HF.8: patch flat file(s) with an EXACT literal find→replace (not regex). hf.12 MULTI-FILE: path accepts ONE path or an ARRAY of paths — the same patch is applied per file with per-file results (a file with 0 matches is reported unchanged, it never blocks the others; expect/all apply per file). Refuses when find matches more than once unless all:true; reports replacements + size/line delta. The safe way to flip statuses and patch lines in .flat.txt.", parameters: { type: "object", properties: { path: { description: "File to edit — or an ARRAY of files (same patch on each)" }, find: { type: "string", description: "Exact text to replace — copy it from find / read output (whitespace matters)" }, replace: { type: "string", description: "New text (empty string = delete the find-text)" }, all: { type: "boolean", description: "true = replace every occurrence (default: more than one match is refused)" }, expect: { type: "integer", description: "Refuse unless exactly this many occurrences matched (safety check, per file)" } }, required: ["path", "find", "replace"] } },
    { name: "split", description: "ADE-hf.10: split a huge flat file (≥30 KB — the LARGE-FILE class) into raw part files + manifest.json in <name>.parts/. Parts are byte-exact slices with NO added headers, so reassembly is lossless. by lines (N lines/part) · bytes (line-aligned ~N B/part — default 15 KB so every part reads WHOLE in one call) · marker (per-line RegExp that STARTS a part — sections stay intact). Then: scan across parts, edit parts part-local, check, assemble rebuilds the master. The big file never enters context whole.", parameters: { type: "object", properties: { path: { type: "string", description: "Big file to split" }, by: { type: "string", enum: ["lines", "bytes", "marker"], description: "Split unit (default lines)" }, value: { type: "string", description: "lines: lines/part (50-5000, default 400) · bytes: bytes/part (4096-262144, default 15360 — one-call readable parts) · marker: per-line RegExp that begins a new part (e.g. '^## ')" }, out: { type: "string", description: "Parts folder (default <name>.parts/ beside the source)" } }, required: ["path"] } },
    { name: "scan", description: "ADE-hf.10: search across ALL ledger parts (from split) in one cheap call — capped 'part:LINE (master LNNN): text' hits. Literal by default; regex:true to switch (same rules as find). Never read a part blind — scan first.", parameters: { type: "object", properties: { manifest: { type: "string", description: "manifest.json path OR the .parts folder" }, pattern: { type: "string", description: "Text to find (literal by default)" }, regex: { type: "boolean", description: "true = pattern is a JS RegExp" }, ignore_case: { type: "boolean", description: "Case-insensitive" }, max: { type: "integer", description: "Max hits (default 40, cap 200)" } }, required: ["manifest", "pattern"] } },
    { name: "check", description: "ADE-hf.10: re-digest every ledger part against the split manifest — clean / DRIFTED (byte delta + digest) / MISSING per part. Drift = the part was edited since the split (expected when patching); assemble then needs expect_drift:true.", parameters: { type: "object", properties: { manifest: { type: "string", description: "manifest.json path OR the .parts folder" } }, required: ["manifest"] } },
    { name: "assemble", description: "ADE-hf.10: surgically reassemble ledger parts → master file in manifest order, digest-verified, byte-exact. Refuses when parts drifted unless expect_drift:true (which refreshes the manifest digests for the next round). Writes a one-shot .pre-assemble.bak of a changed target. The delivery step for chunked ledger work.", parameters: { type: "object", properties: { manifest: { type: "string", description: "manifest.json path OR the .parts folder" }, to: { type: "string", description: "Target file (default: the original source path)" }, expect_drift: { type: "boolean", description: "true = accept intentionally-edited parts and refresh manifest digests" } }, required: ["manifest"] } },
    { name: "state", description: "ADE-hf.10: mid-run STAGE CHECKPOINT — rewrite /ade.state.flat.txt (task/done/next/flags, same format as the reply-end <<<STATE block) so a crash, context cut or closed tab at a stage boundary never costs a re-discovery. Call at milestones: discovery done · plan locked · long stage finished. Keep it terse; bigger artifacts belong in workspace files the lines point to.", parameters: { type: "object", properties: { task: { type: "string", description: "One line — the current task" }, done: { type: "string", description: "Steps already finished, semicolon-separated" }, next: { type: "string", description: "The ONE exact next action" }, flags: { type: "string", description: "Up to 3 open items (default none)" } } } },
    { name: "shell", description: "Run one VIRTUAL-shell command line over the workspace VFS (not an OS shell): ls cat head tail touch mkdir rm cp mv find grep wc echo tree stat du digest python js pip open download pwd cd clear seed date whoami help · && chains · > >> redirects.", parameters: { type: "object", properties: { command: { type: "string", description: "The command line, e.g. ls -l src/ or python demo/hello.py" } }, required: ["command"] } },
    { name: "py", description: "LAST RESORT (ADE-HF.8 — the user does not want python for file/archive/flat-file work; unzip · rezip · zipadd · find · edit cover all of that). Only for tasks that genuinely need python libs (numpy/pandas/matplotlib). Pyodide first run pulls ~10MB after user approval; writes sync back into the workspace. Pass inline code or a workspace path.", parameters: { type: "object", properties: { code: { type: "string", description: "Python source to run inline" }, path: { type: "string", description: "…or a .py file path in the workspace" } } } },
    { name: "js", description: "Execute JavaScript in a sandboxed dedicated worker (no DOM; console.* bridged; top-level await OK; 10s timeout). hf.12: pass files:[paths] to PRELOAD workspace text files into the sandbox as a global FS map (FS['frame-scape-music/framescape-lab.js'] → full text) — the worker has NO network and NO module imports, so this is the only way code there sees workspace files; results come back via console.log (capped) — print digests/counts, never whole files. Pass inline code or a workspace path.", parameters: { type: "object", properties: { code: { type: "string", description: "JS source to run inline" }, path: { type: "string", description: "…or a .js file path in the workspace" }, files: { description: "Workspace file path(s) — string or array — preloaded into the sandbox as the global FS map (path → text)" } } } },
    { name: "preview", description: "Open an HTML file from the workspace in the sandboxed preview iframe (sibling css/js/img inlined from the VFS; console bridged).", parameters: { type: "object", properties: { path: { type: "string", description: "HTML file path" } }, required: ["path"] } },
    { name: "probe", description: "ADE-HF.9: decode a workspace image and MEASURE it — pixel dimensions, alpha-silhouette bbox (figure extremities), luminance edge transitions along given rows/columns, average RGBA per grid cell. The agent measures from NUMBERS, never guesses. No decoder in this context → honest refusal; the measurement must then be recorded as \"seed value, not verified\". Crop to a region for precision.", parameters: { type: "object", properties: { path: { type: "string", description: "Image file path in the workspace" }, crop: { type: "array", items: { type: "integer" }, description: "[x, y, w, h] region to scan (default: whole image)" }, rows: { type: "array", items: { type: "integer" }, description: "y lines to scan for edge transitions (≤8)" }, cols: { type: "array", items: { type: "integer" }, description: "x columns to scan for edge transitions (≤8)" }, grid: { type: "integer", description: "n×n grid of average-RGBA cells (2–8)" }, alpha: { type: "integer", description: "alpha threshold for the silhouette bbox (1–254, default 128)" }, luma: { type: "integer", description: "luminance delta that counts as an edge (1–254, default 40)" } }, required: ["path"] } },
    { name: "caps", description: "Environment capability report — what actually works right now (workspace contents, work-folder link, runtimes, tool list). {deep:true} = full inventory incl. the shell command table + budgets. ADE-HF.3: this tool was advertised in the prompt but missing from the registry — the agent's one successful call burned a turn on 'unknown tool'.", parameters: { type: "object", properties: { deep: { type: "boolean", description: "true = full inventory (agent tools with arg names · shell commands · budgets · version)" } } } }
  ],

  /* full FA class lists — the trace cards in ui-chat.js read these (hf.11: keyed by the ONE-WORD canonical names) */
  ICONS: {
    list: "fa-solid fa-folder-tree", tree: "fa-solid fa-folder-tree",
    digest: "fa-solid fa-table-list",
    read: "fa-solid fa-file-lines", write: "fa-solid fa-file-pen",
    append: "fa-solid fa-file-circle-plus", chunk: "fa-solid fa-layer-group",
    delete: "fa-solid fa-trash-can",
    move: "fa-solid fa-right-left", mkdir: "fa-solid fa-folder-plus",
    shell: "fa-solid fa-terminal", py: "fa-brands fa-python",
    js: "fa-brands fa-js", preview: "fa-brands fa-html5",
    caps: "fa-solid fa-circle-info",
    probe: "fa-solid fa-ruler-combined",
    split: "fa-solid fa-scissors", scan: "fa-solid fa-magnifying-glass-chart", grep: "fa-solid fa-magnifying-glass-plus",
    check: "fa-solid fa-clipboard-check", assemble: "fa-solid fa-puzzle-piece",
    state: "fa-solid fa-floppy-disk",
    unzip: "fa-solid fa-file-zipper", rezip: "fa-solid fa-box-archive", zipadd: "fa-solid fa-plus", clear: "fa-solid fa-broom"
  },

  /* output cap with an explicit truncation note (f1 contract)
     ADE-S13.7 (ch-18.f5, m-33 field report): fs_list / fs_tree / shell called
     _cap(text) with NO limit → "showing undefined of N chars" in the agent's
     tool output. limit now defaults to OUT_CAP. */
  _cap(text, limit, isRead) {
    const s = String(text ?? "");
    if (limit == null) limit = this.OUT_CAP; // ADE-S13.7 — no more "undefined" in truncation notes
    if (s.length <= limit) return s;
    return s.slice(0, limit) + `\n…[truncated — showing ${limit} of ${s.length} chars${isRead ? " — narrow with shell grep/sed/head" : ""}]`;
  },

  /* hf.11 — resolve a requested tool name to its canonical registry spelling.
     Case-insensitive; unknown names pass through untouched (the default case
     teaches with the real registry list + logs the gap). */
  canon(n) {
    const k = String(n ?? "").trim().toLowerCase();
    return this.ALIAS[k] || k;
  },

  /* hf.12 — one file through the FULL read pipeline (seamless slice gate ·
     head/tail · past-EOF guard · 800-char line cap · per-file cap note).
     Extracted from the read case so the MULTI-FILE form can reuse it verbatim
     per file: the multi answer is literally N single-file reads joined under
     ===== path ===== headers, sharing one output budget. */
  async _readOne(p, args, done) {
    const txt = await VFS.readText(p);
    if (txt == null) {
      const row = await VFS.get(p);
      if (row && row.kind === "file") return done(false, `binary file (${row.size} bytes) — not displayed; shell 'download ${p}' or write to replace`);
      return done(false, `not found: ${p}`);
    }
    /* ══ ADE-S14.4 (ch-20.f4, m-35) · FS_READ PAGINATION — hf.14 SEAMLESS ══
       Huge files are read in SLICES — offset/limit (0-based lines)
       or mode 'head'/'tail'. A whole read NEVER refuses (hf.14):
       16–30 KB ships a head slice + skip note; a whole read over the
       30 KB LARGE-FILE line ships the same slice PLUS the slice plan
       (exact next offset · ≈slice count · the grep jump) — one call
       always returns usable content and the exact way to continue.
       (hf.12 refused >50 KB whole: the refusal shipped zero content,
       the model burned a turn, then re-asked blind.)            */
    const lines = txt.split("\n");
    const total = lines.length;
    const DEF = 400; // default slice when no limit is given
    let mode = (args.mode === "head" || args.mode === "tail") ? args.mode : null;
    const off = Number.isFinite(Number(args.offset)) ? Math.max(0, Math.floor(Number(args.offset) || 0)) : 0;
    const lim = Number.isFinite(Number(args.limit)) && Number(args.limit) > 0 ? Math.floor(Number(args.limit)) : null;
    const wholeAsk = !mode && !lim && off === 0;
    const overLarge = wholeAsk && txt.length > this.BIG_READ_CAP; // hf.14 — whole read of a >30 KB LARGE-FILE-class file
    if (wholeAsk && txt.length > this.READ_CAP) mode = "head"; // over-cap whole read → head slice + skip note (any band above 16k)
    let body, from, branch;
    if (wholeAsk && !mode) {
      branch = "whole"; body = txt; from = 0; // whole file fits the cap
    } else {
      const n = lim || DEF;
      if (mode === "head") {
        branch = "head"; from = 0; body = lines.slice(0, n).join("\n");
      } else if (mode === "tail") {
        branch = "tail"; from = Math.max(0, total - n); body = lines.slice(from).join("\n");
        /* ADE-HF.8 (ch-33) — TAIL KEEPS THE END: a tail slice over READ_CAP
           used to keep its HEAD (the _cap default), so the newest lines —
           the whole point of tail — were silently cut (field case: a 21.8k
           tail on rigging.session.planner.flat.txt stopped mid-worklog.4 and
           the true last entry worklog.5 was invisible → the model concluded
           the wrong queue state). Over-cap tails now keep the LAST chars,
           aligned to a line start, and say how far back to re-read. */
        if (body.length > this.READ_CAP) {
          const keep = [];
          let size = 0;
          for (let i = total - 1; i >= from; i--) {
            if (size + lines[i].length + 1 > this.READ_CAP - 600 && keep.length) break; // 600 = head line + skip note margin
            keep.push(lines[i]); size += lines[i].length + 1;
          }
          keep.reverse();
          body = keep.join("\n"); from = total - keep.length;
        }
      } else {
        /* hf.10 — PAST-EOF GUARD. Field trace: fs_read {offset:668} on a
           416-line file clamped onto the phantom trailing-newline element
           and answered "lines 416–415 of 416 · 1 line skipped — re-read
           with offset 415" — a lying loop invitation. Offsets past the
           end now refuse honestly with the valid range. */
        if (off >= total) return done(false, `[read: offset ${off} is past EOF — ${p} has ${total} line${total === 1 ? "" : "s"} (valid offsets 0–${total - 1}). Re-read with a smaller offset, or mode:'tail' limit N for the end.]`);
        branch = "mid"; from = Math.min(off, Math.max(0, total - 1));
        body = lines.slice(from, from + n).join("\n");
      }
    }
    // f4.line.cap — a very long single line (the 500 KB ledgers have them) is capped with an honest +N marker, never silently
    const LINE_CAP = 800;
    const capped = body.split("\n").map(L => L.length > LINE_CAP ? L.slice(0, LINE_CAP) + `…[+${L.length - LINE_CAP} chars on this line — find it, or read a narrower column with shell cut/sed]` : L).join("\n");
    /* hf.14 — BUDGET the shipped body so the final _cap guard never cuts
       mid-content: the head line + notes ride INSIDE the envelope, and the
       slice note is derived from what the model will actually SEE. (Field
       seam: a 400-line slice of fat ledger rows overflowed the cap, _cap
       cut the text AFTER the note was written, and "re-read with offset
       145" pointed past lines the model never received.)
       hf.15 — a SHARED budget (_capOverride from the multi-file/multi-slice
       forms) reserves a proportional margin (≤400 chars: head line + skip
       note + header) instead of the full single-read 1200 — at override
       1200 the old margin left a 0-char envelope (empty bodies). */
    const ovr = Number(args._capOverride) || 0;
    const margin = ovr ? Math.min(400, Math.max(120, Math.floor(ovr / 4))) : 1200;
    const ENV = (ovr || (this.READ_CAP + 400)) - (branch === "whole" ? Math.min(400, margin) : margin);
    let ship = capped;
    if (ship.length > ENV) {
      ship = ship.slice(0, Math.max(0, ENV));
      const nl = ship.lastIndexOf("\n");
      if (nl > 0) ship = ship.slice(0, nl); // back to a whole line (a single fat line keeps its capped 800)
    }
    const shown = body ? ship.split("\n").length : 0;
    const end = from + shown;
    let skipNote = "";
    if (branch === "head") {
      const skipped = Math.max(0, total - end);
      if (skipped > 0) skipNote = `… ${skipped} line${skipped === 1 ? "" : "s"} skipped — re-read with offset ${end} (or mode:'tail' limit ${lim || DEF} for the end)`;
    } else if (branch === "tail") {
      if (from > 0) skipNote = `… ${from} leading line${from === 1 ? "" : "s"} skipped — re-read with offset 0 limit ${from}`;
    } else if (branch === "mid") {
      const skipped = Math.max(0, total - end);
      if (skipped > 0 && shown === 0) skipNote = `(offset ${off} lands on the trailing newline — no visible content; the last real line is at offset ${Math.max(0, total - 2)})`; // hf.10 — never invite a re-read loop
      else if (skipped > 0) skipNote = `… ${skipped} line${skipped === 1 ? "" : "s"} skipped — re-read with offset ${end}`;
    }
    if (overLarge) { // hf.14 — the slice plan rides EVERY whole read of a >30 KB file (seamless: no dead-end refusals)
      const n = lim || DEF;
      const slices = Math.max(2, Math.ceil(total / n));
      skipNote = (skipNote ? skipNote + "\n" : "") + `⚑ LARGE-FILE class — ${(txt.length / 1024).toFixed(0)} KB · ${total} line${total === 1 ? "" : "s"} never ships whole (>${this.BIG_READ_CAP / 1024} KB). Walk the slices: read offset ${end} then +${n} … (≈${slices} slice${slices === 1 ? "" : "s"} to cover) · or grep {pattern, path:"${p}"} to jump to the exact lines (matches only, any size) · to change it: append, or split → scan → edit → assemble`;
    }
    const head = `[read ${p} · lines ${total ? from + 1 : 0}${shown ? "–" + end : ""} of ${total}${mode ? " · " + mode : ""}]`; // hf.10 — no more "416–415" nonsense when nothing is shown
    return done(true, this._cap(head + "\n" + ship + (skipNote ? "\n" + skipNote : ""), Number(args._capOverride) || (this.READ_CAP + 400), true));
  },

  async _grepZeroHint(pat, paths) {
    /* hf.16 — a 0-hit grep must TEACH the next move, not recite tool docs.
       Field case (2026-10-31 round-8): grep "t1[01]\d" on a ledger whose
       touch serials are written "t:100" answered with the generic
       literal-vs-regex hint — the real problem (the missing ':' separator)
       was invisible in it, and the run burned a turn guessing. The probe
       re-scans with cheaper matchers (bounded: ≤4 variants × ≤4 files, one
       linear pass each) and ships the first hit WITH a sample line, so the
       next call can copy the file's actual spelling. Digit-bearing lines
       are preferred as the sample when the pattern references digits. */
    const P = String(pat || "").slice(0, 60);
    const files = (paths || []).slice(0, 4);
    if (!files.length) return "no matches — no searchable text file under that path (see the binary-skipped note above, or fix the path roots)";
    const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const raw = String(pat || "");
    const leadM = raw.match(/^[^^$.*+?{}()[\]\\|]*/);
    const lead = (leadM ? leadM[0] : "").replace(/\^+/, "");
    const cands = [];
    if (lead.length >= 2) cands.push(["prefix \u201c" + lead.slice(0, 12) + "\u201d", esc(lead)]);
    const firstAlpha = (raw.match(/[A-Za-z]/) || [""])[0];
    if (firstAlpha) cands.push([lead.length >= 2 ? "shorter prefix \u201c" + firstAlpha + "\u201d" : "prefix \u201c" + firstAlpha + "\u201d", esc(firstAlpha)]);
    const wide = raw.replace(/\[[^\]]*\]/g, ".").replace(/\\[dDwWsSbB]/g, ".").replace(/[*+?]+$/, "");
    if (wide.length >= 2 && wide !== raw) cands.push(["widened /" + wide.slice(0, 28) + "/", wide]);
    cands.push(["literal \u201c" + P.slice(0, 28) + "\u201d", esc(raw.slice(0, 60))]);
    const wantDigit = /\d|\[0-9]/.test(raw);
    for (const [label, src] of cands.slice(0, 4)) {
      let re = null;
      try { re = new RegExp(src, "i"); } catch { continue; }
      let n = 0, sample = "", sampleD = "";
      for (const p of files) {
        let txt = null;
        try { txt = await VFS.readText(p); } catch { txt = null; }
        if (txt == null) continue;
        const lines = txt.split("\n");
        for (let i = 0; i < lines.length; i++) {
          re.lastIndex = 0;
          if (!re.test(lines[i])) continue;
          n++;
          if (!sample) sample = `${p}:${i + 1}: ${String(lines[i]).trim().slice(0, 120)}`;
          if (wantDigit && !sampleD && /\d/.test(lines[i])) sampleD = `${p}:${i + 1}: ${String(lines[i]).trim().slice(0, 120)}`;
          if (n >= 40 && sampleD) break;
        }
        if (n >= 40 && sampleD) break;
      }
      if (n) return `no matches for /${P}/ — but ${label} hits ${n}\u00d7 (ignore-case), e.g. ${sampleD || sample} — copy the file's actual spelling (separators like ':' \u00b7 case \u00b7 anchors), or add ignore_case:true / literal:true`;
    }
    return `no matches for /${P}/ — every probe missed (prefix \u00b7 widened \u00b7 literal \u00b7 ignore-case): the text is not under this path, or the wording differs — grep a distinctive short word from the target line instead, or survey the file (digest/head) to see its actual tokens`;
  },

  /* hf.12 — one file through the FULL edit pipeline (edits[] atomic multi-edit
     OR the single find→replace form). Extracted from the edit case so the
     MULTI-FILE form can run it per file: expect/all semantics stay per file,
     and a refused file never blocks the others in a multi call. */
  async _editOne(p, args, done) {
    /* hf.10 — MULTI-EDIT: {path, edits:[{find, replace, all?, expect?}, …]}.
       Sequential (each edit sees the previous applied), ATOMIC (any failed
       validation aborts EVERYTHING — the file is written only after all
       edits validate). Field trace: 4 status flips = 4 flat_edit round-
       trips; the multi form patches all of them in one call. */
    if (Array.isArray(args.edits)) {
      if (!p || p === "/") return done(false, "path required — edits[] patches ONE file per call (per-part edits across a ledger need one call per part)");
      if (!args.edits.length) return done(false, "edits[] is empty");
      if (args.edits.length > 40) return done(false, `edits[] has ${args.edits.length} entries (cap 40) — split the batch`);
      let txt = await VFS.readText(p);
      if (txt == null) {
        const row = await VFS.get(p);
        return done(false, row && row.kind === "file" ? `${p} is binary — edit works on text only` : `not found: ${p}`);
      }
      const orig = txt;
      const plan = [];
      for (let i = 0; i < args.edits.length; i++) {
        const e = args.edits[i] && typeof args.edits[i] === "object" ? args.edits[i] : {};
        const find = String(e.find ?? "");
        const repl = String(e.replace ?? "");
        if (!find) return done(false, `edits[${i}]: find is required (LITERAL text, not regex). NOTHING applied — the batch is atomic.`);
        const at = [];
        let idx = txt.indexOf(find);
        while (idx !== -1 && at.length <= 5000) { at.push(idx); idx = txt.indexOf(find, idx + find.length); }
        const count = at.length;
        if (Number.isFinite(Number(e.expect)) && Number(e.expect) > 0 && count !== Math.floor(Number(e.expect)))
          return done(false, `edits[${i}]: expected ${Math.floor(Number(e.expect))} occurrence(s), found ${count}. NOTHING applied — the batch is atomic (edits 0..${i - 1} rolled back).`);
        if (!count)
          return done(false, `edits[${i}]: no match — the find-text must match EXACTLY (copy from find/read output; whitespace matters). NOTHING applied — the batch is atomic (edits 0..${i - 1} rolled back).`);
        if (count > 1 && e.all !== true)
          return done(false, `edits[${i}]: find-text matches ${count}× — add all:true to THAT entry or make find longer. NOTHING applied — the batch is atomic.`);
        const firstLine = txt.slice(0, at[0]).split("\n").length;
        txt = e.all === true ? txt.split(find).join(repl) : txt.slice(0, at[0]) + repl + txt.slice(at[0] + find.length);
        const short = (x) => { const q = JSON.stringify(x); return q.length > 60 ? q.slice(0, 59) + "…" : q; };
        plan.push(`  [${i}] ×${count} at line ${firstLine}${count > 1 ? "+" : ""} · ${short(find)} → ${short(repl)}`);
      }
      await VFS.put(p, txt, true);
      try { WSUI.editing(p, 1, `flat_edit · ${args.edits.length} edits (multi)`, "agent"); } catch { /* window optional */ }
      const dL = txt.split("\n").length - orig.split("\n").length;
      return done(true, `${p}: ${args.edits.length} edit(s) applied atomically · ${orig.length} → ${txt.length} chars (${txt.length - orig.length >= 0 ? "+" : ""}${txt.length - orig.length}) · ${dL >= 0 ? "+" : ""}${dL} lines\n${plan.join("\n")}`);
    }
    const find = String(args.find ?? "");
    const repl = String(args.replace ?? "");
    if (!p || p === "/" || !find) return done(false, "path and find are required — find is LITERAL text (not regex); find first if unsure of the exact wording");
    const txt = await VFS.readText(p);
    if (txt == null) {
      const row = await VFS.get(p);
      return done(false, row && row.kind === "file" ? `${p} is binary — edit works on text only` : `not found: ${p}`);
    }
    const at = [];
    let idx = txt.indexOf(find);
    while (idx !== -1 && at.length <= 5000) { at.push(idx); idx = txt.indexOf(find, idx + find.length); }
    const count = at.length;
    if (!count) return done(false, `no match in ${p} — the find-text must match EXACTLY (copy it from find/read output; whitespace and case matter)`);
    if (Number.isFinite(Number(args.expect)) && Number(args.expect) > 0 && count !== Math.floor(Number(args.expect)))
      return done(false, `expected ${Math.floor(Number(args.expect))} occurrence(s), found ${count} — refusing (make find more specific or fix expect)`);
    if (count > 1 && args.all !== true)
      return done(false, `find-text matches ${count}× in ${p} — re-issue with all:true to replace every occurrence, or make find longer/more specific`);
    const firstLine = txt.slice(0, at[0]).split("\n").length;
    const out = args.all === true ? txt.split(find).join(repl) : txt.slice(0, at[0]) + repl + txt.slice(at[0] + find.length);
    await VFS.put(p, out, true);
    try { WSUI.editing(p, firstLine, `flat_edit · ${count} replacement${count === 1 ? "" : "s"}`, "agent"); } catch { /* window optional */ }
    const dL = out.split("\n").length - txt.split("\n").length;
    return done(true, `${p}: ${count} replacement${count === 1 ? "" : "s"} at line ${firstLine}${count > 1 ? "+" : ""} · ${txt.length} → ${out.length} chars (${out.length - txt.length >= 0 ? "+" : ""}${out.length - txt.length}) · ${dL >= 0 ? "+" : ""}${dL} lines`);
  },

  /* one tool call → { ok, content, ms }; NEVER throws */
  async execTool(name, args) {
    const t0 = Date.now();
    /* hf.15 — the central file-burn hook: every tool result flows through here,
       so the editing panel's per-file token ledger (↑ intake · ↓ output) stays
       live without each tool case remembering to publish. Never throws. */
    const done = (ok, content) => {
      try { this._noteFileUse(name, args, ok, content); } catch { /* cosmetic */ }
      return { ok, content, ms: Date.now() - t0 };
    };
    args = (args && typeof args === "object" && !Array.isArray(args)) ? args : {};
    this._coerceMulti(args); // hf.14 — a JSON-encoded array string for path/files becomes a REAL array (the field grep that searched 0 files)
    name = this.canon(name); // hf.11 — one-word canonical + legacy long names both resolve here
    try {
      switch (name) {
        case "list": {
          const p = VFS.norm(args.path || "/");
          if (!(await VFS.isDir(p))) return done(false, `not a folder: ${p}`);
          const rows = await VFS.list(p);
          const lines = rows.map(r => `${r.kind === "dir" ? "d" : "-"} ${String(r.size || 0).padStart(9)}  ${VFS.base(r.path)}${r.kind === "dir" ? "/" : ""}`);
          return done(true, this._cap(`${p}\n${lines.join("\n") || "(empty folder)"}`));
        }
        case "tree": {
          const root = VFS.norm(args.path || "/");
          const rows = await VFS.tree(root);
          const lines = rows.map(r => "  ".repeat(r.depth || 0) + VFS.base(r.path) + (r.kind === "dir" ? "/" : `  (${r.size || 0}B)`));
          return done(true, this._cap(lines.join("\n") || "(empty)"));
        }
        case "digest": {
          // ADE-S14.1 (ch-20.f1, m-35) + ADE-S23.2 (ch-21.f6, m-49): max knob + honest error guard
          const root = VFS.norm(args.path || "/");
          if (!(await VFS.exists(root))) return done(false, `not found: ${root}`);
          const max = Math.max(1, Math.min(2000, Math.floor(Number(args.max)) || 400));
          let table;
          try { table = await VFS.digestTable(root, max, this.LARGE_FILE); } // hf.14 — the survey flags ≥30 KB rows so slicing/splitting needs no trial-and-error
          catch (e) { return done(false, `digest failed: ${String((e && e.message) || e)} — try a narrower path`); }
          return done(true, this._cap(table));
        }
        case "read": {
          /* hf.15 — MULTI-SLICE READ (user call: "one read call — multiple
             single-file/multi-file chunk scoped reads"). The field log
             (2026-10-31 round-7): the agent fired THREE parallel read calls
             on the SAME ledger in one step (lines 21-28 · 107-119 · 1354)
             and two more on the lab — every one a separate turn of payload.
             reads:[{path|paths, offset?, limit?, mode?}, …] runs ALL of them
             in ONE call: every spec goes through the SAME _readOne pipeline,
             each file under a ===== path ===== header, one shared OUT_CAP
             budget with an honest per-slice share. Identical specs dedupe
             (idempotent re-sends); a failed spec ships as (FAILED) and never
             blocks its siblings. */
          const specsRaw = Array.isArray(args.reads) ? args.reads : (Array.isArray(args.slices) ? args.slices : null);
          if (specsRaw) {
            if (specsRaw.length > this.MULTI_PATH_MAX) return done(false, `reads has ${specsRaw.length} specs (cap ${this.MULTI_PATH_MAX}) — batch the rest into a second call`);
            const specs = specsRaw.filter(s => s && typeof s === "object" && !Array.isArray(s));
            if (!specs.length) return done(false, 'reads must be an array of slice specs: {"reads":[{"path":"a.txt","offset":20,"limit":9},{"path":"a.txt","offset":1353,"limit":3}]} — each spec: path (or paths:[…]) · offset? · limit? · mode?');
            const seenSpec = new Set();
            const units = [];
            for (const sp of specs) {
              const ps = this._paths(sp.path !== undefined ? sp.path : sp.paths);
              for (const p of ps) {
                const key = p + "|" + (sp.offset || 0) + "|" + (sp.limit || "") + "|" + (sp.mode || "");
                if (seenSpec.has(key)) continue; // identical re-send — idempotent
                seenSpec.add(key);
                units.push({ p, sp });
              }
            }
            if (!units.length) return done(false, "every reads[] spec needs a path — {path:'file.txt', offset?, limit?, mode?} (a spec may also carry paths:[f1,f2] for the same slice on several files)");
            const per = Math.max(1600, Math.floor((this.OUT_CAP - 60 * units.length) / units.length)); // honest per-slice share (same formula as the multi-file read)
            const parts = [];
            let failed = 0;
            for (const u of units) {
              const r = await this._readOne(u.p, { ...u.sp, _capOverride: per }, (ok, content) => ({ ok, content }));
              if (!r.ok) failed++;
              parts.push(`===== ${u.p}${r.ok ? "" : " (FAILED)"} =====\n${r.content}`);
            }
            const head = `[multi-slice read · ${specs.length} spec${specs.length === 1 ? "" : "s"} → ${units.length} slice${units.length === 1 ? "" : "s"}${failed ? ` · ${failed} failed` : ""} · shared budget ${this.OUT_CAP} chars — a slice cut short? re-read it alone with offset/limit]`;
            return done(true, this._cap(head + "\n\n" + parts.join("\n\n"), this.OUT_CAP, true));
          }
          /* hf.12 — MULTI-FILE READ: path = "file" (single, unchanged behavior)
             or ["f1","f2",…] → every file through the SAME _readOne pipeline,
             joined under ===== path ===== headers; the per-file cap shrinks so
             the JOINED answer stays inside one OUT_CAP budget and no single
             file can hog it. A 1-element array behaves exactly like the string. */
          const paths = this._paths(args.path);
          if (!paths.length) return done(false, "path required — a file path, an array of paths, or reads:[{path, offset?, limit?, mode?}…] for several chunk-scoped slices in ONE call");
          if (paths.length === 1) return await this._readOne(paths[0], args, done);
          const per = Math.max(1600, Math.floor((this.OUT_CAP - 60 * paths.length) / paths.length)); // honest share, ≥1.6k chars each
          const parts = [];
          for (const p of paths) {
            const r = await this._readOne(p, { ...args, _capOverride: per }, (ok, content) => ({ ok, content }));
            parts.push(`===== ${p}${r.ok ? "" : " (FAILED)"} =====\n${r.content}`);
          }
          return done(true, this._cap(`[multi-read ×${paths.length} · shared budget ${this.OUT_CAP} chars — a file cut short? re-read it alone with offset/limit]\n\n` + parts.join("\n\n"), this.OUT_CAP, true));
        }
        case "head":
        case "tail": {
          /* hf.16 — DEDICATED MULTI-FILE HEAD/TAIL (user call: "add dedicated
             multi-file chunked tools for head and tail reads"). Field log:
             ledger heads/ends went through shell head/tail (cwd-pitfall
             class) or offset-mathed read slices — one call per file. Both
             tools are thin multi-file frontends over _readOne, so they
             inherit the whole house rulebook for free: tail KEEPS THE END
             on over-cap slices, ≥30 KB files ship the slice plan, single
             lines cap at 800 chars, skip notes stay honest. */
          const modeHT = name; // "head" | "tail" — the switch discriminates
          const nHT = Math.max(1, Math.min(400, Math.floor(Number(args.n ?? args.lines ?? 40) || 40)));
          const pathsHT = this._paths(args.path);
          if (!pathsHT.length) return done(false, `path required — args: {path, n?} (path = one file or an ARRAY of files; n = lines, default 40)`);
          if (pathsHT.length === 1) return await this._readOne(pathsHT[0], { mode: modeHT, limit: nHT }, done);
          const perHT = Math.max(1600, Math.floor((this.OUT_CAP - 60 * pathsHT.length) / pathsHT.length));
          const partsHT = [];
          for (const p of pathsHT) {
            const r = await this._readOne(p, { mode: modeHT, limit: nHT, _capOverride: perHT }, (ok, content) => ({ ok, content }));
            partsHT.push(`===== ${p}${r.ok ? "" : " (FAILED)"} =====\n${r.content}`);
          }
          return done(true, this._cap(`[${modeHT} ×${pathsHT.length} file(s) · ${nHT} line${nHT === 1 ? "" : "s"} each · shared budget ${this.OUT_CAP} chars — a file cut short? re-read it alone with mode:"${modeHT}" limit ${nHT * 2}]\n\n` + partsHT.join("\n\n"), this.OUT_CAP, true));
        }
        case "write": {
          // ADE-S23.3 (ch-21.f9, m-51): tolerant arg keys (HF.7 lesson) + honest coercion
          const p = VFS.norm(args.path || args.file || args.target || "");
          if (!p || p === "/") return done(false, "invalid path — args: {path, content}");
          let content = args.content;
          if (content === undefined) content = args.text ?? args.body; // accept the key the model actually sent
          if (content !== undefined && content !== null && typeof content !== "string" && typeof content !== "object") content = String(content);
          if (content === undefined || content === null) return done(false, "content required (string) — got none of: content · text · body");
          if (typeof content === "object") return done(false, "content must be a string — JSON.stringify it first (received: " + (content.constructor && content.constructor.name || "object") + ")");
          if (content.length > this.BIG_CALL_CAP) // hf.11 — the 16k WRITE GATE (a field write this size shipped corrupted): the chunked writer is the path
            return done(false, `content too big for ONE write call: ${content.length.toLocaleString()} chars > ${this.BIG_CALL_CAP.toLocaleString()} — build it with chunk (~${Math.ceil(content.length / this.BIG_CALL_CAP)} pieces): {path, index:0, total:${Math.ceil(content.length / this.BIG_CALL_CAP)}, content:<piece 0>} … the final index auto-assembles + verifies${content.length >= this.LARGE_FILE ? " · ≥30 KB = the LARGE-FILE class — the chunk suite is mandatory here" : ""}`);
          await VFS.put(p, content, true);
          // ADE-S13.9 (ch-19.f2, m-34): feed the NOW EDITING window (guard: WSUI loads after agent.js)
          try { WSUI.editing(p, 1, `rewrite · ${content.split("\n").length} lines`, "agent"); } catch { /* window optional */ }
          const linked = VFS.FSA && VFS.FSA.state === "linked" ? " · mirrored to work folder" : "";
          return done(true, `wrote ${p} (${content.length} chars)${linked}`);
        }
        case "append": {
          const addRaw = args.content ?? args.text ?? args.body; // ADE-S23.3 (ch-21.f9): tolerant keys, honest refusal
          if (addRaw === undefined || addRaw === null) return done(false, "content required — args: {path, content} (an append needs the text to add)");
          if (typeof addRaw === "object") return done(false, "content must be a string — JSON.stringify it first");
          const add = String(addRaw);
          if (add.length > this.BIG_CALL_CAP) return done(false, `append too big for ONE call: ${add.length.toLocaleString()} chars > ${this.BIG_CALL_CAP.toLocaleString()} — split the append into ≤16k pieces across calls, or rebuild the file with chunk {path, index, total, content}`);
          /* hf.12 — MULTI-FILE APPEND: path = one file (unchanged) or an ARRAY
             of files — the SAME content lands on every file; each file is
             independent (a binary/failed file is reported and skipped, it never
             blocks the others). Appending never ships the file body into the
             conversation, so it is the SAFE edit on a ≥30 KB LARGE-FILE-class
             file (worklog rows, ledger §08 patch lines, …). */
          const paths = this._paths(args.path);
          if (!paths.length) return done(false, "path required — args: {path, content} (path = one file, or an array of files)");
          if (paths.length === 1) {
            const p = paths[0];
            const prev = await VFS.readText(p);
            if (prev == null && await VFS.exists(p)) return done(false, `${p} is binary — cannot append`);
            await VFS.put(p, (prev || "") + add, true);
            // ADE-S13.9 (ch-19.f2): the appended block STARTS at the first new line
            try { WSUI.editing(p, (prev || "").split("\n").length, `append · ${add.split("\n").length} lines`, "agent"); } catch { /* window optional */ }
            return done(true, `appended to ${p} (now ${(prev || "").length + add.length} chars)`);
          }
          const rows = [];
          for (const p of paths) {
            const prev = await VFS.readText(p);
            if (prev == null && await VFS.exists(p)) { rows.push(`✗ ${p}: binary — skipped`); continue; }
            await VFS.put(p, (prev || "") + add, true);
            try { WSUI.editing(p, (prev || "").split("\n").length, `append · ${add.split("\n").length} lines`, "agent"); } catch { /* window optional */ }
            rows.push(`✓ ${p}: +${add.length} chars${prev == null ? " (created)" : ` (now ${(prev || "").length + add.length})`}`);
          }
          const okN = rows.filter(r => r.startsWith("✓")).length;
          return done(okN > 0, `multi-append ×${paths.length} files · +${add.length} chars each · ${okN} applied${okN < paths.length ? `, ${paths.length - okN} skipped (each file independent)` : ""}\n${rows.join("\n")}`);
        }
        case "delete": {
          const p = VFS.norm(args.path || "");
          if (!p || p === "/") return done(false, "refusing to delete the workspace root");
          const row = await VFS.get(p);
          if (!row) return done(false, `not found: ${p}`);
          await VFS.rm(p);
          return done(true, `deleted ${p}${row.kind === "dir" ? " (recursive)" : ""}`);
        }
        case "move": {
          // ADE-S23.3 (ch-21.f9): tolerant keys + honest pre-checks (VFS.mv throws raw)
          const from = VFS.norm(args.from || args.source || args.src || "");
          const to = VFS.norm(args.to || args.target || args.dest || "");
          if (!from || !to) return done(false, "from and to are required — args: {from, to} (rename, or move into an existing dir)");
          if (!(await VFS.exists(from))) return done(false, `not found: ${from}`);
          try {
            const dest = await VFS.mv(from, to);
            return done(true, `moved ${from} → ${dest}${dest !== to ? ` (inside ${to})` : ""}`);
          } catch (e) { return done(false, `mv failed: ${String((e && e.message) || e)}`); }
        }
        case "mkdir": {
          const p = VFS.norm(args.path || "");
          if (!p || p === "/") return done(false, "invalid path");
          await VFS.mkdirp(p);
          return done(true, `folder ready: ${p}`);
        }
        /* ══ ADE-HF.8 · DEDICATED ZIP / FLAT-FILE TOOLS ══
           Field driver (user, m-41): "i decided that i do not like
           python, need you to make dedicated tool calls for unzip,
           rezip, clear (workstation), append zip with current
           version, maybe dedicated tool for finding and editing
           flat files". Everything here is pure JS over the vendored
           fflate + the VFS — the agent never needs run_python for
           archive or flat-file work again. */
        case "unzip": {
          const zp = VFS.norm(args.path || "");
          if (!zp || zp === "/") return done(false, "path required — the .zip file to unpack");
          const row = await VFS.get(zp);
          if (!row || row.kind !== "file") return done(false, `zip not found: ${zp}`);
          const dest = VFS.norm(args.dest || "/");
          let u8;
          try { u8 = row.content instanceof Uint8Array ? row.content : new Uint8Array(row.content); }
          catch { return done(false, `${zp} is not readable as binary`); }
          const sum = await VFS.importZip(u8, dest, { overwrite: !!args.overwrite, skip: zp });
          const kept = args.overwrite ? "" : " · existing files kept (pass overwrite:true to replace)";
          return done(true, `unpacked ${zp} → ${dest} · ${sum.imported} file(s) written · ${sum.skipped} skipped${kept} · ${(sum.bytes / 1024).toFixed(1)} KB extracted`);
        }
        case "rezip": {
          // ADE-S23.3 (ch-21.f9, m-51): tolerant sources — {src} · {root} · or {path} pointing at an existing dir
          const srcRaw = args.src || args.root || "";
          let src = srcRaw ? VFS.norm(srcRaw) : "";
          if (!src && args.path && (await VFS.isDir(VFS.norm(args.path)))) src = VFS.norm(args.path);
          if (!src) src = "/";
          if (src !== "/" && !(await VFS.exists(src))) return done(false, `not found: ${src}`);
          const reqPath = args.path ? VFS.norm(args.path) : null;
          const zp = (reqPath && reqPath !== src) ? reqPath : (src === "/" ? "/workspace.zip" : src.replace(/\/+$/, "") + ".zip");
          if (zp === "/") return done(false, "invalid zip path");
          const blob = await VFS.exportZip(src);
          const u8 = new Uint8Array(await blob.arrayBuffer());
          if (u8.length <= 22) return done(false, "nothing to pack — the workspace (or subtree) has no files");
          const buf = u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength);
          await VFS.put(zp, buf, false);
          const nFiles = (await VFS.tree(src)).filter(r => r.kind === "file").length;
          return done(true, `packed ${src} → ${zp} · ${nFiles} file(s) · ${(u8.length / 1024).toFixed(1)} KB`);
        }
        case "zipadd": {
          const f = VFS._fflate();
          const zp = VFS.norm(args.path || "");
          if (!zp || zp === "/") return done(false, "path required — the zip file to create or append to");
          const src = VFS.norm(args.src || "/");
          if (src !== "/" && !(await VFS.exists(src))) return done(false, `not found: ${src}`);
          // 1) carry over the existing zip's entries (unless fresh:true)
          let entries = {};
          let carried = 0;
          const existing = await VFS.get(zp);
          if (existing && existing.kind === "file" && args.fresh !== true) {
            try {
              const u8 = existing.content instanceof Uint8Array ? existing.content : new Uint8Array(existing.content);
              entries = f.unzipSync(u8);
              carried = Object.keys(entries).length;
            } catch (e) {
              return done(false, `existing zip unreadable (${e.message}) — re-issue with fresh:true to rebuild it from the workspace`);
            }
          }
          // 2) merge the current workspace snapshot — workspace WINS over zip entries
          const all = await DB.all(DB.STORES.VFS);
          const prefix = src === "/" ? "" : src.slice(1) + "/";
          let files = 0;
          for (const row of all) {
            if (row.kind !== "file") continue;
            let rel = row.path.replace(/^\//, "");
            if (prefix && !rel.startsWith(prefix)) continue;
            rel = prefix ? rel.slice(prefix.length) : rel;
            if (!rel) continue;
            entries[rel] = typeof row.content === "string" ? f.strToU8(row.content) : new Uint8Array(row.content);
            files++;
          }
          if (!Object.keys(entries).length) return done(false, "nothing to pack — the zip and the workspace are both empty");
          const zipped = f.zipSync(entries, { level: 6 });
          const buf = zipped.buffer.slice(zipped.byteOffset, zipped.byteOffset + zipped.byteLength);
          await VFS.put(zp, buf, false);
          const kb = (zipped.length / 1024).toFixed(1);
          return done(true, `${zp} updated: ${files} workspace file(s) merged${carried ? `, ${carried} existing zip entr${carried === 1 ? "y" : "ies"} loaded` : ""} · ${Object.keys(entries).length} entr${Object.keys(entries).length === 1 ? "y" : "ies"} total · ${kb} KB`);
        }
        case "clear": {
          if (args.confirm !== true)
            return done(false, 'REFUSED — clear deletes EVERY file and folder in the workspace. Re-issue with {"confirm":true} if you are sure.');
          const cnt = await VFS.count();
          const n = await VFS.clearAll();
          const fsa = (window.VFS && VFS.FSA) ? VFS.FSA : null;
          const linked = fsa && fsa.state === "linked" && fsa.handle ? " · linked disk folder NOT touched" : "";
          return done(true, `workstation cleared — ${cnt.files} file(s) + ${cnt.dirs} dir(s) removed (${n} rows) · VFS is now empty${linked}`);
        }
        case "find": {
          const pat = String(args.pattern ?? "");
          if (!pat) return done(false, 'pattern required — e.g. {"pattern":"plan.next","path":"planner.flat.txt"} (a single FILE path searches that file)');
          let re = null;
          if (args.regex === true) {
            try { re = new RegExp(pat, (args.ignore_case === true ? "i" : "") + "m"); } // ADE-HF.8 — m flag: ^/$ anchors apply per-line (lines are tested one by one)
            catch (e) { return done(false, "bad regex: " + e.message); }
          }
          const needle = args.ignore_case === true ? pat.toLowerCase() : pat;
          const max = Math.max(1, Math.min(200, Math.floor(Number(args.max)) || 40));
          /* hf.12 — MULTI-ROOT FIND: path = "/" (default, whole workspace) · a
             single file · a folder · or an ARRAY of files/folders — all roots
             searched in ONE pass with ONE shared hit cap (rows deduped). A
             missing array entry is reported and skipped, it never blocks the
             rest. */
          const roots = Array.isArray(args.path) ? this._paths(args.path) : [VFS.norm(args.path || "/")];
          if (Array.isArray(args.path) && !roots.length) return done(false, "path array is empty or invalid — pass real file/folder paths");
          /* hf.14 — root resolution is HONEST for single paths too: a root that
             is neither a folder nor an existing file lands in `miss` and the
             head reports "N path(s) NOT FOUND". (Field case: a single bogus
             path — or a stringified JSON array read as ONE path — was counted
             as "binary skipped", and the model concluded a real .js file was
             binary.) Binary now means ONLY a real non-text file. */
          const seen = new Set(); const rows = []; const miss = [];
          for (const root of roots) {
            if (root === "/" || (await VFS.isDir(root))) { for (const r of await VFS.tree(root)) if (r.kind === "file" && !seen.has(r.path)) { seen.add(r.path); rows.push(r); } }
            // ADE-S22.1 (ch-21.f5, m-48): a FILE root previously searched NOTHING — VFS.tree walks dirs only.
            else if (await VFS.exists(root)) { if (!seen.has(root)) { seen.add(root); rows.push({ path: root }); } }
            else miss.push(root);
          }
          const hits = [];
          let searched = 0, binary = 0;
          for (const r of rows) {
            // ADE-S22.1: binary pre-check — readText decodes ANY bytes lossily, so
            // non-text rows must be skipped before the decode or they pollute `searched`
            const row = (r.isText === undefined) ? await VFS.get(r.path) : r;
            if (!row || row.kind !== "file") { if (!miss.includes(r.path)) miss.push(r.path); continue; } // hf.14 — vanished between listing and read = NOT FOUND, not binary
            if (!row.isText && !U.isTextName(r.path)) { binary++; continue; }
            let txt = null;
            try { txt = await VFS.readText(r.path); } catch { binary++; continue; }
            if (txt == null) { binary++; continue; }
            searched++; // ADE-S22.1: searched/binary stay honest even after the hit cap lands
            if (hits.length >= max) continue;
            const lines = txt.split("\n");
            for (let i = 0; i < lines.length && hits.length < max; i++) {
              const L = lines[i];
              const hit = re ? re.test(L) : (args.ignore_case === true ? L.toLowerCase().includes(needle) : L.includes(needle));
              if (hit) hits.push(`${r.path}:${i + 1}: ${L.trim().slice(0, 200)}`);
            }
          }
          const rootsLabel = (roots.length === 1 && !Array.isArray(args.path)) ? roots[0] : (roots.join(", ").slice(0, 160) + (roots.join(", ").length > 160 ? "…" : ""));
          const head = `[find "${pat.slice(0, 60)}" in ${rootsLabel} · ${hits.length} hit${hits.length === 1 ? "" : "s"} · searched ${searched} text file(s)${binary ? `, ${binary} binary skipped` : ""}${miss.length ? ` · ${miss.length} path(s) NOT FOUND: ${miss.join(", ").slice(0, 200)}` : ""}]`;
          if (!hits.length) {
            /* ADE-HF.8 — the 0-hit answer now TEACHES: the 2026-10-31 frame-scape
               session lost turns to literal ^worklog\. patterns (flat_find is
               literal-by-default) and the model guessed "no multiline flag". */
            let hint = "no matches — try a shorter pattern or ignore_case:true";
            if (!re && /[\\^$.*+?()[\]{}|]/.test(pat)) hint += ` — this pattern carries REGEX syntax (\\ ^ $ …) but find is LITERAL by default: re-run with {"regex":true} (^/$ anchors apply per line) or use a plain substring`;
            else if (re && (pat.startsWith("^") || pat.endsWith("$"))) hint += " — note: ^/$ anchors apply per line, so leading text before the anchor never matches";
            return done(true, head + "\n" + hint);
          }
          const more = hits.length >= max ? `\n…hit cap ${max} reached — re-run with a higher max or a narrower pattern/path` : "";
          return done(true, this._cap(head + "\n" + hits.join("\n") + more));
        }
        case "grep": {
          /* hf.12 — the DEDICATED -o EXTRACTOR. Field case: the 2026-10-31
             frame-scape run burned ~10 shell gymnastics calls (grep -oE · sed
             -E refusals · awk missing · find on a file) to list id:'…' entries
             from an 83 KB lab file. This tool does it in ONE call over files
             of ANY size: the file body never ships — only capped matches do
             (count/unique give instant inventories). Regex native; literal
             opt-in; capture groups selectable. */
          const pat = String(args.pattern ?? "");
          if (!pat) return done(false, 'pattern required — a JS RegExp by default (e.g. {"pattern":"id:\'([a-zA-Z]+)\'", "unique":true}) or a plain substring with literal:true');
          let re = null;
          if (args.literal === true) {
            try { re = new RegExp(pat.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g" + (args.ignore_case === true ? "i" : "")); }
            catch (e) { return done(false, "bad pattern: " + e.message); }
          } else {
            try { re = new RegExp(pat, "g" + (args.ignore_case === true ? "i" : "")); }
            catch (e) { return done(false, "bad regex: " + e.message); }
          }
          const gspec = args.group == null ? 0 : (args.group === "all" ? "all" : Math.max(0, Math.min(9, Math.floor(Number(args.group) || 0))));
          const mode = ["hits", "only", "count"].includes(args.mode) ? args.mode : "hits";
          const unique = args.unique === true;
          const max = Math.max(1, Math.min(400, Math.floor(Number(args.max)) || 100));
          /* hf.15 — CHUNKED OUTPUT (user call: "rework grep to support multi-file
             + chunking"). (a) offset:N pages the SHIPPED rows forward — a capped
             result continues with {…, offset:N} instead of a bigger max (the
             2026-10-31 round-7 log re-grepped the same file 3× for successive
             slices of one inventory). (b) context:1-5 ships lines around each
             hit (hits mode, overlapping windows deduped) — the read-the-"
             exact-lines" follow-up often dies entirely. The ship cap stays a
             hard 400 rows/call; deep inventories get told to narrow. */
          const off = Math.max(0, Math.min(400, Math.floor(Number(args.offset)) || 0));
          const ctx = Math.max(0, Math.min(5, Math.floor(Number(args.context)) || 0));
          const shipCtx = ctx > 0 && mode === "hits" && !unique;
          const maxTotal = Math.min(400, max + off); // collection cap for this page
          const roots = Array.isArray(args.path) ? this._paths(args.path) : [VFS.norm(args.path || "/")];
          if (Array.isArray(args.path) && !roots.length) return done(false, "path array is empty or invalid — pass real file/folder paths");
          /* hf.14 — honest root resolution (same as find): a missing/bogus root
             reports "NOT FOUND" in the head; only a real non-text file counts
             as "binary skipped". A stringified JSON array path arrives here
             already coerced to a real array (execTool entry). */
          const seen = new Set(); const rows = []; const miss = [];
          for (const root of roots) {
            if (root === "/" || (await VFS.isDir(root))) { for (const r of await VFS.tree(root)) if (r.kind === "file" && !seen.has(r.path)) { seen.add(r.path); rows.push(r); } }
            else if (await VFS.exists(root)) { if (!seen.has(root)) { seen.add(root); rows.push({ path: root }); } }
            else miss.push(root);
          }
          const take = (m) => { // one match → the string this mode ships (may be "")
            if (gspec === "all") {
              if (m.length > 1) return m.slice(1).filter(x => x !== undefined).join("·");
              return String(m[0] ?? ""); // hf.15 — a group:'all' ask on a groupless regex ships the whole match (it used to ship "" → a lying "no matches")
            }
            return String(m[gspec] ?? "");
          };
          const out = [];
          const uniq = new Map(); // unique mode: match → count (first-seen order)
          const counts = [];      // per-file [path, matchCount]
          let total = 0, searched = 0, binary = 0, over = 0;
          const searchedPaths = []; // hf.16 — feeds the 0-hit probe hint
          let ctxShipped = new Set(); // hf.15 — per-file set of line indexes already on the wire (match + context)
          for (const r of rows) {
            const row = (r.isText === undefined) ? await VFS.get(r.path) : r;
            if (!row || row.kind !== "file") { if (!miss.includes(r.path)) miss.push(r.path); continue; } // hf.14 — NOT FOUND, not binary
            if (!row.isText && !U.isTextName(r.path)) { binary++; continue; }
            let txt = null;
            try { txt = await VFS.readText(r.path); } catch { binary++; continue; }
            if (txt == null) { binary++; continue; }
            searched++;
            searchedPaths.push(r.path);
            ctxShipped = new Set(); // context dedupe is per-file
            let n = 0;
            if (mode === "count") { // whole-file scan — matches only COUNT here
              re.lastIndex = 0;
              for (let m = re.exec(txt); m !== null; m = re.exec(txt)) {
                if (m.index === re.lastIndex) re.lastIndex++; // zero-width guard
                const s = take(m); if (s) { n++; if (unique) uniq.set(s, (uniq.get(s) || 0) + 1); }
                if (n >= 500000) { over = 1; break; }
              }
            } else {
              const lines = txt.split("\n"); // per-line: exact line numbers, ^/$ anchors per line
              for (let i = 0; i < lines.length; i++) {
                re.lastIndex = 0;
                for (let m = re.exec(lines[i]); m !== null; m = re.exec(lines[i])) {
                  if (m.index === re.lastIndex) re.lastIndex++; // zero-width guard
                  const s = take(m);
                  if (!s) continue;
                  n++;
                  if (unique) uniq.set(s, (uniq.get(s) || 0) + 1);
                  if (out.length < maxTotal) {
                    if (!unique || !out.some(x => x.__k === s)) {
                      let row0 = mode === "only" ? s.slice(0, 300) : `${r.path}:${i + 1}: ${s.slice(0, 300)}`;
                      if (shipCtx) { // hf.15 — chunk-scoped context around the hit (deduped, 200-char lines)
                        ctxShipped.add(i);
                        const ctxRows = [];
                        for (let j = Math.max(0, i - ctx); j <= Math.min(lines.length - 1, i + ctx); j++) {
                          if (j === i || ctxShipped.has(j)) continue;
                          ctxShipped.add(j);
                          ctxRows.push(`  L${j + 1}: ${String(lines[j]).slice(0, 200)}`);
                        }
                        if (ctxRows.length) row0 += "\n" + ctxRows.join("\n");
                      }
                      out.push({ __k: s, s: row0 });
                    }
                  } else over = 1;
                }
              }
            }
            if (n) counts.push([r.path, n]);
            total += n;
          }
          if (unique && uniq.size > maxTotal) over = 1; // unique inventory exceeds this page's collection cap
          const rootsLabel = (roots.length === 1 && !Array.isArray(args.path)) ? roots[0] : (roots.join(", ").slice(0, 160) + (roots.join(", ").length > 160 ? "…" : ""));
          const head = `[grep ${mode} · ${gspec === "all" ? "all groups" : "group " + gspec}${unique ? " · unique" : ""}${ctx ? ` · ctx ${ctx}` : ""} "${pat.slice(0, 60)}" in ${rootsLabel} · ${total.toLocaleString()} match(es) · searched ${searched} text file(s)${binary ? `, ${binary} binary skipped` : ""}${miss.length ? ` · ${miss.length} path(s) NOT FOUND: ${miss.join(", ").slice(0, 200)}` : ""}${off ? ` · from row ${off + 1}` : ""}]`;
          let body = "";
          let rowsTotal = 0, page = [];
          if (mode === "count") body = counts.map(([p, n]) => `${p}: ${n}`).join("\n") + (counts.length ? `\nTOTAL: ${total}` : "");
          else if (unique && mode === "only") { // unique inventory: bare matches + per-match counts, paged
            rowsTotal = uniq.size;
            page = [...uniq.entries()].slice(off, off + max).map(([s, c]) => `${s}  ×${c}`);
            body = page.join("\n");
          } else { // hits mode (unique keeps the FIRST path:LINE: row per match) · only mode without unique — paged
            rowsTotal = unique ? uniq.size : total;
            page = out.slice(off, off + max).map(x => x.s);
            body = page.join("\n");
          }
          const tail = [];
          const remaining = rowsTotal - (off + page.length);
          if (remaining > 0) {
            if (off + page.length >= 400) tail.push(`…row cap 400 reached (${rowsTotal.toLocaleString()} row(s) match) — narrow the pattern/path, add unique:true, or ship more per page with max (cap 400)`); // the hard cap: a deeper offset can never ship
            else tail.push(`…${remaining.toLocaleString()} more row(s) — next page: same call with offset:${off + page.length} (max ${max}/page)`);
          }
          if (over && remaining <= 0) tail.push(`…match cap reached — raise max (cap 400), narrow the pattern/path, or add unique:true`);
          if (searched > 1 && counts.length > 1 && mode !== "count") tail.push(`per-file: ${counts.slice(0, 8).map(([p, n]) => `${VFS.base(p)} ×${n}`).join(" · ")}${counts.length > 8 ? ` · +${counts.length - 8} more` : ""} — one call covered them; no need to re-grep file-by-file`);
          if (!total) tail.push(await this._grepZeroHint(pat, searchedPaths)); // hf.16 — the 0-hit probe, not a doc recital
          return done(true, this._cap(head + "\n" + body + (tail.length ? "\n" + tail.join("\n") : ""), this.OUT_CAP));
        }
        case "edit": {
          /* hf.12 — MULTI-FILE EDIT: path = one file (single-file behavior
             byte-identical to before, refusals included) or an ARRAY of files
             — the SAME patch (find→replace, or the edits[] form) runs per file
             with per-file expect/all; a file with no match is REPORTED and
             skipped, never blocking the others. */
          const paths = this._paths(args.path);
          if (!paths.length) return done(false, "path required — a file path, or an array of files to patch with the same find→replace (args: {path, find, replace} or {path, edits:[…]})");
          if (paths.length === 1) return await this._editOne(paths[0], args, done);
          const rows = [];
          for (const p of paths) {
            const r = await this._editOne(p, args, (ok, content) => ({ ok, content }));
            rows.push(`${r.ok ? "✓ " : "✗ "}` + String(r.content).split("\n")[0] + (r.ok && String(r.content).includes("\n") ? "\n" + String(r.content).split("\n").slice(1).join("\n") : ""));
          }
          const okN = rows.filter(r => r.startsWith("✓")).length;
          return done(okN > 0, `multi-edit ×${paths.length} files · ${okN} applied, ${paths.length - okN} refused/no-match (each file independent — expect/all apply per file):\n${rows.join("\n")}`);
        }
        /* ══ hf.10 — LEDGER CHUNKER SUITE ══
           A 500 KB ledger ≈ 125k tokens — reading it whole IS the original 413.
           split → find/patch parts → digest-verified byte-exact reassembly.
           Raw parts carry NO added headers (reassembly is lossless); the
           manifest is the only index, written for the TOOLS — don't read it. */
        case "split": {
          const p = VFS.norm(args.path || "");
          if (!p || p === "/") return done(false, "path required — the big flat file to split");
          const txt = await VFS.readText(p);
          if (txt == null) {
            const row = await VFS.get(p);
            return done(false, row && row.kind === "file" ? `${p} is binary — the ledger tools are text-only` : `not found: ${p}`);
          }
          if (txt.length > 8 * 1024 * 1024) return done(false, `${p} is ${(txt.length / 1048576).toFixed(1)} MB — over the 8 MB ledger cap; split it upstream first`);
          const by = ["lines", "bytes", "marker"].includes(args.by) ? args.by : "lines";
          let value = Number(args.value);
          if (by === "lines") { if (!Number.isFinite(value) || value < 50) value = 400; value = Math.min(5000, Math.round(value)); }
          else if (by === "bytes") { if (!Number.isFinite(value) || value < 4096) value = 15360; value = Math.min(262144, Math.round(value)); } // hf.14 — default 15 KB/part: every part reads WHOLE in one call under READ_CAP (32 KB parts tripped the large-file gate themselves)
          else {
            value = String(args.value ?? "").trim();
            if (!value) return done(false, 'by:"marker" needs value — a per-line RegExp that STARTS a new part (e.g. "^## ")');
            try { new RegExp(value); } catch (e) { return done(false, `bad marker RegExp: ${e.message}`); }
          }
          const lines = txt.split("\n");
          const bounds = [];
          if (by === "lines") {
            for (let i = 0; i < lines.length; i += value) bounds.push([i, Math.min(lines.length, i + value)]);
          } else if (by === "bytes") {
            let acc = 0, start = 0;
            for (let i = 0; i < lines.length; i++) {
              acc += lines[i].length + 1;
              if (acc >= value) { bounds.push([start, i + 1]); start = i + 1; acc = 0; }
            }
            if (start < lines.length) bounds.push([start, lines.length]);
          } else {
            const re = new RegExp(value);
            let start = 0;
            for (let i = 1; i < lines.length; i++) if (re.test(lines[i])) { bounds.push([start, i]); start = i; }
            if (start < lines.length) bounds.push([start, lines.length]);
          }
          if (!bounds.length) bounds.push([0, Math.max(1, lines.length)]);
          if (bounds.length > 500) return done(false, `would create ${bounds.length} parts (cap 500) — raise value, or use by:"marker" on section headers`);
          const dir = VFS.norm(String(args.out ?? "").trim() || p.replace(/\/[^/]*$/, "/") + VFS.base(p).replace(/\.(flat\.)?(txt|md|log|json)$/i, "") + ".parts");
          try { await VFS.rm(dir); } catch { /* fresh dir, or a stub without rm — stale extra parts are harmless: the manifest governs */ }
          const parts = [];
          for (let i = 0; i < bounds.length; i++) {
            const [a, b] = bounds[i];
            const body = lines.slice(a, b).join("\n") + (b < lines.length ? "\n" : "");
            const file = `part-${String(i).padStart(3, "0")}.txt`;
            await VFS.put(dir + "/" + file, body, true);
            parts.push({ file, bytes: body.length, lines: b - a, startLine: a, digest: this._fnv(body) });
          }
          const manifest = { v: 1, tool: "split/1", source: p, by, value: by === "marker" ? value : Number(value), created: new Date().toISOString(), sourceBytes: txt.length, sourceLines: lines.length, sourceDigest: this._fnv(txt), chunkCount: parts.length, parts };
          const mfPath = dir + "/manifest.json";
          await VFS.put(mfPath, JSON.stringify(manifest, null, 1), true);
          const shown = parts.slice(0, 24).map(pt => `  ${pt.file}  ${String(pt.bytes).padStart(7)} B  ${String(pt.lines).padStart(5)} lines  from L${pt.startLine + 1}  d${pt.digest}`);
          const more = parts.length > 24 ? `\n  …and ${parts.length - 24} more (manifest.json has the full table — don't read it, the ledger tools do)` : "";
          const note = by === "marker" && parts.length === 1 ? "\nNOTE: the marker matched no line after row 1 — one part holds the whole file; check the pattern." : "";
          return done(true, this._cap(`[split ${p} → ${parts.length} parts · by ${by}${by !== "marker" ? ` · ~${value.toLocaleString()} ${by === "lines" ? "lines/part" : "B/part"} (line-aligned)` : ` · /${value}/ starts a part`} · → ${dir}/]\n${shown.join("\n")}${more}${note}\nmanifest: ${mfPath} (source ${txt.length.toLocaleString()} B · ${lines.length.toLocaleString()} lines · d${manifest.sourceDigest})\nNEXT: scan {manifest:"${mfPath}", pattern:"…"} → patch parts with edit → check → assemble {manifest:"${mfPath}"}`));
        }
        case "scan": {
          const L = await this._ledgerManifest(args.manifest || args.dir || args.path);
          if (L.err) return done(false, L.err);
          const pat = String(args.pattern ?? "");
          if (!pat) return done(false, "pattern required — literal by default, regex:true to switch (same rules as find)");
          let re = null;
          if (args.regex) { try { re = new RegExp(pat, args.ignore_case ? "i" : ""); } catch (e) { return done(false, `bad regex: ${e.message}`); } }
          const needle = args.ignore_case ? pat.toLowerCase() : pat;
          const max = Math.max(1, Math.min(200, Number(args.max) || 40));
          const hits = [];
          let scanned = 0;
          for (const part of L.manifest.parts) {
            if (hits.length >= max) break;
            const body = await VFS.readText(L.dir + "/" + part.file);
            if (body == null) continue;
            scanned++;
            const rows = body.split("\n");
            for (let i = 0; i < rows.length; i++) {
              const hit = re ? re.test(rows[i]) : (args.ignore_case ? rows[i].toLowerCase() : rows[i]).includes(needle);
              if (hit) { hits.push(`${part.file}:${i + 1} (master L${part.startLine + i + 1}): ${rows[i].slice(0, 200)}`); if (hits.length >= max) break; }
            }
          }
          if (!hits.length) {
            let hint = "no hits — try a shorter pattern or ignore_case:true";
            if (!re && /[\\^$.*+?()[\]{}|]/.test(pat)) hint += " — this pattern carries REGEX syntax but scan is LITERAL by default: re-run with {\"regex\":true}";
            return done(true, `[scan ${L.dir} · ${scanned}/${L.manifest.parts.length} parts scanned]\n${hint}`);
          }
          const capped = hits.length >= max ? `\n…hit cap ${max} — narrow the pattern or raise max` : "";
          return done(true, this._cap(`[scan ${L.dir} · ${scanned}/${L.manifest.parts.length} parts scanned · ${hits.length} hit(s)]\n${hits.join("\n")}${capped}\n— read {path:"${L.dir}/<part>", offset:<local line − 1>} pulls context; the (master LNNN) is the line in the original file`));
        }
        case "check": {
          const L = await this._ledgerManifest(args.manifest || args.dir || args.path);
          if (L.err) return done(false, L.err);
          const rows = []; let drift = 0, missing = 0;
          for (const part of L.manifest.parts) {
            const body = await VFS.readText(L.dir + "/" + part.file);
            if (body == null) { rows.push(`  ${part.file}  MISSING`); missing++; continue; }
            const d = this._fnv(body);
            if (d !== part.digest || body.length !== part.bytes) { rows.push(`  ${part.file}  DRIFTED  ${part.bytes}→${body.length} B  d${part.digest}→d${d}`); drift++; }
          }
          const head = `[check ${L.dir} · ${L.manifest.parts.length} parts · clean ${L.manifest.parts.length - drift - missing} · drifted ${drift} · missing ${missing}]`;
          const verdict = (drift || missing)
            ? `${drift + missing} part(s) differ from the split manifest — intentional edits? → assemble {expect_drift:true} rebuilds and refreshes the manifest. Unexpected? → inspect those parts before assembling.`
            : "all parts clean — assemble needs no expect_drift.";
          return done(true, this._cap(head + "\n" + (rows.length ? rows.join("\n") + "\n" : "") + verdict));
        }
        case "assemble": {
          const L = await this._ledgerManifest(args.manifest || args.dir || args.path);
          if (L.err) return done(false, L.err);
          const drift = [];
          const bodies = [];
          for (const part of L.manifest.parts) {
            const body = await VFS.readText(L.dir + "/" + part.file);
            if (body == null) return done(false, `part missing: ${part.file} — cannot reassemble; restore it or re-run split`);
            const d = this._fnv(body);
            if (d !== part.digest || body.length !== part.bytes) drift.push(`${part.file} (${part.bytes}→${body.length} B)`);
            bodies.push(body);
          }
          if (drift.length && args.expect_drift !== true)
            return done(false, `${drift.length} part(s) edited since the split:\n  ${drift.slice(0, 12).join("\n  ")}${drift.length > 12 ? `\n  …+${drift.length - 12} more` : ""}\n— edits INTENTIONAL? re-issue with expect_drift:true (manifest digests refresh). Not sure? check first.`);
          const out = bodies.join("");
          const to = VFS.norm(String(args.to ?? "").trim() || L.manifest.source);
          const prev = await VFS.readText(to);
          let backup = null;
          if (prev != null && prev !== out) {
            backup = to + ".pre-assemble.bak";
            await VFS.put(backup, prev, true);
          }
          await VFS.put(to, out, true);
          if (drift.length) { // refresh the manifest so the NEXT round verifies clean
            for (const part of L.manifest.parts) {
              const body = await VFS.readText(L.dir + "/" + part.file) ?? "";
              part.bytes = body.length; part.lines = body.split("\n").length; part.digest = this._fnv(body);
            }
            await VFS.put(L.manifestPath, JSON.stringify(L.manifest, null, 1), true);
          }
          const same = out.length === L.manifest.sourceBytes && this._fnv(out) === L.manifest.sourceDigest;
          const ident = same ? "byte-identical to the split source ✓" : `differs from the split source (${L.manifest.sourceBytes.toLocaleString()}→${out.length.toLocaleString()} B — the edits above)`;
          return done(true, this._cap(`[assemble → ${to} · ${L.manifest.parts.length} parts · ${out.length.toLocaleString()} B · ${out.split("\n").length.toLocaleString()} lines · d${this._fnv(out)}]\n${ident}${out.length >= this.LARGE_FILE ? `\n≥30 KB file — future edits go split → scan → edit → check → assemble (HUGE LEDGERS)` : ""}${backup ? `\nprevious target kept: ${backup} (one-shot — delete it when the new master is verified)` : ""}\nparts dir kept for further rounds — delete ${L.dir}/ when done`));
        }
        case "state": {
          /* hf.10 — mid-run STAGE CHECKPOINT of the f1 handoff file. The
             <<<STATE block only lands when a reply completes; long stages
             (discovery sweeps, plan locks, music-session prep) call THIS at
             boundaries so a cut/crash/closed tab resumes without re-discovery. */
          const clean = (v) => String(v ?? "").replace(/\s+/g, " ").trim().slice(0, 340);
          const task = clean(args.task), doneS = clean(args.done), next = clean(args.next);
          const flags = clean(args.flags) || "none";
          if (!task && !next) return done(false, "pass at least {task} or {next} — e.g. state {task:\"rig R1.4\", done:\"measured 4 ref sheets via probe\", next:\"write spec.flat.txt §03\"}");
          const txt = `# ade.state.flat.txt — harness-written resume pointer (agent checkpoint via state_save)\n# re-injected on every run start / continue — a restart costs ONE tiny read, never a re-survey\nupdated = ${new Date().toISOString()}\ntask = ${task}\ndone = ${doneS || "(none recorded)"}\nnext = ${next || "(none recorded)"}\nflags = ${flags}\n`;
          if (txt.length > 1200) return done(false, `state block too big (${txt.length} chars > 1200) — keep task/done/next terse; put detail in a workspace file and reference its path`);
          await VFS.put("/ade.state.flat.txt", txt, true);
          return done(true, `stage checkpoint saved → /ade.state.flat.txt (${txt.length} B) — injected as [RESUME STATE] on every future run start / continue; artifacts live in workspace files these lines point to`);
        }
        /* ══ hf.11 — CHUNKED BIG-WRITE ══
           Field driver (user): "a specific tool for agent to write large files
           in chunks, then compile them back" + "agent knows to use it BEFORE
           it's required to build a large file — starts from the tool call,
           writes chunk to memory, sends chunk to work station, ships in
           chunks, assembles when ready". One call = ONE chunk shipped to the
           workstation; chunks rest in <path>.chunks/ staging (size + FNV
           digest recorded per chunk); the FINAL index compiles: every part
           re-verified FROM STORAGE → byte-exact target → one-shot
           .pre-chunkwrite.bak of a replaced target → staging cleaned. */
        case "chunk": {
          const p = VFS.norm(args.path || "");
          if (!p || p === "/" || p.endsWith("/")) return done(false, "invalid path — args: {path, index, total, content} (path is the TARGET file)");
          if (p.includes(".chunks/")) return done(false, `${p} is INSIDE staging — call chunk with the target path only; staging is tool-owned`);
          const dir = p + ".chunks";
          if (args.abort === true) {
            const had = await VFS.exists(dir);
            try { await VFS.rm(dir); } catch { /* already gone */ }
            return done(true, had ? `chunk staging for ${p} discarded (${dir}/ removed)` : `no chunk staging for ${p} — nothing to discard`);
          }
          const mfPath = dir + "/manifest.json";
          const total = Math.round(Number(args.total));
          const index = Math.round(Number(args.index));
          if (args.status === true) {
            const mfRaw = await VFS.readText(mfPath);
            if (mfRaw == null) return done(true, `[chunk status ${p} · NO staging — nothing in flight]\nstart with: chunk {path:"${p}", index:0, total:N, content:<part 0>}`);
            let mf; try { mf = JSON.parse(mfRaw); } catch { return done(false, `staging manifest unreadable: ${mfPath} — abort:true and restart`); }
            const have = (mf.chunks || []).map(c => c.index).sort((a, b) => a - b);
            const missing = []; for (let i = 0; i < mf.total; i++) if (!have.includes(i)) missing.push(i);
            return done(true, `[chunk status ${p} · ${have.length}/${mf.total} staged · target ${mf.target}]\narrived: ${have.join(", ") || "(none)"}${missing.length ? `\nmissing: ${missing.slice(0, 30).join(", ")}${missing.length > 30 ? " …" : ""} — ship them (chunk {path, index:<n>, total:${mf.total}, content})` : "\nall parts staged — re-send the FINAL index (total−1) to compile"}`);
          }
          if (!Number.isFinite(total) || total < 1 || total > 500) return done(false, `total must be 1–500 (got ${args.total ?? "none"}) — one call ships ONE ≤16k-char piece; a single-piece file belongs to write instead`);
          if (!Number.isFinite(index) || index < 0 || index >= total) return done(false, `index out of range: ${args.index ?? "none"} (valid 0–${total - 1})`);
          let content = args.content ?? args.text ?? args.body; // tolerant keys (S23.3 convention)
          if (content === undefined || content === null) return done(false, "content required (this chunk's text)");
          if (typeof content === "object") return done(false, "content must be a string — JSON.stringify it first");
          content = String(content);
          if (content.length > this.BIG_CALL_CAP) return done(false, `chunk too big: ${content.length.toLocaleString()} chars > ${this.BIG_CALL_CAP.toLocaleString()} — raise total and re-ship this index (each call ≤16k chars, the read-cap economy)`);
          const mfRaw = await VFS.readText(mfPath);
          let mf = null;
          if (mfRaw != null) { try { mf = JSON.parse(mfRaw); } catch { mf = null; } }
          if (mf && mf.target !== p) return done(false, `staging at ${dir}/ belongs to "${mf.target}" — {path:"${mf.target}", …} to continue it, or {path:"${p}", abort:true} to discard`);
          if (mf && mf.total !== total) return done(false, `staging holds total ${mf.total}, this call says ${total} — finish with ${mf.total} (status:true shows state) or abort:true + restart`);
          const identical = mf && (mf.chunks || []).some(c => c.index === index && c.bytes === content.length && c.digest === this._fnv(content));
          const replaced = mf && (mf.chunks || []).some(c => c.index === index && !identical);
          /* ALWAYS write the part on arrival — an identical re-send then REFRESHES storage, healing
             a drifted/tampered staged part instead of deadlocking against the compile guard. */
          await VFS.put(dir + "/c" + String(index).padStart(4, "0") + ".part", content, true);
          const now = new Date().toISOString();
          if (!mf) mf = { v: 1, tool: "chunk/1", target: p, total, created: now, chunks: [] };
          mf.updated = now; mf.total = total;
          const rec = { index, file: "c" + String(index).padStart(4, "0") + ".part", bytes: content.length, digest: this._fnv(content) };
          const at = mf.chunks.findIndex(c => c.index === index);
          if (at >= 0) mf.chunks[at] = rec; else mf.chunks.push(rec);
          mf.chunks.sort((a, b) => a.index - b.index);
          await VFS.put(mfPath, JSON.stringify(mf, null, 1), true);
          /* hf.11 fix (suite-caught deadlock): an IDENTICAL re-send of the FINAL index when ALL parts
             are staged must FALL THROUGH to the compile — the early return used to answer
             "re-send the FINAL index" forever, making resume-to-compile impossible. */
          if (identical && !(index === total - 1 && mf.chunks.length === total)) {
            const have = mf.chunks.length;
            const missing = []; for (let i = 0; i < total; i++) if (!mf.chunks.some(c => c.index === i)) missing.push(i);
            return done(true, `chunk ${index}/${total - 1} already arrived, IDENTICAL — staging refreshed (self-heals a drifted part) (${have}/${total} staged${missing.length ? ` — missing: ${missing.slice(0, 20).join(", ")}` : ""}${index === total - 1 ? " — ship the missing part(s), then re-send this final index to compile" : ""})`);
          }
          if (index !== total - 1) {
            const have = mf.chunks.length;
            const missing = []; for (let i = 0; i < total; i++) if (!mf.chunks.some(c => c.index === i)) missing.push(i);
            return done(true, `[chunk ${p} · ${have}/${total} staged${replaced ? ` · index ${index} REPLACED (was different — verify intended)` : ""}]\n  ${rec.file}  ${rec.bytes.toLocaleString()} B  d${rec.digest}${missing.length ? `\nmissing: ${missing.slice(0, 20).join(", ")}${missing.length > 20 ? " …" : ""} — NEXT: chunk {path:"${p}", index:<next>, total:${total}, content}` : ""}`);
          }
          /* FINAL index → COMPILE: re-verify every part FROM STORAGE, then write */
          const missing = []; for (let i = 0; i < total; i++) if (!mf.chunks.some(c => c.index === i)) missing.push(i);
          if (missing.length) return done(false, `final index arrived but ${missing.length} part(s) missing: ${missing.slice(0, 20).join(", ")} — ship them first (status:true shows state); nothing written to ${p}`);
          const bodies = []; const bad = [];
          for (const c of mf.chunks) {
            const body = await VFS.readText(dir + "/" + c.file);
            if (body == null) { bad.push(`${c.file} vanished from staging`); continue; }
            if (body.length !== c.bytes || this._fnv(body) !== c.digest) bad.push(`${c.file} drifted in staging (${c.bytes}→${body.length} B · d${c.digest}→d${this._fnv(body)}) — re-ship: chunk {path, index:${c.index}, total:${total}, content}`);
            else bodies.push({ index: c.index, body });
          }
          if (bad.length) return done(false, `compile REFUSED — staging integrity:\n  ${bad.slice(0, 12).join("\n  ")}\nnothing was written to ${p}.`);
          bodies.sort((a, b) => a.index - b.index);
          const out = bodies.map(b => b.body).join("");
          const expect = Number(args.expectBytes);
          if (Number.isFinite(expect) && expect > 0 && expect !== out.length)
            return done(false, `expectBytes mismatch: assembled ${out.length.toLocaleString()} chars, you expected ${expect.toLocaleString()} — a piece shipped wrong? status:true, find it, re-ship that index; nothing written to ${p}`);
          const prevT = await VFS.readText(p);
          let backup = null;
          if (prevT != null && prevT !== out) { backup = p + ".pre-chunkwrite.bak"; await VFS.put(backup, prevT, true); }
          await VFS.put(p, out, true);
          try { await VFS.rm(dir); } catch { /* staging cleanup is cosmetic */ }
          try { WSUI.editing(p, 1, `chunk-compile · ${total} parts`, "agent"); } catch { /* window optional */ }
          const linked = VFS.FSA && VFS.FSA.state === "linked" ? " · mirrored to work folder" : "";
          return done(true, `[chunk COMPILED → ${p} · ${total} parts · ${out.length.toLocaleString()} chars · ${out.split("\n").length.toLocaleString()} lines · d${this._fnv(out)}]${backup ? `\nprevious target kept: ${backup} (one-shot — delete after verify)` : ""}${out.length >= this.LARGE_FILE ? `\n≥30 KB file — future edits: split → scan → edit → check → assemble (HUGE LEDGERS)` : ""}\nverify: read {path:"${p}", mode:"head"} or digest {path:"${p}"} — staging cleaned${linked}`);
        }

        case "shell": {
          const raw = String(args.command ?? args.cmd ?? args.raw ?? args.line ?? "").trim(); // ADE-HF.7 — accept the key the model actually sent (field report: it guessed `cmd` and burned a turn on "command required")
          if (!raw) return done(false, "command required");
          const r = await Exec.Shell.run(raw, { silent: true });
          /* hf.10 — per-line 800-char cap at PRESENTATION only (pipes/redirects already consumed
             the raw bytes — a redirected file is never capped). Field trace: shell grep shipped a
             4.5 KB meta.plan.next mega-line whole; fs_read lines already cap at 800 — the shell reads the same. */
          const capLine = (L) => L.length > 800 ? L.slice(0, 800) + ` …[+${L.length - 800} chars on this line — cut -c1-800 / read offset for exact slices]` : L;
          const out = [String(r.out || "").split("\n").map(capLine).join("\n"), r.err ? "STDERR:\n" + r.err : "", r.code ? `exit code ${r.code}` : ""].filter(Boolean).join("\n").trim();
          return done(!r.code, this._cap(out || "(no output)"));
        }
        case "py": {
          let code = null, p = null;
          if (typeof args.code === "string" && args.code.trim()) code = args.code;
          else if (args.path) {
            p = VFS.norm(args.path);
            code = await VFS.readText(p);
            if (code == null) return done(false, `not found: ${p}`);
          } else return done(false, "pass code (inline) or path");
          const r = await this._captureConsole(() => p ? Exec.runPython(p) : Exec.runPython(code, true));
          if (!r) return done(false, "python runtime unavailable — the user declined or the pull failed (see run console)");
          const parts = [r.ok ? "ok" : "FAILED: " + (r.err || "error")];
          const con = this._cap(r.__console || "", this.OUT_CAP);
          if (con) parts.push("stdout/stderr:\n" + con);
          if (r.result && r.result !== "None" && r.result !== "undefined") parts.push("result: " + r.result);
          return done(!!r.ok, parts.join("\n"));
        }
        case "js": {
          let p = null, tmp = null;
          if (typeof args.code === "string" && args.code.trim()) {
            tmp = "/tmp/agent-" + U.uid().slice(0, 6) + ".js";
            await VFS.put(tmp, args.code, true);
            p = tmp;
          } else if (args.path) { p = VFS.norm(args.path); }
          else return done(false, "pass code (inline) or path");
          if (!(await VFS.exists(p))) return done(false, `not found: ${p}`);
          /* hf.12 — FILES PRELOAD: workspace text files arrive in the sandbox
             as the global FS map (path → full text). The worker has NO fetch
             (blob: origin — relative URLs cannot even parse) and NO module
             imports — the field case burned turn after turn on
             import('ademure/fs') and fetch('/frame-scape-music/…'). This is
             the one sanctioned seam: load files here, process in the sandbox,
             print SMALL results (counts/digests/slices — never whole files;
             console output is capped anyway). */
          let files = null; const fMiss = [], fBin = [], fBig = []; let fTotal = 0;
          if (args.files != null) {
            const fp = this._paths(args.files);
            if (!fp.length) return done(false, "files: pass a workspace path or an array of paths (≤12 files, ≤2 MB each)");
            files = {};
            for (const f of fp) {
              const row = await VFS.get(f);
              if (!row || row.kind !== "file") { fMiss.push(f); continue; }
              if (row.size > 2 * 1024 * 1024) { fBig.push(f); continue; }
              const t = await VFS.readText(f);
              if (t == null) { fBin.push(f); continue; }
              if (fTotal + t.length > 4 * 1024 * 1024) { fBig.push(f); continue; } // hf.12 — 4 MB total blob budget
              files[f] = t; fTotal += t.length;
            }
            if (!Object.keys(files).length)
              return done(false, `files: nothing preloaded${fMiss.length ? ` — not found: ${fMiss.join(", ")}` : ""}${fBin.length ? ` — binary: ${fBin.join(", ")}` : ""}${fBig.length ? " — over 2 MB each" : ""}`);
          }
          try {
            const r = await this._captureConsole(() => Exec.runJs(p, files));
            const parts = [r.ok ? "ok" : "FAILED: " + (r.error || "error")];
            if (files) parts.unshift(`FS preloaded: ${Object.keys(files).length} file(s) · ${Object.values(files).reduce((n, t) => n + t.length, 0).toLocaleString()} chars — read them as FS["<path>"]${fMiss.length ? ` · not found: ${fMiss.join(", ")}` : ""}${fBin.length ? ` · binary skipped: ${fBin.join(", ")}` : ""}${fBig.length ? ` · >2MB skipped: ${fBig.join(", ")}` : ""}`);
            if (r.result !== undefined && r.result !== "undefined" && r.result !== null) parts.push("result: " + r.result);
            const con = this._cap(r.__console || "", this.OUT_CAP);
            if (con) parts.push("console:\n" + con);
            return done(!!r.ok, parts.join("\n"));
          } finally { if (tmp) { try { await VFS.rm(tmp); } catch { /* best effort */ } } }
        }
        case "preview": {
          const p = VFS.norm(args.path || "");
          const html = await VFS.readText(p);
          if (html == null) return done(false, `not found or not text: ${p}`);
          await Exec.preview(p);
          return done(true, `preview opened: ${p} — sandboxed iframe (no same-origin), console bridged`);
        }
        case "probe": {
          /* f10.image.probe — the agent measures from NUMBERS: dimensions,
             alpha-silhouette bbox (figure extremities), per-row/col edge
             transitions, grid averages. No decoder → honest refusal that maps
             to "seed value, not verified" under the evidence gate. */
          const p = VFS.norm(args.path || "");
          if (!p) return done(false, 'path required — args: {path, crop?, grid?, rows?, cols?, alpha?, luma?}');
          const row = await VFS.get(p);
          if (!row || row.kind !== "file") return done(false, `not found: ${p}`);
          let u8;
          try { u8 = row.content instanceof Uint8Array ? row.content : (typeof row.content === "string" ? new TextEncoder().encode(row.content) : new Uint8Array(row.content)); }
          catch { return done(false, `${p} is not readable as binary`); }
          if (u8.length < 24) return done(false, `${p} is ${u8.length} bytes — not an image (or truncated)`);
          const kind = this._imgKind(u8);
          const alphaT = Math.max(1, Math.min(254, Number(args.alpha) || 128));
          const lumaT = Math.max(1, Math.min(254, Number(args.luma) || 40));
          const maxT = Math.max(4, Math.min(64, Number(args.max_trans) || 32));
          const img = await this._decodeImage(u8);
          if (!img || !img.w || !img.data) return done(false, 'image_probe: no image decoder available in this context — record the measurement as "seed value, not verified" and leave any spec.lock unconfirmed.');
          const { w, h, data } = img;
          if (w * h > 16777216) return done(false, `image too large for one pass (${w}×${h} = ${(w * h / 1e6).toFixed(1)} MP) — pass a crop`);
          let cx = 0, cy = 0, cw = w, ch = h;
          if (Array.isArray(args.crop) && args.crop.length === 4) {
            const c = args.crop.map(n => Math.round(Number(n) || 0));
            cx = Math.max(0, Math.min(w - 1, c[0])); cy = Math.max(0, Math.min(h - 1, c[1]));
            cw = Math.max(1, Math.min(w - cx, c[2])); ch = Math.max(1, Math.min(h - cy, c[3]));
          }
          const px = (x, y) => { const i = (y * w + x) * 4; return [data[i], data[i + 1], data[i + 2], data[i + 3]]; };
          const lum = (r, g, b) => Math.round(0.2126 * r + 0.7152 * g + 0.0722 * b);
          const out = [];
          out.push(`[image_probe ${p} · ${w}×${h}px${kind ? " " + kind : ""} · ${u8.length} B · region x${cx} y${cy} ${cw}×${ch}${Array.isArray(args.crop) ? " (crop)" : ""} · lumaΔ≥${lumaT} · α<${alphaT}]`);
          let minX = -1, minY = -1, maxX = -1, maxY = -1, transparent = 0;
          for (let y = cy; y < cy + ch; y++) {
            for (let x = cx; x < cx + cw; x++) {
              if (px(x, y)[3] < alphaT) { transparent++; if (minX < 0 || x < minX) minX = x; if (x > maxX) maxX = x; if (minY < 0 || y < minY) minY = y; if (y > maxY) maxY = y; }
            }
          }
          if (!transparent) out.push(`alpha: no pixel below α<${alphaT} in region — OPAQUE: no alpha silhouette; use rows/cols scans for feature edges`);
          else out.push(`alpha silhouette (α<${alphaT}): bbox x ${minX}..${maxX} · y ${minY}..${maxY} · ${maxX - minX + 1}×${maxY - minY + 1}px · ${transparent} transparent px in region`);
          const scanLine = (fixed, isRow) => {
            const len = isRow ? cw : ch;
            const tr = [];
            let refL = null, refA = null;
            for (let k = 0; k < len; k++) {
              const x = isRow ? cx + k : fixed, y = isRow ? fixed : cy + k;
              const [r, g, b, a] = px(x, y);
              const L = lum(r, g, b);
              if (refL === null) { refL = L; refA = a; continue; }
              const flip = (a < alphaT) !== (refA < alphaT);
              if (Math.abs(L - refL) >= lumaT || flip) {
                if (tr.length < maxT) tr.push(`${isRow ? "x" : "y"}=${k} ${refL}→${L}${flip ? ` α${refA}→${a}` : ""}`);
                refL = L; refA = a;
              }
            }
            return tr;
          };
          const rowsReq = (Array.isArray(args.rows) ? args.rows : []).map(n => Math.round(Number(n))).filter(n => Number.isFinite(n)).slice(0, 8);
          const colsReq = (Array.isArray(args.cols) ? args.cols : []).map(n => Math.round(Number(n))).filter(n => Number.isFinite(n)).slice(0, 8);
          for (const y of rowsReq) {
            if (y < cy || y >= cy + ch) { out.push(`row y=${y}: outside region (y ${cy}..${cy + ch - 1})`); continue; }
            const tr = scanLine(y, true);
            out.push(`row y=${y}: ${tr.length} edge transition(s)${tr.length >= maxT ? ` (cap ${maxT})` : ""}${tr.length ? "\n  " + tr.join(" · ") : ""}`);
          }
          for (const x of colsReq) {
            if (x < cx || x >= cx + cw) { out.push(`col x=${x}: outside region (x ${cx}..${cx + cw - 1})`); continue; }
            const tr = scanLine(x, false);
            out.push(`col x=${x}: ${tr.length} edge transition(s)${tr.length >= maxT ? ` (cap ${maxT})` : ""}${tr.length ? "\n  " + tr.join(" · ") : ""}`);
          }
          const g = Math.max(0, Math.min(8, Math.floor(Number(args.grid)) || 0));
          if (g >= 2) {
            const cellW = cw / g, cellH = ch / g;
            const glines = [];
            for (let gy = 0; gy < g; gy++) {
              const cells = [];
              for (let gx = 0; gx < g; gx++) {
                let sr = 0, sg = 0, sb = 0, sa = 0, n = 0;
                const x0 = cx + Math.floor(gx * cellW), x1 = cx + Math.floor((gx + 1) * cellW);
                const y0 = cy + Math.floor(gy * cellH), y1 = cy + Math.floor((gy + 1) * cellH);
                for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const c = px(x, y); sr += c[0]; sg += c[1]; sb += c[2]; sa += c[3]; n++; }
                cells.push(n ? `(${Math.round(sr / n)},${Math.round(sg / n)},${Math.round(sb / n)},a${Math.round(sa / n)})` : "—");
              }
              glines.push(`  gy${gy}: ${cells.join(" ")}`);
            }
            out.push(`grid ${g}×${g} avg RGBA (0-255) over region:\n${glines.join("\n")}`);
          }
          return done(true, this._cap(out.join("\n")));
        }
        case "caps": {
          if (args.deep === true) { // ADE-S14.7 (ch-21.f3, m-37): the full inventory in ONE cheap call
            const shellCmds = (window.Exec && Exec.Shell && Exec.Shell._cmds) ? Object.keys(Exec.Shell._cmds).filter(k => k !== "help").sort() : [];
            return done(true, [
              `ADE ${ADE_BUILD.version} · ${ADE_BUILD.stamp}`,
              `agent tools (${this.TOOLS.length}): ` + this.TOOLS.map(t => `${t.name}(${t.parameters && t.parameters.properties ? Object.keys(t.parameters.properties).join(",") : ""})`).join(" · "),
              `shell commands (${shellCmds.length}): ${shellCmds.join(" · ")}`,
              "budgets: OUT_CAP caps every tool result · maxSteps/contextK + py/js timeouts = live values in Settings → Agent · audit prompts: routing §08",
              `gaps this session: ${(window.Exec && Exec.Shell && Exec.Shell.gaps) ? Exec.Shell.gaps.length : 0} — shell: gaps prints the ranked list`
            ].join("\n"));
          }
          const rows = await VFS.tree("/").catch(() => []);
          const files = rows.filter(r => r.kind === "file").length;
          const dirs = rows.filter(r => r.kind === "dir").length;
          const fsa = (window.VFS && VFS.FSA) ? VFS.FSA : null;
          const linked = fsa && fsa.state === "linked" && fsa.handle;
          const pyState = (window.Exec && Exec._py && Exec._py.worker) ? "loaded" : "loads on first use (~10MB, user-approved)";
          return done(true, [
            `workspace: IndexedDB VFS — ${files} file(s) · ${dirs} dir(s)${linked ? ` · work folder LINKED: "${fsa.handle.name}" (write-through)` : " · no disk folder linked"}`,
            `runtimes: python = Pyodide WASM worker (${pyState}) · js = dedicated worker sandbox · html = sandboxed preview iframe · shell = virtual over the VFS`,
            `tools: ${this.TOOLS.map(t => t.name).join(" · ")}`
          ].join("\n"));
        }
        default:
          if (name === "__parse_error") return done(false, "unparseable <<<TOOL>>> JSON — re-emit the COMPLETE line as the last line of your reply · received (tail): " + String(args.__raw || "").slice(-160));
          if (window.Exec && Exec.Shell && Exec.Shell.gap) Exec.Shell.gap(name, "tool"); // ADE-S23.3 (ch-21.f4): unknown tools join the gaps journal
          return done(false, `unknown tool: ${name} — available: ${Agent.TOOLS.map(t => t.name).join(" · ")} (this miss is logged — shell: gaps)`);
      }
    } catch (e) {
      return done(false, String((e && e.message) || e));
    }
  },

  /* exec.js streams run output into ConsoleUI.line — capture it so the
     tool result carries the actual stdout (restore the original after) */
  async _captureConsole(fn) {
    const C = Exec.ConsoleUI;
    const orig = C.line;
    const buf = [];
    C.line = function (kind, text) { if (text != null && text !== "") buf.push(String(text)); orig.call(C, kind, text); };
    try {
      const r = await fn();
      if (r && typeof r === "object") r.__console = buf.join("\n");
      return r;
    } finally { C.line = orig; }
  },

  /* short human summary for the trace card arg line */
  argSummary(args = {}) {
    if (args.from && args.to) return `${args.from} → ${args.to}`;
    if (args.path) return String(args.path);
    if (args.command) return String(args.command);
    if (args.code) { const c = String(args.code).replace(/\s+/g, " ").trim(); return c.slice(0, 44) + (c.length > 44 ? "…" : ""); }
    const ks = Object.keys(args).slice(0, 3);
    return ks.length ? ks.map(k => `${k}=${String(args[k]).slice(0, 20)}`).join(" ") : "—";
  },

  /* ══ ADE-05.4 · TEXT-PROTOCOL FALLBACK appendix ══
     injected into the system prompt when the endpoint rejected the
     tools array (or cfg.forceProto); one <<<TOOL>>> line per reply.
     ADE-HF.3 (field report: 6× __parse_error + 13.4k-token burn in one
     turn): the model was QUOTING this format inside its reasoning, the
     old parser grabbed the quote, and the error loop spiraled. The
     appendix now forbids quoting/narrating outright. */
  PROTO_APPENDIX:
    `\n\nTOOL PROTOCOL (this endpoint has no native tool calling):\n` +
    `To call a tool, end your reply with EXACTLY ONE line — the very last line:\n` +
    `<<<TOOL {"name":"tool_name","args":{…}}>>>\n` +
    `— one call per reply · plain JSON args · NOTHING after the line · no call = your reply is final.\n` +
    `NEVER quote that format line, never explain it, never emit it mid-reply — exactly once, last line only.\n` +
    `Never END a reply by ANNOUNCING a call ("Listing it now.", "Step 1:") without the line — a reply with no tool line IS treated as your final answer, and the user is left waiting. If the task is not done, the tool line must be there.\n` +
    `The < > { } " characters inside the args JSON are safe — write normal code (comparisons, redirects, quotes); never avoid syntax to dodge the protocol.\n` +
    `Do NOT paste the tool's code/command as a markdown block in the reply body — the tool line IS the delivery; duplicate code walls just burn tokens.\n` +
    `Keep replies compact: no protocol narration, no re-stating the task. On a TOOL_RESULT error, fix quietly and re-emit the call.\n` +
    `The next user turn reads: TOOL_RESULT for <name>: <output>. Continue from there.`,

  /* ══ ADE-HF.3 · HARDENED PROTO PARSER (replaces the lazy regex) ══
     Three live-observed failure modes fixed:
     1. FIRST-match capture — the old /<<<TOOL\s*(\{[\s\S]*?\})\s*>>>/ grabbed
        the first occurrence in the reply, often the model QUOTING the
        format in its reasoning → JSON.parse failed on the placeholder
        → __parse_error → narration wall → token spiral. Now the LAST
        marker wins (the real call is the last line per protocol).
     2. Lazy-brace truncation — the old capture stopped at the first `}`
        followed by >>>, mangling args containing redirects/braces. Now
        a string-aware brace-walk extracts the JSON properly.
     3. Stream-cut blindness — a reply cut mid-JSON produced NO match,
        the run ended silently, the task dropped. Now the unterminated
        fragment is flagged (unterminated) so runAgent auto-continues;
        a cut AFTER a complete JSON object (missing trailing >>>) still
        executes; a quoted FORMAT template is flagged (placeholder) and
        never becomes an error turn. Unit-tested: scripts/proto_test.js. */
  _parseProto(acc) {
    const s = String(acc || "");
    /* ADE-S24.3 (ch-30.f1, m-54) — TOLERANT MARKER CAPTURE: the field report
       kept tripping the announce-nudge because models emit drift shapes the
       literal "<<<TOOL" scan missed — lowercase/markdown-wrapped markers
       ("<<<tool {…}>>>", fenced ```json blocks), stray space after <<<.
       The scan is now case-insensitive + whitespace-tolerant (word-boundary
       guarded so "<<<toolbox" can never match), and the visible reply strips
       the EMPTY fence pairs a fence-wrapped marker leaves behind. */
    const opens = [];
    const mre = /<<<\s*tool\b/gi;
    let mm;
    while ((mm = mre.exec(s)) && opens.length < 20) opens.push({ i: mm.index, end: mm.index + mm[0].length });
    if (!opens.length) return null;
    const last = opens[opens.length - 1];   // LAST marker wins — quoted formats in reasoning sit earlier
    const open = last.i;
    const clean = s.slice(0, open)
      .replace(/<<<\s*tool[\s\S]*?>>>/gi, "")
      .replace(/<<<\s*tool[\s\S]*$/i, "")
      .replace(/```[a-z]*[ \t]*\n?[ \t]*```/g, "")   // empty fences left by fence-wrapped markers
      .replace(/\n?```[a-z]*[ \t]*\n?$/i, "")        // the lone OPEN fence a fence-wrapped marker leaves behind
      .trim();
    let i = last.end;
    while (i < s.length && /\s/.test(s[i])) i++;
    const errCall = (raw) => ({ id: "proto_" + U.uid().slice(0, 8), name: "__parse_error", arguments: JSON.stringify({ __raw: String(raw).slice(-200) }) });
    if (i >= s.length || s[i] !== "{")
      return { call: errCall(s.slice(open)), clean, unterminated: true, placeholder: false };
    let depth = 0, inStr = false, esc = false, end = -1;   // string-aware brace walk
    for (let j = i; j < s.length; j++) {
      const ch = s[j];
      if (esc) { esc = false; continue; }
      if (ch === "\\") { esc = true; continue; }
      if (ch === '"') { inStr = !inStr; continue; }
      if (inStr) continue;
      if (ch === "{" || ch === "[") depth++;
      else if (ch === "}" || ch === "]") { depth--; if (depth === 0) { end = j; break; } }
    }
    if (end < 0)                            // stream cut mid-JSON — never executes, never errors the model
      return { call: errCall(s.slice(i)), clean, unterminated: true, placeholder: false };
    const tail = s.slice(i, end + 1);
    let o = null;
    try { o = JSON.parse(tail); } catch { /* falls through to the placeholder/bad-json branch */ }
    if (!o || String(o.name || "") === "tool_name")   // the quoted FORMAT template (parses or not) — never a real call
      return { call: errCall(tail), clean, unterminated: false, placeholder: true };
    const name = String(o.name || "");
    return { call: { id: "proto_" + U.uid().slice(0, 8), name, arguments: JSON.stringify(o.args ?? {}) }, clean, unterminated: false, placeholder: false };
  },

  /* ══ ADE-S25.1 (ch-30.f4, m-55) · ANNOUNCE DETECTOR — ROUND 2 ══
     v9 field evidence: the round-1 detector STILL fired on legitimate
     answers ("Let me know if you want changes." — the lead-in `let me`
     with no action verb after it) and MISSED the narration shape ("Emit
     it now: fs_read js lines 278-383 (offset 278, limit 106)." — no
     recognized verb, ends with a period), so runs died with the user
     waiting. Round-2 rules:
     · length cap 1200 → 360: announce-then-stop lives on SHORT replies;
       a 360+ char reply is an answer, full stop.
     · completion closers gain the polite set that burned v9 (let me
       know · any questions · hope this helps · feel free · happy to
       help · just ask · if you need/want).
     · the step-header rule requires the reply to END on the header — a
       retrospective "Step 1: … Step 2: …" summary whose last line is
       prose is a recap, not an announce.
     · lead-ins (let me / I'll / we'll / going to / about to /
       emit(ting) / re-emit(ting)) require a CONCRETE action verb later
       in the SAME line; a bare action verb at line start still fires.
     · a closing line naming a bare registry tool (fs_read/shell/…)
       with an announce lead-in or trailing colon fires — the model
       narrating its next call is the exact failure the nudge exists for.
     · the fence rehearsal needs a colon intro ("Run this to verify:");
       a reply that just ends with a code block is an answer.
     Completion shapes still refuse to fire (finished work is honored). */
  _announceCheck(lean, ranTools) {
    const s = String(lean || "").trim();
    if (!s || s.length >= 360) return false;               // short replies only — announce-then-stop is a SHORT shape
    const lastLine = s.slice(s.lastIndexOf("\n") + 1).trim();
    if (/\b(done|finished|complete[d]?|all set|that'?s all|task complete|works now|is (?:now )?(?:ready|written|saved|updated|fixed|deployed|in place)|are (?:now )?(?:ready|written|saved|in place)|let me know|any (?:other )?questions|hope this helps|feel free|happy to help|just ask|if you (?:need|want))\b/i.test(lastLine)) return false;
    if (/:\s*$/.test(s)) return true;
    if (lastLine.length < 120 && /^\s*step\s*\d+\s*[:.)-]\s*\S/i.test(lastLine)) return true;   // the reply ENDS on a step header
    if (/(?:^|\n)\s*(?:step\s*\d\s*[:.)-]?\s*)?(?:(?:let me|i['’]ll|we['’]ll|i will|we will|going to|about to|emit(?:ting)?|re-?emit(?:ting)?)\b[^.!?\n]{0,40}?)?\b(listing|reading|read|running|run|executing|execute|testing|test|launching|launch|compiling|compile|extracting|extract|unpacking|unpack|opening|open|checking|check|verif(?:y|ying)|writing|write|creating|create|saving|save|adding|add|appending|append|updating|update|generating|generate|surveying|survey|digesting|digest|fetching|fetch|searching|search|grepping|grep|scanning|scan|finding|find|inspecting|inspect|viewing|view|showing|show|patching|patch|editing|edit|moving|move|renaming|rename|building|build|installing|install|removing|remove|deleting|delete)\b[^.!?\n]{0,80}\.?\s*$/i.test(s)) return true;
    if (!this._toolNameRe) this._toolNameRe = new RegExp("\\b(" + this.TOOLS.map(t => t.name).join("|") + ")\\b", "i");
    if (this._toolNameRe.test(lastLine) && /(?:\b(?:let me|i['’]ll|we['’]ll|i will|we will|going to|about to|emit(?:ting)?|re-?emit(?:ting)?)\b|:\s*$)/i.test(lastLine)) return true;
    const fence = s.match(/(?:^|\n)```[a-z]*[ \t]*\n([^\n]{0,200})\n?[ \t]*```[ \t]*$/i);
    if (fence && ranTools > 0 && !/[.!?]\s*$/.test(fence[1].trim())) {
      const before = s.slice(0, fence.index).trimEnd();
      if (/:\s*$/.test(before)) return true;               // the rehearsal needs a colon intro — a bare trailing code block is an answer
    }
    return false;
  },

  /* ══ ADE-HF.3 · INLINE-REASONING SPLITTER ══
     Endpoints like GLM-5.3-Flash-T fold the chain of thought into the
     reply body (reasoning_content stays empty — the ✦0 burn badge):
     the thinking arrives either wrapped in <think>…</think> or as a
     leading run of blockquote lines. Left unsplit it renders as one
     giant wall ("a very long string, looks wrong") and is re-sent as
     part of the assistant history on EVERY later step (burn
     amplification). splitThink routes it into msg.reasoning (the ✦
     viewer streams it live) and keeps msg.content = the actual answer.
     Pure + conservative: no leading blockquote run ≥ 3 lines or no
     <think> wrapper → returns the text unchanged. */
  splitThink(raw) {
    const s = String(raw || "");
    if (!s) return { think: "", rest: "" };
    const O = "<think>", C = "</" + "think>";
    const a = s.indexOf(O);
    if (a >= 0) {
      const b = s.indexOf(C, a);
      const think = (b >= 0 ? s.slice(a + O.length, b) : s.slice(a + O.length)).trim();
      const rest = (b >= 0 ? (s.slice(0, a) + s.slice(b + C.length)) : s.slice(0, a)).trim();
      return { think, rest };
    }
    const lines = s.split("\n");
    let first = 0;
    while (first < lines.length && !lines[first].trim()) first++;
    let q = first, qCount = 0;
    while (q < lines.length && /^\s*>/.test(lines[q])) { qCount++; q++; }
    if (qCount >= 3) {
      const think = lines.slice(first, q).map(l => l.replace(/^\s*>\s?/, "")).join("\n").trim();
      const rest = lines.slice(q).join("\n").trim();
      return { think, rest };
    }
    return { think: "", rest: s };
  },

  /* ══ system prompt entry point ══
     ADE-06.1 — the FULL ADE protocol prompt (replaces the CH-05
     placeholder body): role + environment + tools + working
     agreement + ADE-06.4 bandwidth policy + ADE-06.5 work-folder-
     first protocol + ADE-06.6 flat-file mastery + the live workspace
     tree snapshot (opts.tree, built fresh per run by runAgent via
     Agent.workspaceSnapshot) · ADE-06.7 injects FlatBridge.PHILOSOPHY
     first (stable prefix — CH-12 wraps this entry point for ai.cache.*). */
  buildSystemPrompt(cfg, opts = {}) {
    const fsa = (window.VFS && VFS.FSA) ? VFS.FSA : null;
    const wsRoot = fsa && fsa.state === "linked" && fsa.handle ? (fsa.handle.name || "linked folder") : null;

    let p = FlatBridge.PHILOSOPHY; // ADE-06.7 — protocol layer is CODE (m-28)

    p +=

`\n\nWHO YOU ARE
You are the ADE agent (Agentic Developer Environment) running inside the user's real, persistent browser workspace — statically hosted, no server behind you. The workspace is an IndexedDB VFS that behaves like a disk: real files, real folders, session-persistent, and (when a work folder is linked) mirrored write-through to actual disk. You are expected to WORK, not to narrate: use your tools, leave artifacts behind, verify what you built.\n\nTOOLS (30) — ONE-WORD names (the legacy long spellings fs_* · flat_* · ledger_* · run_* still resolve) · hf.12 MULTI-FILE: read · find · grep · edit · append accept path as ONE path OR an ARRAY of paths — several files in one call, per-file results, per-file caps · hf.15 BATCHED SLICES: read {reads:[…]} ships several chunk-scoped slices in ONE call; grep pages with offset and adds context lines\n  survey     digest — one line per file (path · size · lines · first-line preview): the CHEAP way to know a folder; list · tree for structure\n  files      list · tree · read (paginated — offset/limit · mode head/tail · MULTI: path:[a,b,c] in one call · MULTI-SLICE: reads:[{path, offset?, limit?, mode?}…] = several slices of one/many files in ONE call) · head · tail (first/last N lines, MULTI-FILE, any size) · write (≤16k chars/call) · append (MULTI: same content to many files) · chunk (BIG-WRITE — see BIG WRITES) · delete · move · mkdir\n  zip        unzip (extract a workspace zip) · rezip (pack the workspace or a subtree) · zipadd (append the current workspace version into a zip — zip-only entries are kept) · clear (wipe the workstation — needs {confirm:true})\n  flat       find (search flat files — capped path:LINE: hits) · grep (the DEDICATED -o extractor — regex matches / capture groups ONLY, modes hits/only/count, unique:true inventories, offset:N result paging, context:1-5 lines around each hit — the file body NEVER ships, any file size, any number of files in one call) · edit (exact literal find→replace patch — or edits:[{find, replace, all?, expect?},…] MULTI form, applied atomically)\n  ledger     split (chunk a huge file — see HUGE LEDGERS) · scan (search across parts) · check · assemble (byte-exact rebuild)\n  checkpoint state (mid-run stage checkpoint → ade.state.flat.txt)\n  run        shell (virtual shell over the VFS — ls · cat · head · tail · grep · find · sed · cut · tr · uniq · tee · nl · rev · diff · patch · mv · cp · tree · digest · tools · gaps · && / ; chains · > >> redirects)\n             py (LAST RESORT — Pyodide WASM; zip/archive/flat-file work NEVER needs it) · js (worker sandbox) · preview (sandboxed HTML iframe)\n  inspect    caps (what this environment supports right now)\n  measure    probe (decode a workspace image → pixel dimensions · alpha-silhouette bbox · per-row/col edge transitions · grid cell averages — MEASURE from numbers, never guess; no decoder = "seed value, not verified")\nCalling a tool returns real output — stdout, errors, diffs. Everything you write persists.\nARG NAMES — use EXACTLY these keys, wrong keys are rejected: list/tree/digest {path, max?} · read {path, offset?, limit?, mode:"head"|"tail"} — path may be an ARRAY (multi-file in one call; a JSON-encoded array STRING coerces too) · read {reads:[{path|paths, offset?, limit?, mode?}…]} — MULTIPLE chunk-scoped slices in ONE call (several offsets of one file / several files / a mix; cap 12 specs; identical specs dedupe) — batch slices instead of firing parallel read calls · head/tail {path, n?} — path may be an ARRAY (per-file first/last N lines in ONE call) · write {path, content} · append {path, content} — path may be an ARRAY (same content to each file) · chunk {path, index, total, content, expectBytes?} · delete {path} · move {from, to} · mkdir {path} · unzip {path, dest?, overwrite?} · rezip {path?, src?} · zipadd {path, src?, fresh?} · clear {confirm:true} · find {pattern, path?, regex?, ignore_case?, max?} — path may be a file, folder, or ARRAY · grep {pattern, path?, group?, mode?"hits"|"only"|"count", unique?, context?, offset?, literal?, ignore_case?, max?} — path may be an ARRAY; regex native (JS dialect); offset:N pages a capped result forward (the tail note names the next offset); context:1-5 ships lines around each hit · edit {path, find, replace, all?, expect?} or MULTI {path, edits:[{find, replace, all?, expect?}, …]} · split {path, by?, value?, out?} · scan {manifest, pattern, regex?, ignore_case?, max?} · check {manifest} · assemble {manifest, to?, expect_drift?} · state {task?, done?, next?, flags?} · shell {command} · py {code} or {path} · js {code} or {path, files?} — files: workspace path(s) preloaded into the sandbox as the global FS map (FS["<path>"] → full text; the worker has NO fetch and NO module imports) · preview {path} · probe {path, crop?, grid?, rows?, cols?, alpha?, luma?} · caps {deep?} — tolerant aliases exist (the legacy long names fs_write/flat_find/ledger_*/… still resolve · write text/body · move source/target · rezip root) — e.g. shell is {"name":"shell","args":{"command":"ls -la"}} (NOT "cmd").\n\nWORKING AGREEMENT\n  1. Inspect before you write: read/list the target before editing it — never write blind.\n  2. Surgical edits: change what the task needs, nothing else; say why if you must touch more. Batch independent patches to ONE file into a single edit edits[] call (atomic multi-edit), and the SAME patch across MANY files into one edit with path:[f1,f2,…] (per-file results; a no-match file is reported, never fatal) — one call per status flip burns a turn each.\n  3. Verify by running: executed code beats described code — py / js / shell / preview to prove it works, then report the ACTUAL output.\n  4. Honest reporting: if something failed, say what failed and what you saw — never claim a run you did not make.\n  5. Prefer editing existing files over re-creating them; prefer diffs-in-place over rewrites.\n  6. READ ECONOMY (hard rule — a folder-wide read once burned 130k+ prompt tokens + 118MB of the user's proxy quota): NEVER read a folder file-by-file. SURVEY first — digest (or the shell command: digest <dir>) renders a whole subtree as one line per file in a single call — then read ONLY the files the task actually names (read path:[a,b,c] pulls several named files in ONE call; head/tail {path:[…], n} ship several files' first/last N lines in ONE call — a ledger's newest entries are tail's home turf), ≤8 full reads per run unless the user said otherwise. On "iterate / patch" tasks start from the bridge files (routing / manifest / planner .flat.txt) + the chunk's chNN.files list — never from a folder sweep. In big flat files NEVER page around hunting for things — grep/find the pattern ONCE across path:[f1,f2,…] — never file-by-file (the result's per-file counts tell you where everything matched), then read the exact lines it reports. Need structure (ids, names, keys) out of a huge file? grep {pattern, unique:true} ships ONLY the matches — the file never enters the conversation; a capped inventory continues with offset:N (the tail note names it), and context:1-5 pulls the surrounding lines without a follow-up read. BATCH YOUR SLICES (hf.15): several offsets/line-ranges of one file — or of several files — go in ONE read {reads:[{path, offset, limit}, …]} call; parallel single-slice read calls on the same survey are wasted turns. Huge file? Read it in slices: read offset/limit (or mode head/tail).\n  7. TOOL PITFALLS (field-earned — each one burned a real session): (a) the shell cwd PERSISTS between calls — after a 'cd', plain filenames resolve inside that dir and workspace-root paths need a leading '/' (a missed root-relative path now auto-resolves and says so); prefer one chained 'cd dir && cmd' when it fits. (b) find is LITERAL by default — regex metacharacters (caret, dollar, dot, star, backslash) match as text unless {"regex":true}; ^/$ anchors apply per line. (c) A capped read is NOT the file's end: '[truncated — showing N of M chars]' or '… N lines skipped' means unseen content EXISTS — never conclude queue/worklog state from a capped read; re-read narrower until you have seen the true last line; files over 30 KB never ship whole (grep/find first, then slice — a whole read returns the head slice + the slice plan). (d) The [ctx meter] line on your task turns is your payload size vs budget — past ~80% stop reading and start writing; after an HTTP 413 the harness auto-shrinks history (old tool results become stubs) and retries the same step, and after repeated empty/failed responses on a large payload the auto-continue re-drive ships SHRUNK too. (e) A >30 KB file is the LARGE-FILE class — a whole read NEVER refuses: it returns the head slice + the slice plan (next offset · ≈slice count); keep walking the offsets, or grep/find the pattern first and read only the reported lines. (f) BUILDING a file you know will be big (>16k chars; ≥30 KB = the LARGE-FILE class): start with chunk at the FIRST tool call — see BIG WRITES; write refuses >16k chars in one call by design.\n  8. STATE HANDOFF (multi-step work): after each COMPLETED step emit ONE block as the LAST thing in the reply:\n     <<<STATE\n     task: <one line — the current task>\n     done: <short steps already finished, semicolon-separated>\n     next: <the ONE exact next action>\n     flags: <≤3 open items, or none>\n     STATE>>>\n     The harness saves it to ade.state.flat.txt and re-injects it on every run start AND continue — a restart must cost one tiny read, never a re-survey. After a RESUME STATE: execute step_next; no re-planning from scratch; no re-reading files the done/next lines already cover unless a tool result contradicts them. Mid-run stage checkpoints: call state {task, done, next, flags} at stage boundaries (discovery done · plan locked · long stage finished) — the reply-end block only lands when a reply completes, the tool lands even if the run is cut right after.\n  9. EVIDENCE GATE (no fake confirmation): flip a status to done/confirmed ONLY when a tool result IN THIS RUN verified the acceptance condition — quote the numbers. Otherwise write status = unverified plus the reason. Image measurements come ONLY from probe numbers (bbox · transitions · grid averages), never from eyeballing; if probe reports no decoder, record the measurement as "seed value, not verified" and leave the lock unconfirmed.\n  10. REASONING DISCIPLINE: keep thinking to ~8 lines — never restate the ledger, the file list or earlier results; state the next action and why, then act.\n\nHUGE LEDGERS — CHUNK, DON'T CHOKE (a 500 KB ledger ≈ 125k tokens: reading it whole IS the 413)\n  A file over ~30 KB (or ~1200 lines) never enters context whole — chunk it and work part-local (or grep it: matches only, any file size):\n  1. split {path, by:"lines"|"bytes"|"marker", value} → raw parts + manifest.json in <name>.parts/. "marker" takes a per-line RegExp that STARTS a part (e.g. "^## ") so sections stay intact. Re-splitting wipes the old parts dir.\n  2. scan {manifest, pattern} — capped hits with part-local AND master line numbers across ALL parts in one cheap call; read the part at offset when you need context.\n  3. Patch parts with edit / write (part-local, surgical). The master stays frozen while you iterate.\n  4. check → assemble {manifest} — digest-verified byte-exact rebuild (expect_drift:true after intentional edits; a one-shot .pre-assemble.bak keeps the previous master). delete the .parts dir when done.\n\nBIG WRITES — CHUNK FROM THE FIRST TOOL CALL (a ≥30 KB file = the LARGE-FILE class: it cannot be read whole, so it must never be written whole either)\n  When you KNOW a file will be large (new module, spec table, dataset >16k chars), do NOT draft it in reply text and do NOT write it whole — start the chunked writer at tool call #1 and ship it in ≤16k-char pieces:\n  1. chunk {path, index:0, total:N, content:<part 0>} — opens <path>.chunks/ staging on the workstation; every call records size + digest.\n  2. Keep shipping: index 1, 2, … one call per piece (out-of-order is fine; identical re-sends are idempotent). Interrupted? {path, status:true} lists what landed — re-send only the missing index; {path, abort:true} discards.\n  3. The FINAL index auto-assembles: every part re-verified FROM STORAGE, byte-exact target written, staging cleaned, one-shot .pre-chunkwrite.bak if it replaced a target. The report carries chars · lines · digest — quote it (rule 9).\n  write and append refuse >16k chars in ONE call by design. Editing an EXISTING ≥30 KB file: split → scan → edit parts → check → assemble (HUGE LEDGERS above) — never a whole-file rewrite; appending worklog/patch lines to it is safe (append never ships the file body).\n  Pixel datasets: probe already returns bounded NUMBERS (dimensions · bbox · transitions · grid averages) — never ship raw pixel/image dumps into the conversation.\n\nFLAT-BRIDGE STATE LAYER (when the files exist in the workspace)\nIf routing.flat.txt · manifest.flat.txt · planner.flat.txt exist in the workspace root, this project runs the campaign protocol live: READ the relevant sections with read BEFORE acting on campaign tasks (ai.read.rule: read the sections you need — never whole-file dump), APPEND your worklog to planner.flat.txt §12 (worklog.NN, append-only), and FLIP statuses in place (m-NN.status, chNN.fX.status — lines never vanish, keys never move). If they don't exist, work normally — the philosophy layer above still governs you.\n\nBANDWIDTH POLICY (the user pays for proxy bandwidth — LIMITED)\n  · Do NOT pull tools, libraries, fonts, datasets or code from the web by default.\n  · When a tool/lib/package IS needed, first explain: what, why, exact source URL and exact size — then offer (a) ONE-TIME pull with the user's approval (vendor it into the workspace so it never downloads again) or (b) self-fetch instructions (exact URL + target path) so the user can fetch it themselves.\n  · pip/micropip installs: announce the package + size and get a yes before installing.\n  · Code you write references vendored/local workspace assets — NEVER CDN links.\n\nWORK-FOLDER-FIRST PROTOCOL\n${wsRoot
      ? `  · A real disk work folder is LINKED: "${wsRoot}". Treat it as your working root — every VFS write mirrors to disk (write-through), state survives reloads there. After a reconnect, re-verify files before editing.`
      : `  · No disk folder is linked yet — work in the IndexedDB VFS (it persists). If the task would benefit from real-disk persistence, suggest linking once (Workspace → LINK WORK FOLDER badge) and move on if the user declines.`}\n\nSTYLE\n  · Markdown; fence code blocks with language tags. Be concise — working output over prose.\n  · When you modified files, end with a short summary: what changed, what you ran, what you saw.\n  · Ask at most one clarifying question when a task is genuinely ambiguous; otherwise pick the reasonable interpretation and say so.`;

    if (opts.profileText) p += "\n\n" + opts.profileText; // ADE-12.2 (ch-12.f2, m-29) — the byte-stable profile prefix (built ONCE per run, Cache.profileBlock); sits AFTER the stable protocol body and BEFORE the volatile tree so provider prefix caching hits the longest stable head
    if (opts.tree) p += `\n\n${opts.tree}`; // ADE-06.1 — live snapshot, fresh per run
    if (opts.proto) p += Agent.PROTO_APPENDIX;
    return p;
  },

  /* ══ ADE-06.1 · WORKSPACE SNAPSHOT ══
     indented tree of the whole VFS (dirs first, sizes), capped at
     maxLines with an honest "… N more entries" tail. Built fresh by
     runAgent once per run and passed through opts.tree.             */
  async workspaceSnapshot(maxLines = 180) {
    try {
      const rows = await VFS.tree("/");
      if (!rows.length) return "WORKSPACE TREE: (empty — nothing has been created yet)";
      const fmt = (r) => {
        const pad = "  ".repeat(r.depth || 0);
        return r.kind === "dir" ? `${pad}${r.path.split("/").filter(Boolean).pop() || "/"}/`
                                : `${pad}${r.path.split("/").pop()}  (${Number(r.size) || 0} b)`;
      };
      const lines = rows.map(fmt);
      const head = `WORKSPACE TREE (live snapshot at run start — ${rows.length} entr${rows.length === 1 ? "y" : "ies"}):`;
      // ADE-S14.1 (ch-20.f1): the tail now points at the one-call digest survey
      const tail = "  → survey with digest <dir> (one line per file) — never read a folder file-by-file";
      if (lines.length <= maxLines) return head + "\n" + lines.join("\n") + "\n" + tail;
      return head + "\n" + lines.slice(0, maxLines).join("\n") + `\n  … ${lines.length - maxLines} more entries (tree / list for the rest)\n` + tail;
    } catch { return ""; } // snapshot is best-effort — never block a run
  },

  /* ══ ADE-05.5 · CONTEXT TRIM ══
     API context rebuilt from the PERSISTED msgs every request:
     user / assistant(+tool_calls) / tool rows → OpenAI messages.
     est-token budget = cfg.contextK · trims whole user-anchored
     segments from the OLDEST end (an assistant tool_calls block and
     its role:tool results always share a segment) · the system
     prompt is always kept.
     ADE-S14.2 (ch-20.f2, m-35) adds TOOL-RESULT EVICTION below the
     trim: between the ~60% soft trigger and full-budget the kept
     history would still re-send every past tool result on EVERY
     step (the O(steps × folder-size) re-send amplification — the
     true m-35 burn). Older segments' tool results collapse to
     one-line stubs; the ACTIVE (newest) segment stays verbatim and
     the pairing contract (assistant tool_calls ↔ tool rows) holds.
     Persisted rows + trace cards are NEVER touched — this only
     shapes the API payload.
     CH-12 wraps this for prompt caching — keep it the single named
     entry point.                                                    */
  buildContext(cfg, opts = {}) {
    /* ADE-HF.8 (ch-33) — 413 AUTO-SHRINK level rides opts.shrink (0 none · 1 half ·
       2 quarter). Field case: the frame-scape session shipped ~55k-tok requests
       until the gateway answered HTTP 413; the run paused and every re-drive
       re-sent the SAME payload. Shrink scales the budget AND force-enables
       trimming/eviction — a payload the endpoint refuses ships nothing, so the
       retry overrides noTrim for that attempt. */
    const shrinkLvl = Math.max(0, Math.min(2, Number(opts.shrink) || 0));
    const budgetTokens = Math.max(4, Number(cfg.contextK ?? 24)) * 1000 / (shrinkLvl ? Math.pow(2, shrinkLvl) : 1);
    const trimming = !cfg.noTrim || shrinkLvl > 0; // ADE-HF.4 toggle respected EXCEPT during a 413 shrink retry
    const est = (s) => U.estimateTokens(typeof s === "string" ? s : JSON.stringify(s ?? ""));
    const sys = { role: "system", content: Agent.buildSystemPrompt(cfg, opts) };

    const hist = State.msgs.filter(m =>
      m.convId === State.activeConvId &&
      m.id !== opts.excludeId &&          // the in-flight assistant placeholder
      !m.error &&
      (m.role === "user" || m.role === "assistant" || m.role === "tool") &&
      (m.role === "tool" ? true : !!((m.content || "").trim() || m.toolCalls))
    );

    /* hf.14 — segment history at REAL task-turn boundaries.
       A new segment starts ONLY on a user row that is a real task turn:
       not a continue nudge ("(auto continue …" / "(manual continue …")
       and not a proto-mode TOOL_RESULT wrapper. Both used to start their
       own segment, which made the REAL task turn "older" during an
       auto-continue: trim/eviction then f3-dropped the active verdict
       turn behind its own nudge (2026-10-31 field case — the run
       "resumed" a stale task from the RESUME STATE while the actual
       verdict dump was gone from the payload). Nudges and tool-result
       wrappers belong to the ONGOING task segment. */
    const isNudgeRow = (m) => m.role === "user" && m.systemNote === true && /^\((auto|manual) continue\b/.test(String(m.content || ""));
    const isToolResultRow = (m) => m.role === "user" && String(m.content || "").startsWith("TOOL_RESULT for");
    const segs = [];
    for (const m of hist) {
      if (!segs.length || (m.role === "user" && !isNudgeRow(m) && !isToolResultRow(m))) segs.push([m]);
      else segs[segs.length - 1].push(m);
    }
    const segTok = (s) => s.reduce((n, m) => n + est(m.content) + (m.toolCalls ? est(m.toolCalls) + 4 : 0) + 4, 0);
    let total = segs.reduce((n, s) => n + segTok(s), 0) + est(sys.content) + 8;
    /* ══ ADE-HF.4 · CONTEXT SHORTENING TOGGLE ══
       Both throttles below are gated on cfg.noTrim — unchecked (default)
       keeps the classic behavior; checked = the full history always ships
       verbatim (no dropped turns, no stubbed tool results).             */
    /* f3.summary.source (DETERMINISTIC — no model call): every segment the
       trim drops leaves ONE ledger line (topic + tools used). The ledger rides
       the newest task turn (tail injection — cache-safe) instead of rewriting
       the request prefix. */
    const droppedLedger = [];
    while (trimming && total > budgetTokens && segs.length > 1) {
      const s0 = segs[0];
      const topic = String((s0.find(m => m.role === "user") || {}).content || "").replace(/\s+/g, " ").trim().slice(0, 160); // hf.14 — 70 chars truncated a verdict dump into gibberish ("the graining echos ar") and the re-driven run misread which task had dropped; 160 keeps the topic identifiable
      const tl = s0.map(m => m.role === "tool" ? m.name : null).filter(Boolean);
      /* hf.16 — the ledger must be enough to RECONSTRUCT the dropped work,
         not just name it. Field case (2026-10-31 round-8): the surviving
         line said only "4 code edits" — the recovery run could not see
         WHICH files/find-texts the edits touched, mis-attributed the
         deliverable to an older round's sound, and registered a duplicate
         verdict while the fresh edits sat unregistered in the lab. Each
         line now carries per-tool arg digests (path · find snippet ·
         pattern · command) and the dropped turn's last assistant text —
         the lost report's head — so the next run rebuilds exactly. */
      const acts = [];
      for (const m of s0) {
        if (m.role !== "tool" || acts.length >= 5) continue;
        let a = "";
        try {
          const A = m.args || {};
          const pp = Array.isArray(A.path) ? A.path.join(",") : (A.path != null ? String(A.path) : (Array.isArray(A.paths) ? A.paths.join(",") : ""));
          if (m.name === "edit" && A.find != null) a = `${pp} find="${String(A.find).replace(/\s+/g, " ").trim().slice(0, 48)}"`;
          else if (A.pattern != null) a = `${pp ? pp + " " : ""}/${String(A.pattern).slice(0, 40)}/`;
          else if (pp) a = pp;
          else if (A.command != null) a = String(A.command).replace(/\s+/g, " ").trim().slice(0, 60);
          else if (A.code != null) a = "code";
        } catch { /* digest is cosmetic */ }
        if (a) acts.push(`${m.name}(${String(a).replace(/\s+/g, " ").slice(0, 90)})`);
      }
      const lastA = [...s0].reverse().find(m => m.role === "assistant");
      const rep = lastA ? String(Agent.splitThink(lastA.content || "").rest || lastA.content || "").replace(/\s+/g, " ").trim().slice(0, 200) : "";
      droppedLedger.push(`“${topic}”${acts.length ? ` · did: ${acts.join(" | ")}` : ""}${tl.length ? ` · tools: ${tl.join(", ")}` : ""}${rep ? ` · report: “${rep}”` : ""}`);
      total -= segTok(s0); segs.shift();
    }

    /* ══ ADE-S14.2 (ch-20.f2, m-35) · TOOL-RESULT EVICTION ══
       Soft trigger at ~60% of the context budget: tool results in all
       but the NEWEST segment collapse to one-line stubs — the active
       segment (what the model is working on right now) stays verbatim.
       Stubs keep the tool name + arg summary + original size so the
       model can re-read on purpose (read pagination makes that
       cheap). Persisted rows and tool-trace cards keep the FULL text. */
    const evict = new Set();
    const EVICT_AT = shrinkLvl ? 0 : 0.7; // ADE-HF.8 — a shrink retry stubs EVERY older segment's tool results · v13: 0.6→0.7 (fewer stub events = fewer cache-prefix breaks; the 413 auto-shrink still guards the wall)
    /* ADE-S25.8 (ch-31.f5, m-55) — UNABSORBED TOOL RESULTS NEVER EVICT.
       Field evidence: a TOOL_RESULT arrives full → the run dies → the
       manual/auto continue nudge (a role:user row) starts a NEW segment →
       this sweep stubs a result the model NEVER had a turn to absorb —
       paid content destroyed on arrival ("Evicted on arrival again. I
       never saw the Engage slice content"), and the model then burned its
       next turn re-deriving its own transcript. A role:tool row sitting
       AFTER the LAST assistant row in hist is by definition unabsorbed —
       it stays verbatim regardless of segment pressure. An evictable
       result is one the model has HAD a chance to read. */
    let _lastA = -1;
    for (let i = 0; i < hist.length; i++) if (hist[i].role === "assistant") _lastA = i;
    const fresh = new Set();
    for (let i = _lastA + 1; i < hist.length; i++) if (hist[i].role === "tool") fresh.add(hist[i].id);
    if (trimming && total > budgetTokens * EVICT_AT && segs.length > 1) {
      for (let i = 0; i < segs.length - 1; i++) {        // every segment except the newest
        for (const m of segs[i]) if (m.role === "tool" && !fresh.has(m.id)) evict.add(m.id);
      }
      // an assistant tool_calls block whose results were ALL evicted keeps its
      // tool rows (as stubs) — the API pairing contract is never broken
    }
    const stubFor = (m) => {
      let what = m.name || "tool";
      try { const s = Agent.argSummary(m.args || {}); if (s && s !== "—") what += " " + s; } catch { /* summary is cosmetic */ }
      const k = Math.round((m.content || "").length / 100) / 10;
      return `[evicted: ${what} · ${k}k chars · re-read if needed — read pagination makes it cheap]`;
    };
    const kept = segs.flat(); // eviction marks ids — the rows themselves all still flow

    const api = [sys];
    /* ADE-12.3 (ch-12.f3) — the cache-ref + drift manifest rides the NEWEST
       real task turn (ai.cache.patch.recipe.3), never a proto-mode
       TOOL_RESULT wrapper; deterministic per run so the prefix above the
       profile stays byte-stable, and never persisted to State.msgs.       */
    let deltaTarget = null;
    if (opts.deltaPrefix) {
      for (let i = kept.length - 1; i >= 0; i--) {
        const m = kept[i];
        if (m.role === "user" && !String(m.content || "").startsWith("TOOL_RESULT for")) { deltaTarget = m.id; break; }
      }
    }
    for (const m of kept) {
      if (m.role === "user") {
        const content = (m.id === deltaTarget) ? (opts.deltaPrefix + "\n\n" + m.content) : m.content;
        api.push({ role: "user", content });
      } else if (m.role === "assistant") {
        /* ADE-HF.3 — LEAN HISTORY: inline reasoning (think-blocks /
           leading blockquote walls) is NOT re-sent — it lives in
           msg.reasoning; the payload carries the answer only. Old rows
           (pre-fix) get the same treatment + any leftover tool-line
           fragments are stripped. Payload-only: the UI keeps the rows. */
        let lean = Agent.splitThink(m.content || "").rest || m.content || "";
        lean = lean.replace(/<<<TOOL[\s\S]*?>>>/g, "").replace(/<<<TOOL[\s\S]*$/, "");
        const a = { role: "assistant", content: lean };
        if (m.toolCalls && m.toolCalls.length) {
          a.tool_calls = m.toolCalls.map(t => ({
            id: t.id || "call_" + U.uid().slice(0, 8),
            type: "function",
            function: { name: t.name, arguments: t.arguments || "{}" }
          }));
        }
        api.push(a);
      } else if (m.role === "tool") {
        const content = evict.has(m.id) ? stubFor(m) : m.content; // eviction shapes the PAYLOAD only — State.msgs keep the full text
        if (opts.proto) api.push({ role: "user", content: `TOOL_RESULT for ${m.name}:\n${content}` });
        else api.push({ role: "tool", tool_call_id: m.toolCallId || "call_x", content });
      }
    }
    /* ADE-HF.8 (ch-33) — CONTEXT METER. The model cannot see its own payload
       size (the frame-scape run grew to ~55k tok with zero in-band signal and
       died on 413). One line rides the newest real user turn — cache-safe,
       that row is always fresh — showing est size vs budget, past 50%. */
    this.lastCtxTok = 0;
    for (const m of api) this.lastCtxTok += est(typeof m.content === "string" ? m.content : JSON.stringify(m.content ?? ""));
    this.lastMsgCount = api.length; // f2 — per-request message count for the error capture
    const lastUser = [...api].reverse().find(m => m.role === "user" && !String(m.content || "").startsWith("TOOL_RESULT for"));
    /* f1.read — RESUME STATE rides the NEWEST task turn (payload TAIL).
       Byte-stable within the run (stateText is read ONCE at run start) and
       the cached prefix above it is NEVER rewritten when the state file
       changes between runs. (First-user-turn injection — the sheet's letter —
       would rewrite the prefix on every state write: one cache miss per STEP.
       The user's cache-first rule wins; note logged in PATCHLOG §06.) */
    if (opts.stateText && lastUser) {
      const st = String(opts.stateText).trim().slice(0, 1200);
      /* hf.16 — STALE-STATE GUARD. The state file is written only when the
         agent emits a STATE block / state call — a run that dies mid-task
         (tool error, cut, stall) never updates it, so on a continue the
         file still describes the PREVIOUS task. Field case (2026-10-31
         round-8): the re-driven run read "task = backlog report · next =
         await verdicts", concluded "work complete" and replied DONE while
         its own edits sat half-shipped — the false-DONE at the root of the
         lost-report chain. When step events exist AFTER the newest task
         turn, the injection now says so, names a trailing tool ERROR, and
         forbids the state-file DONE. */
      let live = 0, liveErr = "";
      for (let i = kept.length - 1; i >= 0; i--) {
        const m = kept[i];
        if (m.role === "user" && !String(m.content || "").startsWith("TOOL_RESULT for") && !(m.systemNote === true && /^\((auto|manual) continue\b/.test(String(m.content || "")))) break;
        if (m.role === "tool") { live++; if (!liveErr && m.ok === false) liveErr = m.name || "tool"; }
        else if (m.role === "assistant" && m.toolCalls && m.toolCalls.length) live++;
      }
      if (live) {
        lastUser.content += `\n\n[RESUME STATE — harness-loaded from ade.state.flat.txt, but it MAY BE STALE: this conversation already has ${live} step event(s) AFTER the task turn below${liveErr ? `, and the last tool result was an ERROR (${liveErr})` : ""}. The state was last written BEFORE that work — continue the LIVE work from the transcript above, not the state's next line; reply DONE only when THIS task's deliverable is verified in this transcript, never because the state's next line looks finished]\n${st}`;
      } else {
        lastUser.content += `\n\n[RESUME STATE — harness-loaded from ade.state.flat.txt (saved by the earlier run):\n${st}\n— execute step_next now: do NOT re-plan from scratch; do NOT re-read files the done/next lines already cover unless a tool result contradicts them]`;
      }
    }
    if (droppedLedger.length && lastUser) {
      const led = droppedLedger.slice(-8).map((t, i) => `  ${i + 1}. ${t}`).join("\n");
      lastUser.content += `\n\n[f3 ledger — ${droppedLedger.length} earlier task turn(s) were dropped to fit the context budget (their tool results too):\n${led}\n— those results are NOT in this payload; the did: digests name the exact files/patterns each dropped turn touched, so reconstruct from them — re-read a file only if the current step truly needs it]`;
    }
    if (this.lastCtxTok > budgetTokens * 0.5 || shrinkLvl > 0) {
      const meter = `\n\n[ctx meter: ~${(this.lastCtxTok / 1000).toFixed(1)}k of ~${Math.round(budgetTokens / 1000)}k tok est${shrinkLvl ? ` · SHRINK LEVEL ${shrinkLvl} active (history was force-stubbed to fit the endpoint)` : ""} — past ~80%: stop reading, start writing; old tool results are stubs, re-read only what you need]`;
      if (lastUser) lastUser.content += meter; // payload-only — State.msgs untouched
    }
    return api;
  },

  /* resolved request URL — proxy template with {url}/{corskey}
     (moved here from ui-chat.js with the stream loop, CH-05)
     ADE-HF.2 — a {corskey} template with NO key stored still resolves
     (so the request fires and the provider's 403/401 educates) but the
     user is warned ONCE per session that the key entry lives in
     Settings → Proxy Setup (now rendering correctly per ADE-HF.1). */
  async resolveUrl(cfg) {
    const target = (cfg.baseUrl || "").replace(/\/+$/, "") + "/chat/completions";
    const tpl = (cfg.proxyUrl || "").trim();
    if (!tpl) return target;
    let url = tpl;
    if (url.includes("{corskey}")) {
      if (!(State.corsKey || "").trim() && !this._keyWarned) {
        this._keyWarned = true;
        U.toast("CorsProxy key missing", { kind: "err", msg: "This config tunnels through CorsProxy.io — paste your key in Settings → Proxy Setup (Save key), then Test ping to verify.", ms: 5600 });
      }
      url = url.replace("{corskey}", encodeURIComponent(State.corsKey || ""));
    }
    if (url.includes("{url}")) { url = url.replace("{url}", encodeURIComponent(target)); return url; }
    if (!/\{\w+\}/.test(url)) return url.replace(/\/+$/, "") + "/" + target; // prefix-style proxy
    return url;
  },

  _stopped() { return !!(ChatUI.abortCtl && ChatUI.abortCtl.signal.aborted); },

  /* ══ ADE-S18.2 (ch-24.f2, m-43) · TOKEN-BURN NORMALIZER ══
     One shape for every provider telemetry the gateway may return:
     · OpenAI-compat (/v1/chat/completions — AIHubMix default):
       usage{prompt_tokens · completion_tokens · total_tokens}
       + completion_tokens_details.reasoning_tokens (thinking models)
       + prompt_tokens_details.cached_tokens
     · Gemini-native (usage telemetry rides usage_metadata):
       prompt_token_count · candidates_token_count ·
       thoughts_token_count · total_token_count
     Returns { p, o, r, t, cached } or null when the payload carries
     NO usable numbers (never a phantom 0-burn row). VALIDATED
     test-first: scripts/test_usage_parser.mjs — 9/9 (OpenAI with /
     without reasoning split · Gemini metadata incl. bare-frame form
     · flat reasoning fallback · computed total · junk → null · full
     SSE stream capture incl. usage-only final chunk · Σ per-request
     conversation burn). */
  normalizeUsage(u) {
    if (!u || typeof u !== "object") return null;
    let meta = u.usage_metadata || u.usageMetadata || null;      // Gemini native shape
    if (!meta && (u.prompt_token_count != null || u.total_token_count != null)) meta = u; // called on a BARE usage_metadata object (SSE frame root)
    const det = u.completion_tokens_details || null;
    const pdet = u.prompt_tokens_details || null;
    const n = (v) => { const x = Number(v); return Number.isFinite(x) && x >= 0 ? x : null; };
    const p = n(u.prompt_tokens) ?? n(meta?.prompt_token_count);
    const c = n(u.completion_tokens) ?? n(meta?.candidates_token_count);
    const r = n(det?.reasoning_tokens) ?? n(u.reasoning_tokens) ?? n(meta?.thoughts_token_count);
    const t = n(u.total_tokens) ?? n(meta?.total_token_count) ?? ((p ?? 0) + (c ?? 0));
    if (p == null && c == null && r == null && n(u.total_tokens) == null && n(meta?.total_token_count) == null) return null;
    return {
      p: p || 0,             // prompt (input) tokens
      o: c || 0,             // output (completion) tokens
      r: r || 0,             // reasoning tokens (0 = provider did not report the split)
      t: t || 0,             // total burn
      cached: pdet ? (n(pdet.cached_tokens) || 0) : (n(meta?.cached_content_token_count) || 0)
    };
  },

  /* one POST — abort controller lives on ChatUI so the existing
     stop button keeps working unchanged */
  async _post(cfg, bodyObj) {
    const url = await Agent.resolveUrl(cfg);
    /* ADE-S25.8 (ch-32.f1, m-57) — the run owns ONE controller (created at
       runAgent entry). Reuse it; replace only when missing/aborted, so a
       Stop pressed during a retry backoff stays aborted (the next fetch
       rejects immediately) instead of being silently swapped for a fresh
       controller that fires anyway. */
    if (!ChatUI.abortCtl || ChatUI.abortCtl?.signal?.aborted) ChatUI.abortCtl = new AbortController();
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + cfg.apiKey },
      body: JSON.stringify(bodyObj),
      signal: ChatUI.abortCtl.signal
    });
  },

  /* ══ SSE loop (moved from ui-chat.js, CH-05) — delta content +
     reasoning_content capture (feeds the ADE-05.6 viewer) +
     index-keyed tool_calls fragment accumulation. 60ms flush.
     ADE-S18.3 (ch-24.f2, m-43): the final chunk's usage telemetry
     (OpenAI `usage` · Gemini `usage_metadata` — AIHubMix returns it
     when stream_options.include_usage is set) is captured via
     Agent.normalizeUsage and returned as `usage`.                  */
  async _readSSE(res, asstMsg, onReasoning) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "", acc = "", reasonAcc = "", usage = null;
    const toolAcc = {};
    let lastFlush = 0, lastThink = 0, aborted = false;
    /* ADE-HF.3 — the "hang forever" report: some gateways die silently
       mid-stream and reader.read() never resolves, so the UI spins
       forever. A 120 s no-data watchdog aborts the fetch and runAgent
       closes/continues honestly instead of hanging. */
    const IDLE_MS = 120000;
    let stalled = false, finishReason = null, lastThinkShown = "";
    let sawDone = false, netDead = false;   // ADE-HF.6 — premature-close detection
    let idleTimer = null;
    const armIdle = () => { clearTimeout(idleTimer); idleTimer = setTimeout(() => { stalled = true; try { ChatUI.abortCtl?.abort(); } catch { /* already dead */ } }, IDLE_MS); };
    armIdle();

    const patchDom = () => {
      const el = document.querySelector(`.msg[data-id="${asstMsg.id}"] .md`);
      if (!el) return;
      /* ADE-HF.3 — inline-reasoning split (GLM folds thinking into the
         body): the wall streams into the ✦ panel, the bubble stays the
         actual answer. Re-split per flush — cheap string scan. */
      const sp = Agent.splitThink(acc);
      if (sp.think) {
        asstMsg.reasoning = reasonAcc ? (reasonAcc + "\n\n" + sp.think) : sp.think;
        if (sp.think !== lastThinkShown) { lastThinkShown = sp.think; if (onReasoning) onReasoning(); }
      }
      asstMsg.content = sp.rest;
      const thread = document.getElementById("thread");
      const stick = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 90;
      el.innerHTML = renderMarkdown(sp.rest);
      if (stick) thread.scrollTop = thread.scrollHeight; // stick-to-bottom ONLY if the user already sat at the bottom — reading position is never yanked ("keep chat on the same line it was when I typed")
    };

    while (true) {
      let chunk;
      try { chunk = await reader.read(); }
      catch { /* user stop / watchdog abort → signal aborted; a silent gateway
                 death rejects the reader WITHOUT the signal — that is a
                 network cut, not a stop (ADE-HF.6) */
             aborted = true;
             netDead = !(ChatUI.abortCtl && ChatUI.abortCtl.signal.aborted);
             break; }
      armIdle(); // any chunk proves the stream alive
      if (chunk.done) break;
      buffer += decoder.decode(chunk.value, { stream: true });
      const events = buffer.split("\n\n");
      buffer = events.pop() || "";
      for (const evt of events) {
        for (const line of evt.split("\n")) {
          if (!line.startsWith("data:")) continue;
          const data = line.slice(5).trim();
          if (data === "[DONE]") { sawDone = true; buffer = ""; break; }
          try {
            const json = JSON.parse(data);
            const delta = json?.choices?.[0]?.delta || {};
            if (typeof delta.content === "string" && delta.content) acc += delta.content;
            /* ADE-HF.3 — finish_reason capture: without this a
               `length` cutoff (reply truncated at the output-token
               limit mid-sentence) was invisible and the run just
               ended silently — the "tasks drop mid process" report. */
            if (json?.choices?.[0]?.finish_reason) finishReason = json.choices[0].finish_reason;
            /* ADE-S18.3 (ch-24.f2, m-43) — exact token burn: the final
               frame carries usage (OpenAI shape) or usage_metadata
               (Gemini shape, frame root). Last one wins. */
            if (json?.usage || json?.usage_metadata) {
              const u = this.normalizeUsage(json.usage || json.usage_metadata);
              if (u) usage = u;
            }
            /* reasoning capture — GLM streams reasoning_content (m-22);
               asstMsg.reasoning updates in memory so the viewer reads it */
            if (typeof delta.reasoning_content === "string" && delta.reasoning_content) {
              reasonAcc += delta.reasoning_content;
              asstMsg.reasoning = reasonAcc;
              const now = Date.now();
              if (onReasoning && now - lastThink > 250) { onReasoning(); lastThink = now; } // off the hot path
            }
            if (Array.isArray(delta.tool_calls)) {
              for (const tc of delta.tool_calls) {
                const i = tc.index ?? 0;
                toolAcc[i] = toolAcc[i] || { id: "", name: "", arguments: "" };
                if (tc.id) toolAcc[i].id += tc.id;
                if (tc.function?.name) toolAcc[i].name += tc.function.name;
                if (tc.function?.arguments) toolAcc[i].arguments += tc.function.arguments;
              }
            }
            const now = Date.now();
            if (now - lastFlush > 60 && acc) { patchDom(); lastFlush = now; }
          } catch { /* skip malformed frame */ }
        }
      }
    }
    clearTimeout(idleTimer);
    const fin = Agent.splitThink(acc); // final split — persistence uses the lean body; the raw acc still carries the tool line for the parser
    if (fin.think) asstMsg.reasoning = reasonAcc ? (reasonAcc + "\n\n" + fin.think) : fin.think;
    return {
      acc,                                          // RAW reply — the proto parser scans this (tool line = last line)
      rest: fin.rest, think: fin.think,             // split for persistence: bubble = answer · ✦ panel = the reasoning wall
      reasonAcc, finishReason, stalled, aborted,
      /* ADE-HF.6 — the "cut abruptly, no closing statement" report: a
         stream that ends with NEITHER [DONE] NOR finish_reason was a
         premature gateway close (the partial text arrived, the run
         just stopped). Flagged as a cut → runAgent auto-continues. */
      truncated: !sawDone && !finishReason && !aborted && !stalled,
      netDead,
      toolCalls: Object.keys(toolAcc).length ? Object.values(toolAcc) : undefined,
      usage
    };
  },

  /* ══ ADE-S25.5 (ch-31.f3, m-55) · TRANSIENT-GATEWAY RETRY TABLE ══
     Field evidence: "Request failed HTTP 524" killed a mid-task step
     (Cloudflare origin-timeout — the m-52 429/proxy infra family). These
     statuses are almost always transient at the gateway/proxy: _streamOnce
     retries them ≤2× per step (2.5 s → 7 s backoff, Retry-After honored,
     capped 15 s) before surfacing the error. 400-class config bugs still
     fail fast — they are NOT in the table. */
  TRANSIENT_STATUS: [408, 425, 429, 500, 502, 503, 504, 522, 523, 524, 529],
  HTTP_HINTS: {
    408: "request timeout — the gateway gave up waiting",
    413: "payload too large — the endpoint refused the request size; the auto-shrink retry (tool results stubbed, context ÷2/÷4) may clear it — else lower Settings → contextK",
    429: "rate-limited — quota or concurrency; the retry backoff may clear it",
    500: "upstream error — usually transient at the gateway",
    502: "bad gateway — the proxy lost the upstream",
    503: "service unavailable — upstream overloaded or down",
    504: "gateway timeout — the upstream took too long",
    522: "connection timed out (Cloudflare)",
    523: "origin unreachable (Cloudflare)",
    524: "gateway timeout (Cloudflare) — the model/proxy took too long",
    529: "upstream overloaded"
  },

  /* ONE streamed request → { acc, reasonAcc, toolCalls, aborted } or
     { error }.  ADE-05.4: on 400/404/422 whose body mentions
     tools/functions → ONE retry without the tools array + proto
     appendix; runAgent then stays in text protocol for the run.    */
  async _streamOnce(cfg, asstMsg, opts) {
    /* ADE-12.7 (ch-12.f7, m-41) — extra-body pass-through: cfg.extraBody JSON
       is merged VERBATIM into every request body LAST (after stream_options /
       tools, so a vendor knob like reasoning_effort / thinking / enable_thinking
       wins by design). Invalid JSON = an honest error row BEFORE any request
       fires and before State.sessionRequests counts a phantom.             */
    let extra = null;
    const rawExtra = String(cfg.extraBody || "").trim();
    if (rawExtra) {
      try { extra = JSON.parse(rawExtra); }
      catch (e) { return { error: "Extra request body is not valid JSON — fix it in Settings → Configs (advanced). " + (e && e.message ? e.message : "") }; }
      if (!extra || typeof extra !== "object" || Array.isArray(extra)) {
        return { error: "Extra request body must be a single JSON object (e.g. {\"reasoning_effort\":\"low\"}) — fix it in Settings → Configs (advanced)." };
      }
    }
    State.sessionRequests++; // ADE-06.3 — real per-session request count (usage pill)
    const bodyObj = () => {
      const apiMessages = Agent.buildContext(cfg, { proto: opts.proto, excludeId: asstMsg.id, tree: opts.tree, deltaPrefix: opts.deltaPrefix, profileText: opts.profileText, shrink: opts._shrink || 0, stateText: opts.stateText }); // ADE-12.2/12.3 — profile prefix + drift manifest · ADE-HF.8 — 413 shrink level · v13 f1 — RESUME STATE rides the newest task turn
      const b = {
        model: cfg.model,
        messages: apiMessages,
        stream: true,
        temperature: Number(cfg.temperature ?? 0.6),
        max_tokens: Number(cfg.maxTokens ?? 8192)
      };
      /* ADE-S18.3 (ch-24.f2, m-43) — ask the gateway for the exact usage
         telemetry: OpenAI's stream_options.include_usage makes the FINAL
         SSE chunk carry the burn numbers (AIHubMix is OpenAI-compatible).
         opts.noUsage flips on a one-shot defensive retry if an endpoint
         rejects the unknown field — default path stays byte-compatible. */
      if (!opts.noUsage) b.stream_options = { include_usage: true };
      if (opts.useTools && !opts.proto) {
        b.tools = Agent.TOOLS.map(t => ({ type: "function", function: { name: t.name, description: t.description, parameters: t.parameters } }));
      }
      if (extra) Object.assign(b, extra); // ADE-12.7 — merged last: vendor knobs win (pass-through semantics)
      this.lastReqBytes = JSON.stringify(b).length; // f2 — request byte size for the error capture + cache math
      return b;
    };

    let res;
    try { res = await this._post(cfg, bodyObj()); }
    catch (e) {
      if (e.name === "AbortError") return { aborted: true };
      /* ADE-S25.5 (ch-31.f3, m-55) — ONE retry on a thrown network fetch:
         "Failed to fetch" is very often a momentary proxy hiccup, and the
         pre-retry evidence shows those clear within seconds. */
      if (!this._stopped()) {
        U.toast("Network hiccup", { kind: "info", msg: "Connection dropped — retrying once in 2.5 s…", ms: 2400 });
        await new Promise(r0 => setTimeout(r0, 2500));
        if (this._stopped()) return { aborted: true }; // ADE-S25.8 (ch-32.f1) — never fire after a Stop
        try { res = await this._post(cfg, bodyObj()); }
        catch (e2) { if (e2.name === "AbortError") return { aborted: true }; e = e2; }
      }
      let hint = e?.message || String(e);
      if (/Failed to fetch|NetworkError|Load failed/i.test(hint)) {
        hint = hint + (cfg.proxyUrl
          ? " — the CORS proxy may be down, rate-limited, or your CorsProxy key is missing/invalid. Wire it in Settings → Proxy Setup (wiring status + Save key + Test ping, ADE-HF.1)."
          : " — the provider likely blocks browser CORS. Set a Proxy URL in Settings.");
      }
      asstMsg.error = hint;
      await DB.saveMsg(asstMsg);
      ChatUI.renderThread();
      return { error: hint };
    }

    /* ADE-S18.3 — read a 4xx body EXACTLY ONCE: three fallbacks share it
       (tools → text protocol · stream_options → drop the field · final
       honest error). Reading per-block double-consumed the body and the
       later fallbacks silently lost their match signal.                 */
    let detail4xx = "";
    if (!res.ok) { // f2 — the body is read EXACTLY ONCE for EVERY failure: the 413/429/5xx body NAMES the limit (the failed run never captured it)
      try { detail4xx = (await res.text()) || ""; } catch { /* empty or body-less */ }
    }

    /* ADE-05.4 — endpoint rejected the tools array → text-protocol retry */
    if (!res.ok && opts.useTools && !opts.proto && [400, 404, 422].includes(res.status)) {
      if (/tool|function/i.test(detail4xx)) {
        opts.proto = true; // sticky for the rest of this run
        U.toast("Text-protocol fallback", { kind: "info", msg: `HTTP ${res.status} mentioning tools — retrying without the tools array (<<<TOOL>>> protocol).`, ms: 4200 });
        try { res = await this._post(cfg, bodyObj()); }
        catch (e) {
          if (e.name === "AbortError") return { aborted: true };
          asstMsg.error = e?.message || String(e);
          await DB.saveMsg(asstMsg);
          ChatUI.renderThread();
          return { error: asstMsg.error };
        }
      }
    }

    /* ADE-S18.3 (ch-24.f2, m-43) — ONE defensive retry: an endpoint that
       rejects stream_options with a 400 naming it drops the field and
       retries; exact burn just stays unavailable on such endpoints.   */
    if (!res.ok && res.status === 400 && !opts.noUsage && /stream_options|include_usage/i.test(detail4xx)) {
      opts.noUsage = true; // sticky for the rest of this run
      try { res = await this._post(cfg, bodyObj()); }
      catch (e) {
        if (e.name === "AbortError") return { aborted: true };
        asstMsg.error = e?.message || String(e);
        await DB.saveMsg(asstMsg);
        ChatUI.renderThread();
        return { error: asstMsg.error };
      }
    }

    /* ADE-S25.5 (ch-31.f3, m-55) — retry TRANSIENT gateway statuses before
       surfacing the error (≤2× per step, backoff, Retry-After honored). */
    if (!res.ok && !this._stopped()) {
      let rt = 0;
      while (!res.ok && this.TRANSIENT_STATUS.includes(res.status) && rt < 3 && !this._stopped()) { // f6.retry — 3 attempts (2 s / 5 s / 12 s), Retry-After still honored
        rt++;
        let wait = rt === 1 ? 2000 : rt === 2 ? 5000 : 12000;
        try { const ra = parseInt(res.headers && res.headers.get ? res.headers.get("retry-after") : "", 10); if (Number.isFinite(ra) && ra > 0) wait = Math.min(ra * 1000, 15000); } catch { /* headers cosmetic */ }
        U.toast("Gateway hiccup", { kind: "info", msg: `HTTP ${res.status} — retrying in ${Math.round(wait / 1000)} s (attempt ${rt}/3)…`, ms: 2600 });
        await new Promise(r0 => setTimeout(r0, wait));
        if (this._stopped()) return { aborted: true }; // ADE-S25.8 (ch-32.f1) — never fire after a Stop
        try { res = await this._post(cfg, bodyObj()); }
        catch (e) {
          if (e.name === "AbortError") return { aborted: true };
          asstMsg.error = e?.message || String(e);
          await DB.saveMsg(asstMsg);
          ChatUI.renderThread();
          return { error: asstMsg.error };
        }
      }
    }
    /* ADE-HF.8 (ch-33) — 413 AUTO-SHRINK RETRY. HTTP 413 = payload too large:
       retrying verbatim can never succeed (the old behavior — pause + re-drive
       — just burned the continue). The SAME step re-posts ≤2× with the context
       force-shrunk (tool results stubbed, budget ÷2 then ÷4). Not transient —
       never retried without the shrink. */
    if (!res.ok && res.status === 413 && !this._stopped()) {
      for (let lvl = 1; lvl <= 2 && !this._stopped(); lvl++) {
        opts._shrink = lvl; // sticky for the rest of this run — once too big, always guarded
        U.toast("Payload too large — auto-shrink", { kind: "info", msg: `HTTP 413 — retrying at shrink level ${lvl} (tool results stubbed, context ÷${lvl * 2})…`, ms: 3400 });
        await new Promise(r0 => setTimeout(r0, 900));
        try { res = await this._post(cfg, bodyObj()); }
        catch (e) {
          if (e.name === "AbortError") return { aborted: true };
          asstMsg.error = e?.message || String(e);
          await DB.saveMsg(asstMsg);
          ChatUI.renderThread();
          return { error: asstMsg.error };
        }
        if (res.ok || res.status !== 413) break; // shipped, or a different failure — let normal handling take it
      }
    }
    if (!res.ok) {
      const httpHint = this.HTTP_HINTS[res.status];
      asstMsg.error = `HTTP ${res.status} ${res.statusText}` + (httpHint ? ` — ${httpHint}` : "") + (detail4xx ? " — " + detail4xx.slice(0, 500) : "") + ` · req ${((this.lastReqBytes || 0) / 1024).toFixed(1)} KB · ~${(this.lastCtxTok || 0).toLocaleString()} tok est · ${this.lastMsgCount || "?"} msgs` + " · run paused — auto-continue will re-drive it (or press ↻ Continue / send a message).";
      await DB.saveMsg(asstMsg);
      ChatUI.renderThread();
      await this._errLog(`HTTP ${res.status} ${res.statusText} · req ${this.lastReqBytes || 0} B · ~${this.lastCtxTok || 0} tok · ${this.lastMsgCount || "?"} msgs · tool-schema ~${this._schemaBytes()} B · body: ${detail4xx.slice(0, 800)}`); // f2.log.where — ade.errors.log (line ≤4 KB, file ≤20 KB), awaited so the log exists before the run pauses
      return { error: asstMsg.error };
    }
    if (!res.body) {
      asstMsg.error = "No response body from upstream.";
      await DB.saveMsg(asstMsg);
      ChatUI.renderThread();
      return { error: asstMsg.error };
    }

    return await this._readSSE(res, asstMsg, () => ChatUI.noteReasoning(asstMsg));
  },

  /* per-step "step k/N" tag in the streaming message meta */
  _stepTag(m, step, max) {
    const meta = document.querySelector(`.msg[data-id="${m.id}"] .meta`);
    if (!meta) return;
    let el = meta.querySelector(".step-tag");
    if (!el) {
      el = document.createElement("span");
      el.className = "step-tag";
      meta.insertBefore(el, meta.querySelector(".tok-est"));
    }
    el.textContent = `step ${step}/${max}`;
  },

  /* ══ ADE-12.3 (ch-12.f3, m-29) · CACHE PILL ══
     "changes since snapshot: N files · est k" in the assistant message
     meta — same inject-into-.meta pattern as _stepTag (zero ui-chat.js
     coupling). Cosmetic: never throws.                                */
  _cachePill(m, text) {
    try {
      const meta = document.querySelector(`.msg[data-id="${m.id}"] .meta`);
      if (!meta) return;
      let el = meta.querySelector(".cache-pill");
      if (!el) {
        el = document.createElement("span");
        el.className = "cache-pill";
        meta.insertBefore(el, meta.querySelector(".step-tag") || meta.querySelector(".tok-est"));
      }
      el.textContent = text;
      el.title = "Prompt-cache mode (ch-12): the profile prefix is byte-stable; drift rides the task turn as a delta";
    } catch { /* pill is cosmetic */ }
  },

  /* ══ ADE-HF.9 (v13) · STATE HANDOFF + ERROR CAPTURE + IMAGE DECODE ══ */

  _schemaBytes() { // f2 — tool-schema byte weight (cached)
    if (this.__schemaBytes == null) {
      try { this.__schemaBytes = JSON.stringify(this.TOOLS.map(t => ({ type: "function", function: { name: t.name, description: t.description, parameters: t.parameters } }))).length; }
      catch { this.__schemaBytes = 0; }
    }
    return this.__schemaBytes;
  },

  /* ══ hf.16 · DEBUG LEDGER (ade.debug.flat.txt) ══
     The user's spec: "pulls every empty response, exact tool that was used
     just before it, exact query the tool ran, agent's thoughts — all
     dated/timed and recorded automatically in ade.debug.flat.txt", with a
     BURN-pane debug button that copies the CURRENT session's lines to the
     clipboard. One flat line per event, append-only, file capped (header
     kept, oldest dropped) — the same discipline as ade.errors.log. */
  DEBUG_FILE: "/ade.debug.flat.txt",
  DEBUG_CAP: 49152,
  async dbg(line) {
    try {
      let old = "";
      try { old = (await VFS.readText(this.DEBUG_FILE)) || ""; } catch { /* first write */ }
      let body = old;
      if (!body.startsWith("#")) body = "# ade.debug.flat.txt — harness-written DEBUG ledger (hf.16): empty-response / stall deaths + tool errors, one flat line each, append-only; the BURN strip's 🐛 debug button copies the ACTIVE conversation's lines to the clipboard\n";
      body += line.endsWith("\n") ? line : line + "\n";
      if (body.length > this.DEBUG_CAP) { // cap: keep the header + the newest lines
        const rows = body.split("\n");
        const head = rows[0] + "\n";
        const keep = [];
        let size = head.length;
        for (let i = rows.length - 1; i > 0; i--) {
          const L = rows[i] + "\n";
          if (size + L.length > this.DEBUG_CAP - 200) break;
          keep.unshift(L); size += L.length;
        }
        body = head + keep.join("");
      }
      await VFS.put(this.DEBUG_FILE, body, true);
      return true;
    } catch { return false; } // debug is best-effort — never breaks the run
  },
  _dbgRow(m) { // one flat digest of a tool row: exact tool + exact query + result head
    if (!m) return "";
    let args = "";
    try { args = JSON.stringify(m.args || {}); } catch { args = "{}"; }
    if (args.length > 240) args = args.slice(0, 237) + "…";
    const res = String(m.content || "").replace(/\s+/g, " ").trim();
    return `tool ${m.name} ${args} · ${m.ok === false ? "ERROR" : "ok"}${m.ms != null ? " " + m.ms + "ms" : ""} · result: ${res.slice(0, 100)}`;
  },
  async dbgDeath(death, attempt, deadRow) {
    /* rich line for an auto-continue death: the exact tool + query that ran
       just before it, the agent's thoughts (nearest reasoning), dated. */
    try {
      const conv = String(State.activeConvId || "?").slice(0, 12);
      const idx = State.msgs.lastIndexOf(deadRow);
      let toolTxt = "no tool ran before it (death right after a user/nudge turn)";
      let thought = "";
      for (let i = idx; i >= 0; i--) {
        const m = State.msgs[i];
        if (i < idx && m.role === "tool" && toolTxt.startsWith("no tool")) { const d = this._dbgRow(m); if (d) toolTxt = d; }
        if (m.role === "assistant" && m.reasoning && !thought) thought = String(m.reasoning).replace(/\s+/g, " ").trim().slice(0, 160);
      }
      const kind = /empty response/i.test(String(death)) ? "EMPTY RESPONSE" : "STALL";
      const own = deadRow && deadRow.reasoning ? String(deadRow.reasoning).replace(/\s+/g, " ").trim().slice(0, 160) : "";
      await this.dbg(`dbg ${new Date().toISOString()} · conv ${conv} · ${kind} (auto-continue attempt ${attempt}) · death: ${String(death).replace(/\s+/g, " ").slice(0, 80)} · before: ${toolTxt}${own ? ` · own thought: "${own}"` : ""}${thought ? ` · thought: "${thought}"` : ""}`);
    } catch { /* best-effort */ }
  },
  async dbgToolError(tMsg) {
    try { await this.dbg(`dbg ${new Date().toISOString()} · conv ${String(State.activeConvId || "?").slice(0, 12)} · TOOL ERROR · ${this._dbgRow(tMsg)}`); } catch { /* best-effort */ }
  },
  debugSessionText(convId, fileText) {
    /* pure + testable: the CURRENT session's debug lines (conv match), oldest first */
    const lines = String(fileText || "").split("\n").filter(L => L.startsWith("dbg "));
    const key = `conv ${String(convId || "?").slice(0, 12)} `;
    const hit = lines.filter(L => L.includes(key));
    return hit.length ? hit.join("\n") : "(no debug lines recorded for this session yet — empty responses, stalls and tool errors land here automatically)";
  },
  async copyDebugSession() {
    try {
      const txt = await VFS.readText(this.DEBUG_FILE);
      const body = this.debugSessionText(State.activeConvId, txt);
      const out = `ADE DEBUG — session ${String(State.activeConvId || "?").slice(0, 12)} · ${new Date().toISOString()}\n${body}`;
      U.copyText(out);
      const n = body.split("\n").length;
      U.toast("Debug copied", { kind: "info", msg: `${n} debug line${n === 1 ? "" : "s"} for this session copied to the clipboard (full ledger: /ade.debug.flat.txt).`, ms: 3400 });
    } catch {
      U.toast("Debug copy failed", { kind: "err", msg: "Could not read /ade.debug.flat.txt.", ms: 3000 });
    }
  },
  async _errLog(line) { // f2.log.where — one flat line per failure into ade.errors.log (VFS root), file capped 20 KB (oldest dropped). Best-effort: never throws.
    try {
      const f = "/ade.errors.log";
      const prev = (await VFS.readText(f)) || "";
      const entry = `${new Date().toISOString()} · ${String(line).replace(/\s+/g, " ").slice(0, 4000)}\n`;
      await VFS.put(f, (prev + entry).slice(-20480), true);
    } catch { /* error logging must never error */ }
  },

  _parseState(body) { // f1.model.contract — LAST <<<STATE … STATE>>> block wins; null when absent or next-less
    const s = String(body || "");
    const re = /<<<STATE\s*\n([\s\S]*?)\s*STATE>>>/g;
    let m, last = null;
    while ((m = re.exec(s))) last = m[1];
    return last && /next\s*:/.test(last) ? last.trim() : null;
  },

  async _saveState(block) { // f1.write — the HARNESS owns ade.state.flat.txt (<1 KB by construction); no block → previous file stands
    try {
      const g = (k, d) => { const m = new RegExp(`^\\s*${k}\\s*:\\s*(.*)$`, "m").exec(block); return (m ? m[1] : d || "").trim().slice(0, 340); };
      const task = g("task"), doneS = g("done"), next = g("next"), flags = g("flags", "none") || "none";
      if (!task && !next) return false;
      const txt = `# ade.state.flat.txt — harness-written resume pointer (parsed from the agent's STATE block)\n# re-injected on every run start / continue — a restart costs ONE tiny read, never a re-survey\nupdated = ${new Date().toISOString()}\ntask = ${task}\ndone = ${doneS || "(none recorded)"}\nnext = ${next || "(none recorded)"}\nflags = ${flags}\n`;
      if (txt.length > 1200) return false; // never let the pointer file bloat
      await VFS.put("/ade.state.flat.txt", txt, true);
      return true;
    } catch { return false; }
  },

  async _loadState() {
    try { const t = await VFS.readText("/ade.state.flat.txt"); return t && t.trim() ? t.trim() : null; } catch { return null; }
  },

  _fnv(s) { // hf.10 — 32-bit FNV-1a over UTF-8 bytes. Drift DETECTION, not crypto: paired with byte-length in every comparison, and assemble cross-checks the rebuilt master against the split-source digest.
    try {
      const u8 = s instanceof Uint8Array ? s : new TextEncoder().encode(String(s ?? ""));
      let h = 0x811c9dc5;
      for (let i = 0; i < u8.length; i++) { h ^= u8[i]; h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0; }
      return ("0000000" + h.toString(16)).slice(-8);
    } catch { return "fnv-unavailable"; }
  },

  async _ledgerManifest(ref) { // hf.10 — resolve manifest.json | parts dir → {manifest, dir, manifestPath} or {err}
    try {
      let p = VFS.norm(String(ref ?? "").trim());
      if (!p || p === "/") return { err: "manifest path required — e.g. /master.parts/manifest.json (or just the .parts folder)" };
      while (p.length > 1 && p.endsWith("/")) p = p.slice(0, -1);
      if (!p.endsWith("/manifest.json")) {
        const cand = p + "/manifest.json";
        if (await VFS.exists(cand)) p = cand;
        else return { err: `no manifest.json in ${p} — split writes one; re-split if the folder is gone` };
      }
      const raw = await VFS.readText(p);
      if (raw == null) return { err: `manifest unreadable: ${p}` };
      const m = JSON.parse(raw);
      if (!m || !Array.isArray(m.parts) || !m.parts.length || !m.source) return { err: `manifest malformed (needs source + parts[]) — re-run split: ${p}` };
      return { manifest: m, dir: p.slice(0, -"/manifest.json".length), manifestPath: p };
    } catch (e) { return { err: `manifest error: ${e && e.message ? e.message : e}` }; }
  },

  _imgKind(u8) {
    if (u8[0] === 0x89 && u8[1] === 0x50) return "png";
    if (u8[0] === 0xff && u8[1] === 0xd8) return "jpeg";
    if (u8[0] === 0x47 && u8[1] === 0x49) return "gif";
    if (u8[8] === 0x57 && u8[9] === 0x45 && u8[10] === 0x42) return "webp";
    if (u8[0] === 0x42 && u8[1] === 0x4d) return "bmp";
    return "";
  },

  async _decodeImage(u8) { // f10 — bytes → { w, h, data(RGBA) }, or null when this context has no decoder. NEVER throws.
    try {
      if (typeof createImageBitmap === "function") {
        const bmp = await createImageBitmap(new Blob([u8]));
        const cw = bmp.width, chh = bmp.height;
        let ctx = null;
        if (typeof OffscreenCanvas === "function") {
          ctx = new OffscreenCanvas(cw, chh).getContext("2d", { willReadFrequently: true });
        } else if (typeof document !== "undefined" && document.createElement) {
          const c = document.createElement("canvas");
          c.width = cw; c.height = chh;
          ctx = c.getContext("2d", { willReadFrequently: true });
        }
        if (!ctx) return null;
        ctx.drawImage(bmp, 0, 0);
        const id = ctx.getImageData(0, 0, cw, chh);
        try { if (bmp.close) bmp.close(); } catch { /* cosmetic */ }
        return { w: cw, h: chh, data: id.data };
      }
    } catch { /* fall through to the honest null */ }
    return null;
  },

  /* ══ ADE-05.2 · THE AGENT LOOP ══
     streamed requests with the tools array · assistant tool_calls
     accumulated + persisted · each call executed, results persisted
     as role:tool · loop continues (cap = cfg.maxSteps) · STOP aborts
     the fetch AND gates tool execution · the final assistant summary
     renders as markdown.  ADE-05.4: once an endpoint rejects tools,
     the whole run switches to the <<<TOOL>>> text protocol.        */
  async runAgent(cfg, userMsg, asstMsg) {
    ChatUI._thinkAuto = null; // re-read the auto-expand setting per run
    /* ADE-S25.8 (ch-32.f1, m-57) — FRESH ABORT CONTROLLER PER RUN. Field
       reports: "last update disabled all of my models!!!!!!" · "Request
       failed / Stopped before any tokens arrived" on EVERY config · "i
       added an antropic endpoint from z.ai, and it glitched my entire
       workbase". Root cause: ChatUI.abortCtl was created per _post but
       NEVER reset at run start — after ANY abort (user Stop · the ch-29.f3
       mid-stream Continue push · the HF.3 120 s watchdog) the NEXT
       runAgent — a manual send, a Continue re-drive, or the ch-31.f4
       auto-continue — hit the loop-top _stopped() check below with the
       PREVIOUS run's aborted controller and died instantly, before any
       request, on every config. One stale abort locked the whole app.
       The controller belongs to the RUN, not to the page. */
    ChatUI.abortCtl = new AbortController();
    // ADE-S13.10 (ch-17.f2, m-32 "work folder to automatically add present items
    // into workspace for ai"): BEFORE the snapshot is built, merge the linked
    // folder in — anything the user dropped on disk since the last sync is now
    // visible to the agent; newer VFS state is never rolled back (merge-newer).
    try {
      const F = VFS.FSA;
      if (F && F.state === "linked" && F.autoSync && F.handle) {
        const st = await F.syncFromFolder({ quiet: true });
        if (st.added || st.updated) { F._lastAuto = Date.now(); try { WSUI.refresh?.(); } catch { /* tree refresh is cosmetic here */ } }
      }
    } catch { /* never block a run on a sync hiccup */ }
    let current = asstMsg;
    const maxSteps = Math.min(100, Math.max(1, Number(cfg.maxSteps ?? 24)));
    /* runOpts is PERSISTENT across steps: _streamOnce flips .proto when
       an endpoint rejects the tools array — every later request in this
       run then goes out without tools + with the proto appendix        */
    const runOpts = { useTools: true, proto: !!cfg.forceProto, tree: await this.workspaceSnapshot() }; // ADE-06.1 — live tree per run; ADE-05.4 — forceProto starts in text protocol
    /* hf.12 — EMPTY-RESPONSE AUTO-SHRINK ESCALATION. The field log (2026-10-31
       frame-scape): the run froze in "empty response — auto-continue re-drives"
       loops because every re-drive re-shipped the SAME heavy payload — the 413
       shrink path never fired (the endpoint answered 200 + an empty stream,
       not 413). _maybeAutoContinue now arms this flag when a stall smells like
       size; the re-driven run STARTS at shrink level 1 (level 2 on the next
       failure): old tool results stub, the budget halves, the payload fits. */
    if (this._autoShrink > 0) {
      runOpts._shrink = Math.min(2, this._autoShrink);
      this._autoShrink = 0;
      U.toast("Payload slimmed", { kind: "info", msg: `Re-driving at shrink level ${runOpts._shrink} — old tool results stubbed, context ÷${runOpts._shrink * 2}. The previous payload likely overflowed the endpoint (repeated empty/failed responses are its way of saying so).`, ms: 4200 });
    }
    runOpts.stateText = await this._loadState(); // f1.read — RESUME STATE rides the newest task turn (cache-safe tail) on every start AND continue

    /* ══ ADE-12.2/12.3/12.5/12.6 (ch-12, m-29 + m-41) · CACHE MODE ══
       One snapshot per run: profile prefix built ONCE (byte-stable for the
       whole run — f6), drift manifest riding the first user turn (f3),
       staleness checked BEFORE the turn (f5), prefix byte-discipline asserted
       (f6). No snapshot = cache mode degrades gracefully to today's behavior. */
    if (cfg.cacheMode) {
      const snap = await Agent.Cache.current();
      if (snap) {
        const drift = await Agent.Cache.diff(snap); // authoritative re-hash — also flips the row STALE/CACHED (f5)
        runOpts.profileText = await Agent.Cache.profileBlock(snap); // built once per run — agent edits during the run never mutate it
        runOpts.deltaPrefix = Agent.Cache.deltaPrefix(drift);       // null at zero drift
        const bad = Agent.Cache.assertStablePrefix(cfg, runOpts.profileText); // f6 — fail loudly, never silently re-send drifting bytes
        if (bad) {
          asstMsg.error = bad;
          await DB.saveMsg(asstMsg);
          ChatUI.renderThread();
          return;
        }
        /* f3 pill — persisted on the row (survives renderThread rebuilds)
           + one live DOM insert for the in-flight view                 */
        const pill = `cache ${snap.id} · changes since snapshot: ${drift.count} file${drift.count === 1 ? "" : "s"} · ~${U.fmtTokens(drift.driftTokens)}${drift.count ? " (delta attached)" : ""}`;
        asstMsg.cachePill = pill;
        await DB.saveMsg(asstMsg);
        this._cachePill(asstMsg, pill);
      }
    }

    let step = 0;
    let cutCount = 0;          // ADE-HF.3 — auto-continue budget for cut/stalled replies
    const MAX_CUTS = 3;
    let announceCount = 0;     // ADE-HF.5 — announced-but-missing-call recovery budget
    let ranTools = 0;          // ADE-HF.6 — tools executed this run (gates the code-rehearsal nudge)

    while (true) {
      if (this._stopped()) {
        await ChatUI.finalize(current, { acc: current.content || "", reasonAcc: current.reasoning || "", aborted: true });
        break;
      }
      step++;
      const r = await this._streamOnce(cfg, current, runOpts);
      if (r.error) break;                 // already persisted + rendered
      this._stepTag(current, step, maxSteps);
      if (r.aborted && !r.stalled && !r.netDead) { // user STOP — a stall or a dead socket is a cut, not a stop (handled below)
        await ChatUI.finalize(current, { acc: r.rest, reasonAcc: r.reasonAcc, usage: r.usage, aborted: true });
        break;
      }
      if (r.stalled && !r.acc && !r.think) {  // ADE-HF.3 — the "hang forever" report: gateway died silently, zero data arrived
        current.error = "Gateway stalled — no data for 120 s (stream dropped?). Press ↻ Continue (left of Send) or send a message to re-drive.";
        await DB.saveMsg(current);
        ChatUI.renderThread();
        break;
      }
      await ChatUI.finalize(current, { acc: r.rest, reasonAcc: r.reasonAcc, toolCalls: r.toolCalls, usage: r.usage }); // ADE-S18.3 exact burn · ADE-HF.3 lean body (reasoning persisted separately)
      /* hf.15 — reasoning tokens land on the file the thought named (the
         editing panel's ✦ column). No name → no attribution (honest). */
      if (r.usage && Number(r.usage.r) > 0) this._noteThink(r.reasonAcc || current.reasoning || "", Number(r.usage.r));
      /* f1.write — after EVERY completed step: parse the model's STATE block
         (if it emitted one) and rewrite ade.state.flat.txt. No block → the
         previous file stands (the contract keeps the last good pointer). */
      try { const st = this._parseState(r.rest || r.acc); if (st) await this._saveState(st); } catch { /* state write is best-effort */ }

      /* collect calls — native tool_calls or one parsed <<<TOOL>>> line.
         _parseProto scans the RAW acc: LAST marker wins, quoted format
         templates and mid-JSON cuts are flagged instead of executed. */
      let calls = current.toolCalls || undefined;
      let cutReply = r.stalled || r.finishReason === "length" || r.truncated || r.netDead; // ADE-HF.3/HF.6 — a truncated reply is a CUT, never a final answer
      if (!calls && runOpts.proto) {
        const parsed = this._parseProto(r.acc);
        if (parsed) {
          current.content = parsed.clean; // tool line stripped from the visible reply
          await DB.saveMsg(current);
          ChatUI.renderThread();
          if (!parsed.unterminated && !parsed.placeholder) calls = [parsed.call];
          else cutReply = true;           // cut mid-JSON or the model only quoted the format → auto-continue, never a parse-error turn
        }
      }
      if (calls && !runOpts.proto && r.finishReason === "length") {  // native mode: a length-cut can leave partial tool args
        const bad = calls.some(c => { try { JSON.parse(c.arguments || "{}"); return false; } catch { return true; } });
        if (bad) { delete current.toolCalls; await DB.saveMsg(current); calls = undefined; cutReply = true; }
      }
      /* ADE-HF.5 — NATIVE-MODE TEXT FALLBACK: some gateways accept the
         tools array but the model still emits the <<<TOOL>>> line as
         plain text (half-supported native calling). Without this scan
         the line is invisible → the run ends → "locked out of tool
         calls". Parse it exactly like proto mode. */
      if (!calls && !runOpts.proto) {
        const parsed = this._parseProto(r.acc);
        if (parsed && !parsed.unterminated && !parsed.placeholder) {
          current.content = parsed.clean;
          await DB.saveMsg(current);
          ChatUI.renderThread();
          calls = [parsed.call];
        }
      }
      if (!calls || !calls.length) {
        /* ADE-HF.3 — NEVER a silent drop: a cut reply auto-continues
           (≤ MAX_CUTS per run), then closes with an honest note. */
        if (cutReply && !this._stopped() && cutCount < MAX_CUTS) {
          cutCount++;
          const nudge = {
            id: U.uid(), convId: State.activeConvId, role: "user", systemNote: true, noteKind: "cut",   /* ADE-S25.2 (ch-30.f5) */
            content: "(your reply was cut off mid-stream" + (r.finishReason === "length" ? " at the output-token limit" : r.netDead ? " — the connection dropped" : r.truncated ? " — the stream closed early" : "") + " — continue exactly where it stopped, re-emitting the tool line complete if it was cut; no repetition)",
            model: current.model, ts: Date.now()
          };
          await DB.saveMsg(nudge);
          State.msgs.push(nudge);
          current = { id: U.uid(), convId: State.activeConvId, role: "assistant", content: "", model: cfg.model, ts: Date.now() };
          await DB.saveMsg(current);
          State.msgs.push(current);
          State.streamingId = current.id;
          ChatUI.renderThread();
          continue;
        }
        if (cutReply) { // cut budget exhausted — close honestly instead of dropping (ADE-S25.2: paused-chip, not a prose wall)
          const note = { id: U.uid(), convId: State.activeConvId, role: "user", systemNote: true, noteKind: "paused", content: `(reply hit the output limit ${cutCount}× — run paused. Auto-continue will re-drive it if enabled; otherwise press ↻ Continue or send a message.)`, model: current.model, ts: Date.now() };
          await DB.saveMsg(note);
          State.msgs.push(note);
          ChatUI.renderThread();
        }
        /* ADE-HF.5 — ANNOUNCED-BUT-MISSING CALL recovery (field report:
           the model wrote "Listing it now." / "Step 1:" and ended the
           turn with NO tool line — the harness treats a no-call reply
           as final, the user waits, "the agent is locked out"). In
           proto mode a reply that ends by announcing an action gets
           ONE nudge to actually emit the line (≤2 per run; a model
           that answers with prose again breaks the loop — its reply
           is then honored as final). */
        if (runOpts.proto && !cutReply && !this._stopped()) {
          const lean = String(r.rest || "").trim();
          /* ADE-S25.1 (ch-30.f4, m-55) — the round-2 detector (see above). */
          const announced = this._announceCheck(lean, ranTools);
          if (announced && announceCount < 2) {
            announceCount++;
            /* ADE-S24.5 (ch-30.f3, m-54) — TOOL GUESS from the announced verb
               (kept from round 1: the concrete line is what models copy). */
            const guess = [
              [/\b(listing|reading|showing|opening|viewing)/i, "read"],
              [/\b(searching|scanning|grepping|finding)/i, "find"],
              [/\b(running|executing|testing|launching|compiling)/i, "shell"],
              [/\b(writing|creating|saving|adding|generating)/i, "write"],
              [/\b(chunking|shipping pieces|building the file)/i, "chunk"],
              [/\b(appending|updating)/i, "append"],
              [/\b(extracting|unpacking|unzipping)/i, "unzip"],
              [/\b(moving|renaming)/i, "move"]
            ].find(([re]) => re.test(lean))?.[1] || "read";
            /* ADE-S25.2 (ch-30.f5) — dieted nudge + noteKind for the chip layer. */
            const nudge = {
              id: U.uid(), convId: State.activeConvId, role: "user", systemNote: true, noteKind: "announce",
              content: "(that reply announced an action but carried no tool line — the run treats it as your final answer. Emit the call now, as the very last line, with real arguments:\n<<<TOOL {\"name\":\"" + guess + "\",\"args\":{…}}>>>\n(\"" + guess + "\" is the likely tool for what you announced). No narration, no quoting the format, no code block — just the line. If the work is complete, reply DONE instead)",
              model: current.model, ts: Date.now()
            };
            await DB.saveMsg(nudge);
            State.msgs.push(nudge);
            current = { id: U.uid(), convId: State.activeConvId, role: "assistant", content: "", model: cfg.model, ts: Date.now() };
            await DB.saveMsg(current);
            State.msgs.push(current);
            State.streamingId = current.id;
            ChatUI.renderThread();
            continue;
          }
          if (announced) { // announce budget exhausted on a STILL announce-shaped reply — never silently honor the narration wall (ADE-S25.1)
            const note = { id: U.uid(), convId: State.activeConvId, role: "user", systemNote: true, noteKind: "paused", content: `(the model announced an action ${announceCount + 1}× without emitting the tool line — run paused. Auto-continue will re-drive it if enabled; otherwise press ↻ Continue to nudge it again.)`, model: current.model, ts: Date.now() };
            await DB.saveMsg(note);
            State.msgs.push(note);
            ChatUI.renderThread();
          }
        }
        break; // plain reply = the final markdown summary
      }

      /* execute each call → persisted role:tool rows (trace cards) */
      for (const call of calls) {
        let args = {};
        try { args = call.arguments ? JSON.parse(call.arguments) : {}; }
        catch { args = { __raw: call.arguments }; }
        const tMsg = {
          id: U.uid(), convId: State.activeConvId, role: "tool",
          toolCallId: call.id || "call_" + U.uid().slice(0, 8),
          name: this.canon(call.name), args, content: "", ok: true, // hf.11 — trace rows record the CANONICAL name (icons + tools inventory resolve)
          model: current.model, ts: Date.now()
        };
        if (this._stopped()) { tMsg.content = "stopped by user"; tMsg.ok = false; }
        else {
          const res = await this.execTool(call.name, args);
          tMsg.content = res.content; tMsg.ok = res.ok; tMsg.ms = res.ms;
          ranTools++;
          if (res.ok === false) { try { await this.dbgToolError(tMsg); } catch { /* best-effort */ } } // hf.16 — every tool ERROR lands in ade.debug.flat.txt (exact tool + query + result head, dated)
          /* ADE-HF.6 — CONSOLE HISTORY for every agent tool call (field
             report: only shell lines journalled, fs_* / run_* were
             invisible → the Workspace CONSOLE HISTORY panel looked dead
             while the agent worked). shell already journals itself. */
          if (tMsg.name !== "shell" && window.Exec && Exec.Shell && Exec.Shell.journal) {
            try { Exec.Shell.journal(tMsg.name + (args && Object.keys(args).length ? "  " + Agent.argSummary(args) : ""), res.ok ? 0 : 1, res.ms || 0); } catch { /* journal is cosmetic */ }
          }
        }
        await DB.saveMsg(tMsg);
        State.msgs.push(tMsg);
        ChatUI.renderThread();
      }

      /* step cap — close the run with an honest note, never a hanging loop */
      if (step >= maxSteps) {
        const note = {   /* ADE-S25.2 (ch-30.f5) — paused-chip, not a prose wall */
          id: U.uid(), convId: State.activeConvId, role: "user", systemNote: true, noteKind: "paused",
          content: `(agent step cap ${maxSteps} reached — tool results above. Press ↻ Continue or send a message to resume.)`,
          model: current.model, ts: Date.now()
        };
        await DB.saveMsg(note);
        State.msgs.push(note);
        ChatUI.renderThread();
        break;
      }

      /* next assistant placeholder — the loop continues */
      current = { id: U.uid(), convId: State.activeConvId, role: "assistant", content: "", model: cfg.model, ts: Date.now() };
      await DB.saveMsg(current);
      State.msgs.push(current);
      State.streamingId = current.id;
      ChatUI.renderThread();
    }
  }
};

/* ══ ADE-05.3 / ADE-05.6 styles — INJECTED (css/ade.css untouched:
   ch-05.files = js/agent.js · js/ui-chat.js; same pattern as the
   CH-04 console styles). Tokens = P1–P20 verbatim.               ══ */
/* ══ ADE-12.x · PROMPT-CACHE ENGINE (ch-12, m-29 — the m-45 experiment's
   product half). Snapshot = per-file 12-hex hashes + est tokens in the NEW
   ade-db v3 'cache' store (additive-only, ai.saves.rule); the CURRENT
   pointer is a settings kv so re-cache supersedes without renames.
   m-45 verdict wired in: the est-k numbers are honest (chars/4), the
   profile prefix is byte-stable per run (f6 asserts it), and the ch-24
   cached-token telemetry measures the REAL provider discount per request. */
Agent.Cache = {
  _seq: null,     // snapshot id counter (cache-NNN) — derived from the store once per session
  _installed: false,

  /* 12-hex content hash — crypto.subtle SHA-256 when the context is secure,
     FNV-1a ×2 fallback for file:// installs (drift detection only — both
     are deterministic within an install, which is all the manifest needs) */
  async sha12(text) {
    try {
      if (typeof crypto !== "undefined" && crypto.subtle) {
        const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
        return Array.from(new Uint8Array(buf).slice(0, 6)).map(b => b.toString(16).padStart(2, "0")).join("");
      }
    } catch { /* insecure context — fall through */ }
    let h1 = 0x811c9dc5, h2 = 0x811c9dc5;
    for (let i = 0; i < text.length; i++) {
      const c = text.charCodeAt(i);
      h1 = (Math.imul(h1 ^ c, 0x01000193)) >>> 0;
      h2 = (Math.imul(h2 ^ (c ^ (i & 0xff)), 0x01000193)) >>> 0;
    }
    return (h1.toString(16).padStart(8, "0") + h2.toString(16).padStart(8, "0")).slice(0, 12);
  },

  /* ══ f1 — build + persist a full-workspace snapshot (cache-NNN) ══ */
  async snapshot() {
    const rows = await VFS.tree("/");
    const files = {};
    let estTokens = 0, fileCount = 0;
    for (const r of rows) {
      if (r.kind !== "file") continue;
      if (!r.isText || typeof r.content !== "string") {
        files[r.path] = { h: "bin", size: r.size || 0, lines: 0, k: 0, bin: true };
        continue;
      }
      const h = await this.sha12(r.content);
      const k = U.estimateTokens(r.content);
      files[r.path] = { h, size: r.content.length, lines: r.content.split("\n").length, k };
      estTokens += k; fileCount++;
    }
    const id = "cache-" + String(await this._nextSeq()).padStart(3, "0");
    const row = { id, ts: Date.now(), fileCount, estTokens, driftCount: 0, status: "CACHED", files, drift: {} };
    await DB.saveCacheRow(row);
    await DB.setSetting(SK.CACHE_CURRENT, id);
    await this._prune();
    return row;
  },
  async _nextSeq() {
    if (this._seq == null) {
      let max = 0;
      for (const r of await DB.allCache()) {
        const m = /^cache-(\d+)$/.exec(r.id || "");
        if (m) max = Math.max(max, Number(m[1]));
      }
      this._seq = max;
    }
    return ++this._seq;
  },
  async _prune() { // keep the last 3 snapshots (never the current one)
    const cur = await DB.getSetting(SK.CACHE_CURRENT);
    for (const r of (await DB.allCache()).slice(3)) if (r.id !== cur) await DB.delCacheRow(r.id);
  },
  async current() {
    const id = await DB.getSetting(SK.CACHE_CURRENT);
    if (!id) return null;
    const row = await DB.get(DB.STORES.CACHE, id);
    return row || null;
  },

  /* ══ f5 — authoritative staleness: re-hash the live VFS vs the snapshot.
     Writes the verdict back on the row (CACHED ✓ / STALE) so the header
     chip stays cheap. Binary rows drift only when they appear/vanish.  */
  async diff(snap) {
    const rows = await VFS.tree("/");
    const res = { count: 0, driftTokens: 0, changed: [], added: [], removed: [] };
    const seen = new Set();
    for (const r of rows) {
      if (r.kind !== "file") continue;
      seen.add(r.path);
      const prev = snap.files[r.path];
      if (!prev) { res.added.push(r.path); res.count++; res.driftTokens += (r.isText && typeof r.content === "string") ? U.estimateTokens(r.content) : 0; }
      else if (!r.isText || typeof r.content !== "string") { if (!prev.bin) { res.changed.push(r.path); res.count++; } }
      else {
        const h = await this.sha12(r.content);
        if (h !== prev.h) { res.changed.push(r.path); res.count++; res.driftTokens += U.estimateTokens(r.content); }
      }
    }
    for (const p of Object.keys(snap.files)) if (!seen.has(p)) { res.removed.push(p); res.count++; }
    if (snap.status !== "CACHED" || snap.driftCount !== res.count) { // write the verdict back (chip stays cheap)
      snap.status = res.count ? "STALE" : "CACHED";
      snap.driftCount = res.count;
      await DB.saveCacheRow(snap);
    }
    return res;
  },

  /* ══ f2 — the byte-stable profile prefix. Built ONCE per run from the
     LIVE VFS (snapshot keeps hashes, not content — no double storage);
     agent edits during the run never mutate the built string, so the
     prefix is stable for every request of the run (f6 asserts it).
     Cross-run drift is HONEST: the badge goes STALE and the delta lists
     what moved — re-cache restores a fully stable prefix.               */
  async profileBlock(snap) {
    const parts = [
      `PROJECT PROFILE — ${snap.id} (${snap.fileCount} files · ~${U.fmtTokens(snap.estTokens)} tok · ai.cache.profile manifest: 12-hex sha per file)`,
      "CACHE CONTRACT (ai.cache.*): the file contents below were captured for this snapshot — they are ALREADY IN THIS PROMPT. Never read a file whose content you hold here; patch straight onto it with write/append. Files that drifted since the snapshot arrive as a DELTA on the task turn (full text ≤ 400 lines, else a changed-file pointer — re-read only those regions). The one-click “Ship cached project zip” workspace action merges the patches and re-caches.",
      "STABILITY: everything between “PROJECT PROFILE” and the workspace tree is byte-identical across every turn of this run — treat it as read-only reference."
    ];
    for (const p of Object.keys(snap.files).sort()) {
      const meta = snap.files[p];
      if (meta.bin) { parts.push(`=== ${p} — BINARY (${meta.size} b; not inlined) ===`); continue; }
      const txt = await VFS.readText(p);
      if (txt == null) { parts.push(`=== ${p} — (not in the live workspace at build time; see delta) ===`); continue; }
      const lines = txt.split("\n");
      const body = lines.length > 4000
        ? lines.slice(0, 4000).join("\n") + `\n…[${lines.length - 4000} more lines — read on demand]`
        : txt;
      parts.push(`=== ${p} · ${meta.h} · ${meta.lines}L ===\n${body}`);
    }
    return parts.join("\n\n");
  },

  /* ══ f3 — the drift manifest that rides the first user turn (null at
     zero drift → the turn stays byte-identical to a non-cache turn).
     ai.cache.patch.recipe.2 in-product: full text for files ≤ 400 lines;
     BIGGER files get a changed-file POINTER (the in-product agent holds
     fs_read pagination instead of a previous-version zip — recorded as a
     deliberate ch-12 note in the planner).                               */
  deltaPrefix(drift) {
    if (!drift || !drift.count) return null;
    const L = [`[cache-ref · DELTA since the profile snapshot — ${drift.count} file${drift.count === 1 ? "" : "s"} drifted (~${U.fmtTokens(drift.driftTokens)} tok). The profile block may lag these files; the live workspace + your tools show current state.]`];
    for (const p of drift.changed) L.push(`  M ${p}`);
    for (const p of drift.added) L.push(`  A ${p}`);
    for (const p of drift.removed) L.push(`  D ${p}`);
    L.push("Patched files above are NOT re-inlined here when > 400 lines — fs_read the exact regions you need (paginated, cheap).");
    return L.join("\n");
  },

  /* ══ f6 — byte-discipline guard (m-41): build the cacheable prefix TWICE
     and fail loudly on any byte drift. Catches any future volatile token
     (Date.now / uid / Math.random / per-run counters) someone adds to the
     profile block or the stable prompt body.                              */
  assertStablePrefix(cfg, profileText) {
    try {
      const a = Agent.buildSystemPrompt(cfg, { profileText, tree: "__T__" });
      const b = Agent.buildSystemPrompt(cfg, { profileText, tree: "__T__" });
      if (a !== b) return "CACHE GUARD (ch-12.f6): the stable prefix is NOT byte-identical across builds — a volatile token (Date.now / uid / random / counter) leaked into the prompt body or profile block. Run aborted rather than silently re-billing drifted bytes. Re-cache or disable cache mode, then report this as a field report.";
      return null;
    } catch (e) {
      return "CACHE GUARD (ch-12.f6) could not run: " + String((e && e.message) || e);
    }
  },

  /* ══ f4 — one-click ship-back: the VFS IS snapshot+patches merged (every
     patch went through fs_write), so export → download → RE-CACHE so the
     next patch task starts clean (ai.cache.patch.recipe.5).              */
  async shipZip() {
    const blob = await VFS.exportZip("/");
    U.downloadBlob(blob, "ade-workspace.zip");
    const snap = await this.snapshot();
    U.toast("Cached project zip shipped", { kind: "ok", msg: `ade-workspace.zip · ${U.fmtBytes(blob.size)} — re-cached as ${snap.id} (${snap.fileCount} files · ~${U.fmtTokens(snap.estTokens)} tok)`, ms: 5200 });
    return snap;
  },

  /* ══ f5 — header chip: NONE · CACHED ✓ · STALE ⚠ (click = one-click re-cache) */
  async chip() {
    try {
      const snap = await this.current();
      if (!snap) return `<span class="ws-cache-chip" id="ws-cache-chip" data-state="none" title="No project profile cached — click to cache the whole workspace once (ch-12): later patch runs re-send only deltas.">CACHE: NONE</span>`;
      const age = U.fmtAge ? U.fmtAge(Date.now() - snap.ts) : Math.round((Date.now() - snap.ts) / 60000) + "m";
      if (snap.status === "STALE" || snap.driftCount > 0)
        return `<span class="ws-cache-chip" id="ws-cache-chip" data-state="stale" title="${snap.id} is STALE — ${snap.driftCount} file(s) drifted outside an applied patch (re-zip · manual edit · FSA pull). Click to re-cache (ai.cache.invalidate).">CACHE: STALE ⚠ ${snap.driftCount}</span>`;
      return `<span class="ws-cache-chip" id="ws-cache-chip" data-state="cached" title="${snap.id} · ${snap.fileCount} files · ~${U.fmtTokens(snap.estTokens)} tok · age ${age} — click to re-cache. Patch tasks in cache mode send the profile once + deltas only.">CACHE: ${snap.id} ✓</span>`;
    } catch { return ""; }
  },

  /* ══ f5 — boot staleness check + (cache mode on) the f6 boot assertion.
     Fire-and-forget from Main.init — never blocks boot, never throws.   */
  async bootCheck() {
    try {
      const snap = await this.current();
      if (snap) await this.diff(snap); // authoritative re-hash flips CACHED/STALE
      const cfg = State.configs?.find(c => c.id === State.activeConfigId);
      if (cfg && cfg.cacheMode && snap) {
        const pt = await this.profileBlock(snap);
        const bad = this.assertStablePrefix(cfg, pt);
        if (bad) console.error("[ADE ch-12.f6]", bad);
      }
      if (typeof WSUI !== "undefined" && WSUI.refreshCacheChip) WSUI.refreshCacheChip();
    } catch { /* boot check is best-effort */ }
  },

  /* ══ f3 — VFS.onWrite hook bus: every write re-hashes into the CURRENT
     snapshot's live-drift map so the chip stays fresh between runs (the
     authoritative diff() re-runs before each patch turn anyway).        */
  install() {
    if (this._installed) return;
    this._installed = true;
    VFS.onWrite(async (type, path, info) => {
      try {
        const snap = await this.current();
        if (!snap) return;
        if (type === "write") {
          const row = await VFS.get(path);
          if (row && row.kind === "file" && row.isText && typeof row.content === "string") {
            const h = await this.sha12(row.content);
            const base = snap.files[path];
            if (!base || base.h !== h) {
              snap.drift = snap.drift || {};
              snap.drift[path] = { h, lines: row.content.split("\n").length, k: U.estimateTokens(row.content) };
              snap.driftCount = Object.keys(snap.drift).length;
              snap.status = "STALE";
              await DB.saveCacheRow(snap);
              if (typeof WSUI !== "undefined" && WSUI.refreshCacheChip) WSUI.refreshCacheChip();
            }
          }
        } else if (type === "rm" || type === "mv") {
          const gone = type === "rm" ? path : ((info && info.from) || path); // mv: _emit passes the DEST as path — the SOURCE (info.from) is what vanished
          if (snap.files[gone] && !snap.drift[gone]) {
            snap.drift = snap.drift || {};
            snap.drift[gone] = null; // removed marker
            snap.driftCount = Object.keys(snap.drift).length;
            snap.status = "STALE";
            await DB.saveCacheRow(snap);
            if (typeof WSUI !== "undefined" && WSUI.refreshCacheChip) WSUI.refreshCacheChip();
          }
        }
      } catch { /* hook errors never break the VFS */ }
    });
  }
};
Agent.Cache.install(); // f3 — the write-through re-hash bus, live from boot

Agent._injectStyles = function () {
  if (document.getElementById("ade-agent-styles")) return;
  const st = document.createElement("style");
  st.id = "ade-agent-styles";
  st.textContent = `
  /* step counter (05.2) */
  .msg .meta .step-tag { color: var(--info); font-family: var(--font-mono); font-size: var(--fs-badge); }
  /* brain-clickable role badge (05.6) */
  .msg .meta .role.brain { cursor: pointer; }
  .msg .meta .role.brain:hover { color: var(--info); }
  .msg .meta .thinking-tag { cursor: pointer; }
  /* tool trace cards (05.3) */
  .msg.tool .avatar { background: rgba(155,127,212,0.08); border-color: rgba(155,127,212,0.35); }
  .msg.tool .avatar i { color: var(--info); }
  .tool-card { display: inline-flex; align-items: center; gap: 8px; padding: 6px 10px; background: var(--bg3); border: 1px solid var(--border); border-left: 2px solid var(--info); border-radius: var(--radius); cursor: pointer; font-family: var(--font-mono); font-size: 11px; color: var(--fg2); max-width: 100%; overflow: hidden; }
  .tool-card:hover { border-color: var(--border-comp); background: var(--bg4); }
  .tool-card > i { font-size: 10px; color: var(--info); flex: none; }
  .tool-card .tool-name { color: var(--fg1); font-weight: 600; flex: none; }
  .tool-card .tool-args { color: var(--fg3); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0; }
  .tool-card .tool-state { flex: none; font-size: 10px; }
  .tool-card .tool-state.ok { color: var(--ok); }
  .tool-card .tool-state.err { color: var(--err); }
  .tool-card .tool-ms { flex: none; color: var(--fg3); font-size: 9px; }
  .tool-detail { margin-top: 6px; border: 1px solid var(--border); border-radius: var(--radius); background: var(--bg2); padding: 8px 10px; max-width: 100%; }
  .tool-detail .td-label { font-size: var(--fs-badge); letter-spacing: 0.08em; color: var(--fg3); margin: 6px 0 3px; }
  .tool-detail .td-label:first-child { margin-top: 0; }
  .tool-detail pre { margin: 0; padding: 6px 8px; background: var(--bg); border: 1px solid var(--border); border-radius: 4px; font-family: var(--font-mono); font-size: 11px; color: var(--fg2); white-space: pre-wrap; word-break: break-word; max-height: 260px; overflow: auto; }
  .tool-copy { margin-top: 6px; font-size: 10px; }
  /* thinking viewer (05.6) — its styles lived HERE as a JS-injected copy
     (the m-40 field report, session 16): the panel box rendered, but the
     stylesheet was split outside css/ade.css, the ✦/brain affordances had
     no pointer cursor, and noteReasoning's async creation raced the stream.
     ch-22.f1 moved the block into css/ade.css (marker ADE-S16.1) — one
     home, one rule set. */`;
  document.head.appendChild(st);
};
Agent._injectStyles();
if (typeof window !== "undefined") window.Agent = Agent; // ADE-S23.3: make the window.Agent/window.Exec guards live (const is a lexical global, not a window prop)

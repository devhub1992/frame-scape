/* ============================================================
   js/ui-chat.js — ADE-01.4 streaming chat UI + ADE-01.5 attachments
   thread render · conversation sidebar · send flow (delegates the
   request loop to js/agent.js since CH-05) · markdown rendering ·
   attachment chips (text → inlined fenced blocks; zip/binary → VFS
   /imports via fflate) · per-message token estimates.
   CH-05 ADDS: ADE-05.3 · TOOL TRACE — persisted role:tool rows
   render as tool-cards (icon · name · arg summary · ok/err · ms,
   click expands args + result, copy button)
               ADE-05.6 · THINKING VIEWER (m-22) — click the agent's
   name badge / ✦ tag → lazy reasoning panel fed from msg.reasoning
   (already captured by the CH-01 parser, now in agent.js); auto-
   expand-while-streaming toggle lives in the panel itself
   S20 ADDS: ADE-S20.1 (ch-26, m-46) · SLIM IDLE-REVEAL BURN STRIP —
   the session-18 burn card becomes one slim line with the chat's $
   cost from the per-model $/1M rate (f2/f3), shown only after the
   chat idles 10s (f4); copy emits the structured summary (S20.5)
   ============================================================ */
"use strict";

const ChatUI = {
  abortCtl: null,   // current AbortController while the agent runs (Agent._post sets it)
  _thinkAuto: null, // cached auto-expand setting — null = re-read (ADE-05.6)

  /* ══ sidebar · conversations ════════════════════════════ */
  /* ══ ADE-S18.1 (ch-23.f1, m-42) · SIDEBAR WIRING — THE FIX ══
     renderSidebar() always emitted open/rename/delete affordances, but
     NO click handler was ever wired on #conv-list — every row action
     (and even opening a conversation by click) was dead on arrival.
     One delegated listener handles all of it: row click → open,
     pen → startRename, trash → deleteConversation (two-step inline
     confirm — window.confirm is BLOCKED in sandboxed iframes/preview
     hosts, which read as “button does nothing”; the confirm now lives
     in the row itself). */
  initSidebar() {
    document.getElementById("conv-list").addEventListener("click", async e => {
      const act = e.target.closest("[data-act]");
      const item = e.target.closest(".conv-item");
      if (!item) return;
      const id = item.dataset.id;
      if (act) {
        e.stopPropagation();
        if (act.dataset.act === "rename") this.startRename(id);
        else if (act.dataset.act === "del") await this.deleteConversation(id, act);
        return;
      }
      if (e.target.closest(".rename-input")) return; // mid-rename — don't steal the click
      await this.openConversation(id);
    });
  },

  async renderSidebar() {
    const list = document.getElementById("conv-list");
    State.convs = await DB.allConvs();
    document.getElementById("conv-count").textContent = State.convs.length + " conv";
    if (!State.convs.length) {
      list.innerHTML = `<div class="conv-empty">No conversations yet.</div>`;
      return;
    }
    list.innerHTML = State.convs.map(c => {
      const active = c.id === State.activeConvId;
      return `<div class="conv-item ${active ? "active" : ""}" data-id="${c.id}">
        <div class="conv-row">
          <i class="fa-regular fa-message conv-icon"></i>
          <span class="conv-title">${U.escapeHtml(c.title || "Untitled")}</span>
          <span class="conv-actions">
            <button class="conv-action" data-act="rename" title="Rename"><i class="fa-solid fa-pen"></i></button>
            <button class="conv-action danger" data-act="del" title="Delete (click twice to confirm)"><i class="fa-solid fa-trash"></i></button>
          </span>
        </div>
        <div class="conv-meta"><span>${U.fmtTime(c.lastTs || c.ts)}</span></div>
      </div>`;
    }).join("");
  },

  async newConversation() {
    const conv = { id: U.uid(), title: "New conversation", ts: Date.now(), lastTs: Date.now() };
    await DB.saveConv(conv);
    State.activeConvId = conv.id;
    await DB.setSetting(SK.ACTIVE_CONV, conv.id);
    State.msgs = [];
    this.migrateScratchDraft(conv.id); // hf.13 — a draft typed before any chat existed carries into the chat it starts
    this.loadDraft(conv.id, { focus: true });
    await this.renderSidebar();
    this.renderThread();
  },

  async openConversation(id) {
    State.activeConvId = id;
    await DB.setSetting(SK.ACTIVE_CONV, id);
    State.msgs = await DB.msgsByConv(id);
    this.loadDraft(id); // hf.13 — switching chats swaps the composer draft with it
    await this.renderSidebar();
    this.renderThread();
    const conv = State.convs.find(c => c.id === id);
    document.getElementById("header-title").textContent = conv ? conv.title : "ADE";
  },

  /* ADE-S18.1 (ch-23.f2) — two-step INLINE confirm (3s window) instead of
     window.confirm(): sandboxed preview iframes block modal dialogs, which
     made delete read as dead. Second click within the window = confirmed. */
  async deleteConversation(id, btn) {
    if (btn && btn.dataset.armed !== "1") {
      btn.dataset.armed = "1";
      btn.classList.add("armed");
      btn.title = "Click again to confirm delete";
      setTimeout(() => { if (btn.isConnected) { btn.dataset.armed = ""; btn.classList.remove("armed"); btn.title = "Delete (click twice to confirm)"; } }, 3000);
      return;
    }
    await DB.delConv(id);
    this.clearDraft(id); // hf.13 — the draft dies with its conversation (deleting a chat is a deliberate discard)
    if (State.activeConvId === id) {
      State.activeConvId = null;
      State.msgs = [];
      await DB.setSetting(SK.ACTIVE_CONV, null);
      this._draftConvId = null;
      this.loadDraft(null);
      this.renderThread();
    }
    await this.renderSidebar();
    U.toast("Conversation deleted", { kind: "ok" });
  },

  startRename(id) {
    const item = document.querySelector(`.conv-item[data-id="${id}"]`);
    if (!item) return;
    const conv = State.convs.find(c => c.id === id);
    const row = item.querySelector(".conv-row");
    row.innerHTML = `<input class="rename-input" value="${U.escapeHtml(conv.title || "")}" />`;
    const input = row.querySelector("input");
    input.focus();
    input.select();
    let done = false; // ADE-S18.1 — Enter commits, the blur that follows must not double-commit
    const commit = async (save) => {
      if (done) return;
      done = true;
      if (save && input.value.trim()) {
        conv.title = input.value.trim();
        await DB.saveConv(conv);
        if (State.activeConvId === id) document.getElementById("header-title").textContent = conv.title;
      }
      await this.renderSidebar();
    };
    input.addEventListener("keydown", e => {
      if (e.key === "Enter") commit(true);
      else if (e.key === "Escape") commit(false);
    });
    input.addEventListener("blur", () => commit(true), { once: true });
  },

  /* ══ thread render ══════════════════════════════════════ */
  /* ADE-S20.4 (ch-26.f4, m-46) — idle-reveal handoff: when this render IS
     the burn strip's reveal (fired by the 1 Hz sweep after BURN_IDLE_MS of
     chat silence), the scroll position is PRESERVED instead of yanked to
     the bottom; every other render counts as activity and re-arms the
     idle window, so the strip hides again the moment the chat wakes up. */
  renderThread() {
    const thread = document.getElementById("thread");
    const conv = State.convs.find(c => c.id === State.activeConvId);
    document.getElementById("header-title").textContent = conv ? conv.title : "ADE";
    const reveal = this._burnReveal === true;
    this._burnReveal = false;
    if (!State.msgs.length) {
      this._burnIdleUntil = Date.now() + this.BURN_IDLE_MS;
      thread.innerHTML = `<div class="thread-empty"><div class="empty-card">
        <i class="fa-solid fa-terminal"></i>
        <p class="title">Agentic Developer Environment</p>
        <p class="sub">The agent has 12 real tools now: files · shell · python/js execution · live preview.</p>
        <div class="hints">
          <span><i class="fa-solid fa-angle-right"></i> Ask it to build something — it writes files, runs them, fixes errors</span>
          <span><i class="fa-solid fa-angle-right"></i> Tool calls stream as trace cards — click one for args + result</span>
          <span><i class="fa-solid fa-angle-right"></i> Everything is local: IndexedDB convs, configs, keys, workspace</span>
        </div>
      </div></div>`;
      return;
    }
    /* ADE-HF.3 — scroll anchoring: go to bottom ONLY if the user already
       sat at the bottom; otherwise their reading position is preserved
       to the exact pixel ("keep chat on the same line it was when I
       typed my request" — no more yank-to-end while the agent renders). */
    const prevScroll = thread.scrollTop;
    thread.innerHTML = State.msgs.map(m => this.msgHtml(m)).join("") + this._burnCardHtml(reveal);
    const stick = thread.scrollHeight - prevScroll - thread.clientHeight < 90;
    thread.scrollTop = stick ? thread.scrollHeight : prevScroll;
    if (!reveal) this._burnIdleUntil = Date.now() + this.BURN_IDLE_MS;
    if (this._updScrollBtn) this._updScrollBtn();       // ADE-S25.4 (ch-31.f2) — keep the ↓ button honest after every render
  },

  /* ══ ADE-S25.4 (ch-31.f2, m-56) · SCROLL-TO-BOTTOM ══
     Floating ↓ button bottom-right of the thread: shows when the view is
     >140 px from the bottom, hides on reach, click = smooth scroll. The
     auto-continue engine reuses scrollBottom() on stall detection (the
     user's "when it freezes scroll to bottom"). */
  scrollBottom(smooth = true) {
    const thread = document.getElementById("thread");
    if (!thread) return;
    thread.scrollTo({ top: thread.scrollHeight, behavior: smooth ? "smooth" : "auto" });
    if (this._updScrollBtn) this._updScrollBtn();
  },

  /* ══ ADE-S20.1 (ch-26.f1, m-46) · SLIM IDLE-REVEAL BURN STRIP ══
     The session-18 burn card answered WHAT the exact burn is — but too
     loudly: a fat 4-cell grid card parked under every conversation.
     Now it is ONE slim line — ↑prompt · ✦reasoning · ↓output · Σtotal ·
     $cost · ⛁cached · reqs/turns — with the verbose explanations moved
     into tooltips (f1), the chat's total COST computed from each model's
     $/1M rate set in Settings (f3), and the whole strip appearing ONLY
     after the chat has been idle for BURN_IDLE_MS (f4) — never mid-stream,
     never while the user is actively working. Totals stay the honest
     session-18 Σ per-request numbers (context re-sends ARE burn).        */
  BURN_IDLE_MS: 10000,   // f4 — the strip appears after 10s of chat idleness
  _burnIdleUntil: 0,     // epoch ms before which the strip stays hidden
  _burnReveal: false,    // true when the NEXT renderThread is the reveal pass
  _burnTimer: null,      // the 1 Hz idle sweep

  /* true when the conversation holds anything the strip can report —
     the SAME predicate the html uses, so the sweep can never pump
     re-renders against an empty report */
  _hasBurnData() {
    return State.msgs.some(m => m.role === "assistant" && (m.usage || !m.error));
  },

  /* ADE-S20.4 (ch-26.f4, m-46) — 1 Hz sweep: once the chat has been quiet
     for BURN_IDLE_MS (and is not streaming, and holds telemetry), fire ONE
     reveal render that appends the strip. The "already in DOM" guard makes
     this a transition detector, not a re-render pump; any activity render
     re-arms _burnIdleUntil, so the strip hides while the chat is awake. */
  _startBurnTick() {
    if (this._burnTimer) return;
    this._burnTimer = setInterval(() => {
      if (State.streaming || !State.activeConvId || !this._hasBurnData()) return;
      if (document.getElementById("burn-card")) return;   // already showing
      if (Date.now() < this._burnIdleUntil) return;       // not idle long enough yet
      this._burnReveal = true;
      this.renderThread();
    }, 1000);
  },

  /* ADE-S20.3 (ch-26.f3, m-46) — chat cost = Σ over requests of tokens ×
     the model's $/1M rate (Settings → config editor → "Cost per 1M tokens",
     ch-26.f2). Requests on models WITHOUT a rate stay in the token totals
     but are honestly excluded from the $ (reported back in the tooltip). */
  _burnRates(rows) {
    const byModel = {};
    for (const m of rows) {
      const k = m.model || "(unknown model)";
      const g = (byModel[k] = byModel[k] || { t: 0, n: 0 });
      g.t += m.usage.t || 0;
      g.n++;
    }
    let cost = 0;
    const lines = [], unrated = [];
    for (const [name, g] of Object.entries(byModel)) {
      const cfg = State.configs.find(c => c.model === name && Number(c.costPerM) > 0);
      if (cfg) {
        const rate = Number(cfg.costPerM);
        const c = (g.t / 1e6) * rate;
        cost += c;
        lines.push(`${name}: ${U.fmtTokens(g.t)} tok × $${rate}/1M = $${c >= 0.01 ? c.toFixed(2) : c.toFixed(4)}`);
      } else {
        unrated.push(`${name} (${g.n} req${g.n === 1 ? "" : "s"}, ${U.fmtTokens(g.t)} tok)`);
      }
    }
    return { cost, lines, unrated };
  },

  _burnCardHtml(reveal) {
    const rows = State.msgs.filter(m => m.role === "assistant" && m.usage);
    const legacy = State.msgs.filter(m => m.role === "assistant" && !m.usage && !m.error);
    if (!rows.length && !legacy.length) return "";
    if (!reveal) return "";                              // f4 — hidden unless idle-revealed
    const sum = (k) => rows.reduce((n, m) => n + (m.usage[k] || 0), 0);
    const estLegacy = legacy.reduce((n, m) => n + U.estimateTokens(m.content || ""), 0);
    const toolRows = State.msgs.filter(m => m.role === "user").length;
    const { cost, lines, unrated } = this._burnRates(rows);
    const fmt$ = (v) => "$" + (v >= 0.01 ? v.toFixed(2) : v.toFixed(4));
    const parts = [
      ["prompt", sum("p"), "↑", "input sent to the model (context re-sends included — that re-send IS real burn)"],
      ["reasoning", sum("r"), "✦", "thinking tokens (0 = provider reported no split — GLM folds reasoning into output there)"],
      ["output", sum("o"), "↓", "tokens the model wrote (incl. reasoning when no split is reported)"],
      ["total", sum("t"), "Σ", "the actual burn this conversation cost so far"]
    ];
    let costTitle = "chat cost at the per-model $/1M rate set in Settings";
    if (lines.length) costTitle += " · " + lines.join(" · ");
    if (unrated.length) costTitle += " · NOT counted (no rate set in Settings): " + unrated.join(", ");
    const costHtml = cost > 0 ? `<span class="burn-seg cost" title="${U.escapeHtml(costTitle)}"><b>${fmt$(cost)}</b></span>` : "";
    const cachedHtml = sum("cached")
      ? `<span class="burn-seg" title="prompt tokens the provider served from cache — the split the ch-12 cache economics read"><i class="fa-solid fa-database"></i> ${U.fmtTokens(sum("cached"))} cached</span>`
      : "";
    return `<div class="burn-card" id="burn-card" role="status">
      <span class="burn-head" title="exact API-reported burn — appears after ${Math.round(this.BURN_IDLE_MS / 1000)}s of chat idle (ch-26.f4); hover each number for what it counts"><i class="fa-solid fa-fire"></i> BURN</span>
      <span class="burn-line">
        ${parts.map(([label, v, ico, tip]) => `<span class="burn-seg${label === "total" ? " total" : ""}" title="${label} — ${tip}"><span class="burn-ico">${ico}</span><b>${U.fmtTokens(v)}</b></span>`).join("")}
        <span class="burn-unit">tok</span>
      </span>
      ${costHtml}
      ${cachedHtml}
      <span class="burn-reqs" title="exact (API-reported) — one request per agent step">${rows.length} req · ${toolRows} turn${toolRows === 1 ? "" : "s"}</span>
      <button class="conv-action burn-copy" data-act="copy-burn" title="Copy burn + cost summary"><i class="fa-regular fa-copy"></i></button>
      <button class="conv-action burn-copy" data-act="copy-debug" title="Debug — copy this session's empty responses / stalls / tool errors with the exact tools + queries + thoughts before each (ade.debug.flat.txt)"><i class="fa-solid fa-bug"></i></button>
      ${legacy.length ? `<span class="burn-legacy">+ ${legacy.length} earlier message${legacy.length === 1 ? "" : "s"} predate telemetry · est ≈ ${U.fmtTokens(estLegacy)} tok not in the exact totals</span>` : ""}
    </div>`;
  },

  /* ADE-S20.5 (ch-26.f3, m-46) — the copy button now emits the structured
     summary (totals + per-model cost lines), not a scrape of the strip. */
  _burnSummaryText() {
    const rows = State.msgs.filter(m => m.role === "assistant" && m.usage);
    const legacy = State.msgs.filter(m => m.role === "assistant" && !m.usage && !m.error);
    const sum = (k) => rows.reduce((n, m) => n + (m.usage[k] || 0), 0);
    const { cost, lines, unrated } = this._burnRates(rows);
    const L = [
      "TOKEN BURN — exact (API-reported)",
      `prompt ${sum("p")} · reasoning ${sum("r")} · output ${sum("o")} · TOTAL ${sum("t")} tokens`,
      `${rows.length} API request${rows.length === 1 ? "" : "s"} · ${State.msgs.filter(m => m.role === "user").length} turn(s)`
    ];
    if (sum("cached")) L.push(`provider-cached prompt: ${sum("cached")} tok`);
    if (cost > 0) L.push(`cost: $${cost >= 0.01 ? cost.toFixed(2) : cost.toFixed(4)} (per-model $/1M from Settings)`);
    if (lines.length) L.push(...lines.map(x => "  " + x));
    if (unrated.length) L.push(`not costed (no $/1M set): ${unrated.join(", ")}`);
    if (legacy.length) L.push(`+ ${legacy.length} message(s) predate telemetry (est ≈ ${legacy.reduce((n, m) => n + U.estimateTokens(m.content || ""), 0)} tok, not in totals)`);
    return L.join("\n");
  },

  /* ══ ADE-S24.1 (ch-29.f2, m-53) · RUNNING SESSION TOTALS ══
     The per-message badge now carries the SESSION-so-far burn: Σ tokens
     over every API-reported request up to and including this row (the
     burn-strip's honest per-request semantics, applied cumulatively),
     plus the running $ cost at the per-model $/1M rates (ch-26.f3).
     Identity-scan up to THIS row keeps streaming renders cheap.          */
  _runningUsage(m) {
    const rows = [];
    for (const x of State.msgs) {
      if (x.role === "assistant" && x.usage) rows.push(x);
      if (x === m) break;
    }
    const sum = (k) => rows.reduce((n, r) => n + (r.usage[k] || 0), 0);
    return { p: sum("p"), r: sum("r"), o: sum("o"), t: sum("t"), n: rows.length, cost: this._burnRates(rows).cost };
  },

  /* ══ ADE-S25.3 (ch-31.f1, m-55) · SYSTEM-NOTE CHIPS ══
     The machinery notes (announce/cut/manual/auto nudges, paused notes)
     no longer render as dimmed fake-user message walls — the user called
     them "very unprofessional". Each systemNote row renders as ONE
     compact centered chip; the full model-facing text moves into the
     tooltip + a click-to-expand detail pre (the tool-card pattern).
     buildContext is untouched — rendering dignity, not protocol. */
  _sysChipLabel(m) {
    const k = m.noteKind || (String(m.content || "").startsWith("(manual continue") ? "manual" : String(m.content || "").startsWith("(your reply was cut off") ? "cut" : "announce");   // pre-S25 rows have no noteKind — sniff
    return k === "cut" ? "↻ auto-continue · resuming after a cut"
         : k === "manual" ? "↻ manual continue"
         : k === "auto" ? "↻ auto-continue · stall detected"
         : k === "paused" ? "run paused — ↻ Continue / a message re-drives"
         : "↻ auto-continue · nudge to emit the call";
  },

  /* hf.11 — quiet error chip: the S25.3 chip pattern for assistant error rows that
     carry no content ("Request failed …" · "Empty response from model."). One dim,
     centered, click-to-expand row instead of a red bubble wall. */
  _errChipHtml(m) {
    const full = U.escapeHtml(String(m.error || ""));
    const label = /empty response/i.test(m.error || "") ? "empty response — auto-continue re-drives" : "request failed — logged · retry / auto-continue handles it";
    return `<div class="msg sysnote-chip" data-id="${m.id}">
      <button class="sys-chip err" data-act="sysnote" title="${full}"><i class="fa-solid fa-triangle-exclamation"></i>${U.escapeHtml(label)}</button>
      <pre class="sys-detail" hidden>${full}</pre>
    </div>`;
  },

  _sysNoteHtml(m) {
    const label = this._sysChipLabel(m);
    const full = U.escapeHtml(m.content || "");
    return `<div class="msg sysnote-chip" data-id="${m.id}">
      <button class="sys-chip" data-act="sysnote" title="${full}"><i class="fa-solid fa-rotate-right"></i>${U.escapeHtml(label)}</button>
      <pre class="sys-detail" hidden>${full}</pre>
    </div>`;
  },

  msgHtml(m) {
    if (m.role === "tool") return this._toolMsgHtml(m); // ADE-05.3 — persisted tool trace rows
    if (m.systemNote) return this._sysNoteHtml(m);      // ADE-S25.3 (ch-31.f1) — machinery notes render as chips, not walls
    /* hf.11 · QUIET ERRORS — the "Request failed" bubble wall + "Empty response from model."
       read as malfunctions (user: not informative or professional — remove from view).
       The DATA stays (ade.errors.log · retry ×3 · auto-continue); the VIEW degrades to ONE
       compact chip (the S25.3 pattern): full text in the tooltip, click expands. Rows that
       carry real content keep the inline error block. */
    if (m.role === "assistant" && m.error && !m.content && !m.reasoning && m.id !== State.streamingId) return this._errChipHtml(m);
    const isUser = m.role === "user";
    const isStream = m.id === State.streamingId;
    const modelBadge = !isUser && m.model ? `<span class="model">${U.escapeHtml(m.model)}</span>` : "";
    /* ADE-S18.4 (ch-24.f3, m-43) — EXACT burn when the provider reported it,
       est fallback otherwise. Badge: ↑prompt · ✦reasoning · ↓output.
       ADE-S24.1 (ch-29.f2, m-53) — the line now ALSO carries the running
       session total: · Σt from the second reported request on, · $c when
       any involved model has a $/1M rate set (same arithmetic as the
       burn strip). ADE-S24.1 (ch-29.f1) — the badge RENDERS AT THE END
       of the message (footer under the bubble), not in the top meta. */
    let tokEst = "";
    if (m.usage) {
      const run = this._runningUsage(m);
      const fmt$ = (v) => "$" + (v >= 0.01 ? v.toFixed(2) : v.toFixed(4));
      let title = `exact API-reported burn — prompt ${m.usage.p} · reasoning ${m.usage.r} · output ${m.usage.o} (total ${m.usage.t})`;
      const runTok = run.n > 1 ? ` · <span class="tok-run" title="session so far (Σ per-request, re-sends included): ${run.t} tok over ${run.n} reported requests">Σ${U.fmtTokens(run.t)}</span>` : "";
      const runCost = run.cost > 0 ? ` · <span class="tok-run" title="session cost so far ≈ ${fmt$(run.cost)} at the per-model $/1M rates set in Settings">${fmt$(run.cost)}</span>` : "";
      if (run.n > 1) title += ` · session so far: ${run.t} tok over ${run.n} requests`;
      if (run.cost > 0) title += ` · ≈${fmt$(run.cost)} at the $/1M rates set in Settings`;
      tokEst = `<span class="tok-est exact" title="${U.escapeHtml(title)}">↑${U.fmtTokens(m.usage.p)} · ✦${U.fmtTokens(m.usage.r)} · ↓${U.fmtTokens(m.usage.o)}${runTok}${runCost}</span>`;
    } else {
      tokEst = `<span class="tok-est" title="estimated (chars/4) — this row predates exact telemetry">~${U.fmtTokens(U.estimateTokens(m.content || ""))} tok</span>`;
    }
    /* ADE-05.6 — ✦ tag + role badge become click-to-view when reasoning exists */
    const thinkable = !isUser && m.reasoning;
    const roleSpan = thinkable
      ? `<span class="role brain" data-act="think" title="View reasoning">${isUser ? "You" : "Agent"}</span>`
      : `<span class="role">${isUser ? "You" : "Agent"}</span>`;
    const thinkingTag = thinkable
      ? `<span class="thinking-tag" data-act="think" title="View reasoning">✦ thought</span>`
      : "";
    const streamTag = isStream ? `<span class="streaming-tag"><span class="blink">●</span> streaming</span>` : "";
    const errHtml = m.error
      ? `<div class="bubble error"><div class="err-title"><i class="fa-solid fa-triangle-exclamation"></i> Request failed</div>${U.escapeHtml(m.error)}</div>`
      : `<div class="bubble"><div class="md ${isStream ? "cursor-blink" : ""}">${renderMarkdown(m.content) || (isStream ? "" : "<p><em>(empty)</em></p>")}</div></div>`;
    const attHtml = (m.atts && m.atts.length)
      ? `<div class="att-list">${m.atts.map(a => `
          <span class="att-chip" title="${a.vfsPath ? "in workspace: " + U.escapeHtml(a.vfsPath) : "inlined into message"}">
            <i class="${U.fileIcon(a.name)}"></i>
            <span class="att-name">${U.escapeHtml(a.name)}</span>
            <span class="att-size">${U.fmtBytes(a.size)}</span>
          </span>`).join("")}</div>`
      : "";
    const actions = isStream ? "" : `<div class="msg-actions">
      <button class="conv-action" data-act="copy-msg" title="Copy text"><i class="fa-regular fa-copy"></i></button>
      ${isUser ? "" : `<button class="conv-action" data-act="del-msg" title="Delete message"><i class="fa-solid fa-trash"></i></button>`}
    </div>`;
    const sysnote = m.systemNote ? " sysnote" : ""; // ADE-HF.3 — auto-continue nudges render as dim system notes, not fake user turns
    return `<div class="msg${sysnote} ${isUser ? "user" : "assistant"}" data-id="${m.id}">
      <div class="avatar"><i class="fa-solid ${m.systemNote ? "fa-circle-info" : (isUser ? "fa-user" : "fa-robot")}"></i></div>
      <div class="body">
        <div class="meta">
          ${roleSpan}
          ${modelBadge}${streamTag}${thinkingTag}${m.cachePill ? `<span class="cache-pill" title="Prompt-cache mode (ch-12): the profile prefix is byte-stable; drift rides the task turn as a delta">${U.escapeHtml(m.cachePill)}</span>` : ""}
        </div>
        ${attHtml}
        ${errHtml}
        <div class="tok-foot">${tokEst}</div><!-- ADE-S24.1 (ch-29.f1) — the burn line lives at the END of the message -->
        ${actions}
      </div>
    </div>`;
  },

  /* ══ ADE-05.3 · TOOL TRACE — persisted role:tool row → card ══
     icon + name + arg summary + ok/err state (+ms); click expands
     args + result <pre>; copy button. Persisted in IndexedDB so the
     trace re-renders on reload like any other message.            */
  _toolMsgHtml(m) {
    const icon = (Agent.ICONS && Agent.ICONS[m.name]) || "fa-solid fa-wrench";
    const state = m.ok
      ? `<span class="tool-state ok"><i class="fa-solid fa-check"></i></span>`
      : `<span class="tool-state err"><i class="fa-solid fa-xmark"></i></span>`;
    const ms = m.ms != null ? `<span class="tool-ms">${m.ms}ms</span>` : "";
    return `<div class="msg tool" data-id="${m.id}">
      <div class="avatar"><i class="${icon}"></i></div>
      <div class="body">
        <div class="meta"><span class="role">tool</span><span class="tok-est">${U.escapeHtml(m.name)}</span></div>
        <div class="tool-card" data-act="tool-toggle" title="Click to expand args + result">
          <i class="${icon}"></i>
          <span class="tool-name">${U.escapeHtml(m.name)}</span>
          <span class="tool-args">${U.escapeHtml(Agent.argSummary(m.args))}</span>
          ${state}${ms}
        </div>
        <div class="tool-detail" hidden>
          <div class="td-label">ARGS</div>
          <pre>${U.escapeHtml(JSON.stringify(m.args ?? {}, null, 2))}</pre>
          <div class="td-label">RESULT${m.ok ? "" : " — ERROR"}</div>
          <pre>${U.escapeHtml(m.content || "(empty)")}</pre>
          <button class="conv-action tool-copy" data-act="tool-copy" title="Copy result"><i class="fa-regular fa-copy"></i> copy result</button>
        </div>
      </div>
    </div>`;
  },

  /* ══ ADE-05.6 · THINKING VIEWER (m-22) ══
     click the role badge / ✦ tag → lazy reasoning panel under the
     message; fed from msg.reasoning; renders OFF the streaming hot
     path (agent throttles noteReasoning to 250ms and only touches
     the DOM); auto-expand-while-streaming toggle lives in the panel
     header, persisted in the settings store ('think_autoexpand').  */
  async thinkAuto() {
    if (this._thinkAuto === null) {
      /* ADE-HF.3 — default ON: the user reads the thought process AS it
         renders (their explicit request). Unset setting = open while
         streaming; an explicit false (checkbox off) is respected. */
      try { this._thinkAuto = (await DB.getSetting("think_autoexpand")) !== false; }
      catch { this._thinkAuto = true; }
    }
    return this._thinkAuto;
  },

  async toggleThinkPanel(id) {
    const el = document.querySelector(`.msg[data-id="${id}"]`);
    const m = State.msgs.find(x => x.id === id);
    if (!el || !m) return;
    let panel = el.querySelector(".think-panel");
    if (panel) { panel.classList.toggle("open"); this._fillThink(m, panel); return; }
    if (!m.reasoning) return; // nothing to show yet
    panel = document.createElement("div");
    panel.className = "think-panel open";
    panel.innerHTML = `
      <div class="think-head"><i class="fa-solid fa-brain"></i> REASONING
        <label class="think-auto"><input type="checkbox" class="think-auto-cb" /> auto-expand while streaming</label>
      </div>
      <div class="think-body"></div>`;
    const anchor = el.querySelector(".bubble") || el.querySelector(".att-list");
    if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(panel, anchor);
    else el.querySelector(".body").appendChild(panel);
    const cb = panel.querySelector(".think-auto-cb");
    cb.checked = await this.thinkAuto();
    cb.addEventListener("change", () => { this._thinkAuto = cb.checked; DB.setSetting("think_autoexpand", cb.checked); });
    this._fillThink(m, panel);
  },

  _fillThink(m, panel) {
    if (!panel) return;
    const body = panel.querySelector(".think-body");
    if (!body) return;
    body.textContent = m.reasoning || "";
    /* ADE-HF.3 — the panel sticks to its own bottom only while the user
       reads there; scrolled up, their position in the thought process
       is preserved while it streams. */
    const stick = body.scrollHeight - body.scrollTop - body.clientHeight < 60;
    if (stick) body.scrollTop = body.scrollHeight;
  },

  /* live hook — the agent calls this on reasoning deltas (already
     throttled to 250ms upstream); cheap DOM touches only */
  async noteReasoning(m) {
    const el = document.querySelector(`.msg[data-id="${m.id}"]`);
    if (!el) return;
    const meta = el.querySelector(".meta");
    if (meta && !meta.querySelector(".thinking-tag")) {
      meta.insertAdjacentHTML("beforeend", `<span class="thinking-tag" data-act="think" title="View reasoning">✦ thinking</span>`);
    }
    const role = meta ? meta.querySelector(".role") : null;
    if (role && !role.classList.contains("brain")) { role.classList.add("brain"); role.dataset.act = "think"; role.title = "View reasoning"; }
    if (!(await this.thinkAuto())) return;
    let panel = el.querySelector(".think-panel");
    if (panel && !panel.classList.contains("open")) panel.classList.add("open");
    /* ADE-S16.2 (ch-22.f2, m-40) — panel creation is ASYNC (the settings
       read inside toggleThinkPanel awaits IndexedDB): the un-awaited call
       raced the streaming DOM, so _fillThink could paint a detached node
       and the auto panel could come up empty. Await creation, then
       re-query the live panel. */
    if (!panel) { await this.toggleThinkPanel(m.id); panel = el.querySelector(".think-panel"); }
    this._fillThink(m, panel);
  },

  async deleteMessage(id) {
    await DB.delMsg(id);
    State.msgs = State.msgs.filter(m => m.id !== id);
    this.renderThread();
  },

  /* ══ attachments (ADE-01.5) ═════════════════════════════
     text files → inlined as fenced blocks into the user message
     zip / binaries → saved straight into the workspace VFS at
     /imports/<ts>-<name> via the CH-01 vfs stub (row shape is
     the final CH-02 shape — extraction lands with CH-02 fflate) */
  async addFiles(files) {
    for (const f of files) {
      if (State.pendingAtts.length >= 10) { U.toast("Attachment cap", { kind: "err", msg: "Max 10 files per message." }); break; }
      const att = { id: U.uid(), name: f.name, type: f.type || "application/octet-stream", size: f.size };
      if (U.isTextName(f.name, f.type) && f.size <= 2 * 1024 * 1024) {
        att.text = await U.readTextFile(f);
      } else {
        att.blob = f;
        att.kind = "binary";
        if (f.size > 24 * 1024 * 1024) {
          U.toast("File too large", { kind: "err", msg: f.name + " exceeds 24 MB — skipped." });
          continue;
        }
      }
      State.pendingAtts.push(att);
    }
    this.renderAttPreview();
  },

  renderAttPreview() {
    const box = document.getElementById("att-preview");
    box.innerHTML = State.pendingAtts.map(a => `
      <span class="att-chip" data-id="${a.id}" title="${a.kind === "binary" ? "lands in workspace /imports" : "text — inlines into message"}">
        <i class="${U.fileIcon(a.name)}"></i>
        <span class="att-name">${U.escapeHtml(a.name)}</span>
        <span class="att-size">${U.fmtBytes(a.size)}${a.kind === "binary" ? " · → /imports" : ""}</span>
        <i class="fa-solid fa-xmark att-x" data-act="rm-att"></i>
      </span>`).join("");
  },

  /* persist binary attachments into the VFS; returns chip records.
     CH-02: zip attachments now EXTRACT via fflate (importZip) into
     /imports/<ts>-<name>/ — the ch-01.f5 deferral is paid off here
     (touch outside ch-02.files, justified: one function the planner
     note explicitly assigned to ch-02.f4). */
  async storeBinaryAtts(atts) {
    const out = [];
    for (const a of atts) {
      if (a.kind !== "binary") { out.push({ name: a.name, size: a.size, inline: true }); continue; }
      try {
        const buf = await U.readArrayBuffer(a.blob);
        const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
        let path;
        if (/\.zip$/i.test(a.name) && typeof fflate !== "undefined") {
          const dest = `/imports/${ts}-${a.name.replace(/\.zip$/i, "")}`;
          const s = await VFS.importZip(buf, dest);
          path = s.lastPath ? s.root : dest;
          U.toast("Zip extracted", { kind: "ok", msg: `${a.name} → ${s.root} · ${s.imported} files` });
        } else {
          path = `/imports/${ts}-${a.name}`;
          await VFS.put(path, buf, false);
        }
        out.push({ name: a.name, size: a.size, vfsPath: path });
      } catch (e) {
        U.toast("Import failed", { kind: "err", msg: a.name + " — " + (e?.message || e) });
        out.push({ name: a.name, size: a.size, inline: true });
      }
    }
    return out;
  },

  /* ══ send flow ═════════════════════════════════════════ */
  buildUserContent(text, atts) {
    let content = text || "";
    for (const a of atts) {
      if (a.text != null) {
        const lang = (a.name.split(".").pop() || "").toLowerCase();
        content += `\n\n--- File: ${a.name} ---\n\`\`\`${lang}\n${a.text}\n\`\`\`\n--- End ${a.name} ---`;
      }
    }
    return content.trim();
  },

  activeConfig() {
    return State.configs.find(c => c.id === State.activeConfigId) || null;
  },

  async send() {
    if (State.streaming) return;
    const input = document.getElementById("msg-input");
    const text = input.value.trim();
    const atts = State.pendingAtts.slice();
    if (!text && !atts.length) return;

    const cfg = this.activeConfig();
    if (!cfg) { U.toast("No AI config", { kind: "err", msg: "Open Settings → Configs and add one." }); return; }
    if (!cfg.apiKey) { U.toast("Missing API key", { kind: "err", msg: `Config "${cfg.name}" has no AiHubMix key.` }); return; }

    if (!State.activeConvId) await this.newConversation();

    const attRecords = await this.storeBinaryAtts(atts);
    const content = this.buildUserContent(text, atts);
    State.pendingAtts = [];
    this.renderAttPreview();

    const conv = State.convs.find(c => c.id === State.activeConvId);
    if (conv && (conv.title === "New conversation" || !conv.title)) {
      conv.title = (text || atts[0]?.name || "Conversation").slice(0, 48);
      await DB.saveConv(conv);
    }

    input.value = "";
    this.clearDraft(this._draftConvId != null ? this._draftConvId : State.activeConvId); // hf.13 — the sent text leaves the draft store too
    this._draftConvId = State.activeConvId;
    this.autoResize(input);

    await this.runTurn(cfg, State.activeConvId, content, { atts: attRecords }); // ADE-S18.6 — flow extracted for the scheduler (ch-25)
  },

  /* ══ ADE-S18.6 (ch-25.f2, m-44) · ONE SHARED RUN TURN ══
     The send flow minus composer/attachment concerns, so the task
     scheduler (js/scheduler.js) can launch agent runs into a NEW
     conversation with the exact same persistence + render behavior:
     user row → assistant placeholder → Agent.runAgent → finalize UI.
     Switches the active conversation to convId first — the agent loop
     persists rows against State.activeConvId.                         */
  async runTurn(cfg, convId, text, { atts = [] } = {}) {
    if (State.streaming) return null;
    State.activeConvId = convId;
    clearTimeout(this._autoTimer); this._autoTimer = null;   // ADE-S25.6 — a fresh user/scheduler turn supersedes any pending auto-continue
    this._autoChain = 0;                                     // ADE-S25.6 — each fresh turn starts a fresh chain
    await DB.setSetting(SK.ACTIVE_CONV, convId);
    State.msgs = await DB.msgsByConv(convId); // render context now points at the target conv (persisted truth)
    this.loadDraft(convId); // hf.13 — composer follows the conversation the agent now runs in (scheduler turns too)

    const userMsg = { id: U.uid(), convId, role: "user", content: text, atts, ts: Date.now() };
    await DB.saveMsg(userMsg);
    State.msgs.push(userMsg);

    const conv = State.convs.find(c => c.id === convId);
    if (conv) { conv.lastTs = Date.now(); await DB.saveConv(conv); }

    const asstMsg = { id: U.uid(), convId, role: "assistant", content: "", model: cfg.model, ts: Date.now() };
    await DB.saveMsg(asstMsg);
    State.msgs.push(asstMsg);
    State.streamingId = asstMsg.id;

    this.renderThread();
    this.setStreaming(true);
    try {
      await Agent.runAgent(cfg, userMsg, asstMsg); // CH-05 — the tool loop lives in js/agent.js
    } finally {
      State.streamingId = null;
      this.setStreaming(false);
      await this.renderSidebar();
      this.renderThread();
      /* ADE-S24.2 (ch-29.f3, m-53) — a mid-stream Continue PUSH aborted the
         dead fetch to get here; now that the run closed honestly, fire the
         continuation once (deferred past the finally, guard against races). */
      let pushed = false;
      if (this._pushAfterStop) {
        this._pushAfterStop = false;
        pushed = true;
        setTimeout(() => { this.continueTurn().catch(() => {}); }, 80);
      }
      /* ADE-S25.6 (ch-31.f4, m-56) — AUTO-CONTINUE ENGINE: if the run died
         on a transient/stall shape, scroll to bottom + 5 s grace + re-drive
         (the manual push above IS a continue — never double-drive). */
      if (!pushed) await this._maybeAutoContinue(cfg);
    }
    return asstMsg;
  },

  /* ══ ADE-S24.2 (ch-29.f3, m-53) · CONTINUE — push a dropped model ══
     Field report: gateways drop mid-answer; the run closes with a cut
     note or a stalled-error and the user had NO one-click way to resume.
     Two modes, one button left of send/stop:
     · IDLE → continueTurn(): appends a system-note nudge (the HF.3
       auto-continue machinery, manual) + a fresh assistant row and
       re-enters Agent.runAgent — the model resumes EXACTLY where the
       last row stopped, no repetition, no fake user turn.
     · MID-STREAM → continuePush(): the stream is presumed dead (that is
       why you are pushing) — abort the fetch, let runTurn's finally
       close the run honestly (cut semantics preserved), then
       continueTurn fires from the hook above.                        */
  /* ══ ADE-S25.6 (ch-31.f4, m-56) · AUTO-CONTINUE ENGINE ══
     "add option to rerun continue if it stalls on its own" · "when it
     freezes scroll to bottom and give it 5 second grace period, then
     continue". After EVERY run close (runTurn + continueTurn finally),
     the LAST assistant row is inspected for death shapes; a death arms
     the user's exact spec — scroll to bottom, 5 s grace, then a continue
     re-drive through the SAME systemNote machinery (noteKind "auto").
     Chain budget 6, then ONE honest give-up note; the chain resets on a
     fresh turn (runTurn) or a healthy close; a user abort, a 400-class
     config error, a newer user send or a pending manual push never
     auto-continue. The setting is DB kv "auto_continue", default ON
     (Settings → Agent checkbox, ADE-S25.7).                              */
  AUTO_ERR_RE: /failed to fetch|networkerror|load failed|gateway stalled|empty response|http\s*(?:408|425|429|500|502|503|504|522|523|524|529)\b/i,
  AUTO_NOTE_RES: [/\(reply hit the output limit /i, /\(the model announced an action /i],
  AUTO_GRACE_MS: 5000,
  AUTO_CHAIN_MAX: 6,
  _autoChain: 0,
  _autoTimer: null,

  _deathKind(row) {
    if (!row) return null;
    if (row.error && this.AUTO_ERR_RE.test(row.error)) return row.error.slice(0, 60);
    const c = String(row.content || "");
    if (this.AUTO_NOTE_RES.some(re => re.test(c))) return c.slice(0, 60);
    return null;
  },

  async _maybeAutoContinue(cfg) {
    if (this._pushAfterStop) return;                     // the manual push IS a continue — never double-drive
    const row = State.msgs.slice().reverse().find(m => m.role === "assistant");
    const death = this._deathKind(row);
    if (!death) { this._autoChain = 0; return; }         // healthy close — fresh chain next run
    if (State.streaming || !State.activeConvId || !cfg) return;  // a newer run already took over
    let on = true;
    try { on = (await DB.getSetting("auto_continue")) !== false; } catch { /* default ON */ }
    if (!on) return;                                     // manual ↻ remains, as before
    if (this._autoChain >= this.AUTO_CHAIN_MAX) {
      this._autoChain = 0;
      const giveUp = { id: U.uid(), convId: State.activeConvId, role: "assistant", content: `_(auto-continue gave up after ${this.AUTO_CHAIN_MAX} attempts — the run kept dying. Press ↻ Continue to retry manually, or check the endpoint/config.)_`, model: row.model || cfg.model || "", ts: Date.now() };
      await DB.saveMsg(giveUp);
      State.msgs.push(giveUp);
      this.renderThread();
      U.toast("Auto-continue stopped", { kind: "err", msg: "The run kept dying — continue manually or check the endpoint.", ms: 4200 });
      return;
    }
    this._autoChain++;
    /* hf.16 — DEBUG LEDGER: the death is recorded into /ade.debug.flat.txt
       with the exact tool + query that ran just before it + the agent's
       thoughts, dated (the BURN strip's 🐛 debug button copies the session). */
    try { await Agent.dbgDeath(death, this._autoChain, row); } catch { /* best-effort */ }
    /* hf.12 — EMPTY-RESPONSE ESCALATION: a stall that repeats on the same
       payload is almost always SIZE — the endpoint answers 200 + an empty
       stream instead of a clean 413 (the field log: "empty response —
       auto-continue re-drives" ×N at ~20k-tok payloads). When the last
       measured context sits past ~50% of the configured budget, arm the
       re-drive with the auto-shrink (level = chain depth): the next runAgent
       stubs old tool results and halves the budget instead of re-shipping
       the identical payload. A tiny context or a clean network error stays
       on the plain retry path. */
    if (/empty response|gateway stalled|load failed|failed to fetch/i.test(death) && Agent.lastCtxTok) {
      const budgetK = Number(cfg.contextK ?? 24) || 24;
      if (Agent.lastCtxTok > budgetK * 1000 * 0.5) Agent._autoShrink = Math.min(2, this._autoChain);
    }
    this.scrollBottom(true);                             // the spec: "when it freezes scroll to bottom"
    U.toast("Auto-continue", { kind: "info", msg: `Run stalled (${death}) — re-driving in 5 s (attempt ${this._autoChain}/${this.AUTO_CHAIN_MAX})…`, ms: 3200 });
    clearTimeout(this._autoTimer);
    this._autoTimer = setTimeout(() => {                 // the spec: "5 second grace period, then continue"
      this._autoTimer = null;
      if (State.streaming) return;
      this.continueTurn({ auto: true }).catch(() => {});
    }, this.AUTO_GRACE_MS);
  },

  _pushAfterStop: false,

  async continuePush() {
    if (State.streaming) {
      this._pushAfterStop = true;
      try { this.abortCtl?.abort(); } catch { /* already dead */ }
      U.toast("Pushing", { kind: "info", msg: "Stopped the dead stream — continuing from where it dropped…", ms: 2600 });
      return;
    }
    await this.continueTurn();
  },

  async continueTurn({ auto = false } = {}) {
    if (State.streaming) return;
    clearTimeout(this._autoTimer); this._autoTimer = null;   // a human/manual drive supersedes a pending auto
    const cfg = this.activeConfig();
    if (!cfg) { U.toast("No AI config", { kind: "err", msg: "Open Settings → Configs and add one." }); return; }
    if (!cfg.apiKey) { U.toast("Missing API key", { kind: "err", msg: `Config "${cfg.name}" has no AiHubMix key.` }); return; }
    if (!State.activeConvId || !State.msgs.length) {
      U.toast("Nothing to continue", { kind: "err", msg: "Send a message first — Continue re-drives the latest task." });
      return;
    }
    const nudge = {
      id: U.uid(), convId: State.activeConvId, role: "user", systemNote: true,
      noteKind: auto ? "auto" : "manual",   /* ADE-S25.2 (ch-30.f5) + ADE-S25.6 (ch-31.f4) */
      content: auto
        ? "(auto continue — the run stalled or the connection dropped: resume the task exactly where the last reply stopped, mid-sentence if needed; no repetition, no re-greeting, no re-planning; reply DONE only when the CURRENT task's deliverable is verified in this transcript — unfinished tool work, or a tool ERROR just above, means continue, never DONE)"
        : "(manual continue — resume the task exactly where the last reply stopped, mid-sentence if needed; no repetition, no re-greeting, no re-planning; reply DONE only when the CURRENT task's deliverable is verified in this transcript — unfinished tool work, or a tool ERROR just above, means continue, never DONE)",
      model: cfg.model, ts: Date.now()
    };
    await DB.saveMsg(nudge);
    State.msgs.push(nudge);
    const asstMsg = { id: U.uid(), convId: State.activeConvId, role: "assistant", content: "", model: cfg.model, ts: Date.now() };
    await DB.saveMsg(asstMsg);
    State.msgs.push(asstMsg);
    State.streamingId = asstMsg.id;
    this.renderThread();
    this.setStreaming(true);
    try {
      await Agent.runAgent(cfg, nudge, asstMsg);
    } finally {
      State.streamingId = null;
      this.setStreaming(false);
      await this.renderSidebar();
      this.renderThread();
      await this._maybeAutoContinue(cfg);   // ADE-S25.6 — the re-drive itself may die; the chain continues (budget-capped)
    }
    return asstMsg;
  },

  setStreaming(on) {
    State.streaming = on;
    document.getElementById("send-btn").style.display = on ? "none" : "";
    document.getElementById("stop-btn").style.display = on ? "" : "none";
  },

  /* resolved request URL — moved to Agent.resolveUrl (CH-05);
     kept as a thin async alias so nothing else breaks */
  async resolveUrl(cfg) { return Agent.resolveUrl(cfg); },

  async finalize(asstMsg, { acc = "", reasonAcc = "", toolCalls, usage, aborted = false } = {}) {
    asstMsg.content = acc;
    if (reasonAcc) asstMsg.reasoning = reasonAcc;      // persisted — CH-05 viewer reads this
    if (toolCalls) asstMsg.toolCalls = toolCalls;      // persisted — CH-05 replays these
    if (usage) asstMsg.usage = usage;                  // ADE-S18.4 (ch-24) — exact burn persisted
    if (usage && Number(usage.t) > 0) State.sessionTokens = (State.sessionTokens || 0) + Number(usage.t); // hf.13 — tab-lifetime Σ (secondary figure in the clock tooltip); the hdr clock itself reads the CHAT's own usage rows since hf.13
    /* ADE-S25.8 (ch-32.f2, m-57) — name what happened + the recovery (the
       bare line read like a malfunction and fed the "all models disabled"
       report). Still NEVER auto-continues: a deliberate stop stays a stop
       (ch-31.f4 doctrine — the test pins it). */
    if (aborted && !acc && !reasonAcc) asstMsg.error = "Stopped before any tokens arrived — Stop was pressed (or the stream died before the first byte). Press ↻ Continue to re-drive.";
    else if (!acc && !reasonAcc && !aborted && !asstMsg.error) asstMsg.error = "Empty response from model."; // ADE-HF.3 — an all-thinking reply (reasoning present) is NOT empty
    await DB.saveMsg(asstMsg);
    const conv = State.convs.find(c => c.id === State.activeConvId);
    if (conv) { conv.lastTs = Date.now(); await DB.saveConv(conv); }
  },

  /* resolved request URL — moved to Agent.resolveUrl (CH-05);
     kept as a thin alias so nothing else breaks */
  resolveUrl(cfg) { return Agent.resolveUrl(cfg); },

  /* ══ composer wiring ═══════════════════════════════════ */
  autoResize(ta) {
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 180) + "px";
  },

  /* ══ hf.13 · COMPOSER DRAFT PERSISTENCE ══
     Every keystroke in #msg-input lands in localStorage under the ACTIVE
     conversation id (ade_draft_v1_<convId>, 48k-char cap) — a reload, an
     SW-update reload (controllerchange) or a closed tab never eats typed
     work. Drafts follow chat switching (openConversation loads the target
     chat's draft), the pre-chat scratch draft (typed while no conversation
     is active — key __new) migrates into the chat it starts, send() clears
     the entry, deleting a chat discards it. _draftConvId pins WHERE the
     current composer content belongs, so a scheduler turn switching convs
     mid-typing can never file the user's text under the wrong chat.
     localStorage (not sessionStorage): survives both reloads AND tab
     restarts. Private mode / quota errors degrade to in-memory behavior. */
  _draftConvId: null,
  _draftKey(id) { return "ade_draft_v1_" + (id || "__new"); },
  saveDraft() {
    const input = document.getElementById("msg-input");
    if (!input) return;
    const id = this._draftConvId != null ? this._draftConvId : State.activeConvId;
    try {
      const v = input.value;
      if (v) localStorage.setItem(this._draftKey(id), v.length > 48000 ? v.slice(0, 48000) : v);
      else localStorage.removeItem(this._draftKey(id));
    } catch { /* private mode / quota — the draft just lives in the textarea */ }
  },
  loadDraft(id, { focus = false } = {}) {
    this._draftConvId = id != null ? id : null;
    const input = document.getElementById("msg-input");
    if (!input) return;
    let v = "";
    try { v = localStorage.getItem(this._draftKey(id)) || ""; } catch { /* private mode */ }
    input.value = v;
    this.autoResize(input);
    if (v) { try { input.setSelectionRange(v.length, v.length); } catch { /* stub in tests */ } }
    if (focus) input.focus();
  },
  clearDraft(id) {
    try { localStorage.removeItem(this._draftKey(id)); } catch { /* private mode */ }
  },
  migrateScratchDraft(newId) {
    try {
      const pre = localStorage.getItem(this._draftKey(null));
      if (pre && !localStorage.getItem(this._draftKey(newId))) {
        localStorage.setItem(this._draftKey(newId), pre);
        localStorage.removeItem(this._draftKey(null));
      }
    } catch { /* private mode — nothing to migrate */ }
  },

  initComposer() {
    this._startBurnTick(); // ADE-S20.4 (ch-26.f4, m-46) — 1 Hz idle sweep for the burn strip
    const input = document.getElementById("msg-input");
    input.addEventListener("keydown", e => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); this.send(); }
    });
    input.addEventListener("input", () => { this.autoResize(input); this.saveDraft(); }); // hf.13 — keystroke → draft store
    window.addEventListener("pagehide", () => { try { this.saveDraft(); } catch { /* last-ditch flush */ } }); // hf.13 — covers paste/IME paths that skip `input`
    this.loadDraft(State.activeConvId); // hf.13 — boot restore (main.js restores the last conv before this runs)

    document.getElementById("send-btn").addEventListener("click", () => this.send());
    document.getElementById("stop-btn").addEventListener("click", () => {
      try { this.abortCtl?.abort(); } catch { /* ignore */ }
    });
    /* ADE-S24.2 (ch-29.f3, m-53) — CONTINUE sits left of send/stop */
    document.getElementById("continue-btn").addEventListener("click", () => this.continuePush());

    /* ADE-S25.4 (ch-31.f2, m-56) — SCROLL-TO-BOTTOM button + tracking */
    const threadEl = document.getElementById("thread");
    const sbtn = document.getElementById("scroll-btn");
    this._updScrollBtn = () => {
      const far = threadEl.scrollHeight - threadEl.scrollTop - threadEl.clientHeight > 140;
      sbtn.classList.toggle("show", far);
    };
    threadEl.addEventListener("scroll", this._updScrollBtn, { passive: true });
    sbtn.addEventListener("click", () => this.scrollBottom(true));

    document.getElementById("attach-btn").addEventListener("click", () => document.getElementById("file-input").click());
    document.getElementById("file-input").addEventListener("change", e => {
      this.addFiles([...e.target.files]);
      e.target.value = "";
    });

    // drag-drop onto the composer → attachments (ADE-01.5)
    const area = document.getElementById("input-area");
    let dragDepth = 0;
    area.addEventListener("dragenter", e => { e.preventDefault(); dragDepth++; area.classList.add("dragging"); });
    area.addEventListener("dragover", e => e.preventDefault());
    area.addEventListener("dragleave", () => { if (--dragDepth <= 0) { dragDepth = 0; area.classList.remove("dragging"); } });
    area.addEventListener("drop", async e => {
      e.preventDefault();
      dragDepth = 0;
      area.classList.remove("dragging");
      if (e.dataTransfer?.files?.length) await this.addFiles([...e.dataTransfer.files]);
    });

    // attachment chip remove + message actions (delegated)
    document.getElementById("att-preview").addEventListener("click", e => {
      const x = e.target.closest(".att-x");
      if (!x) return;
      const chip = x.closest(".att-chip");
      State.pendingAtts = State.pendingAtts.filter(a => a.id !== chip.dataset.id);
      this.renderAttPreview();
    });
    document.getElementById("thread").addEventListener("click", async e => {
      const btn = e.target.closest("[data-act]");
      if (!btn) return;
      const msgEl = btn.closest(".msg");
      const id = msgEl?.dataset.id;
      const act = btn.dataset.act;
      if (act === "copy-msg") {
        const m = State.msgs.find(x => x.id === id);
        if (m) U.copyText(m.content || "");
      } else if (act === "copy-burn") {           // ADE-S20.5 (ch-26.f3, m-46) — structured burn + cost summary
        U.copyText(this._burnSummaryText());
      } else if (act === "copy-debug") {          // hf.16 — copy the ACTIVE session's debug lines (empty responses / stalls / tool errors, dated, with tools + queries + thoughts)
        try { await Agent.copyDebugSession(); } catch { /* toast handled inside */ }
      } else if (act === "del-msg") {
        await this.deleteMessage(id);
      } else if (act === "sysnote") {               // ADE-S25.3 (ch-31.f1) — expand a machinery-note chip
        const detail = btn.closest(".sysnote-chip")?.querySelector(".sys-detail");
        if (detail) detail.hidden = !detail.hidden;
      } else if (act === "think") {
        await this.toggleThinkPanel(id);            // ADE-05.6 — lazy reasoning panel
      } else if (act === "tool-toggle") {           // ADE-05.3 — expand args + result
        const detail = btn.closest(".body")?.querySelector(".tool-detail");
        if (detail) detail.hidden = !detail.hidden;
      } else if (act === "tool-copy") {
        const m = State.msgs.find(x => x.id === id);
        if (m) U.copyText(m.content || "");
      }
    });
  }
};


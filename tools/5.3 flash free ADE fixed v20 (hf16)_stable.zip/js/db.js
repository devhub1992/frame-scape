/* ============================================================
   js/db.js — ADE-01.2 · IndexedDB core ("ade-db" v1)
   stores: convs · msgs (idx convId) · configs · settings (kv)
           · vfs (path rows + parent idx) · handles (FSA, 'wsdir')
   + global State + settings helpers + storage.persist() on boot.
   SCHEMA IS ADDITIVE-ONLY (routing §01 ai.saves.rule): future
   chunks may add stores/keys/indexes — never rename or drop.
   HF-02 (m-31): DB.migrate() — settings-schema versioning so OLD
   LOCAL CACHE SETTINGS (configs persisted by earlier builds)
   cannot shadow a new deploy: dead keyless proxy templates are
   upgraded to the keyed default, missing agent fields are filled
   from defaults, secrets (apiKey · corsKey) are always preserved.
   ============================================================ */
"use strict";

const DB = (() => {
  const DB_NAME = "ade-db";
  const DB_VERSION = 3; // ADE-12.1 (ch-12.f1, m-29): v3 adds the 'cache' store — additive-only (ai.saves.rule); v2 was ch-25's 'tasks', v1 data untouched

  const STORE_CONVS = "convs";      // { id, title, ts, lastTs }
  const STORE_MSGS = "msgs";        // { id, convId, role, content, reasoning?, toolCalls?, atts?, model?, error?, usage?, ts }
  const STORE_CONFIGS = "configs";  // { id, name, model, baseUrl, apiKey, proxyUrl, temperature, maxTokens, maxSteps, contextK, costPerM, forceProto, ts }
  const STORE_SETTINGS = "settings";// kv: key -> any
  const STORE_VFS = "vfs";          // { path, kind, parent, isText, content, size, mtime } (index: parent)
  const STORE_HANDLES = "handles";  // kv: 'wsdir' -> FileSystemDirectoryHandle
  const STORE_TASKS = "tasks";      // ADE-S18.8 (ch-25.f1) — { id, name, prompt, freq, intervalMin, startAt, times, runs, nextRun, lastRun, lastStatus, lastNote, lastConvId, enabled, createdAt }
  const STORE_CACHE = "cache";      // ADE-12.1 (ch-12.f1, m-29) — project-profile snapshots: { id: "cache-NNN", ts, fileCount, estTokens, driftCount, status, files: { path: { h, size, lines, k } } }

  let _dbPromise = null;

  function open() {
    if (_dbPromise) return _dbPromise;
    _dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_CONVS)) db.createObjectStore(STORE_CONVS, { keyPath: "id" });
        if (!db.objectStoreNames.contains(STORE_MSGS)) {
          const s = db.createObjectStore(STORE_MSGS, { keyPath: "id" });
          s.createIndex("convId", "convId", { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_CONFIGS)) db.createObjectStore(STORE_CONFIGS, { keyPath: "id" });
        if (!db.objectStoreNames.contains(STORE_SETTINGS)) db.createObjectStore(STORE_SETTINGS);
        if (!db.objectStoreNames.contains(STORE_VFS)) {
          const s = db.createObjectStore(STORE_VFS, { keyPath: "path" });
          s.createIndex("parent", "parent", { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_HANDLES)) db.createObjectStore(STORE_HANDLES);
        if (!db.objectStoreNames.contains(STORE_TASKS)) db.createObjectStore(STORE_TASKS, { keyPath: "id" }); // ADE-S18.8 — v2 upgrade, v1 installs skip nothing
        if (!db.objectStoreNames.contains(STORE_CACHE)) db.createObjectStore(STORE_CACHE, { keyPath: "id" }); // ADE-12.1 — v3 upgrade, additive-only
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return _dbPromise;
  }

  function tx(store, mode, fn) {
    return open().then(db => new Promise((resolve, reject) => {
      const t = db.transaction(store, mode);
      const s = t.objectStore(store);
      const req = fn(s);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  }

  /* ── PATCH 3/3 (ch-16.f1, marker ADE-HF2.5) · settings-schema migration ──
     (additive-only, idempotent — ai.saves.rule safe)
     v1 = any build before HF-02 (no schema_v stamp stored).
     v2 = keyed-proxy era: keyless corsproxy templates are DEAD (403,
     live-tested 2026-10-30) — stored configs still carrying one are
     upgraded to the keyed default template; agent fields missing in
     pre-CH-05 rows are filled from the factory defaults. Everything
     the user typed (name · model · baseUrl · apiKey · custom proxyUrl)
     is preserved untouched. Bump SETTINGS_SCHEMA_VERSION + add a step
     in migrate() per release — never rewrite user data silently. */
  const SETTINGS_SCHEMA_VERSION = 4; /* ADE-S20.2 (ch-26.f2, m-46) — v4: costPerM on every stored config */
  const LEGACY_PROXY_TEMPLATES = [ // keyless pre-HF-01 defaults — all 403 today
    "https://corsproxy.io/?{url}",
    "https://corsproxy.io/?url={url}",
    "https://corsproxy.io/"
  ];

  async function migrate() {
    const from = (await tx(STORE_SETTINGS, "readonly", s => s.get("schema_v"))) || 1; // tx — getSetting lives on the API object, not in this closure
    if (from >= SETTINGS_SCHEMA_VERSION) return { from, to: SETTINGS_SCHEMA_VERSION, changed: [] };
    const changed = [];
    if (from < 2) {
      const cfgs = await tx(STORE_CONFIGS, "readonly", s => s.getAll());
      for (const c of cfgs) {
        const d = makeDefaultConfig(); // field defaults only — id/ts/name of d unused
        let dirty = false;
        for (const k of ["temperature", "maxTokens", "maxSteps", "contextK", "forceProto"]) {
          if (c[k] === undefined || c[k] === null) { c[k] = d[k]; changed.push(`${c.name}: ${k} → ${d[k]}`); dirty = true; }
        }
        if (typeof c.proxyUrl === "string" && LEGACY_PROXY_TEMPLATES.includes(c.proxyUrl.trim())) {
          c.proxyUrl = d.proxyUrl; // keyed template — Proxy Setup will show KEY MISSING until the key is saved
          changed.push(`${c.name}: proxyUrl → keyed CorsProxy.io template`);
          dirty = true;
        }
        if (dirty) await tx(STORE_CONFIGS, "readwrite", s => s.put(c));
      }
    }
    /* ADE-12.1 (ch-12.f1) — v3: prompt-caching config fields on EVERY stored
       config (cache-mode per-config toggle + extra-body JSON), additive only */
    if (from < 3) {
      const cfgs = await tx(STORE_CONFIGS, "readonly", s => s.getAll());
      for (const c of cfgs) {
        let dirty = false;
        if (typeof c.cacheMode !== "boolean") { c.cacheMode = false; changed.push(`${c.name}: cacheMode → false`); dirty = true; }
        if (typeof c.extraBody !== "string") { c.extraBody = ""; changed.push(`${c.name}: extraBody → ""`); dirty = true; }
        if (dirty) await tx(STORE_CONFIGS, "readwrite", s => s.put(c));
      }
    }
    /* ADE-S20.2 (ch-26.f2, m-46) — v4: cost-per-1M-tokens on EVERY stored
       config (the burn strip's $ total, ch-26.f3); additive only — 0 = not
       tracked, the strip simply shows no $ segment until a rate is set */
    if (from < 4) {
      const cfgs = await tx(STORE_CONFIGS, "readonly", s => s.getAll());
      for (const c of cfgs) {
        if (typeof c.costPerM !== "number" || !isFinite(c.costPerM) || c.costPerM < 0) {
          c.costPerM = 0;
          changed.push(`${c.name}: costPerM → 0`);
          await tx(STORE_CONFIGS, "readwrite", s => s.put(c));
        }
      }
    }
    await tx(STORE_SETTINGS, "readwrite", s => s.put(SETTINGS_SCHEMA_VERSION, "schema_v"));
    return { from, to: SETTINGS_SCHEMA_VERSION, changed };
  }

  return {
    STORES: { CONVS: STORE_CONVS, MSGS: STORE_MSGS, CONFIGS: STORE_CONFIGS, SETTINGS: STORE_SETTINGS, VFS: STORE_VFS, HANDLES: STORE_HANDLES, TASKS: STORE_TASKS, CACHE: STORE_CACHE },

    /* generic helpers — get/set/del/all/byIndex/clear */
    get: (store, key) => tx(store, "readonly", s => s.get(key)),
    set: (store, val, key) => tx(store, "readwrite", s => key !== undefined ? s.put(val, key) : s.put(val)),
    del: (store, key) => tx(store, "readwrite", s => s.delete(key)),
    all: (store) => tx(store, "readonly", s => s.getAll()),
    byIndex: (store, index, key) => tx(store, "readonly", s => s.index(index).getAll(key)),
    clear: (store) => tx(store, "readwrite", s => s.clear()),

    /* kv sugar for settings + handles stores */
    getSetting: async (key) => { try { return await tx(STORE_SETTINGS, "readonly", s => s.get(key)); } catch { return undefined; } },
    setSetting: (key, val) => tx(STORE_SETTINGS, "readwrite", s => s.put(val, key)),
    delSetting: (key) => tx(STORE_SETTINGS, "readwrite", s => s.delete(key)),
    getHandle: (key) => tx(STORE_HANDLES, "readonly", s => s.get(key)),
    setHandle: (key, val) => tx(STORE_HANDLES, "readwrite", s => s.put(val, key)),
    delHandle: (key) => tx(STORE_HANDLES, "readwrite", s => s.delete(key)),

    /* convs + msgs + configs */
    allConvs: async () => {
      const all = await tx(STORE_CONVS, "readonly", s => s.getAll());
      return all.sort((a, b) => (b.lastTs || b.ts) - (a.lastTs || a.ts));
    },
    saveConv: (c) => tx(STORE_CONVS, "readwrite", s => s.put(c)),
    delConv: async (id) => {
      const msgs = await DB.byIndex(STORE_MSGS, "convId", id);
      for (const m of msgs) await tx(STORE_MSGS, "readwrite", s => s.delete(m.id));
      await tx(STORE_CONVS, "readwrite", s => s.delete(id));
    },
    msgsByConv: async (convId) => {
      const all = await DB.byIndex(STORE_MSGS, "convId", convId);
      return all.sort((a, b) => a.ts - b.ts);
    },
    saveMsg: (m) => tx(STORE_MSGS, "readwrite", s => s.put(m)),
    delMsg: (id) => tx(STORE_MSGS, "readwrite", s => s.delete(id)),
    allConfigs: async () => {
      const all = await tx(STORE_CONFIGS, "readonly", s => s.getAll());
      return all.sort((a, b) => a.ts - b.ts);
    },
    saveConfig: (c) => tx(STORE_CONFIGS, "readwrite", s => s.put(c)),
    delConfig: (id) => tx(STORE_CONFIGS, "readwrite", s => s.delete(id)),

    /* ADE-S18.8 (ch-25.f1) — scheduled tasks (v2 store) */
    allTasks: async () => {
      const all = await tx(STORE_TASKS, "readonly", s => s.getAll());
      return all.sort((a, b) => (a.nextRun || Infinity) - (b.nextRun || Infinity));
    },
    saveTask: (t) => tx(STORE_TASKS, "readwrite", s => s.put(t)),
    delTask: (id) => tx(STORE_TASKS, "readwrite", s => s.delete(id)),

    /* ADE-12.1 (ch-12.f1) — project-profile cache snapshots (v3 store).
       allCache() newest-first · saveCacheRow · delCacheRow · the CURRENT
       pointer lives in settings (SK.CACHE_CURRENT) so re-cache supersedes
       without renames (ai.saves.rule). Pruning keeps the last 3 rows. */
    allCache: async () => {
      const all = await tx(STORE_CACHE, "readonly", s => s.getAll());
      return all.sort((a, b) => (b.ts || 0) - (a.ts || 0));
    },
    saveCacheRow: (row) => tx(STORE_CACHE, "readwrite", s => s.put(row)),
    delCacheRow: (id) => tx(STORE_CACHE, "readwrite", s => s.delete(id)),

    /* boot — open + request durable storage (ADE-01.2)
       HF-02: migrate() runs from Main.init BEFORE state loads */
    async init() {
      await open();
      try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch { /* best effort */ }
    },

    migrate,
    SETTINGS_SCHEMA_VERSION
  };
})();

/* ── global State — in-memory mirror, persisted via DB ───── */
const State = {
  convs: [],            // [{ id, title, ts, lastTs }]
  msgs: [],             // active conversation's messages
  configs: [],          // [{ ...config }]
  activeConfigId: null,
  activeConvId: null,
  streaming: false,     // a stream is in flight
  pendingAtts: [],      // composer attachments [{ name, type, size, text?|blob? }]
  sessionRequests: 0,   // AI request count this session
  sessionTokens: 0,     // hf.11 — Σ EXACT API-reported tokens this browser-tab lifetime (all chats; secondary figure in the hdr-clock tooltip since hf.13 — the clock itself reads the active chat's own usage rows; incremented in ChatUI.finalize)
  corsKey: "",          // shared CorsProxy.io key (settings store)
  agentMaxSteps: null,  // CH-06 global budget defaults (settings store, loaded at boot)
  agentContextK: null
};

/* settings keys used across modules (additive-only) */
const SK = {
  ACTIVE_CONFIG: "active_config_id",
  ACTIVE_CONV: "active_conv_id",
  CORS_KEY: "corsproxy_api_key",
  /* CH-06 (ADE-06.2/06.3) — agent budgets + workspace seed flag */
  AGENT_MAX_STEPS: "agent_max_steps",      // global default for NEW configs
  AGENT_CONTEXT_K: "agent_context_k",      // global default for NEW configs
  WORKSPACE_SEEDED: "workspace_seeded",    // auto-seed runs once (re-seed = console `seed`)
  CACHE_CURRENT: "cache_current_id"        // ADE-12.1 (ch-12.f1) — id of the current profile snapshot
};

/* default config factory — f3: model presets + agent fields
   CH-06 (ADE-06.3): agent budgets default from the settings-store
   globals edited in Settings → Agent & Workspace (State.agent* loaded
   at boot by main.js); a config's own values always win at run time */
function makeDefaultConfig() {
  return {
    id: U.uid(),
    name: "GLM 5.3 Flash Free",
    model: "coding-glm-5.3-flash-free",   // m-03: main model, free text
    baseUrl: "https://aihubmix.com/v1",
    apiKey: "",
    proxyUrl: "https://corsproxy.io/?key={corskey}&url={url}",
    temperature: 0.6,
    maxTokens: 8192,
    maxSteps: Math.min(100, Math.max(1, Number(State.agentMaxSteps) || 24)),  // agent step cap (used from CH-05)
    contextK: Math.min(200, Math.max(4, Number(State.agentContextK) || 24)),  // context budget k-tokens (used from CH-05)
    noTrim: false,       // ADE-HF.4 — context-shortening OFF toggle (per config; false = trim/evict as before)
    forceProto: false,   // force <<<TOOL>>> text protocol (CH-05)
    costPerM: 0,         // ADE-S20.2 (ch-26.f2, m-46) — $ per 1M tokens (drives the burn strip's $ total; 0 = not tracked)
    cacheMode: false,    // ADE-12.2 (ch-12.f2) — send-once profile cache mode (per config)
    extraBody: "",       // ADE-12.7 (ch-12.f7, m-41) — verbatim JSON merged into every request body
    ts: Date.now()
  };
}
/* model preset chips shown in the config editor (f3) */
const MODEL_PRESETS = [
  "coding-glm-5.3-flash-free",
  "glm-5.3-flash",
  "glm-4.6",
  "glm-4.5-air"
];

/* ============================================================
   js/ui-workspace.js — ADE-02.2 · FILE TREE UI
                       ADE-02.3 · FILE CRUD + EDITOR
                       ADE-02.5 · UPLOAD INTEGRATION
                       ADE-03.3 · PULL/PUSH HEADER ACTIONS
                       ADE-03.4 · BACKEND BADGE (LINK STATES)
                       ADE-03.5 · WORK-FOLDER STRUCTURE TOOLTIP
   Replaces the CH-01 stub. The right panel is now a real
   workspace over the IndexedDB VFS: recursive expand/collapse
   tree, breadcrumb cwd, per-row hover actions (edit · rename ·
   download · delete · run/preview), a mono text editor modal,
   zip import/export (vendored fflate) and drag-drop + file
   picker uploads that land IN the workspace at the cwd.
   CH-03 WIRES THE REAL FSA ACTIONS: the backend badge becomes
   the link/reconnect button (INDEXEDDB · LINK WORK FOLDER ·
   LINK… · LINKED ✓ · RECONNECT NEEDED), Pull ← folder /
   Push → folder appear while linked, and the badge tooltip
   documents the m-24 work-folder structure.
   CH-04 plugs real executors into the run/preview actions.
   ============================================================ */
"use strict";

/* header toggle lives here so main.js wiring never changes */
const WorkspaceUI = {
  toggle(force) {
    const panel = document.getElementById("ws-panel");
    const open = force !== undefined ? force : !panel.classList.contains("open");
    panel.classList.toggle("open", open);
    try { DB.setSetting("ws_panel_open", open); } catch { /* best effort */ }
    if (open) WSUI.refresh();
  }
};

const WSUI = {
  el: null,
  cwd: "/",                    // current working dir (breadcrumb + uploads + new files)
  expanded: new Set(["/"]),    // expanded dir paths
  _dragDepth: 0,

  /* ══ init — build the static chrome, wire events ══════════ */
  async init() {
    this.el = document.getElementById("ws-body");

    // restore persisted session state
    try {
      this.cwd = VFS.norm((await DB.getSetting("ws_cwd")) || "/");
      const exp = await DB.getSetting("ws_expanded");
      this.expanded = new Set(Array.isArray(exp) && exp.length ? exp : ["/"]);
      this.expanded.add("/");
    } catch { this.expanded = new Set(["/"]); }

    this.buildHeaderActions();
    this.buildBody();
    this.wireUploads();
    this.bindSubWindows(); // ADE-S13.9 (ch-19.f2) — the two windows under the tree

    // external VFS writes (chat attachments → /imports, later agent edits)
    // ADE-03.3: suppressed while FSA pull/push bulk-imports (one refresh at end)
    VFS.onWrite(() => { if (!(VFS.FSA && VFS.FSA._bulk)) this.refresh(); });
    // ADE-03.4: badge + pull/push buttons re-render on every link-state flip
    VFS.FSA.onState(() => { this.renderHeaderActions(); this.renderBackend(); });
    await this.refresh();

    document.getElementById("toggle-ws")?.addEventListener("click", () => WorkspaceUI.toggle());
    document.getElementById("ws-close")?.addEventListener("click", () => WorkspaceUI.toggle(false));
  },

  /* header action buttons — import/export (ADE-02.4) · pull/push (ADE-03.3,
     rendered only while a work folder is linked) */
  buildHeaderActions() { this.renderHeaderActions(); },
  renderHeaderActions() {
    const box = document.getElementById("ws-header-actions");
    if (!box) return;
    const btn = (act, icon, title, extra = "") =>
      `<button class="icon-btn ws-act${extra}" data-wsact="${act}" title="${title}"><i class="fa-solid ${icon}"></i></button>`;
    const linked = VFS.FSA.state === "linked";
    box.innerHTML =
      btn("new-file", "fa-file-circle-plus", "New file (in current folder)") +
      btn("new-folder", "fa-folder-plus", "New folder (in current folder)") +
      btn("upload", "fa-file-arrow-up", "Upload files into current folder") +
      btn("import-zip", "fa-file-zipper", "Import a .zip here") +
      btn("export-zip", "fa-download", "Export whole workspace as ade-workspace.zip") +
      btn("cache-profile", "fa-layer-group", "Cache project profile (ch-12) — snapshot the whole workspace once; patch tasks then send the profile prefix + deltas only") + // ADE-12.1 (ch-12.f1, m-29)
      btn("cache-zip", "fa-box-archive", "Ship cached project zip (ch-12.f4) — downloads snapshot + applied patches as a fresh zip and RE-CACHES, so the next patch task starts clean") + // ADE-12.4
      btn("console", "fa-terminal", "Toggle run console (virtual shell — ADE-04.4)") +
      (linked
        ? btn("pull-folder", "fa-folder-arrow-down", "Pull ← work folder (folder overwrites the VFS)")
        + btn("push-folder", "fa-folder-arrow-up", "Push → work folder (workspace overwrites the disk)")
        : "") +
      btn("refresh", "fa-rotate-right", "Refresh tree");
    box.addEventListener("click", e => {
      const b = e.target.closest("[data-wsact]");
      if (b) this.headerAction(b.dataset.wsact);
    });
  },

  buildBody() {
    this.el.innerHTML = `
      <div class="ws-crumbs" id="ws-crumbs"></div>
      <div class="ws-tree" id="ws-tree" role="tree"></div>
      <div class="ws-status" id="ws-status"></div>
      <input type="file" id="ws-file-input" multiple style="display:none" />`;
    this.el.addEventListener("click", e => this.onTreeClick(e));
    this.el.addEventListener("dblclick", e => {
      const row = e.target.closest(".ws-row[data-kind='dir']");
      if (row) this.setCwd(row.dataset.path);
    });
    // ADE-03.4 — badge + unlink × are click-routed per link state
    this.el.addEventListener("click", e => {
      if (e.target.closest("#ws-unlink")) { e.preventDefault(); return this.unlinkAsk(); }
      if (e.target.closest("#ws-backend-badge")) { e.preventDefault(); return this.badgeClick(); }
      if (e.target.closest("#ws-cache-chip")) { e.preventDefault(); return this.cacheProfile(); } // ADE-12.5 — chip click = one-click re-cache
    });
  },

  /* ══ header actions (ADE-02.4 / 02.5 / 03.3 / 04.4) ═══ */
  headerAction(act) {
    switch (act) {
      case "new-file": return this.newNode("file");
      case "new-folder": return this.newNode("dir");
      case "upload": return document.getElementById("ws-file-input").click();
      case "import-zip": return this.pickZip();
      case "export-zip": return this.exportZip();
      case "cache-profile": return this.cacheProfile(); // ADE-12.1 (ch-12.f1)
      case "cache-zip": return this.shipCachedZip();    // ADE-12.4 (ch-12.f4)
      case "pull-folder": return this.pullFolder();
      case "push-folder": return this.pushFolder();
      case "console": return Exec.ConsoleUI.toggle();
      case "refresh": return this.refresh(true);
    }
  },

  /* ══ ADE-12.1/12.4/12.5 (ch-12, m-29) · CACHE ACTIONS + CHIP ══
     cacheProfile = one-click snapshot (badge click too) · shipCachedZip =
     f4 ship-back + re-cache · refreshCacheChip = cheap chip re-render the
     engine calls after every status flip (boot, drift hook, diff).       */
  async cacheProfile() {
    try {
      const snap = await Agent.Cache.snapshot();
      U.toast("Project profile cached", { kind: "ok", msg: `${snap.id} · ${snap.fileCount} files · ~${U.fmtTokens(snap.estTokens)} tok — patch tasks in cache mode now send the profile once + deltas only (enable per config in Settings)`, ms: 5600 });
      this.refreshCacheChip();
    } catch (e) { U.toast("Cache failed", { kind: "err", msg: String((e && e.message) || e) }); }
  },
  async shipCachedZip() {
    try { await Agent.Cache.shipZip(); this.refreshCacheChip(); }
    catch (e) { U.toast("Ship-back failed", { kind: "err", msg: String((e && e.message) || e) }); }
  },
  async refreshCacheChip() {
    const slot = document.getElementById("ws-cache-chip-slot");
    if (!slot) return;
    try { slot.innerHTML = await Agent.Cache.chip(); } catch { /* chip is cosmetic */ }
  },

  /* ══ breadcrumb cwd bar (ADE-02.2) ════════════════════════ */
  renderCrumbs() {
    const box = document.getElementById("ws-crumbs");
    if (!box) return;
    const segs = this.cwd.split("/").filter(Boolean);
    let acc = "";
    const crumbs = [`<button class="crumb ${this.cwd === "/" ? "here" : ""}" data-goto="/"><i class="fa-solid fa-root"></i> ws</button>`];
    for (const s of segs) {
      acc += "/" + s;
      const p = acc;
      crumbs.push(`<i class="fa-solid fa-chevron-right crumb-sep"></i>`);
      crumbs.push(`<button class="crumb ${p === this.cwd ? "here" : ""}" data-goto="${U.escapeHtml(p)}">${U.escapeHtml(s)}</button>`);
    }
    box.innerHTML = crumbs.join("");
    box.querySelectorAll("[data-goto]").forEach(b =>
      b.addEventListener("click", () => this.setCwd(b.dataset.goto)));
  },

  async setCwd(path) {
    this.cwd = VFS.norm(path);
    try { await DB.setSetting("ws_cwd", this.cwd); } catch { /* best effort */ }
    // make sure the cwd is visible in the tree
    let p = this.cwd;
    while (p !== "/") { this.expanded.add(p); p = VFS.parent(p); }
    await DB.setSetting("ws_expanded", [...this.expanded]);
    this.refresh();
  },

  /* ══ tree render (ADE-02.2) ═══════════════════════════════ */
  async refresh(force) {
    if (!this.el) return;
    const tree = await VFS.tree("/");
    const { files, dirs, bytes } = await VFS.count();

    const treeEl = document.getElementById("ws-tree");
    if (!treeEl) return;
    if (!tree.length) {
      treeEl.innerHTML = `<div class="ws-empty ws-empty-sm">
        <i class="fa-solid fa-folder-open"></i>
        <div>Workspace is empty</div>
        <span class="ws-chip">drop files here · new file · import a zip</span>
      </div>`;
    } else {
      // render only rows whose ancestor chain is expanded
      const rows = tree.filter(r => {
        let p = VFS.parent(r.path);
        while (p !== "/") { if (!this.expanded.has(p)) return false; p = VFS.parent(p); }
        return true;
      });
      treeEl.innerHTML = rows.map(r => this.rowHtml(r)).join("");
    }

    this.renderCrumbs();
    this.renderBackend(files, dirs, bytes);
    if (force) U.toast("Workspace refreshed", { kind: "info", ms: 1200 });
  },

  /* ══ ADE-03.4 · backend badge — INDEXEDDB · LINK WORK FOLDER ·
     LINK… · LINKED ✓ · RECONNECT NEEDED (click-routed per state)
     ADE-03.5 · the tooltip documents the m-24 work-folder layout ══ */
  renderBackend(files, dirs, bytes) {
    const st = document.getElementById("ws-status");
    if (!st) return;
    // state-flip callers omit counts → keep the existing counts span
    const counts = files === undefined
      ? st.querySelector("[data-counts]")?.outerHTML || ""
      : `<span data-counts><i class="fa-solid fa-cube"></i> ${files} file${files === 1 ? "" : "s"} · ${dirs} dir${dirs === 1 ? "" : "s"} · ${U.fmtBytes(bytes)}</span>`;
    st.innerHTML = counts + `<span id="ws-cache-chip-slot"></span>` + this.badgeHtml();
    this.refreshCacheChip(); // ADE-12.5 (ch-12.f5) — chip rides every status render (async fill, never blocks)
  },

  badgeHtml() {
    const F = VFS.FSA;
    const stName = F.handle ? U.escapeHtml(F.handle.name) : "";
    /* ADE-03.5 — work-folder structure (m-24 · routing §07 build.fsa.structure) */
    const struct = "Work folder = live disk mirror of this workspace\n"
      + "root: routing · manifest · planner .flat.txt + readme.txt (+ configs.flat.txt from ch-09)\n"
      + "imports/ (attachment + zip drops) · demo/ (seed files, ch-06) · your project files alongside\n"
      + "write-through mirrors every edit while autoSync is ON\n"
      + "Pull ← folder overwrites the VFS · Push → folder overwrites the disk (refined ch-11.f1)";
    switch (F.state) {
      case "linked":
        return `<span class="ws-backend" id="ws-backend-badge" data-state="linked" title="${U.escapeHtml(struct)}" style="color:var(--ok,#5fb26a);border-color:var(--ok,#5fb26a);cursor:pointer">LINKED ✓ ${stName}</span>`
          + `<span class="ws-backend" id="ws-unlink" title="Unlink work folder (the VFS keeps everything)" style="cursor:pointer">×</span>`;
      case "reconnect":
        return `<span class="ws-backend" id="ws-backend-badge" data-state="reconnect" title="Work folder &quot;${stName}&quot; needs one fresh permission click — reconnect now (your click is the gesture)" style="color:var(--warn,#d4a23a);border-color:var(--warn,#d4a23a);cursor:pointer">RECONNECT NEEDED</span>`;
      case "linking":
        return `<span class="ws-backend" id="ws-backend-badge" data-state="linking" title="Linking work folder…"><i class="fa-solid fa-circle-notch fa-spin"></i> LINK…</span>`;
      case "unsupported":
        return `<span class="ws-backend" data-state="unsupported" title="File System Access needs a Chromium browser (Chrome/Edge/Brave) on https or localhost — zip import/export remains the work-folder fallback here">INDEXEDDB</span>`;
      default: /* none + supported → the badge IS the "Link work folder" button (f1) */
        return `<span class="ws-backend" id="ws-backend-badge" data-state="none" title="Link a real disk work folder — read/write, session-persistent, write-through on every edit. The folder becomes the live mirror of this workspace (structure shown in the tooltip once linked)." style="color:var(--primary,#d4893a);border-color:var(--primary,#d4893a);cursor:pointer">LINK WORK FOLDER</span>`;
    }
  },

  async badgeClick() {
    const F = VFS.FSA;
    switch (F.state) {
      case "none": return F.link();
      case "reconnect": return F.reconnect();
      case "linked": {
        const c = await VFS.count();
        return U.toast("Work folder", { kind: "info", ms: 4200,
          msg: `${F.handle?.name || "?"} · write-through ${F.autoSync ? "ON" : "OFF"} · VFS: ${c.files} file${c.files === 1 ? "" : "s"} · ${U.fmtBytes(c.bytes)}` });
      }
    }
  },

  unlinkAsk() {
    const F = VFS.FSA;
    if (F.state !== "linked") return;
    if (confirm(`Unlink work folder "${F.handle?.name || ""}"?\n\nThe VFS keeps every file — only the live disk mirror stops.`)) F.unlink();
  },

  /* ══ ADE-03.3 · pull / push header actions (confirms state the rule) ══ */
  async pullFolder() {
    const F = VFS.FSA;
    if (F.state !== "linked") return U.toast("No work folder linked", { kind: "info", msg: "Click the LINK WORK FOLDER badge first." });
    if (!confirm("Pull ← work folder?\n\nThe folder OVERWRITES matching VFS files (pull rule — refined ch-11.f1).\nFolder: " + (F.handle?.name || ""))) return;
    const r = await F.pull();
    await this.refresh();
    U.toast("Pull complete", { kind: "ok", msg: `${r.count} file${r.count === 1 ? "" : "s"} imported${r.skipped ? ` · ${r.skipped} skipped` : ""}` });
  },

  async pushFolder() {
    const F = VFS.FSA;
    if (F.state !== "linked") return U.toast("No work folder linked", { kind: "info", msg: "Click the LINK WORK FOLDER badge first." });
    if (!confirm("Push → work folder?\n\nThe workspace OVERWRITES matching files on disk (push rule — refined ch-11.f1).\nFolder: " + (F.handle?.name || ""))) return;
    const r = await F.push();
    U.toast("Push complete", { kind: "ok", msg: `${r.written} file${r.written === 1 ? "" : "s"} written${r.failed ? ` · ${r.failed} failed` : ""}` });
  },

  rowHtml(r) {
    const name = U.escapeHtml(VFS.base(r.path));
    const isDir = r.kind === "dir";
    const open = this.expanded.has(r.path);
    const here = r.path === this.cwd;
    const chev = isDir
      ? `<i class="fa-solid fa-chevron-right ws-chev ${open ? "open" : ""}" data-act="expand"></i>`
      : `<span class="ws-chev spacer"></span>`;
    const icon = isDir ? (open ? "fa-solid fa-folder-open" : "fa-solid fa-folder") : U.fileIcon(r.path);
    const size = isDir ? "" : `<span class="ws-size">${U.fmtBytes(r.size)}</span>`;
    const acts = this.rowActions(r);
    return `<div class="ws-row ${isDir ? "dir" : "file"} ${here ? "here" : ""}" data-path="${U.escapeHtml(r.path)}" data-kind="${r.kind}" style="--depth:${r.depth || 0}">
      ${chev}<i class="${icon} ws-ficon"></i><span class="ws-name" title="${U.escapeHtml(r.path)}">${name}</span>${size}
      <span class="ws-row-actions">${acts}</span>
    </div>`;
  },

  /* per-row hover actions (ADE-02.3) — run/preview appears for
     py/js/html and upgrades itself when CH-04 executors land   */
  rowActions(r) {
    const a = (act, icon, title, cls = "") =>
      `<button class="ws-ract ${cls}" data-act="${act}" title="${title}"><i class="fa-solid ${icon}"></i></button>`;
    const acts = [];
    if (r.kind === "dir") {
      acts.push(a("open", "fa-folder-open", "Open (set as current folder)"));
    } else {
      if (r.isText || VFS.isTextName(r.path)) acts.push(a("edit", "fa-pen-to-square", "Edit"));
      if (/\.(py|js|mjs|html?|css)$/i.test(r.path)) acts.push(a("run", "fa-play", "Run / preview (CH-04 executors)"));
      acts.push(a("download", "fa-download", "Download"));
    }
    acts.push(a("rename", "fa-i-cursor", "Rename"));
    acts.push(a("delete", "fa-trash", "Delete" + (r.kind === "dir" ? " (recursive)" : ""), "danger"));
    return acts.join("");
  },

  /* ══ tree interactions (delegated) ════════════════════════ */
  async onTreeClick(e) {
    const actBtn = e.target.closest("[data-act]");
    const row = e.target.closest(".ws-row");
    if (!row) return;
    const path = row.dataset.path;
    const kind = row.dataset.kind;
    if (actBtn) {
      e.stopPropagation();
      return this.rowAction(actBtn.dataset.act, path, kind);
    }
    if (kind === "dir") {
      // plain click on a dir toggles expand (matches the chevron)
      await this.toggleExpand(path);
    } else {
      const r = await VFS.get(path);
      if (r && (r.isText || VFS.isTextName(path))) this.openEditor(path);
      else if (r) U.toast("Binary file", { kind: "info", msg: "Use the download action — the viewer lands with CH-04 preview." });
    }
  },

  async rowAction(act, path, kind) {
    switch (act) {
      case "expand": return this.toggleExpand(path);
      case "open": return this.setCwd(path);
      case "edit": return this.openEditor(path);
      case "run": {
        // ADE-04 — real executors live: .py → Pyodide · .js → worker ·
        // .html → sandboxed preview (the CH-02 affordance upgrades itself)
        if (window.Exec && typeof Exec.run === "function") return Exec.run(path);
        return U.toast("Executors land at CH-04", { kind: "info", msg: "Pyodide python · JS worker · sandboxed HTML preview — next exec chunk." });
      }
      case "download": return this.download(path);
      case "rename": return this.renameNode(path);
      case "delete": return this.deleteNode(path, kind);
    }
  },

  async toggleExpand(path) {
    if (this.expanded.has(path)) this.expanded.delete(path);
    else this.expanded.add(path);
    try { await DB.setSetting("ws_expanded", [...this.expanded]); } catch { /* best effort */ }
    this.refresh();
  },

  /* ══ CRUD (ADE-02.3) ══════════════════════════════════════ */
  async newNode(kind) {
    const name = await this.promptModal(
      kind === "dir" ? "New folder" : "New file",
      kind === "dir" ? "folder-name" : "file.txt",
      `created in ${this.cwd}`);
    if (name == null) return;
    const clean = this.cleanName(name);
    if (!clean) return U.toast("Invalid name", { kind: "err", msg: "Name cannot be empty, or contain / \\ .." });
    const path = VFS.join(this.cwd, clean);
    if (await VFS.exists(path)) return U.toast("Already exists", { kind: "err", msg: path });
    if (kind === "dir") { await VFS.mkdirp(path); this.expanded.add(VFS.parent(path)); }
    else {
      await VFS.put(path, "");
      this.openEditor(path); // straight into the editor, like a real IDE
    }
    try { await DB.setSetting("ws_expanded", [...this.expanded]); } catch { /* best effort */ }
    await this.refresh();
    U.toast(kind === "dir" ? "Folder created" : "File created", { kind: "ok", msg: path });
  },

  async renameNode(path) {
    const old = VFS.base(path);
    const name = await this.promptModal("Rename", old, VFS.parent(path));
    if (name == null || name === old) return;
    const clean = this.cleanName(name);
    if (!clean) return U.toast("Invalid name", { kind: "err", msg: "Name cannot be empty, or contain / \\ .." });
    try {
      const dest = await VFS.mv(path, VFS.join(VFS.parent(path), clean));
      // keep the tree consistent if the renamed dir was open / was the cwd
      if (this.expanded.has(path)) { this.expanded.delete(path); this.expanded.add(dest); }
      if (this.cwd === path || this.cwd.startsWith(path + "/")) await this.setCwd(dest + this.cwd.slice(path.length));
      else await this.refresh();
      U.toast("Renamed", { kind: "ok", msg: dest });
    } catch (e) { U.toast("Rename failed", { kind: "err", msg: e?.message || String(e) }); }
  },

  async deleteNode(path, kind) {
    const label = kind === "dir" ? "folder and EVERYTHING inside it" : "file";
    if (!confirm(`Delete this ${label}?\n\n${path}\n\nThis cannot be undone.`)) return;
    try {
      await VFS.rm(path);
      this.expanded.delete(path);
      if (this.cwd === path || this.cwd.startsWith(path + "/")) await this.setCwd(VFS.parent(path));
      else await this.refresh();
      U.toast("Deleted", { kind: "ok", msg: path });
    } catch (e) { U.toast("Delete failed", { kind: "err", msg: e?.message || String(e) }); }
  },

  async download(path) {
    const r = await VFS.get(path);
    if (!r || r.kind !== "file") return;
    if (typeof r.content === "string") U.downloadText(r.content, VFS.base(path));
    else U.downloadBlob(new Blob([r.content], { type: "application/octet-stream" }), VFS.base(path));
  },

  cleanName(n) {
    n = String(n || "").trim();
    if (!n || /[\/\\]/.test(n) || n === "." || n === ".." || n.includes("..")) return "";
    return n;
  },

  /* ══ ADE-S13.9 (ch-19.f2, m-34) — THE TWO WINDOWS UNDER THE TREE ══
     NOW EDITING — file name + exact line, fed by:
       · the agent: Agent.execTool publishes on fs_write ("rewrite · N
         lines", line 1) and fs_append (the appended block's START line)
       · the user: openEditor() tracks the textarea cursor live
     CONSOLE HISTORY — every executed shell line (user console AND the
     agent's silent `shell` tool calls) via the Shell.log journal
     (ADE-S13.8 in exec.js); click a row to copy the command.         */
  editing(path, line, note, source) {
    const row = document.getElementById("ws-editing-row");
    const empty = document.getElementById("ws-editing-empty");
    if (!row || !empty) return; // window absent (old markup) — never break the caller
    empty.style.display = "none";
    row.style.display = "";
    document.getElementById("ws-editing-file").textContent = path;
    document.getElementById("ws-editing-line").textContent = line != null ? `line ${line}` : "—";
    document.getElementById("ws-editing-note").textContent = note || "";
    row.dataset.source = source || "user";
  },

  /* ══ hf.15 · FILE TOKEN BURN — the editing panel reflects the agent's
     prompt/reasoning spend per file (user call: "editing panel should reflect
     if agent is using prompt/reasoning tokens on a specific file/files").
     Fed by Agent._noteFileUse / _noteThink (js/agent.js) on every tool result:
       ↑ intake = prompt tokens the file shipped into context (read/grep/find)
       ✦ think  = reasoning tokens while the thought NAMED the file
       ↓ output = tokens written back (write/append/edit/chunk)
     Rows: 6 most-recent files · Σ in the head · hover a row for path+time. */
  fileBurn(map) {
    const wrap = document.getElementById("ws-burn");
    const body = document.getElementById("ws-burn-body");
    const sumEl = document.getElementById("ws-burn-sum");
    if (!wrap || !body) return; // old markup — never break the caller
    const rows = [...map.entries()].filter(([, e]) => e && (e.intake || e.output || e.think))
      .sort((a, b) => (b[1].lastTs || 0) - (a[1].lastTs || 0)).slice(0, 6);
    if (!rows.length) { wrap.style.display = "none"; return; }
    const sum = rows.reduce((a, [, e]) => a + (e.intake || 0) + (e.output || 0) + (e.think || 0), 0);
    wrap.style.display = "";
    if (sumEl) sumEl.textContent = `Σ ${U.fmtTokens(sum)} tok`;
    body.innerHTML = rows.map(([p, e]) => {
      const segs = [
        e.intake ? `<span class="ws-burn-in" title="prompt tokens this file shipped into context (read/grep/find)">↑${U.fmtTokens(e.intake)}</span>` : "",
        e.think ? `<span class="ws-burn-think" title="reasoning tokens while the agent's thought named this file (named-attribution)">✦${U.fmtTokens(e.think)}</span>` : "",
        e.output ? `<span class="ws-burn-out" title="tokens written back (write/append/edit/chunk)">↓${U.fmtTokens(e.output)}</span>` : ""
      ].join("");
      const last = e.lastTs ? new Date(e.lastTs).toLocaleTimeString([], { hour12: false }) : "";
      return `<div class="ws-burn-row" title="${U.escapeHtml(p)} · last: ${U.escapeHtml(e.lastTool || "?")} ${last} · ${e.calls} call${e.calls === 1 ? "" : "s"}"><span class="ws-burn-file">${U.escapeHtml(p.split("/").pop())}</span><span class="ws-burn-segs">${segs}</span><span class="ws-burn-act">${U.escapeHtml(e.lastTool || "")}</span></div>`;
    }).join("");
  },

  bindSubWindows() {
    // collapse toggles — state persists across sessions
    // ADE-S18.7 (ch-25): the third window (SCHEDULED TASKS) joins the pair
    const heads = [["ws-editing-head", "ws_sub_editing_open", "ws-sub-editing"],
                   ["ws-consolelog-head", "ws_sub_console_open", "ws-sub-consolelog"],
                   ["ws-schedule-head", "ws_sub_schedule_open", "ws-sub-schedule"]];
    for (const [headId, key, subId] of heads) {
      const head = document.getElementById(headId);
      if (!head) continue;
      head.addEventListener("click", () => {
        const sub = document.getElementById(subId);
        const collapsed = !sub.classList.contains("collapsed");
        sub.classList.toggle("collapsed", collapsed);
        try { DB.setSetting(key, !collapsed); } catch { /* best effort */ }
      });
      try {
        DB.getSetting(key).then(v => { if (v === false) document.getElementById(subId)?.classList.add("collapsed"); }).catch(() => {});
      } catch { /* best effort */ }
    }
    // CONSOLE HISTORY — subscribe to the journal (exec.js ADE-S13.8);
    // onLog replays the current ring first (ev = "init")
    try { Exec.Shell.onLog((entry, ev) => this.renderConsoleLog(entry, ev)); } catch { /* exec missing — skip */ }
  },

  renderConsoleLog(entry, ev) {
    const body = document.getElementById("ws-consolelog-body");
    if (!body) return;
    const count = document.getElementById("ws-consolelog-count");
    if (count && Exec?.Shell?.log) count.textContent = String(Exec.Shell.log.length);
    if (ev === "init") {
      const items = Array.isArray(entry) ? entry : [];
      body.innerHTML = "";
      if (!items.length) { body.innerHTML = `<div class="ws-chist-empty">no commands yet — run one in the console</div>`; return; }
      for (const it of items) this._appendConsoleLogRow(body, it);
      body.scrollTop = body.scrollHeight;
      return;
    }
    if (!entry) return;
    body.querySelector(".ws-chist-empty")?.remove();
    this._appendConsoleLogRow(body, entry);
    while (body.children.length > 200) body.firstChild.remove();
    body.scrollTop = body.scrollHeight;
  },

  _appendConsoleLogRow(body, entry) {
    const d = document.createElement("div");
    d.className = "ws-chist-row" + (entry.code ? " fail" : "");
    d.dataset.source = entry.source || "user";
    d.title = `${new Date(entry.ts).toLocaleTimeString()} · exit ${entry.code} · ${entry.ms}ms · click to copy`;
    const t = new Date(entry.ts).toLocaleTimeString([], { hour12: false });
    d.innerHTML = `<span class="ws-chist-dot"></span><span class="ws-chist-time">${t}</span><span class="ws-chist-cmd">${U.escapeHtml(entry.cmd)}</span>`;
    d.addEventListener("click", () => {
      try { navigator.clipboard.writeText(entry.cmd); U.toast("Copied", { kind: "info", msg: entry.cmd, ms: 1400 }); } catch { /* clipboard optional */ }
    });
    body.appendChild(d);
  },

  /* ══ editor modal (ADE-02.3) ══════════════════════════════ */
  openEditor(path) {
    this.closeEditor();
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop open";
    backdrop.id = "ws-editor-modal";
    backdrop.innerHTML = `
      <div class="modal ws-editor">
        <div class="modal-header">
          <h2><i class="fa-solid fa-file-lines"></i>
            <span class="ws-ed-path">${U.escapeHtml(path)}</span>
            <span class="sub" id="ws-ed-size"></span>
          </h2>
          <button class="icon-btn" id="ws-ed-close" title="Close (Esc)"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="ws-ed-body">
          <textarea class="ws-ed-ta" id="ws-ed-ta" spellcheck="false"></textarea>
        </div>
        <div class="ws-ed-footer">
          <span class="ws-ed-hint"><kbd>Ctrl</kbd>+<kbd>S</kbd> save · <kbd>Esc</kbd> close · saved → VFS + write-through</span>
          <button class="btn" id="ws-ed-cancel">Cancel</button>
          <button class="btn primary" id="ws-ed-save"><i class="fa-solid fa-floppy-disk"></i> Save</button>
        </div>
      </div>`;
    document.body.appendChild(backdrop);

    const ta = backdrop.querySelector("#ws-ed-ta");
    const sizeEl = backdrop.querySelector("#ws-ed-size");
    const setSize = () => {
      sizeEl.textContent = `${U.fmtBytes(new Blob([ta.value]).size)} · ${ta.value.split("\n").length} lines`;
    };
    // ADE-S13.9 (ch-19.f2): the NOW EDITING window tracks the user's cursor line live
    const cursorToLine = () => {
      const upto = ta.value.slice(0, ta.selectionStart ?? 0);
      this.editing(path, upto.split("\n").length, "cursor", "user");
    };
    ta.addEventListener("keyup", cursorToLine);
    ta.addEventListener("click", cursorToLine);
    ta.addEventListener("input", cursorToLine);

    VFS.readText(path).then(txt => {
      ta.value = txt == null ? "" : txt;
      setSize();
      ta.focus();
    });
    ta.addEventListener("input", setSize);
    ta.addEventListener("keydown", e => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") { e.preventDefault(); save(); }
    });

    const save = async () => {
      await VFS.put(path, ta.value, true);
      setSize();
      this.editing(path, ta.value.slice(0, ta.selectionStart ?? 0).split("\n").length, `saved · ${ta.value.split("\n").length} lines`, "user"); // ADE-S13.9
      this.refresh();
      U.toast("Saved", { kind: "ok", msg: path + " → VFS" + (VFS.FSA.state === "linked" ? " + work folder (write-through)" : "") });
    };
    backdrop.querySelector("#ws-ed-save").addEventListener("click", save);
    const close = () => this.closeEditor();
    backdrop.querySelector("#ws-ed-cancel").addEventListener("click", close);
    backdrop.querySelector("#ws-ed-close").addEventListener("click", close);
    backdrop.addEventListener("mousedown", e => { if (e.target === backdrop) close(); });
    this._escHandler = e => { if (e.key === "Escape") close(); };
    document.addEventListener("keydown", this._escHandler);
  },

  closeEditor() {
    document.getElementById("ws-editor-modal")?.remove();
    if (this._escHandler) { document.removeEventListener("keydown", this._escHandler); this._escHandler = null; }
  },

  /* ══ name prompt modal (new / rename) ═════════════════════ */
  promptModal(title, value, sub) {
    return new Promise(resolve => {
      const backdrop = document.createElement("div");
      backdrop.className = "modal-backdrop open";
      backdrop.innerHTML = `
        <div class="modal ws-prompt">
          <div class="modal-header">
            <h2><i class="fa-solid fa-pen"></i> ${U.escapeHtml(title)} <span class="sub">${U.escapeHtml(sub || "")}</span></h2>
          </div>
          <div class="ws-prompt-body">
            <input type="text" class="ws-prompt-input" value="${U.escapeHtml(value || "")}" spellcheck="false" />
          </div>
          <div class="ws-ed-footer">
            <button class="btn" data-r="0">Cancel</button>
            <button class="btn primary" data-r="1"><i class="fa-solid fa-check"></i> OK</button>
          </div>
        </div>`;
      document.body.appendChild(backdrop);
      const input = backdrop.querySelector("input");
      input.focus();
      input.select();
      const done = v => { backdrop.remove(); document.removeEventListener("keydown", onKey); resolve(v); };
      const onKey = e => {
        if (e.key === "Escape") done(null);
        if (e.key === "Enter") done(input.value);
      };
      document.addEventListener("keydown", onKey);
      backdrop.addEventListener("mousedown", e => { if (e.target === backdrop) done(null); });
      backdrop.querySelectorAll("[data-r]").forEach(b =>
        b.addEventListener("click", () => done(b.dataset.r === "1" ? input.value : null)));
    });
  },

  /* ══ uploads — drag-drop + file picker (ADE-02.5) ═════════ */
  wireUploads() {
    const panel = document.getElementById("ws-panel");

    // drag-drop onto the workspace panel → lands IN the workspace (cwd)
    panel.addEventListener("dragenter", e => { e.preventDefault(); this._dragDepth++; panel.classList.add("ws-dragging"); });
    panel.addEventListener("dragover", e => e.preventDefault());
    panel.addEventListener("dragleave", () => { if (--this._dragDepth <= 0) { this._dragDepth = 0; panel.classList.remove("ws-dragging"); } });
    panel.addEventListener("drop", async e => {
      e.preventDefault();
      this._dragDepth = 0;
      panel.classList.remove("ws-dragging");
      if (e.dataTransfer?.files?.length) await this.ingestFiles([...e.dataTransfer.files]);
    });

    // file-picker import into cwd
    document.getElementById("ws-file-input").addEventListener("change", async e => {
      const files = [...e.target.files];
      e.target.value = "";
      if (files.length) await this.ingestFiles(files);
    });
  },

  pickZip() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".zip,application/zip";
    input.onchange = async () => { if (input.files?.[0]) await this.ingestFiles([input.files[0]]); };
    input.click();
  },

  /* route each file by type: zip → importZip · text → put · binary → put */
  async ingestFiles(files) {
    let ok = 0, fail = 0;
    for (const f of files) {
      try {
        if (f.size > VFS.MAX_FILE) {
          U.toast("File too large", { kind: "err", msg: `${f.name} — ${U.fmtBytes(f.size)} exceeds the ${U.fmtBytes(VFS.MAX_FILE)} upload cap.` });
          fail++; continue;
        }
        if (/\.zip$/i.test(f.name)) {
          const buf = await U.readArrayBuffer(f);
          const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
          const dest = VFS.join(this.cwd, `${ts}-${f.name.replace(/\.zip$/i, "")}`);
          const s = await VFS.importZip(buf, dest);
          U.toast("Zip imported", { kind: "ok", msg: `${f.name} → ${s.root} · ${s.imported} files${s.skipped ? ` (${s.skipped} skipped)` : ""}` });
          this.expanded.add(dest);
        } else if (U.isTextName(f.name, f.type) && f.size <= 2 * 1024 * 1024) {
          await VFS.put(VFS.join(this.cwd, f.name), await U.readTextFile(f), true);
          ok++;
        } else {
          await VFS.put(VFS.join(this.cwd, f.name), await U.readArrayBuffer(f), false);
          ok++;
        }
      } catch (e) {
        fail++;
        U.toast("Import failed", { kind: "err", msg: `${f.name} — ${e?.message || e}` });
      }
    }
    if (ok) U.toast("Upload complete", { kind: "ok", msg: `${ok} file${ok === 1 ? "" : "s"} → ${this.cwd}` });
    try { await DB.setSetting("ws_expanded", [...this.expanded]); } catch { /* best effort */ }
    await this.refresh();
  },

  /* ══ zip export (ADE-02.4) — whole workspace → ade-workspace.zip ══ */
  async exportZip() {
    try {
      const blob = await VFS.exportZip("/");
      U.downloadBlob(blob, "ade-workspace.zip");
      U.toast("Workspace exported", { kind: "ok", msg: `ade-workspace.zip · ${U.fmtBytes(blob.size)}` });
    } catch (e) {
      U.toast("Export failed", { kind: "err", msg: e?.message || String(e) });
    }
  }
};

/* ══ ADE-12.5 (ch-12.f5, m-29) · CACHE CHIP STYLES — INJECTED ══
   css/ade.css stays outside ch-12.files (same injected-block pattern as
   the CH-04 console styles + ADE-S18.9 session blocks). Chip mirrors
   .ws-backend (P-token sizing) with cache-specific state colors.     ══ */
(() => {
  if (document.getElementById("ade-cache-chip-styles")) return;
  const st = document.createElement("style");
  st.id = "ade-cache-chip-styles";
  st.textContent = `
  .ws-status .ws-cache-chip {
    border: 1px solid var(--border-comp);
    border-radius: 8px;
    padding: 1px 7px;
    color: var(--fg3);
    font-family: var(--font-mono);
    font-size: var(--fs-badge);
    letter-spacing: 0.04em;
    cursor: pointer;
    white-space: nowrap;
  }
  .ws-status .ws-cache-chip[data-state="cached"] { color: var(--ok, #5fb26a); border-color: var(--ok, #5fb26a); }
  .ws-status .ws-cache-chip[data-state="stale"] { color: var(--warn, #d4a23a); border-color: var(--warn, #d4a23a); }
  .ws-status .ws-cache-chip[data-state="none"] { color: var(--fg3); }
  /* ADE-12.3 — the "changes since snapshot" pill in the assistant meta */
  .msg .meta .cache-pill { color: var(--ok, #5fb26a); font-family: var(--font-mono); font-size: var(--fs-badge); }`;
  document.head.appendChild(st);
})();

================================================================================
 5.3 FLASH FREE ADE — README
 Agentic Developer Environment for GLM 5.3 Flash Free
 BUILD STAMP: ade-s30-hf16 · SESSION 30 (HF.16 — DEBUG LEDGER · HEAD/TAIL TOOLS
              · GREP 0-HIT PROBE · F3 RECONSTRUCTION · STALE-RESUME GUARD)
              · 2026-10-31
 CODE SHIPPED: YES — hf.16 = the round-8 "lost report" wave (user calls:
              "rework failures on grep" · "add dedicated multi-file chunked
              tools for head and tail reads" · "context cut is too aggressive
              there is data loss" · "at the end of every session (inside burn
              pane), i would like to have a button 'debug', that pulls every
              empty response, exact tool that was used just before it, exact
              query the tool ran, agents thoughts, all of this dated/timed and
              recorded automatically in ade.debug.flat.txt, with 'debug'
              button copying current session's debug results to clipboard"):
              (1) DEBUG LEDGER — /ade.debug.flat.txt auto-records, one dated
              flat line each, EVERY auto-continue death (kind EMPTY RESPONSE
              or STALL + attempt + death text) and EVERY tool ERROR, each
              with the EXACT tool that ran just before (name + args JSON
              ≤240 chars + ok/ERROR + ms + result head ≤100 chars) and the
              agent's nearest reasoning (≤160 chars). File capped 48 KB
              (header kept, oldest dropped — the ade.errors.log discipline);
              writes are best-effort and never break a run. The BURN strip's
              idle-reveal card gains a 🐛 debug button beside the copy
              button: one click copies the ACTIVE session's lines to the
              clipboard (with a count toast) — hand it to the next session
              or the next bug report verbatim.
              (2) HEAD/TAIL TOOLS (TOOLS 28→30) — the dedicated chunked
              first/last-N-lines reads as first-class one-word tools:
              {path, n?} with path = ONE file OR an ARRAY (per-file
              ===== path ===== sections, one shared output budget, a failed
              file ships "(FAILED)" and never blocks siblings), any file
              size. Thin frontends over _readOne, so the whole house
              rulebook is inherited: tail KEEPS THE END on over-cap slices,
              ≥30 KB files ship the slice plan, single lines cap at 800
              chars, skip notes stay honest. n default 40, cap 400. The
              system prompt teaches them (files line · ARG NAMES · rule 6:
              a ledger's newest entries are tail's home turf).
              (3) GREP 0-HIT PROBE — a zero-match grep no longer recites the
              generic literal-vs-regex hint: _grepZeroHint re-scans with ≤4
              cheaper matchers (leading-literal prefix · shorter prefix ·
              widened regex · whole literal — all ignore-case, ≤4 files) and
              ships the first hit WITH a sample line, digit-bearing lines
              preferred when the pattern references digits. The round-8
              field killer — grep "t1[01]\d" against serials written
              "t:100" — now answers itself ("prefix \"t\" hits N×, e.g.
              file:212: t:100 …") instead of burning a guessing turn.
              (4) F3 RECONSTRUCTION (the data-loss fix) — a dropped task
              turn's f3 ledger line is no longer just topic + tool names:
              it now carries per-tool arg digests (edit → path + find
              snippet; grep/find → path + /pattern/; shell → command head;
              ≤5 tools) AND the dropped turn's last assistant text (the
              lost report's head, 200 chars). The round-8 field case — the
              ledger said only "4 code edits", so the recovery run could not
              see WHICH files the edits touched and mis-attributed the
              deliverable to an older round's sound — cannot repeat.
              (5) STALE-RESUME GUARD (the false-DONE fix) — the RESUME STATE
              injection now counts step events after the newest task turn;
              on a continue that already advanced (esp. with a trailing tool
              ERROR) it reads "MAY BE STALE … continue the LIVE work from
              the transcript above … reply DONE only when THIS task's
              deliverable is verified in this transcript", and the auto/
              manual continue nudges carry the same verified-DONE wording
              (the old "if the work is complete, reply DONE" clause plus a
              stale state file was exactly the round-8 false-DONE). Tests:
              tests/test-hf16.mjs — 19/19 (real agent.js in vm sandboxes;
              hf.11 24/24 + hf.12 25/25 + hf.13 16/16 + hf.14 21/21 +
              hf.15 21/21 still green). PATCHLOG.flat.txt §03h.
 CODE SHIPPED: YES — hf.15 = the round-7 "messy transcript" wave (user call:
              "need to rework grep to support multi-file + chunking, still
              seeing multiple read calls being called, need read tool to have
              seamless chunking integration (one read call — multiple
              single-file/multi-file chunk scoped reads), now editing panel
              should reflect if agent is using prompt/reasoning tokens on a
              specific file/files"):
              (1) READ MULTI-SLICE — read {reads:[{path|paths, offset?,
              limit?, mode?}…]} performs SEVERAL chunk-scoped reads in ONE
              call: several offsets of one file, several files, or a mix
              (cap 12 specs; identical specs dedupe; every spec rides the
              same seamless _readOne pipeline — 16k gate · 30 KB slice plan ·
              past-EOF guard · 800-char line cap — under ===== path =====
              headers, one shared output budget; a failed spec ships
              "(FAILED)" and never blocks its siblings). The round-7 field
              pattern (THREE parallel read calls on the SAME ledger in one
              step — lines 21-28 · 107-119 · 1354 — plus two on the lab) is
              now one call.
              (2) GREP CHUNKED OUTPUT — offset:N pages a capped result
              forward (the tail names the next offset; the hard 400-row ship
              cap says "narrow" instead of promising a page that can never
              ship); context:1-5 ships deduped lines around each hit in the
              same call; group:'all' on a groupless regex ships the whole
              match (was a lying "no matches"); multi-file results carry a
              per-file counts tail so file-by-file re-grepping dies.
              (3) FILE TOKEN BURN — the NOW EDITING window gains a per-file
              token ledger (Agent.fileBurn → WSUI.fileBurn): ↑ intake =
              prompt tokens the file actually shipped into context (exact
              per ===== section for reads, per path:LINE row for grep/find),
              ↓ output = tokens written back (write/append/edit/chunk,
              measured from the payload, not the report), ✦ think =
              reasoning tokens while the step's thought NAMED the file
              (honest named-attribution — nothing named, nothing charged).
              Reads/greps feed the lead row too ("read · +2.1k tok").
              (4) THE PROMPT TEACHES IT — TOOLS intro · ARG NAMES (read
              reads:[…] · grep context?/offset?) · rule 6 "BATCH YOUR
              SLICES" + "grep ONCE across path:[f1,f2,…]".
              Tests: tests/test-hf15.mjs — 21/21 (real agent.js in a vm
              sandbox; hf.11 24/24 + hf.12 25/25 + hf.13 16/16 + hf.14 21/21
              still green). PATCHLOG.flat.txt §03g documents the wave.
 CODE SHIPPED: YES — hf.14 = the 30 KB LARGE-FILE line + chunking redesigned
              to work seamlessly around it (user call) + the round-7 field
              fixes:
              (1) THE LINE IS 30 KB — BIG_READ_CAP + LARGE_FILE = 30720; the
              same class line drives the read gate, the write/append gates,
              chunk, the split/assemble notes, the digest flag and every
              prompt teaching (rule 7 c/e/f · HUGE LEDGERS · BIG WRITES).
              (2) A WHOLE READ NEVER REFUSES — 16–30 KB ships the head slice
              + skip note; >30 KB ships the head slice + THE SLICE PLAN
              (exact next offset · ≈slice count · the grep jump · the edit
              path). hf.12's refusal shipped zero content and burned a turn;
              one call now always returns usable content and the way on.
              The "re-read with offset" note is derived from what ACTUALLY
              ships (the body is budgeted inside the cap envelope first —
              the old note could point past text the model never received).
              (3) MULTI-PATH COERCION — a JSON-encoded array STRING for
              path/files coerces to a real array (the round-7 field case:
              grep path:"[\"a.js\",\"b.js\"]" ran as ONE literal path →
              "searched 0 text file(s), 1 binary skipped"; now it searches
              both). find/grep report a missing root as "N path(s) NOT
              FOUND" — binary now means ONLY a real non-text file.
              (4) SEAMLESS CHUNKING HELPERS — digest flags ≥30 KB rows ⚑L
              with a legend (the survey shows what must be sliced/split);
              split's bytes default drops 32768 → 15360 so every part reads
              WHOLE in one call under the 16k read cap.
              (5) NUDGE-SAFE CONTEXT SEGMENTS — buildContext starts a
              segment at REAL task turns only: a continue nudge or a proto
              TOOL_RESULT row no longer starts its own segment, so
              trim/eviction can never f3-drop the ACTIVE task turn behind
              its own nudge (the 2026-10-31 round-7 derailment: the
              re-driven run "resumed" a stale task from RESUME STATE while
              the actual verdict dump was gone from the payload). f3 topics
              widen 70 → 160 chars.
              Tests: tests/test-hf14.mjs — 21/21 (real agent.js + real
              vfs.js in vm sandboxes; hf.11 24/24 + hf.12 25/25 + hf.13
              16/16 still green). PATCHLOG.flat.txt §03f documents the wave.
 CODE SHIPPED: YES — hf.13 = the per-chat clock + never-lose-a-draft pass:
              (1) PER-CHAT HEADER CLOCK — the hf.11 clock anchored at the
              browser TAB and Σ'd State.sessionTokens across every chat, so
              a 57-min tab that ran two ~600k-tok + one ~300k-tok project
              showed one never-resetting timer and a blended 4470 tok/min.
              The clock now belongs to the ACTIVE CHAT: elapsed anchors at
              the chat's creation (new chat → 0:00, chat switch swaps the
              anchor, IndexedDB-stable across reloads); tokens = Σ exact
              usage.t of the chat's OWN assistant rows (other chats' burn
              structurally cannot leak in; estimate rows never counted);
              tok/min = that Σ ÷ chat minutes (1-min floor). The old
              tab-lifetime Σ survives as the tooltip's secondary figure.
              (2) COMPOSER DRAFT PERSISTENCE — every keystroke of the chat
              input lands in localStorage per conversation
              (ade_draft_v1_<convId>, 48k cap): a reload, an SW-update
              reload or a closed tab never eats typed work; drafts follow
              chat switches; the pre-chat scratch draft migrates into the
              chat it starts; send clears it, deleting a chat discards it.
              Tests: tests/test-hf13.mjs — 16/16 (real ui-chat.js + main.js
              in a vm sandbox; hf.11 24/24 + hf.12 25/25 still green).
              PATCHLOG.flat.txt §03e documents the wave in full.
 CODE SHIPPED: YES — hf.12 = the MULTI-FILE + 50 KB wave (read/find/edit/
              append accept path as ONE path OR an ARRAY — per-file results,
              names unchanged; NEW grep tool = the dedicated -o extractor —
              regex/capture groups ONLY, hits/only/count, unique, any file
              size; js files:[paths] FS preload closes the worker's
              fetch/import dead ends; 50 KB is the new LARGE-FILE line —
              BIG_READ_CAP/LARGE_FILE halved; empty-response auto-shrink
              escalation arms the re-drive with the 413 shrink instead of
              re-shipping identical bytes; shell: multi-file grep/sed,
              sed -E, find -pattern/-E/-max + FILE roots, js -e).
              Tests: tests/test-hf12.mjs — 25/25. PATCHLOG.flat.txt §03d.
 CODE SHIPPED: YES — hf.11 = four user asks, one pass:
              (1) the CHUNK tool — build a large file FROM THE FIRST TOOL
              CALL: one call ships ONE ≤16k-char piece to <path>.chunks/
              staging (size + digest recorded per piece), the final index
              auto-compiles with per-part re-verification from storage, a
              one-shot .pre-chunkwrite.bak of a replaced target, and a
              chars·lines·digest report — resume-safe ({status:true} lists
              what landed · {abort:true} discards · identical re-sends are
              idempotent AND self-heal a drifted staged part); (2) ONE-WORD
              tool names — write · read · find · edit · chunk · split ·
              scan · check · assemble · state · py · js · preview · probe …
              every legacy fs_* / flat_* / ledger_* / run_* spelling still
              resolves through the alias layer; write/append REFUSE >16k
              chars in one call and ≥100 KB files are the LARGE-FILE class
              (== the 100 KB whole-read gate: chunk-build · split-edit ·
              assemble — never whole); (3) the header SESSION CLOCK — time
              since session start + exact tok/min (1 Hz · 1-minute floor ·
              estimated rows not counted); (4) QUIET ERRORS — "Request
              failed" and "Empty response from model." no longer render as
              red bubble walls: one dim click-to-expand chip each (the data
              still lands in ade.errors.log · retry ×3 · auto-continue).
              Tests: tests/test-hf11.mjs — 24/24 (runs the REAL agent.js in
              a vm sandbox against an in-memory VFS; caught 2 real bugs
              before ship: the resume-to-compile deadlock + drift healing).
 CODE SHIPPED: YES — wave 2 = one new chunk, same-pass (hotfix jump):
              ch-32 RUN LIFECYCLE HARDENING (m-57): the field reports
              "last update disabled all of my models" · "Request failed /
              Stopped before any tokens arrived" on EVERY config · an added
              z.ai Anthropic endpoint that glitched the workbase — ROOT
              CAUSE: the run's AbortController was never reset at run
              start, so after ANY abort (Stop · mid-stream Continue push
              · the 120 s watchdog) the NEXT run died instantly before
              any request, on every config — one stale abort locked the
              whole app (reproduced red in the test harness first).
              ch-32.f1: the controller is now created fresh at runAgent
              entry and reused unless dead — a Stop during a retry
              backoff can no longer be swapped for a live request; stop-
              guards sit after every retry backoff. ch-32.f2: the zero-
              token note names what happened + gives the ↻ Continue
              recovery. Wave 1 (same session):
              ch-30.f4 DETECTOR ROUND 2 (m-55): the announce-nudge no longer
              fires on "Let me know if you want changes." / "I'll leave the
              file as-is." / retrospective "Step 1… Step 2…" summaries or
              replies that merely end with a code block — and it NOW catches
              the narrated-call shape ("Emit it now: fs_read js lines
              278-383 …") that used to end the run with you waiting. Lead-ins
              require a real action verb; tool names in the closing line
              count; the length gate tightened 1200 → 360 chars.
              ch-30.f5 NUDGE DIET + noteKind: every machinery note is
              shorter, de-shouted, and carries a noteKind for the chip layer.
              ch-31 AUTO-CONTINUE ENGINE + CHAT DIGNITY (m-55/m-56):
              f1 SYSTEM-NOTE CHIPS — the announce/cut/manual/auto nudges and
              paused notes render as ONE compact centered chip (full text in
              the tooltip + click to expand) instead of dimmed fake-user
              message walls — no more unprofessional feedback.
              f2 SCROLL TO BOTTOM — a floating ↓ button appears when the
              thread is >140 px from the bottom (click = smooth scroll), and
              the engine auto-scrolls to the bottom the moment a run stalls.
              f3 TRANSIENT RETRY — HTTP 408/425/429/500/502/503/504/522/523/
              524/529 (the Cloudflare/proxy family that killed steps with
              "Request failed HTTP 524") now retries up to 2× per step with
              backoff + Retry-After; the final error speaks human and points
              at ↻ Continue.
              f4 AUTO-CONTINUE — your exact spec: stall detected → scroll to
              bottom → 5 second grace period → the run re-drives itself
              (≤6 attempts, then one honest give-up note). Toggle in
              Settings → Agent ("Auto-continue stalled runs", default ON).
              User stops, 400-class config errors and a newer send never
              auto-continue.
              f5 UNABSORBED TOOL RESULTS NEVER EVICT — the last batch's
              "Evicted on arrival" bug: a tool result the model never had a
              turn to read stays verbatim even when a continue-nudge starts
              a fresh context segment (amends the ch-20 economy — paid
              content is no longer destroyed on arrival).
              Verified: scripts/test_s26.mjs 13/13 (the lockout reproduced
              RED, then green) + test_s25.mjs 71/71 + test_s24.mjs 55/55
              (Node vm over the REAL util/agent/ui-chat) + node --check on
              every touched file.
              Requests: 57 total — 56 done; open: m-50 (ch-28 ledger
              repair, still plan.next).
 PLAN NEXT: CH-28 (LEDGER REPAIR — backfill the unlogged hotfix sessions,
              re-anchor counters to grep-able truth, re-seed the cache
              snapshot; zero code), then the extension wave resumes at
              CH-07.
================================================================================

WHAT THIS IS
------------
This zip is the SESSION-21 deliverable of the ADE campaign: CH-27 (m-47) —
DEPLOY ADE AS AN OFFLINE WEB APP. ADE is now a full installable PWA: sw.js
precaches the entire shell (js · css · icons · the flat files) at install,
manifest.webmanifest + a generated icon set make it installable on desktop
and mobile (sidebar install button, ch-27.f4), a CDN allowlist keeps fonts
+ Font Awesome + Pyodide alive offline after one online visit, and DEPLOY.txt
ships the concrete hosting matrix (Netlify Drop · Cloudflare Pages · GitHub
Pages · python http.server). All shipped + headless-verified in the same
pass — including a real OFFLINE reload E2E. Previous (session 20): a ROUTING
pass
that reworked the token-burn display per your four asks — ONE slim strip
instead of the fat card, a per-model "Cost per 1M tokens ($)" Settings
entry, the chat's total cost on the strip, and a delayed reveal (only after
the chat idles 10s) — CH-26 (m-46), all shipped and headless-verified in the
same pass. Previous milestone (session 19): the Sonnet context-claim
experiment (mechanism confirmed at 14.8×; numbers in
scripts/context_claim_report.txt) + CH-12 PROMPT CACHING (m-29): the agent
snapshots the workspace once, patch runs carry a byte-stable profile prefix
+ drift deltas only, and one click ships the merged zip back and re-caches.
Previous (session 18): three same-pass chunks — conversation actions fix,
exact token-burn telemetry, task scheduler. Previous-previous (session 17):
the token-economy advisory triage of your pasted Gemini + Sonnet advice
(2 adopted → ch-12.f6/f7 · 2 confirmed already true · 5 rejected as
doctrine; zero code).
The agent can now SURVEY before it reads (fs_digest / `digest`), its context
no longer re-sends every past tool result on every step (eviction), its
instructions forbid file-by-file folder reads (read economy), and huge files
read in honest slices (fs_read pagination). Previous milestone (session 14):
ROUTING — your field-report wave #2 was routed into the work list and the
protocol halves shipped; zero code that pass, all of it landing here.
Previous-previous (session 13): your live ADE-agent chat WAS the field report
— ch-17 work-folder auto-import, ch-18 shell correctness, ch-19 the NOW
EDITING + CONSOLE HISTORY windows.

ADE in one sentence: your single-file "Builder Ai" chat app reworked into a
real agentic developer environment — the model (coding-glm-5.3-flash-free)
gets a persistent browser workspace it can actually WORK in: read/write/
rename/delete files, restructure folders, drive a console, and execute
python / js / html — and since CH-03 the workspace MIRRORS a real disk
work folder (write-through, session-persistent link) — all statically hosted.

WHAT'S IN THIS ZIP
------------------
  index.html          app shell markup ONLY — links css, loads js/vendor + the
                      9 js in the final dependency order (vendor lib loads
                      first; the 9 tags never moved) · tags now carry ?v=
                      cache-busting (HF-02, bumped per release)
  sw.js               NEW (ch-14, HF-02 PATCH 1/3, m-31) — the cache-refresh
                      service worker: network-first same-origin GETs ·
                      versioned cache ade-sw-vhf02 + old-cache purge on
                      activate · skipWaiting + clients.claim · ADE_SW_CLEAR
                      message hook; registered by main.js (secure contexts
                      only — a worker file, NOT a script tag in index.html)
  css/ade.css         ALL styles — P1-P20 design tokens ported verbatim from
                      Builder Ai (surfaces bg…bg5 · accent #d4893a · radius 5px
                      · Space Grotesk + JetBrains Mono) + every component +
                      NEW: tree · crumbs · row actions · editor/prompt modals
                      · HF-03: the ADE-05.6 reasoning-viewer block (ch-22.f1
                      — .think-panel/.think-head/.think-auto/.think-body,
                      which had NEVER been written — marker ADE-S16.1)
  js/vendor/          NEW (ch-02.f4, m-23) — fflate.min.js (0.8.2 UMD) acquired
                      ONCE at build time; the product never CDNs it at runtime
  js/util.js          utils · toasts · markdown renderer (incl. pipe tables) ·
                      highlighter (js/py/html/css/json/bash/yaml) · copy/dl
  js/db.js            IndexedDB "ade-db" v1: convs · msgs · configs · settings
                      · vfs · handles + global State + storage.persist() ·
                      HF-02 (ch-16): DB.migrate() settings-schema versioning
                      — stale stored configs upgraded on boot, secrets
                      preserved, idempotent (additive-only) · CH-06: agent
                      budget defaults feed makeDefaultConfig (agent_max_steps
                      · agent_context_k) + workspace_seeded flag
  js/vfs.js           REAL since CH-02 — VFS core: path rows · .. -safe helpers
                      · mkdir/mkdirp/put/readText/list/tree/rm/mv/count/du ·
                      digest/digestTable NEW ch-20 (subtree → one survey
                      table off the VFS rows) · zip import/export (fflate) ·
                      VFS.onWrite hook bus · CH-03: VFS.FSA — linked work
                      folder (link · boot restore · reconnect · pull/push ·
                      write-through) · SESSION-13 (ch-17/18): syncFromFolder()
                      merge-newer auto-import (folder → workspace on five
                      triggers, pre-run included) · synthetic VFS root row
                      ("/" finally exists for ls/cd/fs_list/tree/find)
  js/exec.js          REAL since CH-04 — PyRun (pyodide v0.26.4 worker ·
                      ask-first ~10MB pull or self-fetched vendor/pyodide/ ·
                      /ws snapshot + diff sync-back · auto-load prebuilt
                      packages · micropip confirm · timeout kill+reload) ·
                      JSRun (blob worker · console bridge · top-level await
                      · timeout) · Preview (sandboxed iframe · console
                      bridge · sibling link/script/img inlined) · Shell
                      (34 commands incl. digest [dir] NEW ch-20 · && ·
                      PIPES | with stdin-aware head/tail/wc/grep/sort ·
                      > >> · ls -la · find -name/-type/-maxdepth · du -s/-h
                      · Shell.log command journal) + ConsoleUI
  js/agent.js         REAL since CH-05 (replaces the stub) — 13-tool OpenAI
                      registry (fs_list/tree/read/write/append/delete/move/
                      mkdir · fs_digest NEW ch-20 · shell · run_python ·
                      run_js · open_preview; reads 16k / outputs 12k caps +
                      truncation notes · fs_read paginated offset/limit/
                      head/tail NEW ch-20 · all paths norm()-sanitized ·
                      writes hit VFS + write-through) · the agent loop
                      (streamed tool_calls · role:tool rows persisted ·
                      step counter + STOP gating) · <<<TOOL>>> text-protocol
                      fallback (400/404/422 auto-retry, sticky) · context
                      trim + TOOL-RESULT EVICTION NEW ch-20 · READ ECONOMY
                      rule NEW ch-20 · buildSystemPrompt/buildContext left
                      as clean named hooks for CH-06 + CH-12
  js/ui-chat.js       thread · send flow (delegates to Agent.runAgent) ·
                      attachments (zips EXTRACT into /imports/<ts>-<name>/)
                      · conv sidebar · NEW CH-05: TOOL TRACE cards (icon ·
                      name · arg summary · ok/err · ms — click = args +
                      result + copy; persisted, re-render on reload) ·
                      THINKING VIEWER (m-22): ✦ tag / Agent badge click →
                      lazy reasoning panel + auto-expand-while-streaming
                      toggle (persisted 'think_autoexpand') · NEW
                      SESSION-20 (ch-26, m-46): the SLIM IDLE-REVEAL BURN
                      STRIP — one ~24px line (↑p · ✦r · ↓o · Σt · $ ·
                      cached · reqs/turns · copy; explanations in tooltips)
                      · $ = Σ tokens × the model's $/1M (per-model sum,
                      unrated honestly excluded) · reveals ONLY after 10s
                      of chat idle, hides on any activity, reveal preserves
                      scroll · copy = structured summary (ADE-S20.1…S20.5)
  js/ui-workspace.js  REAL since CH-02 — file tree (expand/collapse · chevrons
                      · FA icons · size badges · breadcrumb cwd) · per-row
                      actions (edit/rename/download/delete/run) · modal text
                      editor · drag-drop + picker uploads · zip buttons ·
                      CH-03: backend badge = link/reconnect button · Pull ← /
                      Push → header actions · CH-04: run/preview action now
                      calls the real executors + run-console toggle button
                      · NEW SESSION-13 (ch-19): TWO windows under the tree —
                      NOW EDITING (file + exact line, agent + your cursor)
                      and CONSOLE HISTORY (user + agent commands, click =
                      copy) · (markers ADE-03.3…03.5 · ADE-S13.9 carried)
  js/ui-settings.js   settings modal: Configs CRUD (incl. maxSteps · contextK
                      · costPerM NEW ch-26 "Cost per 1M tokens ($)" ·
                      forceProto) · Agent & Workspace status · Proxy Setup
                      (SESSION-10: tab-render fix · wiring status · test ping
                      · mode presets — the key entry is finally reachable)
  js/main.js          init · wiring · first-run seed · ADE_BUILD stamp
                      (now ade-s20-ch26) · CH-03: FSA boot restore ·
                      SESSION-13: starts the work-folder auto-sync triggers ·
                      SESSION-18: wires ChatUI.initSidebar + SchedUI.init
  js/scheduler.js     NEW (ch-25, m-44, ADE-S18.7) — the task scheduler:
                      tasks in ade-db v2 'tasks' store · 15s tick +
                      visibility/focus sweeps · fires due tasks through the
                      REAL agent loop (ChatUI.runTurn) into fresh "⟳ task"
                      conversations · freq: once / every-N-min / hourly /
                      daily / weekly · how-many-times cap (0 = until paused)
                      · missed-window catch-up collapses to one run ·
                      one-run-at-a-time + user-run-deferred guards ·
                      SCHEDULED TASKS window + add/edit modal
  routing.flat.txt    the protocol — meta.session.20 + §01 ai.token.policy
                      (the m-41 token-economy doctrine) + §08 ai.audit.p1/p2/p3
                      (the token-cheap tool-audit prompts)
  manifest.flat.txt   request ledger — 46 requests; m-46 registered this pass
                      (token-burn display rework, shipped same-pass) — 43/46
                      done; open: m-36 · m-37 · m-39
  planner.flat.txt    THE MOST IMPORTANT FILE — 26 chunks · 98 feature lines ·
                      20 chunks done (build wave + hotfixes + the session-13
                      wave + CH-20 + CH-22 + CH-23/24/25 + CH-12 + CH-26) ·
                      worklog.20 appended · plan.next ch-21 (m-36/m-37/m-39)
  readme.txt          this file
  ref/index_old.html  the superseded Builder Ai single-file app (reference)

STATUS
------
  chunks done : 20/26 — BUILD WAVE CLOSED + field-report waves #1…#4 + the
                caching/telemetry milestones (CH-01…CH-06 + CH-13 hotfix +
                CH-14/15/16 trio + CH-17/18/19 + CH-20 context economy +
                CH-22 HF-03 + CH-23/24/25 trio + CH-12 prompt caching +
                CH-26 burn strip rework) · features done : 78/98
  session 20  : ROUTING + CH-26 SHIP — m-46 registered and shipped
                same-pass: the token-burn display reworked per four asks —
                f1 ONE slim ~24px strip (fat grid card retired, explanations
                in tooltips) · f2 per-model "Cost per 1M tokens ($)"
                Settings entry (+ settings schema v3→4 additive migration) ·
                f3 chat total cost on the strip (Σ tokens × $/1M per model;
                unrated models excluded from the $ with an honest "NOT
                counted" tooltip; copy = structured summary) · f4 delayed
                idle reveal (10s sweep; hidden while streaming/active;
                reveal preserves scroll) — verified verify_s20.py 26/26
                headless + parser 9/9 + s19 harness 33/34 (stamp gate only)
                · LEDGER REPAIR: m-41 flipped done (s19 flip missed the
                line) — 43/46 done, open: m-36 · m-37 · m-39
  session 19  : ROUTING + CH-12 SHIP — the Sonnet context-claim experiment
                ran FIRST (scripts/context_claim_experiment.py: naive sweep
                846k tok vs protocol context 57.2k tok = 14.8×, at the
                claim's floor; multiplier = untouched fraction; sliced reads
                1.8× vs whole) then plan.next CH-12 PROMPT CACHING shipped
                f1–f7 same-pass (profile snapshot store · send-once stable
                prefix · drift-delta exchange · ship-cached-zip · staleness
                chip · prefix byte guard · extra-body pass-through) —
                verified 34/34 headless — 42/45 done
  session 18  : ROUTING + 3-PATCH SHIP — m-42/m-43/m-44 registered and ALL
                shipped same-pass: ch-23 conv actions fix (missing #conv-list
                click wiring + sandbox-safe confirm) · ch-24 exact token burn
                (TEST-FIRST: 9/9 parser unit; stream_options usage capture +
                burn card) · ch-25 task scheduler (unattended agent loop
                runs) — verified 38/38 headless E2E + 0 page errors
                (scripts/verify_s18.py) — 39/44 done, open: m-29 · m-36 ·
                m-37 · m-39 · m-41
  session 17  : ROUTING — the pasted Gemini + Sonnet token-burn advice
                triaged against shipped code (m-41): 2 adopted → ch-12.f6
                stable-prefix byte discipline + ch-12.f7 thinking-effort /
                extra-body pass-through · 2 confirmed already true (prefix
                ordering · reasoning never re-sent — buildContext invariant)
                · 5 rejected as doctrine (routing §01 ai.token.policy) ·
                ledger repairs: planner §00 counters + routing session-16
                entry backfilled · zero code — 36/41 done, open: m-29 ·
                m-36 · m-37 · m-39 · m-41
  session 15  : ITERATION — ran plan.next → CH-20 shipped 4/4 (m-35 quota-
                burn fix: fs_digest/digest survey · tool-result eviction ·
                read-economy in-prompt · fs_read pagination) — 34/37 done,
                open: m-29 · m-36 · m-37
  session 16  : ROUTING + HOTFIX HF-03 — s15 build re-verified 30/30 (debug
                pass, stamps moved only after) · m-38 (pre-15 planner Q&A
                burn, ~100k tok) → ch-20 evidence · m-39 (host shell shim
                failures) → ch-21 evidence · m-40 (auto-expand reasoning
                toggle dead) → CH-22 shipped: the ADE-05.6 viewer had NO css
                — full stylesheet + race fix, verified 14/14 — 36/40 done,
                open: m-29 · m-36 · m-37 · m-39
  plan.next   : CH-21 (shell text-transform corps — sed & co · tool audit ·
                tool-gaps journal; m-36/m-37/m-39), then CH-07 resumes
  budget      : 30k tokens per routing/iteration session (hard cap, planner §01)
  cache       : cache-015 = THIS zip (session-20 payload — CODE DRIFTED,
                stamps bumped ade-s20-ch26; cache-014 superseded) — patch
                tasks per routing §01 ai.cache.patch.recipe: CACHE + DELTA +
                TASK, never a full re-send and NEVER a folder-wide read; the
                IN-APP half is live now (Agent.Cache + the CACHE chip)

RUN IT (30 seconds)
-------------------
  1. unzip this folder
  2. from inside it:  python -m http.server 8080
  3. open http://localhost:8080  (or host the folder on any static host —
     DEPLOY.txt has the full matrix: Netlify Drop · Cloudflare Pages · GitHub
     Pages) — the sidebar footer build stamp must read ade-s21-ch27; if an
     older
     stamp survives a re-upload, hit the ↻ arrow beside it (clear caches
     + reload — one click, HF-02 PATCH 2/3)
  3b. OFFLINE + INSTALL (NEW, session 21): after ONE online load the worker
     has precached the shell — go offline (devtools Network → Offline) and
     reload: ADE still boots. Install it as an app from the sidebar download
     button (Chrome/Edge/Android offer the prompt) or iOS Share → Add to
     Home Screen. Full guide: DEPLOY.txt in this folder.
  4. Settings → Proxy Setup → paste YOUR CorsProxy.io key → Save key (the tab
     now RENDERS — session-10 fix); watch the wiring status row, hit Test ping
     · Settings → Configs → set your AiHubMix key (model preset is already
     coding-glm-5.3-flash-free)
  5. send a message — plain questions stream as usual; ask it to BUILD
     something ("write demo/hello.py and run it") and watch the tool trace.
     The agent now runs the FULL ADE protocol (CH-06): it reads before it
     writes, verifies by running, respects your bandwidth, and — when the
     flat files are in its workspace — reads the bridge, appends worklogs
     and flips statuses like a campaign native

  file:// works degraded too (chat + storage fine; some CDNs may warn).

WHAT WORKS RIGHT NOW (SESSION-24 WAVE + SESSION-21 + SESSION-20 + SESSION-19 WAVE + SESSION-15 WAVE + SESSION-13 WAVE + CH-06 + CH-01…CH-05 + HF-01/HF-02)
------------------------------------
  CHAT SURFACE + PROTO DISCIPLINE (NEW, SESSION-24 CH-29/CH-30 — your m-53/
  m-54 asks):
  · BURN LINE AT THE END (ADE-S24.1, ch-29.f1): the per-message badge now
    lives under the bubble as a quiet footer — the top meta keeps only
    role / model / ✦ thought / cache pill
  · RUNNING SESSION TOTALS (ADE-S24.1, ch-29.f2): the badge gains
    · Σsession tokens from the second API-reported request on and · running
    $ at the per-model $/1M rates set in Settings (unrated models honestly
    excluded); tooltips carry the exact numbers (re-sends count — they ARE
    burn, same semantics as the strip below)
  · ↻ CONTINUE (ADE-S24.2, ch-29.f3): sits LEFT of Send/Stop — mid-stream
    it aborts the dead fetch and auto-continues once the run closes;
    idle it re-drives the latest task via a system-note nudge; the
    stalled/cut error notes now point at the button
  · TOLERANT TOOL-LINE CAPTURE (ADE-S24.3, ch-30.f1): lowercase, fence-
    wrapped and spaced (<<< TOOL) markers parse — a drifted-but-real call
    executes instead of nagging; fence residue is stripped from the reply
  · ANNOUNCE NAG FIXED (ADE-S24.4/.5, ch-30.f2/f3): no more false "no tool
    line" pings on final answers (done/complete/saved closers exempt ·
    code walls are answers · bare now/looking triggers gone); when the
    nudge DOES fire it carries a tool guess + a concrete copy-able line
    (≤2 per run, unchanged)

  OFFLINE DEPLOY SHELL (SESSION-21 CH-27 — your m-47 ask):
  · PRECACHE WORKER (ADE-S21.1): sw.js seeds the ENTIRE shell at install
    (index.html · css · all 11 js incl. fflate · manifest · icons · sw.js
    itself AND the 4 flat files + readme + DEPLOY.txt — so even the
    workspace auto-seed works offline); network-first is KEPT (online
    always wins, ch-14 doctrine) and a cold-cache navigation offline now
    falls back to the cached index.html instead of a dead tab
  · CDN RUNTIME CACHE (ADE-S21.2): stale-while-revalidate for the allowlist
    ONLY — cdnjs (Font Awesome) · Google Fonts · cdn.jsdelivr (Pyodide) —
    one online visit makes icons/fonts/python survive offline; AI/API/proxy
    hosts are never cached, POSTs never intercepted
  · INSTALLABLE PWA (ADE-S21.3): manifest.webmanifest (standalone · theme
    #0a0a09 · start ./) + generated icon set (192 · 512 · maskable-512 ·
    apple-touch-180) + theme-color/apple metas in the head
  · INSTALL FLOW (ADE-S21.4): beforeinstallprompt captured → the
    sidebar-footer download button appears → click = native install prompt
    → appinstalled toasts + hides it (Safari: Share → Add to Home Screen)
  · DEPLOY GUIDE (ADE-S21.5): DEPLOY.txt — hosting matrix · offline vs
    needs-network · install steps · update flow · new-file checklist

  BURN STRIP — SLIM · $/1M COST · IDLE REVEAL (SESSION-20 CH-26 — your
  m-46 asks; the ch-24 Σ per-request telemetry semantics stay untouched):
  · SLIM STRIP (ADE-S20.1): the fat 4-cell burn card is retired for ONE
    ~24px flex line — 🔥 BURN · ↑prompt · ✦reasoning · ↓output · Σtotal tok
    · $cost · ⛁cached · reqs/turns · copy — with the verbose explanations
    in hover tooltips and the legacy-est footnote kept as a wrap line only
    when pre-telemetry rows exist
  · PER-MODEL $/1M (ADE-S20.2): Settings → Configs → the config editor gains
    "Cost per 1M tokens ($)" — THIS model's price per 1,000,000 tokens
    (0.15 = $0.15/1M); stored configs migrate additively (settings schema
    v3→4; costPerM=0/empty = not tracked, no $ segment renders; secrets
    never touched)
  · CHAT COST (ADE-S20.3/S20.5): the strip's $ = Σ tokens × the model's
    $/1M, summed PER MODEL when a conversation mixes models; requests on
    unrated models stay in the token totals but are excluded from the $
    (the tooltip lists them under "NOT counted"); the copy button emits a
    structured summary (totals · cached · per-model cost lines · unrated ·
    legacy footnote)
  · IDLE REVEAL (ADE-S20.4): a 1 Hz sweep reveals the strip ONLY after 10s
    of chat silence (BURN_IDLE_MS) — never mid-stream, never while you
    work; any activity re-hides it; the reveal preserves your scroll
    position instead of yanking to the bottom; telemetry-less conversations
    can never trigger it (shared predicate, no re-render pump by design)
  CONTEXT ECONOMY (NEW, SESSION-15 CH-20 — the m-35 quota-burn fix, 4 features):
  · FOLDER DIGEST (ADE-S14.1): fs_digest agent tool (13 tools now) + `digest
    [dir]` shell command — a whole subtree renders as ONE compact table
    (path · size · lines · first-line preview) in a single ~1k-token call,
    built straight off the VFS rows (content + size already live there — zero
    extra reads); the workspace-tree snapshot the agent gets every run now
    ends with "→ survey with digest <dir> / fs_digest — never read a folder
    file-by-file"
  · TOOL-RESULT EVICTION (ADE-S14.2): when est-token pressure trips ~60% of
    the context budget, tool results in all but the ACTIVE (newest)
    user-segment collapse to one-line stubs — "[evicted: fs_read /js/agent.js
    · 40k chars · re-read if needed — fs_read pagination makes it cheap]" —
    so a folder-reading task no longer re-sends every past read on every
    step (the O(steps × folder) amplification behind the 130k burn); the
    persisted thread and the tool-trace cards keep the FULL text
  · READ-ECONOMY RULE (ADE-S14.3): the system prompt's working agreement
    gains hard rule 6 — NEVER read a folder file-by-file · survey first ·
    fs_read ONLY the files the task names · ≤8 full reads per run unless the
    user said otherwise · iterate/patch tasks start from the bridge files +
    the chunk's chNN.files, never a folder sweep
  · FS_READ PAGINATION (ADE-S14.4): fs_read accepts offset (0-based line) /
    limit / mode head|tail — every slice opens with "[fs_read <path> · lines
    A–B of N]"; an over-cap whole read returns the head slice + "… N lines
    skipped — re-read with offset M" instead of a blind mid-file truncation

  WORK-FOLDER AUTO-IMPORT (SESSION-13 CH-17 — your m-32 field report):
  · SYNC CORE (ADE-S13.1): VFS.FSA.syncFromFolder() walks the linked folder
    and MERGES it into the workspace newer-wins — missing file → imported ·
    disk newer → overwritten · workspace same/newer → left alone (agent
    edits survive). The manual Pull button keeps the documented wholesale
    rule; the AUTOMATIC path only ever ADDS
  · FIVE AUTO TRIGGERS (ADE-S13.1/13.10): link · boot relink · a 20s poll
    while the tab is visible · return-to-tab refresh · AND a pre-run hook —
    the folder merges BEFORE every agent run, so the workspace tree the AI
    sees is always fresh from disk. Honors the autosync toggle

  SHELL/CONSOLE CORRECTNESS (NEW, SESSION-13 CH-18 — your m-33 field report):
  · SYNTHETIC ROOT (ADE-S13.2): `ls /`, `cd /`, agent fs_list "/" and tree
    "/" all work now — the VFS never stored a row for "/", so every root
    path query failed; get() synthesizes it and everything heals
  · DIALECT (ADE-S13.3/4/5): ls -la/-al long format · find [dir] [-name pat]
    [-type f|d] [-maxdepth N] (bare `find .` lists everything) · du -s/-h
  · PIPES (ADE-S13.6): `find . -type f | head -50` works — stdout feeds the
    next command's stdin; head/tail/wc/grep and NEW sort (-r -u) read stdin;
    `head -50` shorthand accepted
  · TRUNCATION FIX (ADE-S13.7): no more "showing undefined of N chars" in
    long tool outputs — the cap defaults correctly

  TWO WINDOWS UNDER THE WORKSPACE (NEW, SESSION-13 CH-19 — your m-34 request):
  · NOW EDITING (ADE-S13.9): file name + EXACT LINE, live — the agent's
    fs_write ("rewrite · N lines") and fs_append (computed start line)
    publish here, and your editor modal tracks the cursor line as you type
  · CONSOLE HISTORY (ADE-S13.8/9): every shell line — YOUR console input
    and the agent's silent tool calls — time-stamped with a green/red exit
    dot, click a row to copy the command; scrollback 200, collapsible

  ADE AGENT PROTOCOL (SESSION-12 CH-06 — closed the build wave):
  · ADE SYSTEM PROMPT (ADE-06.1): the placeholder hint is gone — the agent
    gets its role, the 12-tool map, the working agreement (inspect before
    write · surgical edits · verify by running · honest reporting) and a
    LIVE WORKSPACE TREE snapshot (≤180 lines) appended fresh every run
  · FLAT-BRIDGE PHILOSOPHY EMBED (ADE-06.7, m-28): FlatBridge.PHILOSOPHY —
    a hard-coded JS constant injected FIRST into every system prompt (any
    model/config/endpoint, native tools or text protocol): the 3 files'
    roles · the request→routed→done lifecycle · register-never-remember ·
    append-only · stable-keys · additive-only · §01 read-order · the
    two-artifact deliverable. Philosophy = code; when the flat files exist
    in the workspace the STATE LAYER directs the agent to fs_read their
    live contents, append worklogs to planner §12 and flip statuses
  · IN-PROMPT POLICIES (ADE-06.4/5/6): bandwidth policy (explain-then-ask,
    pull-once-vendored or self-fetch instructions, micropip confirms,
    vendored refs only — m-23) · work-folder-first protocol (linked folder
    = working root; adapts live to the FSA state — m-25) · flat-file
    mastery (m-26)
  · WORKSPACE AUTO-SEED (ADE-06.2): first boot with an empty VFS fetches
    routing/manifest/planner/readme from the hosting directory (the zip IS
    the seed; file:// → embedded stubs) + writes the demo set; the flag
    stamps on terminal outcomes only (a mid-seed deploy-reload retries);
    console `seed` re-runs it, idempotent
  · BUDGETS + SETTINGS UI (ADE-06.3): Settings → Agent & Workspace is real
    now — budget defaults for new configs (+ apply to active), python/js
    executor timeouts (persisted to the keys the runners already read),
    work-folder autosync toggle (live), usage pills (context est vs budget
    · requests this session), live environment rows incl. flat-file presence

  DEPLOY REFRESH (SESSION-11 HF-02 — your m-31 field report, 3 patches):
  · PATCH 1/3 — SW REFRESH WORKER (ADE-HF2.1/2.2, ch-14): sw.js at the site
    root serves every same-origin GET NETWORK-FIRST — online, the page always
    loads the freshly uploaded files; the cache copy is only the offline
    fallback. On activate it purges every older cache (the cache name bumps
    every release — currently ade-sw-vs13), and a
    new worker takes control immediately (skipWaiting + clients.claim) —
    main.js reloads the page exactly once on controllerchange, so a deploy
    goes live with no manual hard-refresh; returning to the tab nudges a
    reg.update() so new deploys are picked up even mid-session
  · PATCH 2/3 — CACHE-BUSTING + VISIBILITY (ADE-HF2.3/2.4, ch-15): every
    css/js tag in index.html carries ?v= (currently ade-s13-ch1719 — bump
    per release) so
    browsers fetch new files even where the worker can't register (file:// ·
    non-https); the sidebar footer shows the build stamp — the at-a-glance
    "is my deploy live" check — plus a refresh-arrow button = clear caches
    + reload in one click
  · PATCH 3/3 — SETTINGS MIGRATION (ADE-HF2.5/2.6, ch-16): DB.migrate() runs
    before state loads — stored configs from older builds get dead keyless
    proxy templates upgraded to the keyed default and missing agent fields
    filled (temperature/maxTokens/maxSteps/contextK/forceProto); secrets
    (apiKey · corsKey · custom proxyUrl) are never touched; idempotent and
    additive-only (ai.saves.rule); a toast reports what moved · schema_v=2

  PROXY KEY WIRING (SESSION-10 HF-01 — your m-30 field report):
  · TAB RENDER FIX (ADE-HF.1): the Proxy Setup tab now builds its body on
    every switch — before this fix the panel was BLANK unless the modal was
    force-opened on that tab, so the CorsProxy key field was unreachable
  · WIRING STATUS (ADE-HF.2): the tab opens with a status row — active config,
    proxy mode (keyed with N chars · KEY MISSING · direct · custom) and the
    resolved request URL preview; Agent.resolveUrl toasts ONCE per session
    when a {corskey} template fires with no key stored (re-armed on Save key)
  · TEST PING (ADE-HF.3): one button proves the key end-to-end — HTTP 200 =
    wired; 401 = tunnel fine, your AiHubMix key needs attention; 403 =
    corsproxy key/domain issue (register the host at console.corsproxy.io →
    Manage Domains)
  · MODE PRESETS (ADE-HF.3): chips write the Proxy URL onto EVERY config —
    "CorsProxy.io — keyed (default)" or "Direct — no proxy" (AiHubMix itself
    serves CORS headers, verified live 2026-10-30; public keyless proxies are
    DEAD — workers.dev abuse-banned · allorigins drops POST · cors.lol 429)
  AGENT LOOP (CH-05) — the chat is now a real tool-using agent:
  · 27 TOOLS (hf.11 — ONE-WORD names; legacy fs_* · flat_* · ledger_* ·
    run_* spellings still resolve): list · tree · digest (survey) · read
    (16k chars, truncation note) · write (≤16k/call) · append · chunk (the
    BIG-WRITE — see hf.11 header) · delete · move · mkdir · unzip · rezip
    · zipadd · clear · find · edit (atomic multi) · split · scan · check
    · assemble · state · shell · py · js · preview · probe · caps —
    OpenAI-format schemas, outputs capped 12k with notes, every path
    norm()-sanitized (nothing escapes the workspace), every write goes
    VFS → write-through → linked work folder. Thresholds: one call ships
    ≤16384 chars; a file ≥100 KB is the LARGE-FILE class — it cannot be
    read whole, so it is never written whole: build with chunk, edit via
    split → scan → edit parts → check → assemble.
  · THE LOOP (ADE-05.2): streamed /chat/completions with the tools array;
    assistant tool_calls accumulate + persist mid-stream; each call
    executes, the result persists as a role:tool row, the loop continues
    (cap = config maxSteps, default 24) · "step k/N" counter in the meta
    row · STOP aborts the fetch AND gates pending tools · the final
    assistant reply renders as markdown
  · TOOL TRACE (ADE-05.3): every call renders as a card — icon · name ·
    arg summary · ok/err · ms — click expands ARGS + RESULT <pre> with a
    copy button; cards are PERSISTED (IndexedDB role:tool rows) and
    re-render on reload
  · TEXT-PROTOCOL FALLBACK (ADE-05.4): HTTP 400/404/422 whose body mentions
    tools/functions → automatic retry WITHOUT the tools array + a <<<TOOL
    {"name":…,"args":{…}}>>> protocol appendix; one call per reply, the
    result feeds back as the next user turn; sticky for the rest of the
    run · forceProto config starts there from turn one · unparseable tool
    JSON returns a corrective error to the model, never a crash
  · CONTEXT TRIM (ADE-05.5): API context rebuilt from persisted msgs every
    request; est-token budget = config contextK; trims WHOLE user-anchored
    segments oldest-first — an assistant tool_calls block can never be
    split from its tool results; the system prompt is always kept
  · THINKING VIEWER (ADE-05.6, your m-22): when the endpoint streams
    reasoning_content, a ✦ thinking tag appears — click it (or the Agent
    name badge) to open the reasoning panel; rendered LAZILY off the
    stream hot path (250ms throttle) so long reasoning never lags tokens;
    "auto-expand while streaming" toggle lives in the panel header,
    persisted ('think_autoexpand')
  EXECUTORS (CH-04) — the workspace RUNS your code, all in-browser:
  · PYTHON (ADE-04.1): the tree's play action on a .py file runs it in a
    Pyodide v0.26.4 worker — FIRST run asks (≈10MB core, stated, m-23:
    never a silent pull) → pulled once from jsDelivr, browser-cached
    forever, OR self-fetch a release into vendor/pyodide/ (auto-detected,
    skips the pull) · the whole VFS is snapshotted into the runtime's /ws
    (4MB/file · 48MB total · node_modules/.git/__pycache__ skipped) with
    cwd /ws so relative opens work · stdout/stderr stream live to the run
    console · files python writes are diff-checked and synced back into
    the VFS (write-through mirrors them to the linked work folder) ·
    numpy/pandas/matplotlib/scipy/sympy auto-load when imported, each
    announcing its size first · `pip install <pkg>` goes through micropip
    with a size-confirm step · 120s timeout (settings) kills + reloads
  · JAVASCRIPT (ADE-04.2): .js files run in a dedicated worker built from
    a blob — console.log/info/warn/error bridge into the console, top-level
    await works (AsyncFunction body), the last expression's result is
    returned via a top-level return, 10s timeout terminates the worker
  · HTML PREVIEW (ADE-04.3): .html files open in a modal sandboxed iframe
    (allow-scripts/form/modals/popups, NO allow-same-origin) — console and
    window.onerror postMessage into the run console — sibling resolution:
    <link href> → inlined <style>, <script src> → inlined <script>,
    <img src> → data URIs (same-dir files that exist in the VFS)
  · VIRTUAL SHELL + RUN CONSOLE (ADE-04.4): the terminal button opens a
    collapsible console under the tree — 31 commands (help about clear pwd
    cd ls -l cat head tail echo touch mkdir -p rm -r cp mv find -name grep
    -i wc stat du tree open download python/py pip js/node seed date
    whoami), quote-aware tokenizer, && chaining, > and >> redirects into
    the VFS, ↑/↓ history, cmd/out/err/sys line classes, clear · shell cwd
    persists per session · py/js/html run from the shell stream into the
    same console · the AGENT drives this same shell silently (CH-05)
  WORK FOLDER (CH-03) — the workspace MIRRORS a real disk folder:
  · "LINK WORK FOLDER" badge (the workspace status bar) → pick a folder
    (read/write) → wholesale pull into the VFS (text by extension,
    binaries as ArrayBuffer, >8MB skipped, __MACOSX/.DS_Store junk
    skipped, count toasted) → badge flips to LINKED ✓ <folder name>
  · SESSION-PERSISTENT: the handle lives in IndexedDB — on reload a
    granted permission silently relinks (background pull reports what
    synced); 'prompt' shows RECONNECT NEEDED — ONE click (your gesture)
    re-grants → pull → linked; denied/missing handle → cleared + toast
  · WRITE-THROUGH: every workspace write — editor save · upload ·
    attachment drop · folder create · rename/move · delete — also lands
    on disk while autoSync is ON (subdirs auto-created; failures toast
    throttled and NEVER break the VFS operation)
  · "Pull ← folder" and "Push → folder" header buttons (appear while
    linked) for full-tree sync — documented conflict rule: pull
    overwrites the VFS, push overwrites the disk (refined at ch-11.f1)
  · badge click when linked shows folder + sync status; × unlink keeps
    every VFS file; Firefox/Safari/file:// → badge reads INDEXEDDB with
    a tooltip explaining the zip import/export fallback
  · badge tooltip documents the m-24 work-folder layout: root = routing
    · manifest · planner .flat.txt + readme.txt (+ configs from ch-09)
    · imports/ · demo/ (ch-06) · your project files alongside
  WORKSPACE (CH-02) — the right panel is a real file workspace:
  · recursive file tree with expand/collapse (state persists), chevrons,
    per-extension icons, dirs-first sort, size badges, breadcrumb cwd bar
  · full CRUD: new file / new folder (into the current folder), rename,
    download, delete (confirm; recursive for dirs — file-manager semantics)
  · built-in text editor: modal, mono, live size + lines label, Ctrl+S save,
    straight-to-editor on file creation; binaries download-only
  · zip import (a .zip → the current folder, structure preserved; junk like
    __MACOSX skipped; nothing silently overwritten) + zip export (the whole
    workspace → ade-workspace.zip; empty dirs preserved) — fflate is
    BUILD-TIME VENDORED at js/vendor/fflate.min.js, zero runtime CDN (m-23)
  · uploads that land IN the workspace: drag-drop onto the panel or the file
    picker — zip → import, text → file, binary → file; 24 MB guard + toast
  · everything in IndexedDB: files survive reload; cwd / expanded folders /
    panel-open state persist per session; status line shows count · size
  · run/preview actions appear for py/js/html and toast "lands at CH-04"
    until the executors arrive — the affordance is already wired
  CHAT (CH-01)
  · streaming chat with markdown: headings, lists, pipe tables, blockquotes,
    links, bold/italic, fenced code blocks with lang badge + copy + download
  · syntax highlighting for js/py/html/css/json/bash/yaml
  · GLM reasoning: when the endpoint streams reasoning_content the agent
    shows a ✦ thinking marker — CLICK IT (or the Agent badge) to open the
    reasoning panel (CH-05, your m-22) · panel auto-expands while
    streaming when the toggle is on ('think_autoexpand')
  · config manager: full CRUD, model preset chips (coding-glm-5.3-flash-free
    default · glm-5.3-flash · glm-4.6 · glm-4.5-air), free-text model field,
    maxSteps / contextK / forceProto, 4-token Test ping, header dropdown
  · attachments: text files inline as fenced blocks; zip attachments now
    EXTRACT into /imports/<ts>-<name>/ (fflate); other binaries land in /imports
  · conversations: sidebar, rename, delete, auto-title, per-message token
    estimates, copy/delete actions, everything persists in IndexedDB
  · the two-key model carried over: CorsProxy.io key (tunnel, shared) +
    AiHubMix key (AI billing, per config) — local-only, as always

CAPABILITIES ON THE ROADMAP (the full specs are the planner f-lines)
--------------------------------------------------------------------
  CH-12  NEXT (plan.next — the promoted m-29) — prompt caching: "Cache
         project profile" action (per-file short-sha snapshot in an additive
         IndexedDB 'cache' store) · send-once wiring (stable prefix:
         system prompt → profile → volatile tail) · patch-delta exchange
         (only hash-drifted files travel; VFS.onWrite re-hashes live) ·
         one-click "Ship cached project zip" (merge + re-zip + snapshot
         refresh) · NONE / CACHED ✓ / STALE badges with boot + pre-turn
         staleness checks — ch-20's economy + eviction just made this
         strictly more effective (the volatile tail is smaller)
  CH-21  shell text-tool expansion + audit: sed subset (the agent's own ask)
         · cut/tr/uniq/tee/nl/rev/basename/dirname/diff/patch (all
         pipe-first) · a `tools` command that prints the full inventory in
         one cheap call · a tool-gaps journal so missing-tool moments become
         ledger data
  CH-07  optional local python bridge (ade_server.py): real bash/pip/git
  CH-08+ editor upgrades (CodeMirror · diff view · tabs), configs.flat.txt
         ledger + "Ship ADE zip" button, preview v2 (live reload),
         hardening/backup

HOW THE CAMPAIGN RUNS (for any AI session)
------------------------------------------
  0. the 3 flat files + readme live DIRECTLY at the project-folder root —
     never nested, names never changed (routing §07 build.flatfiles.root) —
     every task assembly starts there; no root scan needed, the bridge is
     always in the same place
  1. read routing.flat.txt §01 (protocol) → §03 (profile) → §07 (build structure)
  2. read manifest.flat.txt §01 (requests) — new requests register there
  3. open planner.flat.txt, take the plan.next chunk block (ch-12 now)
  4. paste ai.prompt.recipe + that block into a FRESH session, say: run plan.next
  5. the session ships TWO artifacts: the next "5.3 flash free ADE.zip"
     (full folder, name unchanged, readme stamp bumped) + the flat files updated
  6. work is logged in planner §12; configs.flat.txt becomes the per-session
     execution ledger from CH-09 on (schema: planner §02)

MODEL & KEYS
------------
  model    : coding-glm-5.3-flash-free (default; free-text, presets included)
  endpoint : OpenAI-compatible /chat/completions — default base aihubmix.com/v1
  keys     : TWO, both local-only in IndexedDB — a CorsProxy.io key (tunnel,
             wired via Settings → Proxy Setup: status row + Save key + Test
             ping — session-10 fix) and an AiHubMix key (AI billing, per
             config); same two-key flow as Builder Ai
  proxy    : the CorsProxy.io key IS the tunnel — public keyless proxies died
             in 2026 (live-tested); "direct — no proxy" works for AiHubMix
             endpoints (they serve CORS headers, verified 2026-10-30)
  fallback : LIVE since CH-05 — endpoints that reject native tools auto-switch
             to the <<<TOOL>>> text protocol (one retry, sticky) — nothing
             breaks on "free" tiers

HOSTING
-------
  static   : GitHub Pages / Netlify / Cloudflare Pages — just upload the folder
  local    : python -m http.server 8080   (python hosts it; zero extra files)
  file://  : works degraded (chat + storage fine)
  browsers : Chromium (Chrome/Edge/Brave) = full experience incl. the linked
             work folder (CH-03+) · Firefox/Safari = everything else
  deploys  : HF-02 — sw.js (network-first, versioned purge) + ?v= busting make
             every re-upload win over browser caches; optional host tweak:
             serve index.html + sw.js with Cache-Control: no-cache

SECURITY MODEL
--------------
  keys and data never leave your browser except: AI calls (to your endpoint,
  via your proxy) and folder writes (to the folder YOU picked). Python will
  run in a WASM sandbox, JS in a worker, HTML in a same-origin-less iframe.
  The virtual shell only ever touches the workspace VFS — OS access only
  exists in the opt-in CH-07 local bridge (127.0.0.1).

BANDWIDTH POLICY (THE FINISHED PRODUCT — m-23)
----------------------------------------------
The user's proxy bandwidth is limited — the ADE is built to respect that:
  · static hosting = no default web pulls. Build-time libraries are
    VENDORED into js/vendor/ and loaded locally (fflate first, CH-02).
  · big runtimes pull ONCE, with approval. Pyodide (~10MB core) asks
    before its first download, then the browser caches it — one download
    per browser, ever. A self-fetched release dropped into vendor/pyodide/
    skips the pull entirely.
  · the ADE agent asks before it fetches (CH-06.f4): explain what + why +
    exact size → offer (a) pull once with your approval, or (b) self-fetch
    instructions (exact URL + target path). pip/micropip installs announce
    package size and confirm first.
  · project code the agent writes references local/vendored assets, not
    CDNs.
Nothing in the finished product downloads without your explicit OK.

TOOL AUDIT PROMPTS (m-37 — PASTE THESE INTO THE ADE AGENT · ~2k TOKENS)
----------------------------------------------------------------------
You asked for token-cheap ways to make the agent reveal every tool it needs
and its architecture — WITHOUT the folder read that burned 130k tokens
(m-35). The trick: the model ALREADY holds its tool registry, the shell help
table and caps in its system prompt — so these prompts FORBID file reads and
force answers from the registry. Run pass 1 then pass 2 in the same agent
chat (or pass 3 alone when even that is too much). Paste the reply into the
next routing session — every named gap becomes a planner feature line.

  PASS 1 — INVENTORY (~1k tokens):
  --------------------------------------------------------------------
  TOOL AUDIT · pass 1 — inventory only. Do NOT read any files (no
  fs_read/fs_list/fs_tree, no shell cat); answer from your tool registry,
  the shell help table and caps only. (1) List your agent tools: name ·
  one-line purpose · arg names. (2) List every virtual-shell command,
  grouped like help does. (3) State your limits: OUT_CAP · maxSteps ·
  contextK · py/js timeouts. Keep the whole reply under 60 lines.
  --------------------------------------------------------------------

  PASS 2 — GAPS + ARCHITECTURE (~1k tokens, same session):
  --------------------------------------------------------------------
  TOOL AUDIT · pass 2 — gaps + architecture (run after pass 1, same
  session). Do NOT read files; work from this conversation and pass 1
  only. (1) GAPS: every moment a task needed a tool/command that was
  missing or misbehaved (e.g. "no sed in this shell") — name the
  capability + the fallback you used + its cost in steps/tokens.
  (2) ARCHITECTURE: for the top 5 gaps spec each as — name · args
  (one-line JSON schema) · implementing ADE layer (VFS row op / Shell
  _cmds fn reading stdin / agent TOOLS entry wrapping Shell·PyRun·
  Preview) · output contract (stdout string + exit code) · est LOC.
  (3) RANK by frequency-needed × tokens-saved. Under 80 lines. No file
  reads, no code execution.
  --------------------------------------------------------------------

  PASS 3 — ONE-SHOT MICRO (~0.5k tokens):
  --------------------------------------------------------------------
  AUDIT (one-shot): without reading any file, print (a) the agent tools
  + shell commands you have, (b) the 5 tools you most needed and lacked
  in recent tasks, (c) for each: args one-liner + which ADE layer
  implements it (VFS / Shell _cmds / TOOLS wrapper) + est LOC. Under
  100 lines.
  --------------------------------------------------------------------

  The same three prompts live in routing.flat.txt §08 (ai.audit.p1/p2/p3).
  ch-21.f3 turns pass 1 into a zero-prompt `tools` command; ch-21.f4 logs
  every missing-command moment automatically (`gaps`).

WORK FOLDER STRUCTURE (FSA — m-24)
----------------------------------
The work folder you link via "Link work folder" (CH-03, Chromium browsers)
is a real disk folder that mirrors the workspace. Expected layout
(routing §07 build.fsa.structure):
  <work-folder>/
  ├── routing.flat.txt      bridge files live at the ROOT — the campaign
  ├── manifest.flat.txt     protocol travels with the workspace (seeded
  ├── planner.flat.txt      into it at CH-06.f2; from then on the folder
  ├── readme.txt            IS the bridge's home)
  ├── imports/              attachment + zip drops land here (CH-01+)
  ├── demo/                 seed demo files (CH-06: hello.py, index.html…)
  └── <your project files>  everything else — synced both ways
Pull imports the folder wholesale (text by extension, binaries ≤8MB);
write-through keeps disk current while autoSync is ON; paths are
sanitized so no write can escape the picked folder. Firefox/Safari has
no FSA — zip import/export stays the fallback there.

FLAT-BRIDGE MASTERY (THE 3 FLAT FILES — m-26…m-28, SESSION 4)
-------------------------------------------------------------
The user's session-4 directive: the finished ADE must UNDERSTAND the exact
structure and function of the 3 flat files — and the philosophy must be
HARD-EMBEDDED via JS so ANY AI linked through the API understands this exact
pattern. Here is the pattern, in full (this is what the ADE system prompt will
teach verbatim at ch-06.f6, and what FlatBridge.PHILOSOPHY will carry as code
at ch-06.f7):

  THE ONE RULE
  ------------
  register, never remember. Every request, every done item, every projected
  task becomes a LINE in a flat file. Nothing lives only in chat or memory.
  Lines never vanish — they move and flip status. The files are the single
  source of truth between the user and every future AI session.

  THE 3 FILES — STRUCTURE AND FUNCTION
  ------------------------------------
  routing.flat.txt — THE PROTOCOL (how work happens)
    structure : fixed sections §00–§07 · key = value, one fact per line, no
                nesting · group.key for fixed groups · group.id.attr for
                enumerated instances · # banners mark sections, state lives
                ON the line never in comments
    function  : §01 the AI protocol (session types · one chunk per iteration ·
                plan.next · 30k budget zones · the ai.prompt.recipe that assembles
                a task) · §02 how user requests enter · §03 the project profile
                (what we are building) · §06 strategy verdicts · §07 the
                expected build structure — the contract the code must match

  manifest.flat.txt — THE REQUEST LEDGER (what the user asked)
    structure : m-NN lines, each with .text · .status · .routed · .note ·
                §01 session batches · §09 inbox for mid-run interrupts ·
                meta.denominator/open/done counters · §12 append-only session log
    function  : every request is registered verbatim-intent, status = open →
                routed (keyword-matched to an open chunk per ai.routing.rule) →
                done (only when the feature actually ships); routing MOVES a
                line (m-NN.routed = ch-NN), it never deletes it

  planner.flat.txt — THE WORK PLAN (the most important file)
    structure : ch-NN chunk blocks, each with .title · .size · .est.k ·
                .status · .deps · .files · .keywords · fX feature lines with
                .text/.status/.source · §01 plan-state (plan.next, progress) ·
                §02 configs.flat.txt schema · §12 append-only worklog
    function  : dependency-ordered, token-budgeted sessions; plan.next names
                the top runnable chunk; a chunk ships only when ALL its open
                fX flip done in one sweep; worklog.N records every session
                (files touched · decisions · follow-ups must point at real lines)

  THE ROOT INVARIANT (m-27)
  -------------------------
  the 3 flat files + readme live DIRECTLY inside the project folder — root
  level, never nested, names never changed — in every assembly surface: this
  zip · the VFS auto-seed (ch-06.f2 fetches ./*.flat.txt into /) · the FSA
  linked work folder (ch-03.f5) · the ship-zip release set (ch-09.f2). Any
  task assembly — fresh unzip, AI session, agent run — finds the bridge
  immediately at the same place. (routing §07 build.flatfiles.root)

  THE HARD EMBED (m-28) — PHILOSOPHY = CODE · STATE = FILES
  ---------------------------------------------------------
  two layers, by design:
    · philosophy layer (CODE) — FlatBridge.PHILOSOPHY, a JS constant hard-coded
      in js/agent.js (ch-06.f7): the files' roles, the request→routed→done
      lifecycle, register-never-remember · append-only · stable-keys, the read
      order, the two-artifact deliverable. Injected into EVERY system prompt —
      any model, any config, any endpoint (native tools or <<<TOOL>>>
      text-protocol) — even with ZERO workspace files present. No runtime file
      reads required; the pattern cannot be lost.
    · state layer (FILES) — the live .flat.txt contents from the workspace
      root, appended on top of the philosophy layer when present: current
      statuses, plan.next, open requests. This is what the agent edits,
      line-by-line, per the flat conventions (routing §04).
  Any AI linked through the ADE's API therefore inherits the exact pattern on
  every turn — and any external AI session the user runs gets it from the
  files at the project root. Same protocol, everywhere, by construction.

PROMPT CACHING (m-29 — SESSION 6 DIRECTIVE, CRUCIAL)
----------------------------------------------------
The user's session-6 directive: robust prompt caching — send the project ONCE,
then only exchange the change iterations during patch tasks, then provide a
full zip profile back. Registered as m-29, routed to NEW chunk ch-12. Two
halves, by the established campaign split:

  PROTOCOL HALF — SHIPPED THIS SESSION (routing.flat.txt §01 ai.cache.*):
  · cache-001 seeded in planner meta.cache — the file manifest + short
    sha-256 hashes of the session-6 zip payload (the 15 non-ledger files;
    planner excludes ITSELF — it is the ledger and churns by design)
  · ai.cache.patch.recipe — a patch session receives CACHE (snapshot ref) +
    DELTA (only files whose hash drifted: full text ≤ 400 lines, else unified
    diff) + TASK (prompt recipe + chunk block) and returns patches + updated
    bridge lines — never a re-send of unchanged files
  · SHIP-BACK contract — the AI ships patches; the requesting side merges
    them onto the cached snapshot and re-zips the FULL project (the ADE
    automates this at ch-12.f4) — the deliverable side is unchanged
  · invalidation — any hash drift outside an applied patch = STALE →
    re-cache before further patch tasks
  · usable RIGHT NOW, manually: upload this zip ONCE to a fresh AI session,
    then run every later patch task as CACHE + DELTA + TASK

  PRODUCT HALF — QUEUED AS CH-12 (extensions wave · deps ch-06 · est 14k · M):
  · ch-12.f1 project profile cache — "Cache project profile" action builds a
    per-file short-sha-256 snapshot from the VFS, persisted in a NEW additive
    IndexedDB 'cache' store (ade-db v2 bump, ai.saves.rule safe)
  · ch-12.f2 send-once wiring — stable prefix ordering (system prompt →
    profile → volatile tail) for provider-side prompt caching; later turns
    carry only hash-drifted files
  · ch-12.f3 patch-task exchange — deltas apply onto the snapshot; live
    re-hash via the VFS.onWrite hook bus; "changes since snapshot" pill
  · ch-12.f4 full zip profile back — one-click merge + re-zip of the release
    set (fflate export, stamp bumped) + snapshot refresh
  · ch-12.f5 robustness — NONE · CACHED ✓ · STALE badges, boot + pre-turn
    staleness checks, per-config cache-mode toggle

SESSION-17 DECISIONS OF RECORD
------------------------------
  session type     : ROUTING, zero code — the user's pasted external advice
                     (Gemini + Sonnet) on token burn, triaged per m-41
  method           : verdicts settled against the SHIPPED CODE, not the
                     abstract — three targeted greps decided three of them
                     (buildContext's assistant mapping · buildSystemPrompt's
                     volatile-token audit · the request-body param list)
  adopted          : ch-12.f6 STABLE-PREFIX BYTE DISCIPLINE — the cacheable
                     prefix (system prompt + profile block) must be
                     byte-identical across turns; boot assertion re-builds
                     the prefix twice and fails loudly on drift; snapshot id
                     + hashes change only on re-cache; reasoning never
                     re-enters history (invariant, guarded here) ·
                     ch-12.f7 THINKING-EFFORT / EXTRA-BODY PASS-THROUGH —
                     per-config "extra request body (JSON)" merged verbatim
                     into the request so thinking {type:…} / reasoning_effort
                     / enable_thinking can be dialed per provider WITHOUT
                     hardcoding vendor semantics; invalid JSON errors
                     honestly BEFORE the request; default empty =
                     byte-identical body
  confirmed        : cache ORDERING — ch-12.f2 already specifies stable
                     prefix first / volatile tail last (the Gemini rule,
                     verbatim) · REASONING STRIPPING — buildContext maps
                     assistant rows to content + tool_calls ONLY
                     (agent.js 464-473); GLM reasoning_content feeds the ✦
                     viewer and NEVER re-enters the API payload
  rejected         : summarizer model (the flat ledger IS the running
                     summary — a second model drifts + double-spends) ·
                     planner/executor model split (the chunk system already
                     is plan-once/execute-many; single free-tier model) ·
                     framework state channels (no framework; buildContext IS
                     the filtered channel) · hard sliding window (would drop
                     early task constraints; the trim + eviction ladder
                     covers the fat — falsifiable revival condition: est-k
                     pill shows prose dominance) · bulk inline paste (m-38:
                     ~100k tokens for ONE 104KB read — inline is the
                     disease, digest + pagination the cure)
  why ch-12        : the adoptions ride plan.next instead of a 23rd chunk —
                     it owns the payload surface, and two features do not
                     justify a new chunk (one-chunk-per-session budget)
  ledger repairs   : planner §00 counters were STALE since session 16 (done
                     54 vs the true 56 — ch-22's shipped features were never
                     folded in; chunks 21 vs 22) AND a FOURTH grep audited
                     the feature denominator itself: the carried 85/87
                     totals were never equal to the countable chNN.fX.text
                     lines (a phantom from the early projections) —
                     re-anchored to the grep-able truth: 83 total · 56 done ·
                     routing meta.session.16 BACKFILLED (routing was not
                     touched in sessions 15→16) + meta.last-patch advanced
  cache            : refreshed → cache-012 — LEDGER-ONLY drift (4 bridge
                     files); code byte-identical to cache-011; stamps NOT
                     bumped (zero code shipped)

SESSION-16 DECISIONS OF RECORD
------------------------------
  session type     : ROUTING + HOTFIX HF-03 — field-report wave #3 (the
                     pre-15 host transcript + the user's live toggle report),
                     one small chunk shipped same-pass (session-13 precedent)
  debug pass       : scripts/verify_s15.py re-run against the staged s15
                     build — 30/30 PASS (boot · stamp · 13-tool registry ·
                     digest · pagination · eviction · 0 page errors) —
                     session 15 went through correctly; stamps moved only
                     AFTER the pass so the result is attributable to the
                     s15 build exactly as shipped
  m-38 routing     : the ~100k-token planner Q&A burn registered as ch-20
                     EVIDENCE — the fix already shipped (digest survey ≈1k
                     tok + read-economy + pagination); the remaining half is
                     ch-12 caching (plan.next, untouched)
  m-39 routing     : the host shell's non-POSIX shims (head "text file or
                     pipe input required" · grep pattern-first quirk ·
                     pyodide VFS miss · python -c stdout swallow) registered
                     as ch-21.f3/f4 EVIDENCE — the tool audit + gaps journal
                     turn this failure class into ledger data; host shells
                     are not the ADE shell — no POSIX assumptions
  root cause m-40  : the viewer's styles EXISTED but were JS-INJECTED at the
                     tail of agent.js (Agent._injectStyles, beside the tool-
                     trace rules) instead of living in css/ade.css — split
                     home, no pointer affordance on ✦/brain, and
                     noteReasoning's async panel creation raced the streaming
                     DOM — together the viewer read as "toggle does not work"
                     (a live-cascade probe caught the injected copy after the
                     first diagnosis said "css never written" — corrected);
                     also possible the report targets the HOST UI's own
                     auto-expand chip (same label) — ADE-side hardening ships
                     regardless
  shipped          : ch-22.f1 reasoning-viewer stylesheet consolidated into
                     css/ade.css (.think-panel display:none ⇄ .open block ·
                     .think-head info/mono · .think-auto label with accent-
                     color checkbox · .think-body 260px scrollable mono ·
                     pointer/hover affordances — marker ADE-S16.1) and the
                     DUPLICATE injected copy removed from agent.js · ch-22.f2
                     noteReasoning await fix (panel creation is async — the
                     un-awaited path raced the streaming DOM and could fill
                     a detached node — marker ADE-S16.2)
  files            : css/ade.css (block consolidated) · js/agent.js (duplicate
                     injected think-* copy removed from _injectStyles) ·
                     js/ui-chat.js · js/main.js + index.html + sw.js (release
                     stamps only) · manifest.flat.txt · planner.flat.txt ·
                     readme.txt · scripts/verify_s16.py
                     (NEW — 14 toggle + auto-expand assertions)
  verification     : headless-browser pass 14/14 — toggle opens/closes
                     (computed display block⇄none) · setting persists across
                     a full re-render · auto-expand opens mid-stream, checked
                     · repeat deltas leave exactly ONE panel · 0 page errors
                     · ch-20 registry intact (13 tools)
  ledger           : m-38 + m-40 done, m-39 open (36/40; open: m-29 → ch-12 ·
                     m-36/m-37/m-39 → ch-21) · denominators: features 54→56
                     (ch-22.f1/f2) · chunks 14→15 (ch-22) · requests 37→40 ·
                     cache-010 superseded → cache-011 = THIS zip
  design note      : the toggle keeps its existing default (off) — auto-
                     expand stays opt-in per the m-22 design; the fix
                     restores the FEATURE, it does not flip the default · a
                     Settings → Chat default-toggle for think_autoexpand
                     would fit ch-06.f3's tab if wanted (noted, not built)

SESSION-15 DECISIONS OF RECORD
------------------------------
  session type     : ITERATION — ran plan.next → CH-20, all 4 features in one
                     sweep, then stopped (ai.unit-of-work)
  shipped          : ch-20.f1 folder digest (fs_digest tool + `digest` cmd +
                     VFS.digest core + snapshot tail) · f2 tool-result
                     eviction · f3 read-economy rule in-prompt · f4 fs_read
                     pagination — markers ADE-S14.1…14.4 left
  files            : js/vfs.js (digest/digestTable) · js/agent.js (fs_digest
                     tool + ICONS · eviction pass in buildContext · prompt
                     rule 6 + TOOLS (13) map · fs_read pagination + schema)
  outside ch-20.files, justified : js/exec.js — the `digest` shell command
                     lives in Shell._cmds (the session-12 seed-delegation
                     precedent: the feature's own home is outside the chunk
                     list); js/main.js + index.html + sw.js — release
                     discipline stamps only (ade-s15-ch20 / ade-sw-vs15) ·
                     js/ui-workspace.js is LISTED in ch-20.files but needed
                     NO change — digest surfaces through the shell + agent
                     tool, and the tree already shows sizes (recorded per
                     ai.output.rule honesty)
  digest design    : reads the VFS ROWS (content + size already in IndexedDB)
                     instead of re-reading files — the survey is O(rows), not
                     O(bytes); dirs render as "d <path>/ (N items)" so the
                     table keeps structure; a file path digests as a one-row
                     table; the header line itself teaches the rule ("fs_read
                     ONLY what the task names")
  eviction design  : fires AFTER the whole-segment trim so the two economies
                     compose; soft trigger at 60% of contextK (the trim owns
                     100%, the stubs own 60%); stubs keep tool name + arg
                     summary + original size so a re-read is ON PURPOSE and
                     — with f4 shipped in the same sweep — a re-read is a
                     cheap slice; pairing contract preserved (assistant
                     tool_calls keep their stubbed tool rows); quiet by
                     design (no toast — the trace cards still show the user
                     everything)
  pagination design: slice header "[fs_read <path> · lines A–B of N]" on
                     every sliced read; over-cap whole reads flip to a
                     400-line head slice + honest skip note instead of a
                     blind mid-file char truncation; tail mode reports the
                     LEADING skip; past-EOF clamps with no fake note; _cap
                     stays as the belt-and-suspenders guard (+400 headroom
                     for header/notes)
  verification     : headless-browser pass, 30/30 — boot clean · stamp
                     ade-s15-ch20 · 13-tool registry · fs_digest (/ · /demo ·
                     file arg · missing path) · shell digest + help table ·
                     snapshot tail · READ ECONOMY + TOOLS (13) in-prompt ·
                     over-cap head slice + offset/limit slice + tail/head +
                     EOF clamp + small-file whole read · eviction stub exact
                     + active segment verbatim + pairing kept + persisted
                     rows untouched + proto path · 0 page errors
  ledger           : m-35 flipped done (34/37; open: m-29 → ch-12 · m-36/m-37
                     → ch-21) · denominators: features 50→54 · chunks 13→14 ·
                     cache-009 superseded → cache-010 = THIS zip

SESSION-12 DECISIONS OF RECORD
------------------------------
  session type     : ITERATION — ran plan.next → CH-06, all 7 features in one
                     sweep (ai.unit-of-work) — THE BUILD WAVE IS CLOSED
  shipped          : ch-06.f1 ADE system prompt + live tree snapshot ·
                     ch-06.f2 workspace auto-seed · ch-06.f3 budgets +
                     settings UI + usage pills · ch-06.f4 bandwidth policy
                     (m-23) · ch-06.f5 work-folder-first (m-25) · ch-06.f6
                     flat-file mastery (m-26) · ch-06.f7 FlatBridge.PHILOSOPHY
                     hard-embed (m-28) — markers ADE-06.1…06.7
  prompt size      : 5,466 chars ≈ 1.4k tokens with all layers + tree — of a
                     24k default context budget (philosophy block is byte-
                     stable → maximum provider-cache benefit at CH-12)
  seed edge case   : the workspace_seeded flag stamps ONLY on terminal
                     outcomes (done · failed · non-empty) — a mid-seed reload
                     (the HF-02 controllerchange reload on a first deploy)
                     retries next boot instead of locking a partial seed
  touched beyond   : js/ui-settings.js (f3's home — outside ch-06.files,
                     justified) · js/exec.js (seed delegates to
                     Main.seedWorkspace, 5 lines — the command's own ch-06.f2
                     forward-hook) · css/ade.css (usage-pill styles, 9 lines)
                     · sw.js + index.html (release discipline: SW_CACHE
                     ade-sw-vch06 · ?v=ade-s12-ch06)
  verification     : headless-browser pass — full auto-seed lands (8 files:
                     4 real flat files fetched over http + demo set) · prompt
                     contains all layers · budgets save/apply round-trip ·
                     seed idempotent · agent tab renders with live rows ·
                     0 page errors
  ledger           : 7 requests flipped done (m-01 umbrella · m-05 · m-16 ·
                     m-23 · m-25 · m-26 · m-28) — 30/31 done, only m-29
                     (prompt caching → ch-12) open · plan.next = ch-07 —
                     the EXTENSION WAVE opens (ch-07…ch-12 in id order)
  denominators     : features 61→68 (ch-06.f1…f7 done) · chunks 16→17 (10
                     done) · cache-006 superseded → cache-007 = THIS zip

SESSION-11 DECISIONS OF RECORD
------------------------------
  session type     : ROUTING (user instruction: "turn it into routing session,
                     bump up patches to be next in line") — with the trio
                     shipped in the same pass because the implementation was
                     already complete and browser-verified in-tree
                     (user: "dont revert code · notate carefully")
  registration     : m-31 field report (site updated, page loads old
                     configurations from local cache · "maybe a worker file
                     to refresh?")
  routing          : split into the PATCH TRIO — ch-14 (sw.js refresh worker)
                     · ch-15 (?v busting + build stamp + force refresh) ·
                     ch-16 (settings-schema migration) — bumped next-in-line
                     ahead of ch-06; all three done this session; plan.next
                     = ch-06 stands (queue note in planner §01)
  refresh policy   : deploy always beats cache — network-first worker + ?v=
                     busting + migration; per-release discipline: bump SW_CACHE
                     in sw.js AND both ?v= strings in index.html AND the
                     ADE_BUILD stamp in main.js with every shipped build
  migration policy : settings-schema versioning (schema_v · v2 = keyed-proxy
                     era); future releases bump SETTINGS_SCHEMA_VERSION in
                     db.js and append a step in migrate() — never rewrite user
                     data silently, secrets always preserved (ai.saves.rule)
  verification     : headless-browser pass on localhost — clean boot (0 page
                     errors) · SW registers + takes control · exactly one
                     controllerchange reload (no loop) · build stamp renders
                     ade-s11-hf02 · seeded legacy config (keyless template +
                     missing agent fields) migrated on reload with apiKey/name
                     preserved · schema_v=2 stamped · Proxy Setup tab
                     regression green (key field · status row · test ping)
  denominators     : features 55→61 (ch-14.f1-f2 · ch-15.f1-f2 · ch-16.f1-f2)
                     · chunks 13→16 · requests 30→31, m-31 done (23/31) ·
                     cache-005 superseded → cache-006 = THIS zip

SESSION-9 DECISIONS OF RECORD
-----------------------------
  session type     : ITERATION — ran plan.next → CH-05, all 6 features in one
                     sweep, then stopped (ai.unit-of-work)
  shipped          : ch-05.f1 tool registry · f2 agent loop · f3 tool trace
                     UI · f4 text-protocol fallback · f5 context trim ·
                     f6 thinking viewer (m-22) — markers ADE-05.1…05.6 left
  files            : js/agent.js (FULL REPLACEMENT of the 21-line CH-01 stub
                     — diff impractical, the stub carried no code) ·
                     js/ui-chat.js (send() delegates to Agent.runAgent ·
                     streamChat/resolveUrl MOVED to agent.js · finalize kept
                     as the agent's callback · tool-card + think-panel UI)
  outside ch-05.files, justified : js/main.js — ADE_BUILD stamp bump only
                     (same as sessions 7/8) · css/ade.css untouched — trace
                     + think-panel styles are INJECTED by agent.js at runtime
                     (a <style> block reusing the P1-P20 tokens, the CH-04
                     pattern) · index.html untouched (script tags never move)
  handoff room     : buildSystemPrompt + buildContext left as single named
                     entry points — CH-06.1 replaces the prompt body, ch-06.f7
                     injects FlatBridge.PHILOSOPHY, CH-12 wraps both for
                     ai.cache.* (per worklogs 6 + 8)
  tool backends    : the registry EXECUTES on the real stack — fs_* over the
                     CH-02 VFS (writes mirror via the CH-03 bus) · shell =
                     Exec.Shell.run(silent) · run_python/run_js = Exec ·
                     open_preview = Exec.preview · run output captured by
                     TEMPORARILY wrapping ConsoleUI.line (restored after) so
                     tool results carry real stdout, not just exit status
  run_js inline    : inline code goes to a temp /tmp/agent-*.js row, runs,
                     the row is deleted (trace keeps the code visible in ARGS)
  trim design      : segments anchor at USER messages — an assistant
                     tool_calls block and its role:tool results always share
                     a segment, so a trim can never orphan a pair; budget
                     floors at 4k (Math.max(4, contextK)); system kept always
  fallback design  : ONE retry on 400/404/422 whose body mentions
                     tools/functions; proto is then STICKY for the run; the
                     visible reply strips the <<<TOOL>>> line; results map
                     back as role:user TOOL_RESULT turns; bad JSON → the
                     model gets a corrective tool-error row, not a crash
  smoke test       : headless-browser pass, 42/42 — boot clean · 12 schemas
                     + icons · 10 execTool round-trips on the real VFS ·
                     cap notes · proto parser (good/bad/none) · trim keeps
                     pairs + drops oldest + system first · tool-card expand +
                     copy · think panel lazy open/toggle · FULL loop via
                     mocked SSE (tool executed → /loop.txt in VFS → final
                     summary → reasoning persisted → nothing unpersisted) ·
                     fallback path (400 → tool-less retry → TOOL_RESULT
                     turn → sticky) · zero page errors
  denominators     : features 19→25 (ch-05.f1…f6 done) · chunks 4→5 · requests
                     20→21 done (m-22 flipped) · cache refreshed: cache-004
                     (cache-003 superseded)

SESSION-8 DECISIONS OF RECORD
-----------------------------
  session type     : ITERATION — ran plan.next → CH-04, all 4 features in one
                     sweep, then stopped (ai.unit-of-work)
  shipped          : ch-04.f1 python runner · ch-04.f2 js runner · ch-04.f3
                     html preview · ch-04.f4 virtual shell + run console —
                     markers ADE-04.1…04.4 left
  files            : js/exec.js (FULL REPLACEMENT of the 17-line CH-01 stub —
                     diff impractical, the stub carried no code) ·
                     js/ui-workspace.js (run action → real Exec.run + console
                     toggle button in the header actions)
  outside ch-04.files, justified : NONE — console/preview styles are INJECTED
                     by exec.js at runtime (a small <style> block reusing the
                     P1-P20 tokens), so css/ade.css stays untouched ·
                     index.html untouched (all new UI is JS-built) · main.js
                     untouched (no boot change needed)
  bandwidth (m-23) : pyodide pull = explicit confirm dialog stating ≈10MB,
                     asked ONCE ever (settings 'pyodide_pull'), self-fetched
                     release at vendor/pyodide/ auto-detected via HEAD probe
                     and skips the pull · every package auto-load announces
                     its size in the console · micropip installs confirm
                     first · the prebuilt set loads from the SAME jsDelivr
                     origin the core came from (browser-cached)
  pyodide runtime  : one shared dedicated worker, boot-time ~2.2s observed in
                     smoke · snapshot → /ws before each run, /ws walked after,
                     per-file diff → VFS.put (write-through mirrors) ·
                     timeout kill = worker.terminate() + full reload next run
  js runner design : user source travels INSIDE the worker blob as a JSON
                     string (zero escaping pitfalls) and executes as an
                     AsyncFunction body — top-level await AND top-level
                     return work; eval-based approach was tried and rejected
                     (await not valid in direct eval strict context)
  smoke test       : headless-browser pass — boot clean · js: console bridge
                     (log+error), return values, throw propagation, await ✓
                     · python: REAL jsDelivr pull approved via the m-23 dialog
                     → ready 2.2s → file run stdout streamed → python-written
                     file synced back into VFS ✓ · preview: link/script/img
                     all inlined, sandbox attrs exact, bridge routed ✓ ·
                     shell: 20+ command assertions incl. && chain, > >>,
                     quotes, grep file+dir, cp/mv, tree, find, wc, unknown-
                     command error, cwd persistence ✓ · zero page errors
  bugs caught+fixed in sweep : AsyncFunction swap for eval (await-in-eval
                     invalid) · grep dangling-else (file targets never
                     pushed) · _pyPickPkgs greedy \s across lines (missed
                     from-imports) · hardened not-found returns to {ok:false}
  denominators     : features 15→19 (ch-04.f1…f4 done) · chunks 3→4 · requests
                     16→20 done (m-04, m-06, m-07, m-08 flipped) · cache
                     refreshed: cache-003 (cache-002 superseded)

SESSION-7 DECISIONS OF RECORD
-----------------------------
  session type     : ITERATION — ran plan.next → CH-03, all 5 features in one
                     sweep, then stopped (ai.unit-of-work)
  shipped          : ch-03.f1 link flow · ch-03.f2 session persistence +
                     reconnect · ch-03.f3 write-through + pull/push ·
                     ch-03.f4 badge states + safety · ch-03.f5 m-24 structure
                     tooltip — markers ADE-03.1…03.5 left
  files            : js/vfs.js (VFS.FSA module + mkdirp now emits "mkdir" per
                     created row + _emit gained an info arg: rm.recursive ·
                     mv.from — additive) · js/ui-workspace.js (badge click-
                     routing · renderHeaderActions with pull/push while
                     linked · renderBackend/badgeHtml · editor-save toast
                     updated) · js/main.js (FSA boot restore + stamp bump)
  outside ch-03.files, justified : NONE — css/ade.css untouched (badge state
                     colors are inline styles on the existing .ws-backend
                     class; a full styling pass can ride a later chunk) ·
                     index.html untouched (header actions are JS-rendered)
  write-through    : hangs off the CH-02 VFS.onWrite bus exactly as planned
                     (fire-and-forget — mirroring never slows or breaks the
                     VFS op); covers put · mkdir · rm (recursive) · mv
                     (remove old + write new subtree); _bulk guard suppresses
                     re-mirroring during pull/push (one refresh at end)
  pull semantics   : wholesale import per m-24 layout — pull OVERWRITES the
                     VFS (documented conflict rule); junk skipped; >8MB
                     binaries skipped; per-entry errors skip-and-count
  smoke test       : headless-browser pass — boot clean (http) · badge state
                     renders for none/linked/reconnect/unsupported + tooltip
                     zip-fallback text · REAL-handle round-trip via OPFS
                     (same FSA API): write-through put/mv/rm · pull (junk
                     skipped, count correct) · push (disk overwritten) ·
                     regression: put/re-read/rm/zip-export all pass · zero
                     page errors
  denominators     : features 10→15 (ch-03.f1…f5 done) · chunks 2→3 · requests
                     13→16 done (m-11, m-18, m-24 flipped) · cache refreshed:
                     cache-002 (cache-001 superseded per ai.cache.invalidate)

SESSION-6 DECISIONS OF RECORD
-----------------------------
  directive scope  : BOTH faces — the campaign protocol (usable now, manual)
                     AND the finished product (ch-12, automated)
  registration     : m-29 (crucial, user-flagged) — registered manifest §09,
                     routed ch-12 per ai.new-chunk.rule
  routing verdict  : keyword sweep found only an incidental ch-09 hit ("zip")
                     — intent is agent-context caching, no open chunk matches
                     → NEW chunk ch-12 (extensions wave, next free id; the
                     build wave ch-01…ch-06 is untouched)
  plan.impact      : plan.next UNCHANGED (ch-03) — ch-12 deps ch-06 so it
                     cannot run early; promote via meta.plan.then if wanted
  denominators     : features 48→53 (ch-12.f1…f5) · chunks 11→12 · requests
                     28→29 · cache.count 0→1 (cache-001)
  cache seed       : cache-001 = this zip (the session-6 payload) — manifest
                     + est-token total live in planner meta.cache
  self-application : session 6 itself ran the pattern it registers — the
                     project arrived ONCE (the zip upload), only bridge-file
                     edits were exchanged, and the full zip ships back
  code             : NONE this session — routing-only per ai.session.types

SESSION-5 DECISIONS OF RECORD
-----------------------------
  session type     : ITERATION — ran plan.next → CH-02, all 5 features in one
                     sweep, then stopped (ai.unit-of-work)
  shipped          : ch-02.f1 VFS core · ch-02.f2 file tree UI · ch-02.f3 CRUD
                     + editor · ch-02.f4 zip import/export (fflate vendored) ·
                     ch-02.f5 upload integration — markers ADE-02.1…02.5 left
  outside ch-02.files, justified : index.html gained ONE line (the
                     js/vendor/fflate.min.js script tag, loads before vfs.js;
                     the 9-tag order untouched) · js/ui-chat.js storeBinaryAtts
                     now routes zip attachments through VFS.importZip (the
                     ch-01.f5 note explicitly deferred extraction to ch-02.f4)
                     · js/main.js stamp bump only
  zip semantics    : import NEVER silently overwrites (collisions skipped +
                     counted in the toast) — direct uploads DO overwrite via
                     put (re-upload-your-edit semantics) · zip-slip contained:
                     every entry name passes the .. -safe norm() before it can
                     touch a path · __MACOSX / .DS_Store junk skipped
  forward hooks    : VFS.onWrite listener bus installed now — CH-03 write-
                     through and CH-10 live reload plug in without re-touching
                     the core · tree's run/preview action calls Exec.run the
                     moment CH-04 provides it
  smoke test       : headless-browser pass — boot (http + file://) · tree
                     render · expand/collapse · editor round-trip · rename ·
                     recursive delete via confirm · mv subtree re-path · zip
                     export → wipe → re-import · zip-slip attempt contained ·
                     reload persistence (cwd · expanded · panel open)
  denominators     : features 5→10 (ch-02.f1…f5 done) · chunks 1→2 · requests
                     11→13 done (m-09, m-10 flipped) · no new requests

SESSION-4 DECISIONS OF RECORD
-----------------------------
  directive scope  : PRODUCT capability (like session 3's m-23) — the ADE
                     itself must master the protocol; campaign flow unchanged
  registration     : m-26 (flat-file mastery) · m-27 (root-level invariant,
                     done this session as routing §07 build.flatfiles.root) ·
                     m-28 (hard-embedded philosophy via JS) — m-26/m-28 open,
                     routed ch-06
  routing          : m-26 → ch-06.f6 (system prompt teaches the exact anatomy
                     + function of all 3 files) · m-28 → ch-06.f7
                     (FlatBridge.PHILOSOPHY JS constant, failsafe layer,
                     CH-05's agent.js replacement must carry it forward) ·
                     m-27 → routing §07 build.flatfiles.root (no new feature
                     line needed — the invariant already holds everywhere)
  design split     : philosophy = CODE (model-agnostic, survives missing
                     files) vs state = FILES (live statuses, edited line-by-line)
  denominators     : features 46→48 (ch-06.f6, ch-06.f7) · requests 25→28 ·
                     ch-06.est.k 14→17 (still size M)
  code             : NONE this session — the embed ships with CH-06 per
                     ai.unit-of-work; plan.next stays ch-02

SESSION-3 DECISIONS OF RECORD
-----------------------------
  constraint scope : PRODUCT-only (user correction mid-session) — governs the
                     finished ADE + its agent, NOT the campaign sessions
  registration     : m-23 (bandwidth) · m-24 (work-folder structure) ·
                     m-25 (workdir persistence) — all open, routed
  routing          : m-23 → ch-06.f4 (agent tool policy) + ch-02.f4 / ch-04.f1 /
                     ch-08.f1 (lib acquisition) · m-24 → ch-03.f5 + routing §07
                     build.fsa.structure + readme §WORK FOLDER · m-25 → ch-06.f5
                     (+ ch-03, which m-18 already owns)
  libs             : fflate → build-time vendored js/vendor/fflate.min.js ·
                     pyodide → one approved pull (~10MB, stated) + browser cache,
                     or self-fetched release in vendor/pyodide/ · codemirror →
                     vendored or omitted — zero runtime CDNs in all cases
  denominators     : features 43→46 (ch-03.f5, ch-06.f4, ch-06.f5) · requests
                     21→25 (fixes stale session-2 count)

SESSION-2 DECISIONS OF RECORD
-----------------------------
  stub strategy       : vfs/exec/agent/ui-workspace ship as marked stubs so
                        index.html script tags are FROZEN in final load order
                        — CH-02/04/05 are pure file replacements
  vfs row shape       : CH-01's /imports rows already use the final CH-02
                        shape (path · kind · parent · isText · content · size
                        · mtime) — additive-only, nothing migrates later
  zip extraction      : deferred to ch-02.f4 (fflate lands there)
  streamChat location : ui-chat.js for CH-01; moves into agent.js at CH-05
  m-22 (thinking)     : registered mid-run per ai.interrupt.rule → routed
                        ch-05.f6; CH-01 captures reasoning_content already

SESSION-1 DECISIONS OF RECORD (unchanged)
-----------------------------------------
  static-first verdict : FEASIBLE — full matrix in routing.flat.txt §06
  real OS console      : statically impossible (browser sandbox) → virtual
                         shell now, optional local bridge later (CH-07)
  structure            : actively split css/js per best practice (your m-17 —
                         SHIPPED this session)
  persistence          : FSA handle session-persistent via IndexedDB (m-18)
================================================================================

/* ============================================================
   js/main.js — ADE-01.1 · init + wiring + first-run seed
   boots db → state → UI; seeds the default GLM config (f3);
   wires sidebar / header / config select / settings / workspace.
   ADE_BUILD stamps the console about line (readme ↔ code).
   HF-02 (m-31): boots the cache-refresh worker (sw.js) — network-
   first + versioned cache purge make every deploy win; reloads
   ONCE when a new worker takes control (controllerchange); runs
   the settings migration (DB.migrate) so stale stored configs
   pick up new defaults; sidebar shows the build stamp + a one-
   click "clear caches + reload" button (Main.forceRefresh).
   ============================================================ */
"use strict";

const ADE_BUILD = {
  version: "ade-s31-hf17",
  stamp: "SESSION 31 — HF.17 (the tools-registry decoupling + web tool S0 — user call: 'seamlessly decouple tools from their current structure, place them under js/tools/<name>.js so the tool list is easier to maintain, then route the web tool'): (1) TOOLS REGISTRY — all 30 hf.16 tool case bodies moved VERBATIM out of agent.js into self-registering js/tools/<name>.js files (ADETools.register({name, description, parameters, icon, run})); agent.js composes TOOLS/ICONS from the registry (TOOLS: ADETools.schemas() · ICONS: ADETools.icons()) and execTool dispatches via ONE ADETools.dispatch call — the 30-case switch is gone; adding a tool = drop one file + one script tag; TOOLS order = tag order, pinned in js/tools/_pinned_order.json + asserted by tests; schema/icon equivalence with hf.16 verified EXACT by the extraction codemod (byte-identical schema lines, key-set icons); a throwing/rejecting tool reports via done() with the hf.16 catch text — execTool still never throws; (2) WEB TOOL 31 (S0 scaffold of the multi-session web plan) — new js/tools/web.js: bind/pull/push/share answer 'not yet: S#' per plan §6.2, web test prints the key/lane status banner; Settings → Proxy Setup gains the Web & Sync key panel (localStorage: github_pat · neocities_api_key · webtool_proxy_url — keys never leave the browser); plan-D6 transport lanes (gh/raw/tmpfiles direct · neocities via the {corskey} tunnel template) wired in the S0 helpers, sessions S1–S5 fill the ops; (3) prompt teaching TOOLS 30→31 + web arg-names line; hf.16 behavior regression-locked by tests/test-hf11..16 (loader block feeds the registry before agent.js) + new tests/test-hf17.mjs (registry contract + web scaffold + pinned order) · PATCHLOG §03i · 2026-11-01",
  chunk: "carries hf.16 (debug ledger ade.debug.flat.txt + BURN 🐛 session-copy button · head/tail multi-file chunked read tools · grep 0-hit probe hint · f3 dropped-turn ledger with tool-arg digests + report heads · stale-RESUME-STATE guard on continues · verified-DONE nudge wording), hf.15 (batched-slice reads + chunked grep output + the file token burn panel), hf.14 (the 30 KB LARGE-FILE line + seamless chunking + multi-path coercion + honest NOT FOUND + nudge-safe segments), hf.13 (per-chat clock + composer draft persistence), hf.12 (multi-file read/find/edit/append + grep extractor + empty-response auto-shrink), hf.11 (chunked big-write tool + one-word tool names + quiet errors), hf.10 (ledger chunker suite split/scan/check/assemble + mid-run state checkpoints + shell per-line cap) and s25 wave 2 (ch-32 run-lifecycle hardening)"
};

const Main = {
  _swReloaded: false, /* controllerchange reload guard (in-memory — reset by the reload itself) */

  async init() {
    await DB.init();
    this.registerSW(); // fire-and-forget — installs while the rest boots

    // PATCH 3/3 (ch-16.f2, marker ADE-HF2.6) — settings migration BEFORE
    // state loads: upgrades stored configs from old builds (dead keyless
    // proxy templates · missing agent fields) and stamps the schema
    // version; toasts when it changed anything
    let migrated = null;
    try { migrated = await DB.migrate(); } catch { /* never block boot */ }
    if (migrated && migrated.changed.length) {
      setTimeout(() => U.toast("Configurations updated", {
        kind: "ok",
        msg: `migrated ${migrated.changed.length} stale setting(s) to ${ADE_BUILD.version} — old local cache settings no longer shadow this build`,
        ms: 6000
      }), 600);
    }
    DB.setSetting("last_seen_build", ADE_BUILD.version).catch(() => {});

    // load state
    State.configs = await DB.allConfigs();
    State.corsKey = (await DB.getSetting(SK.CORS_KEY)) || "";
    State.activeConfigId = await DB.getSetting(SK.ACTIVE_CONFIG);
    State.agentMaxSteps = await DB.getSetting(SK.AGENT_MAX_STEPS);   // CH-06 budget defaults (null = factory 24)
    State.agentContextK = await DB.getSetting(SK.AGENT_CONTEXT_K);

    // first-run seed — one default config (ADE-01.3)
    if (!State.configs.length) {
      const c = makeDefaultConfig();
      await DB.saveConfig(c);
      State.configs = [c];
      State.activeConfigId = c.id;
      await DB.setSetting(SK.ACTIVE_CONFIG, c.id);
      setTimeout(() => U.toast("Welcome to ADE", {
        kind: "info",
        msg: "Seeded config \"" + c.name + "\" — add your AiHubMix key in Settings → Configs, CorsProxy key in Proxy Setup.",
        ms: 6000
      }), 400);
    }
    if (!State.configs.find(c => c.id === State.activeConfigId)) {
      State.activeConfigId = State.configs[0]?.id || null;
    }

    // wire UI
    ChatUI.initComposer();
    ChatUI.initSidebar(); // ADE-S18.1 (ch-23, m-42) — conv open/rename/delete were NEVER wired
    SettingsUI.init();
    WSUI.init();
    SchedUI.init(); // ADE-S18.7 (ch-25, m-44) — task scheduler engine + window (fire-and-forget boot)
    Agent.Cache.bootCheck(); // ADE-12.5 (ch-12, m-29) — boot staleness diff + f6 byte-discipline assertion (fire-and-forget, never blocks boot)

    // ADE-03.2 — FSA session persistence: restore the 'wsdir' handle from
    // IndexedDB → granted = silently relink (+ background wholesale pull) ·
    // 'prompt' = arm the one-click RECONNECT badge · denied = clear + toast.
    // Fire-and-forget: boot never waits on the folder.
    if (VFS.FSA.supported()) VFS.FSA.boot();
    else VFS.FSA.setState("unsupported"); // badge explains the zip fallback
    // ADE-S13.1 (ch-17.f2, m-32): work-folder AUTO-IMPORT triggers — the 20s
    // merge-newer poll + visibilitychange refresh live in FSA.startAutoSync();
    // link/boot/pre-agent-run call syncFromFolder() directly. Honors fsa_autosync.
    VFS.FSA.startAutoSync();

    document.getElementById("new-chat-btn").addEventListener("click", () => ChatUI.newConversation());
    document.getElementById("toggle-sidebar").addEventListener("click", () => this.toggleSidebar());
    document.getElementById("sidebar-backdrop").addEventListener("click", () => this.toggleSidebar(false));
    document.getElementById("app-refresh-btn").addEventListener("click", () => this.forceRefresh()); // HF-02
    this.initInstall(); // ADE-S21.4 (ch-27.f4, m-47) — installable PWA flow
    this.wireConfigSelect();

    // restore session
    const lastConv = await DB.getSetting(SK.ACTIVE_CONV);
    await ChatUI.renderSidebar();
    if (lastConv && State.convs.find(c => c.id === lastConv)) {
      await ChatUI.openConversation(lastConv);
    } else {
      ChatUI.renderThread();
    }
    const wsOpen = await DB.getSetting("ws_panel_open");
    if (wsOpen) WorkspaceUI.toggle(true);

    // ADE-06.2 — workspace auto-seed: first boot with an empty VFS pulls the
    // 4 flat files from the hosting directory (the zip IS the seed) + writes
    // the demo set; fetch fails (file://) → embedded short stubs instead.
    // The flag is stamped ONLY on a terminal outcome (done · failed ·
    // non-empty workspace) — never before — so a mid-seed reload (e.g. the
    // HF-02 controllerchange reload on a first deploy) simply retries next
    // boot. Re-seed anytime via console `seed`.
    if (!(await DB.getSetting(SK.WORKSPACE_SEEDED))) {
      const empty = await VFS.count().then(c => c.files === 0).catch(() => false);
      if (empty) {
        this.seedWorkspace().then(async r => {
          await DB.setSetting(SK.WORKSPACE_SEEDED, true).catch(() => {});
          if (r.made) U.toast("Workspace seeded", {
            kind: "ok",
            msg: `${r.made} file(s) — flat bridge ${r.fetched ? "fetched from the site" : "stubs (file:// fallback)"} + demo set. Re-seed anytime: console → seed.`,
            ms: 6500
          });
        }).catch(() => DB.setSetting(SK.WORKSPACE_SEEDED, true).catch(() => {}));
      } else {
        DB.setSetting(SK.WORKSPACE_SEEDED, true).catch(() => {}); // existing workspace — mark seen, never auto-seed over it (console `seed` is opt-in)
      }
    }

    this.renderHeaderConfig();
    this.renderBuildStamp();
    this.startClock(); // hf.11 — header session clock (time since session start + exact tok/min)

    console.log(`%cADE %c${ADE_BUILD.version} · ${ADE_BUILD.stamp}`,
      "color:#d4893a;font-weight:bold", "color:#999490");
  },

  /* ── ADE-S21.4 (ch-27.f4, marker ADE-S21.4) · installable PWA flow ──
     captures beforeinstallprompt (Chrome/Edge/Android — Safari uses
     Share → Add to Home Screen, no event), reveals the sidebar install
     button, and prompts on click; appinstalled hides it again + toasts.
     Main._installReady lets tests assert the flow without a real prompt. */
  _deferredPrompt: null,
  _installReady: false,

  initInstall() {
    const btn = document.getElementById("install-btn");
    if (!btn) return;
    window.addEventListener("beforeinstallprompt", (e) => {
      e.preventDefault();          // keep ADE's own affordance, not the mini-infobar
      this._deferredPrompt = e;    // stash for the click prompt
      this._installReady = true;
      btn.style.display = "";      // reveal the download button
    });
    btn.addEventListener("click", async () => {
      if (!this._deferredPrompt) return;
      try {
        this._deferredPrompt.prompt();
        const { outcome } = await this._deferredPrompt.userChoice;
        if (outcome === "accepted") U.toast("ADE installed", {
          kind: "ok",
          msg: "runs from its own window · shell + workspace work offline — AI turns still need the network (DEPLOY.txt)"
        });
      } catch { /* prompt canceled or unavailable — button stays for a retry */ }
      this._deferredPrompt = null;
    });
    window.addEventListener("appinstalled", () => {
      btn.style.display = "none";  // installed — the affordance has done its job
      this._installReady = false;
      this._deferredPrompt = null;
      U.toast("ADE installed", {
        kind: "ok",
        msg: "launch it from your home screen / apps — the offline worker keeps the shell cached (SW_CACHE ade-sw-vs24)"
      });
    });
  },

  /* ── HF-02 · PATCH 1/3 (ch-14.f2, marker ADE-HF2.2) · cache refresh worker ──
     registers sw.js (secure contexts only — https / localhost);
     network-first inside the worker means every deploy wins, the
     versioned-cache purge drops older builds, and controllerchange
     reloads the page ONCE so fresh code runs without a manual
     hard-refresh. file:// and non-https hosts skip silently — the
     ?v= busting on the index.html asset tags covers those. */
  registerSW() {
    if (!("serviceWorker" in navigator)) return;
    navigator.serviceWorker.register("sw.js", { updateViaCache: "none" })
      .then(reg => {
        /* pick up deployed updates whenever the tab becomes visible again */
        document.addEventListener("visibilitychange", () => {
          if (document.visibilityState === "visible") reg.update().catch(() => {});
        });
      })
      .catch(() => { /* insecure context or host forbids sw — ?v= covers it */ });
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (this._swReloaded) return; // one reload per update — never loop
      this._swReloaded = true;
      location.reload(); // the new worker has fresh code queued — go load it
    });
  },

  /* sidebar build stamp + one-click force refresh — PATCH 2/3
     (ch-15.f2, marker ADE-HF2.4): the at-a-glance "is my deploy
     live" check — the stamp must equal the ADE_BUILD.version of
     the latest zip, else the page is running cached code (and the
     refresh arrow forces the newest build in) */
  renderBuildStamp() {
    const el = document.getElementById("build-stamp");
    if (el) el.textContent = ADE_BUILD.version;
  },

  /* ══ hf.13 · CHAT CLOCK (per-chat — replaces the hf.11 tab-session clock) ══
     Field report (2026-10-31): the hf.11 clock anchored at the browser TAB
     and Σ'd State.sessionTokens across EVERY chat, so a 57-min tab that ran
     two ~600k-tok projects + a ~300k one showed one never-resetting timer
     and a nonsense blended rate (4470 tok/min). The user reads the clock
     PER CHAT — so both numbers now anchor to the ACTIVE conversation:
     · elapsed  = now − conv.ts (chat creation) → a NEW chat restarts at
       0:00, switching chats swaps the anchor, a reload shows the same
       chat-age again (conv.ts lives in IndexedDB — deterministic);
     · tokens  = Σ usage.t over the chat's OWN assistant rows (State.msgs,
       exact API-reported burn persisted per message in ChatUI.finalize) —
       no other chat's burn can leak into the number; estimated rows are
       never counted;
     · tok/min = tokens ÷ elapsed minutes (1-minute floor) — the chat's
       true average burn rate, no cross-chat mixing.
     State.sessionTokens (tab-lifetime Σ) is still maintained in finalize
     and shown in the tooltip as the secondary figure. 1 Hz tick, text
     swap only — no thread re-render, no scroll reset. Math in
     Main.chatClock() — kept pure so tests can pin it. */
  chatClock() {
    const conv = State.convs.find(c => c.id === State.activeConvId);
    const start = (conv && conv.ts) || (State.msgs[0] && State.msgs[0].ts) || Date.now();
    const elapsed = Math.max(0, Date.now() - start);
    let tok = 0;
    for (const m of State.msgs) {
      const t = m && m.role === "assistant" && m.usage && Number(m.usage.t);
      if (Number.isFinite(t) && t > 0) tok += t;
    }
    const perMin = Math.round(tok / Math.max(1, elapsed / 60000)); // 1-minute floor — no absurd spikes in the first seconds
    return { elapsed, tok, perMin };
  },
  startClock() {
    const el = document.getElementById("hdr-clock");
    if (!el) return;
    const fmt = (ms) => {
      const s = Math.max(0, Math.floor(ms / 1000));
      const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
      return (h ? h + ":" + String(m).padStart(2, "0") : String(m).padStart(2, "0")) + ":" + String(ss).padStart(2, "0");
    };
    const tick = () => {
      const { elapsed, tok, perMin } = this.chatClock();
      const life = State.sessionTokens || 0;
      el.innerHTML = `<i class="fa-regular fa-clock"></i> <b>${fmt(elapsed)}</b><span class="clock-sep">·</span><span class="clock-tok">${U.fmtTokens(tok)} tok · ${perMin}/min</span>`;
      el.title = `this chat: ${fmt(elapsed)} since it started · ${tok.toLocaleString()} exact API-reported tokens in THIS chat · ≈${perMin} tok/min (rate floors at 1 minute; estimated rows are not counted) · hf.13: the clock is per-chat — a new chat restarts it and other chats' burn never mixes in (tab lifetime Σ: ${life.toLocaleString()} tok)`;
    };
    tick();
    setInterval(tick, 1000);
  },

  /* one-click escape hatch (sidebar refresh arrow): wipe every SW cache,
     nudge the worker to update, then reload — the ?v= tags do the rest */
  async forceRefresh() {
    try {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    } catch { /* no Cache API — reload is still the fix */ }
    try {
      const reg = await navigator.serviceWorker?.getRegistration();
      await reg?.update();
    } catch { /* no SW here */ }
    location.reload();
  },

  /* ── ADE-06.2 · WORKSPACE AUTO-SEED (ch-06.f2) ──
     the zip IS the seed: on a static host the 4 flat files are
     fetched from the hosting directory into the VFS root; under
     file:// the fetch fails and short embedded stubs are written
     instead (role + pointer to the zip). Demo files always land.
     Idempotent — existing files are never overwritten; the console
     `seed` command (exec.js) delegates here for explicit re-seeds. */
  async seedWorkspace() {
    const stubs = {
      "routing.flat.txt": "routing.flat.txt (STUB — file:// fallback)\n================================================\nThe PROTOCOL file of the ADE campaign: session types · plan.next · budget · prompt recipe · save rules.\nThis is a short stub written because the browser could not fetch the real file (file:// host).\nThe canonical copy ships in \"5.3 flash free ADE.zip\" — unzip it next to this page or host it and re-run: seed.",
      "manifest.flat.txt": "manifest.flat.txt (STUB — file:// fallback)\n==================================================\nThe REQUEST LEDGER: every user request is one m-NN record (text · status · routed · note).\nShort stub — the canonical file ships in \"5.3 flash free ADE.zip\". Re-run: seed after hosting.",
      "planner.flat.txt": "planner.flat.txt (STUB — file:// fallback)\n===============================================\nThe WORK PLAN: ch-NN chunk blocks (title · size · status · deps · files · fX features) + §12 worklog.\nShort stub — the canonical file ships in \"5.3 flash free ADE.zip\". Re-run: seed after hosting.",
      "readme.txt": "readme.txt (STUB — file:// fallback)\n========================================\nThe build + expectations document: what exists now, what ships next.\nShort stub — the canonical file ships in \"5.3 flash free ADE.zip\"."
    };
    let made = 0, fetched = 0, stubbed = 0;
    for (const [name, stub] of Object.entries(stubs)) {
      if (await VFS.exists("/" + name)) continue;
      try {
        const res = await fetch(name, { cache: "no-cache" });
        if (!res.ok) throw new Error(String(res.status));
        await VFS.put("/" + name, await res.text(), true);
        made++; fetched++;
      } catch {
        await VFS.put("/" + name, stub, true);
        made++; stubbed++;
      }
    }
    /* demo set — byte-identical to the console `seed` command's originals */
    const put = async (p, c) => { if (!(await VFS.exists(p))) { await VFS.put(p, c, true); made++; } };
    await put("/README.txt", "ADE workspace quickstart\n\n- left: chat (your GLM config) · right: this workspace\n- run .py / .js / .html from the file tree's play action\n- link a real disk folder with the LINK WORK FOLDER badge\n- console: the terminal button opens the virtual shell\n");
    await put("/demo/hello.py", "import sys\n\nprint(\"hello from pyodide\", sys.version.split()[0])\nfor i in range(3):\n    print(\"  line\", i)\n");
    await put("/demo/index.html", "<!DOCTYPE html>\n<html><head><title>demo</title></head>\n<body><h1>ADE demo page</h1>\n<script>console.log(\"preview console bridge works\")</script>\n</body></html>\n");
    await put("/demo/util.js", "const add = (a, b) => a + b;\nconsole.log(\"util.js says:\", add(2, 3));\n");
    return { made, fetched, stubbed };
  },

  toggleSidebar(force) {
    const sb = document.getElementById("sidebar");
    const bd = document.getElementById("sidebar-backdrop");
    const collapsed = force !== undefined ? !force : !sb.classList.contains("collapsed");
    sb.classList.toggle("collapsed", collapsed);
    if (window.matchMedia("(max-width: 760px)").matches) {
      bd.classList.toggle("show", !collapsed);
    }
  },

  /* ── header config select (custom dropdown, ADE-01.3) ── */
  wireConfigSelect() {
    const wrap = document.getElementById("config-select");
    const trigger = document.getElementById("config-select-trigger");
    trigger.addEventListener("click", e => {
      e.stopPropagation();
      const existing = wrap.querySelector(".select-menu");
      if (existing) { existing.remove(); return; }
      const menu = document.createElement("div");
      menu.className = "select-menu";
      if (!State.configs.length) {
        menu.innerHTML = `<div class="select-option">No configs</div>`;
      }
      for (const c of State.configs) {
        const opt = document.createElement("div");
        opt.className = "select-option" + (c.id === State.activeConfigId ? " selected" : "");
        opt.innerHTML = `<span>${U.escapeHtml(c.name)}</span><span class="opt-model">${U.escapeHtml(c.model)}</span>`;
        opt.addEventListener("click", async () => {
          State.activeConfigId = c.id;
          await DB.setSetting(SK.ACTIVE_CONFIG, c.id);
          menu.remove();
          this.renderHeaderConfig();
          U.toast("Config switched", { kind: "ok", msg: c.name + " · " + c.model });
        });
        menu.appendChild(opt);
      }
      const manage = document.createElement("div");
      manage.className = "select-option";
      manage.innerHTML = `<span><i class="fa-solid fa-gear" style="font-size:10px"></i> Manage configs…</span>`;
      manage.addEventListener("click", () => { menu.remove(); SettingsUI.open("configs"); });
      menu.appendChild(manage);
      wrap.appendChild(menu);
    });
    document.addEventListener("click", () => {
      wrap.querySelector(".select-menu")?.remove();
    });
  },

  renderHeaderConfig() {
    const cfg = ChatUI.activeConfig();
    const label = document.getElementById("config-select-label");
    const badge = document.getElementById("header-config-badge");
    const badgeName = document.getElementById("header-config-name");
    label.textContent = cfg ? cfg.name : "No config";
    if (cfg) {
      badge.style.display = "";
      badge.classList.toggle("no-key", !cfg.apiKey);
      badgeName.textContent = cfg.model + (cfg.apiKey ? "" : " · no key");
    } else {
      badge.style.display = "none";
    }
  }
};

window.addEventListener("DOMContentLoaded", () => Main.init());

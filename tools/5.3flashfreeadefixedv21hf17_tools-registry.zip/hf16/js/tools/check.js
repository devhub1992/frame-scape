/* ============================================================================
   ADE hf.17 — js/tools/check.js
   The hf.16 `case "check":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "check", description: "ADE-hf.10: re-digest every ledger part against the split manifest — clean / DRIFTED (byte delta + digest) / MISSING per part. Drift = the part was edited since the split (expected when patching); assemble then needs expect_drift:true.", parameters: { type: "object", properties: { manifest: { type: "string", description: "manifest.json path OR the .parts folder" } }, required: ["manifest"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-clipboard-check", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const L = await this._ledgerManifest(args.manifest || args.dir || args.path);
          if (L.err) return done(false, L.err);
          const rows = []; let drift = 0, missing = 0;
          for (const part of L.manifest.parts) {
            const body = await VFS.readText(L.dir + "/" + part.file);
            if (body == null) { rows.push(`  ${part.file}  MISSING`); missing++; continue; }
            const d = this._fnv(body);
            if (d !== part.digest || body.length !== part.bytes) { rows.push(`  ${part.file}  DRIFTED  ${part.bytes}→${body.length} B  d${part.digest}→d${d}`); drift++; }
          }
          const head = `[check ${L.dir} · ${L.manifest.parts.length} parts · clean ${L.manifest.parts.length - drift - missing} · drifted ${drift} · missing ${missing}]`;
          const verdict = (drift || missing)
            ? `${drift + missing} part(s) differ from the split manifest — intentional edits? → assemble {expect_drift:true} rebuilds and refreshes the manifest. Unexpected? → inspect those parts before assembling.`
            : "all parts clean — assemble needs no expect_drift.";
          return done(true, this._cap(head + "\n" + (rows.length ? rows.join("\n") + "\n" : "") + verdict));
  }
}));
})();

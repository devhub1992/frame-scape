/* ============================================================================
   ADE hf.17 — js/tools/read.js
   The hf.16 `case "read":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "read", description: "Read text file(s) in slices — offset/limit (0-based line numbers) or mode 'head'/'tail'. MULTI-FILE: path accepts ONE path or an ARRAY of paths (a JSON-encoded array string coerces) — each file returns under a ===== path ===== header with its own slice, the whole answer sharing one output budget (each file says '… N lines skipped — re-read with offset' when it has more). MULTI-SLICE (hf.15): reads:[{path, offset?, limit?, mode?}, …] performs SEVERAL chunk-scoped reads in ONE call — several offsets of one file, several files, or a mix (each spec may also carry paths:[…]); batch your slices instead of firing parallel read calls. A whole read NEVER refuses: over the 16k-char cap it returns the head slice + skip note; over the 30 KB LARGE-FILE line it returns the head slice + the slice plan (next offset · ≈slice count · the grep jump). ≥30 KB files are the LARGE-FILE class — they never ship whole. Binary files are refused with their size. Single lines are capped at 800 chars with a …[+N chars] marker.", parameters: { type: "object", properties: { path: { description: "File path — or an ARRAY of paths to read several files in one call" }, reads: { type: "array", description: "MULTI-SLICE — an array of chunk-scoped read specs run in ONE call: {path (or paths:[…]), offset?, limit?, mode?} per entry (cap 12). Use this instead of several parallel read calls", items: { type: "object", properties: { path: { description: "File path — or an ARRAY of paths (the same slice applies to each)" }, offset: { type: "integer", description: "0-based start line" }, limit: { type: "integer", description: "Max lines" }, mode: { type: "string", enum: ["head", "tail"] } } } }, offset: { type: "integer", description: "0-based start line (default 0)" }, limit: { type: "integer", description: "Max lines to return (default 400 when slicing)" }, mode: { type: "string", enum: ["head", "tail"], description: "head = first N lines · tail = last N (offset ignored)" } }, required: ["path"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-file-lines", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          /* hf.15 — MULTI-SLICE READ (user call: "one read call — multiple
             single-file/multi-file chunk scoped reads"). The field log
             (2026-10-31 round-7): the agent fired THREE parallel read calls
             on the SAME ledger in one step (lines 21-28 · 107-119 · 1354)
             and two more on the lab — every one a separate turn of payload.
             reads:[{path|paths, offset?, limit?, mode?}, …] runs ALL of them
             in ONE call: every spec goes through the SAME _readOne pipeline,
             each file under a ===== path ===== header, one shared OUT_CAP
             budget with an honest per-slice share. Identical specs dedupe
             (idempotent re-sends); a failed spec ships as (FAILED) and never
             blocks its siblings. */
          const specsRaw = Array.isArray(args.reads) ? args.reads : (Array.isArray(args.slices) ? args.slices : null);
          if (specsRaw) {
            if (specsRaw.length > this.MULTI_PATH_MAX) return done(false, `reads has ${specsRaw.length} specs (cap ${this.MULTI_PATH_MAX}) — batch the rest into a second call`);
            const specs = specsRaw.filter(s => s && typeof s === "object" && !Array.isArray(s));
            if (!specs.length) return done(false, 'reads must be an array of slice specs: {"reads":[{"path":"a.txt","offset":20,"limit":9},{"path":"a.txt","offset":1353,"limit":3}]} — each spec: path (or paths:[…]) · offset? · limit? · mode?');
            const seenSpec = new Set();
            const units = [];
            for (const sp of specs) {
              const ps = this._paths(sp.path !== undefined ? sp.path : sp.paths);
              for (const p of ps) {
                const key = p + "|" + (sp.offset || 0) + "|" + (sp.limit || "") + "|" + (sp.mode || "");
                if (seenSpec.has(key)) continue; // identical re-send — idempotent
                seenSpec.add(key);
                units.push({ p, sp });
              }
            }
            if (!units.length) return done(false, "every reads[] spec needs a path — {path:'file.txt', offset?, limit?, mode?} (a spec may also carry paths:[f1,f2] for the same slice on several files)");
            const per = Math.max(1600, Math.floor((this.OUT_CAP - 60 * units.length) / units.length)); // honest per-slice share (same formula as the multi-file read)
            const parts = [];
            let failed = 0;
            for (const u of units) {
              const r = await this._readOne(u.p, { ...u.sp, _capOverride: per }, (ok, content) => ({ ok, content }));
              if (!r.ok) failed++;
              parts.push(`===== ${u.p}${r.ok ? "" : " (FAILED)"} =====\n${r.content}`);
            }
            const head = `[multi-slice read · ${specs.length} spec${specs.length === 1 ? "" : "s"} → ${units.length} slice${units.length === 1 ? "" : "s"}${failed ? ` · ${failed} failed` : ""} · shared budget ${this.OUT_CAP} chars — a slice cut short? re-read it alone with offset/limit]`;
            return done(true, this._cap(head + "\n\n" + parts.join("\n\n"), this.OUT_CAP, true));
          }
          /* hf.12 — MULTI-FILE READ: path = "file" (single, unchanged behavior)
             or ["f1","f2",…] → every file through the SAME _readOne pipeline,
             joined under ===== path ===== headers; the per-file cap shrinks so
             the JOINED answer stays inside one OUT_CAP budget and no single
             file can hog it. A 1-element array behaves exactly like the string. */
          const paths = this._paths(args.path);
          if (!paths.length) return done(false, "path required — a file path, an array of paths, or reads:[{path, offset?, limit?, mode?}…] for several chunk-scoped slices in ONE call");
          if (paths.length === 1) return await this._readOne(paths[0], args, done);
          const per = Math.max(1600, Math.floor((this.OUT_CAP - 60 * paths.length) / paths.length)); // honest share, ≥1.6k chars each
          const parts = [];
          for (const p of paths) {
            const r = await this._readOne(p, { ...args, _capOverride: per }, (ok, content) => ({ ok, content }));
            parts.push(`===== ${p}${r.ok ? "" : " (FAILED)"} =====\n${r.content}`);
          }
          return done(true, this._cap(`[multi-read ×${paths.length} · shared budget ${this.OUT_CAP} chars — a file cut short? re-read it alone with offset/limit]\n\n` + parts.join("\n\n"), this.OUT_CAP, true));
  }
}));
})();

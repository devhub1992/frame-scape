/* ============================================================================
   ADE hf.17 — js/tools/rezip.js
   The hf.16 `case "rezip":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "rezip", description: "ADE-HF.8: pack the workspace (or a subtree) into a .zip INSIDE the workspace (pure JS — no python).", parameters: { type: "object", properties: { path: { type: "string", description: "Zip file to create (default /workspace.zip)" }, src: { type: "string", description: "Subtree to pack (default / = whole workspace)" } } } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-box-archive", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          // ADE-S23.3 (ch-21.f9, m-51): tolerant sources — {src} · {root} · or {path} pointing at an existing dir
          const srcRaw = args.src || args.root || "";
          let src = srcRaw ? VFS.norm(srcRaw) : "";
          if (!src && args.path && (await VFS.isDir(VFS.norm(args.path)))) src = VFS.norm(args.path);
          if (!src) src = "/";
          if (src !== "/" && !(await VFS.exists(src))) return done(false, `not found: ${src}`);
          const reqPath = args.path ? VFS.norm(args.path) : null;
          const zp = (reqPath && reqPath !== src) ? reqPath : (src === "/" ? "/workspace.zip" : src.replace(/\/+$/, "") + ".zip");
          if (zp === "/") return done(false, "invalid zip path");
          const blob = await VFS.exportZip(src);
          const u8 = new Uint8Array(await blob.arrayBuffer());
          if (u8.length <= 22) return done(false, "nothing to pack — the workspace (or subtree) has no files");
          const buf = u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength);
          await VFS.put(zp, buf, false);
          const nFiles = (await VFS.tree(src)).filter(r => r.kind === "file").length;
          return done(true, `packed ${src} → ${zp} · ${nFiles} file(s) · ${(u8.length / 1024).toFixed(1)} KB`);
  }
}));
})();

/* ============================================================================
   ADE hf.17 — js/tools/move.js
   The hf.16 `case "move":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "move", description: "Rename or move a file/folder (moving a folder re-paths its whole subtree; target dir = move inside).", parameters: { type: "object", properties: { from: { type: "string", description: "Source path" }, to: { type: "string", description: "Destination path (or existing dir to move into)" } }, required: ["from", "to"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-right-left", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          // ADE-S23.3 (ch-21.f9): tolerant keys + honest pre-checks (VFS.mv throws raw)
          const from = VFS.norm(args.from || args.source || args.src || "");
          const to = VFS.norm(args.to || args.target || args.dest || "");
          if (!from || !to) return done(false, "from and to are required — args: {from, to} (rename, or move into an existing dir)");
          if (!(await VFS.exists(from))) return done(false, `not found: ${from}`);
          try {
            const dest = await VFS.mv(from, to);
            return done(true, `moved ${from} → ${dest}${dest !== to ? ` (inside ${to})` : ""}`);
          } catch (e) { return done(false, `mv failed: ${String((e && e.message) || e)}`); }
  }
}));
})();

/* ============================================================================
   ADE hf.17 — js/tools/digest.js
   The hf.16 `case "digest":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "digest", description: "ADE-S14.1: survey a subtree in ONE cheap call — one line per file (path · size · lines · first-line preview). ALWAYS survey before bulk reading; never read a folder file-by-file. max caps rows.", parameters: { type: "object", properties: { path: { type: "string", description: "Root of the subtree (default /)" }, max: { type: "integer", description: "Max rows (default 400, cap 2000)" } } } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-table-list", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          // ADE-S14.1 (ch-20.f1, m-35) + ADE-S23.2 (ch-21.f6, m-49): max knob + honest error guard
          const root = VFS.norm(args.path || "/");
          if (!(await VFS.exists(root))) return done(false, `not found: ${root}`);
          const max = Math.max(1, Math.min(2000, Math.floor(Number(args.max)) || 400));
          let table;
          try { table = await VFS.digestTable(root, max, this.LARGE_FILE); } // hf.14 — the survey flags ≥30 KB rows so slicing/splitting needs no trial-and-error
          catch (e) { return done(false, `digest failed: ${String((e && e.message) || e)} — try a narrower path`); }
          return done(true, this._cap(table));
  }
}));
})();

/* ============================================================================
   ADE hf.17 — js/tools/assemble.js
   The hf.16 `case "assemble":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "assemble", description: "ADE-hf.10: surgically reassemble ledger parts → master file in manifest order, digest-verified, byte-exact. Refuses when parts drifted unless expect_drift:true (which refreshes the manifest digests for the next round). Writes a one-shot .pre-assemble.bak of a changed target. The delivery step for chunked ledger work.", parameters: { type: "object", properties: { manifest: { type: "string", description: "manifest.json path OR the .parts folder" }, to: { type: "string", description: "Target file (default: the original source path)" }, expect_drift: { type: "boolean", description: "true = accept intentionally-edited parts and refresh manifest digests" } }, required: ["manifest"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-puzzle-piece", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const L = await this._ledgerManifest(args.manifest || args.dir || args.path);
          if (L.err) return done(false, L.err);
          const drift = [];
          const bodies = [];
          for (const part of L.manifest.parts) {
            const body = await VFS.readText(L.dir + "/" + part.file);
            if (body == null) return done(false, `part missing: ${part.file} — cannot reassemble; restore it or re-run split`);
            const d = this._fnv(body);
            if (d !== part.digest || body.length !== part.bytes) drift.push(`${part.file} (${part.bytes}→${body.length} B)`);
            bodies.push(body);
          }
          if (drift.length && args.expect_drift !== true)
            return done(false, `${drift.length} part(s) edited since the split:\n  ${drift.slice(0, 12).join("\n  ")}${drift.length > 12 ? `\n  …+${drift.length - 12} more` : ""}\n— edits INTENTIONAL? re-issue with expect_drift:true (manifest digests refresh). Not sure? check first.`);
          const out = bodies.join("");
          const to = VFS.norm(String(args.to ?? "").trim() || L.manifest.source);
          const prev = await VFS.readText(to);
          let backup = null;
          if (prev != null && prev !== out) {
            backup = to + ".pre-assemble.bak";
            await VFS.put(backup, prev, true);
          }
          await VFS.put(to, out, true);
          if (drift.length) { // refresh the manifest so the NEXT round verifies clean
            for (const part of L.manifest.parts) {
              const body = await VFS.readText(L.dir + "/" + part.file) ?? "";
              part.bytes = body.length; part.lines = body.split("\n").length; part.digest = this._fnv(body);
            }
            await VFS.put(L.manifestPath, JSON.stringify(L.manifest, null, 1), true);
          }
          const same = out.length === L.manifest.sourceBytes && this._fnv(out) === L.manifest.sourceDigest;
          const ident = same ? "byte-identical to the split source ✓" : `differs from the split source (${L.manifest.sourceBytes.toLocaleString()}→${out.length.toLocaleString()} B — the edits above)`;
          return done(true, this._cap(`[assemble → ${to} · ${L.manifest.parts.length} parts · ${out.length.toLocaleString()} B · ${out.split("\n").length.toLocaleString()} lines · d${this._fnv(out)}]\n${ident}${out.length >= this.LARGE_FILE ? `\n≥30 KB file — future edits go split → scan → edit → check → assemble (HUGE LEDGERS)` : ""}${backup ? `\nprevious target kept: ${backup} (one-shot — delete it when the new master is verified)` : ""}\nparts dir kept for further rounds — delete ${L.dir}/ when done`));
  }
}));
})();

/* ============================================================================
   ADE hf.17 — js/tools/split.js
   The hf.16 `case "split":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "split", description: "ADE-hf.10: split a huge flat file (≥30 KB — the LARGE-FILE class) into raw part files + manifest.json in <name>.parts/. Parts are byte-exact slices with NO added headers, so reassembly is lossless. by lines (N lines/part) · bytes (line-aligned ~N B/part — default 15 KB so every part reads WHOLE in one call) · marker (per-line RegExp that STARTS a part — sections stay intact). Then: scan across parts, edit parts part-local, check, assemble rebuilds the master. The big file never enters context whole.", parameters: { type: "object", properties: { path: { type: "string", description: "Big file to split" }, by: { type: "string", enum: ["lines", "bytes", "marker"], description: "Split unit (default lines)" }, value: { type: "string", description: "lines: lines/part (50-5000, default 400) · bytes: bytes/part (4096-262144, default 15360 — one-call readable parts) · marker: per-line RegExp that begins a new part (e.g. '^## ')" }, out: { type: "string", description: "Parts folder (default <name>.parts/ beside the source)" } }, required: ["path"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-scissors", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const p = VFS.norm(args.path || "");
          if (!p || p === "/") return done(false, "path required — the big flat file to split");
          const txt = await VFS.readText(p);
          if (txt == null) {
            const row = await VFS.get(p);
            return done(false, row && row.kind === "file" ? `${p} is binary — the ledger tools are text-only` : `not found: ${p}`);
          }
          if (txt.length > 8 * 1024 * 1024) return done(false, `${p} is ${(txt.length / 1048576).toFixed(1)} MB — over the 8 MB ledger cap; split it upstream first`);
          const by = ["lines", "bytes", "marker"].includes(args.by) ? args.by : "lines";
          let value = Number(args.value);
          if (by === "lines") { if (!Number.isFinite(value) || value < 50) value = 400; value = Math.min(5000, Math.round(value)); }
          else if (by === "bytes") { if (!Number.isFinite(value) || value < 4096) value = 15360; value = Math.min(262144, Math.round(value)); } // hf.14 — default 15 KB/part: every part reads WHOLE in one call under READ_CAP (32 KB parts tripped the large-file gate themselves)
          else {
            value = String(args.value ?? "").trim();
            if (!value) return done(false, 'by:"marker" needs value — a per-line RegExp that STARTS a new part (e.g. "^## ")');
            try { new RegExp(value); } catch (e) { return done(false, `bad marker RegExp: ${e.message}`); }
          }
          const lines = txt.split("\n");
          const bounds = [];
          if (by === "lines") {
            for (let i = 0; i < lines.length; i += value) bounds.push([i, Math.min(lines.length, i + value)]);
          } else if (by === "bytes") {
            let acc = 0, start = 0;
            for (let i = 0; i < lines.length; i++) {
              acc += lines[i].length + 1;
              if (acc >= value) { bounds.push([start, i + 1]); start = i + 1; acc = 0; }
            }
            if (start < lines.length) bounds.push([start, lines.length]);
          } else {
            const re = new RegExp(value);
            let start = 0;
            for (let i = 1; i < lines.length; i++) if (re.test(lines[i])) { bounds.push([start, i]); start = i; }
            if (start < lines.length) bounds.push([start, lines.length]);
          }
          if (!bounds.length) bounds.push([0, Math.max(1, lines.length)]);
          if (bounds.length > 500) return done(false, `would create ${bounds.length} parts (cap 500) — raise value, or use by:"marker" on section headers`);
          const dir = VFS.norm(String(args.out ?? "").trim() || p.replace(/\/[^/]*$/, "/") + VFS.base(p).replace(/\.(flat\.)?(txt|md|log|json)$/i, "") + ".parts");
          try { await VFS.rm(dir); } catch { /* fresh dir, or a stub without rm — stale extra parts are harmless: the manifest governs */ }
          const parts = [];
          for (let i = 0; i < bounds.length; i++) {
            const [a, b] = bounds[i];
            const body = lines.slice(a, b).join("\n") + (b < lines.length ? "\n" : "");
            const file = `part-${String(i).padStart(3, "0")}.txt`;
            await VFS.put(dir + "/" + file, body, true);
            parts.push({ file, bytes: body.length, lines: b - a, startLine: a, digest: this._fnv(body) });
          }
          const manifest = { v: 1, tool: "split/1", source: p, by, value: by === "marker" ? value : Number(value), created: new Date().toISOString(), sourceBytes: txt.length, sourceLines: lines.length, sourceDigest: this._fnv(txt), chunkCount: parts.length, parts };
          const mfPath = dir + "/manifest.json";
          await VFS.put(mfPath, JSON.stringify(manifest, null, 1), true);
          const shown = parts.slice(0, 24).map(pt => `  ${pt.file}  ${String(pt.bytes).padStart(7)} B  ${String(pt.lines).padStart(5)} lines  from L${pt.startLine + 1}  d${pt.digest}`);
          const more = parts.length > 24 ? `\n  …and ${parts.length - 24} more (manifest.json has the full table — don't read it, the ledger tools do)` : "";
          const note = by === "marker" && parts.length === 1 ? "\nNOTE: the marker matched no line after row 1 — one part holds the whole file; check the pattern." : "";
          return done(true, this._cap(`[split ${p} → ${parts.length} parts · by ${by}${by !== "marker" ? ` · ~${value.toLocaleString()} ${by === "lines" ? "lines/part" : "B/part"} (line-aligned)` : ` · /${value}/ starts a part`} · → ${dir}/]\n${shown.join("\n")}${more}${note}\nmanifest: ${mfPath} (source ${txt.length.toLocaleString()} B · ${lines.length.toLocaleString()} lines · d${manifest.sourceDigest})\nNEXT: scan {manifest:"${mfPath}", pattern:"…"} → patch parts with edit → check → assemble {manifest:"${mfPath}"}`));
  }
}));
})();

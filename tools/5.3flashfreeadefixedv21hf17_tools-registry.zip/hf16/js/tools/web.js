/* ============================================================================
   ADE hf.17 — js/tools/web.js   (tool 31 — S0 SCAFFOLD, plan §6.2)

   Status per SESSION STATE: S0 only. Ops bind/pull/push/share answer
   "not yet: S#" and their sessions (S1–S5 in ADE_Web_Tool_MultiSession_Plan.md)
   will fill them. `web test` already prints the real key/lane status banner.

   Rules that never change (plan §0.1):
   - Keys live in localStorage ONLY (github_pat, neocities_api_key,
     webtool_proxy_url, webtool_profiles, webtool_manifests).
   - Local writes go ONLY through the VFS. Transport lanes (D6):
     direct = api.github.com / raw.githubusercontent.com / tmpfiles.org;
     tunneled = neocities.org via webtool_proxy_url with {corskey}=State.corsKey.
   - Main thread only (workers have no fetch).
   ========================================================================== */
"use strict";

const WT = {
  LS: { PAT: "github_pat", NEO: "neocities_api_key", PROXY: "webtool_proxy_url",
        PROFILES: "webtool_profiles", MANIFESTS: "webtool_manifests" },

  /* §5.1: unset → default corsproxy template; stored "" → always direct. */
  DEFAULT_PROXY: "https://corsproxy.io/?key={corskey}&url={url}",

  /* ---- localStorage helpers (S0 acceptance: keys round-trip) ------------- */
  getKey(k)   { try { return localStorage.getItem(k); } catch (e) { return null; } },
  setKey(k,v) { try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, String(v)); } catch (e) {} },

  get k() {
    return {
      pat:   this.getKey(this.LS.PAT) || "",
      neo:   this.getKey(this.LS.NEO) || "",
      proxy: this.rawProxy()
    };
  },
  rawProxy() {
    const raw = this.getKey(this.LS.PROXY);
    if (raw === null) return WT.DEFAULT_PROXY;   // never configured
    return raw.trim();                            // "" = direct-only (§5.1)
  },

  /* ---- profile + manifest stores (S2 fills the semantics) ---------------- */
  profiles()  { try { return JSON.parse(this.getKey(this.LS.PROFILES) || "[]"); }  catch (e) { return [];  } },
  saveProfiles(p) { this.setKey(this.LS.PROFILES, JSON.stringify(p || [])); },

  manifests() { try { return JSON.parse(this.getKey(this.LS.MANIFESTS) || "{}"); } catch (e) { return {}; } },
  manifest(id) { return this.manifests()[id] || null; },
  saveManifest(id, m) {
    const all = this.manifests();
    if (m) all[id] = m; else delete all[id];
    this.setKey(this.LS.MANIFESTS, JSON.stringify(all));
  },

  /* ---- tunnel (§2.3: resolveUrl *pattern*, never resolveUrl itself) ------ */
  _keyWarned: false,
  tunnel(url) {
    const tpl = (this.k.proxy || "").trim();
    if (!tpl) return url;                       // direct-only
    let u = tpl.replace("{url}", encodeURIComponent(url));
    if (u.includes("{corskey}")) {
      if (!(typeof State !== "undefined" && (State.corsKey || "").trim()) && !this._keyWarned) {
        this._keyWarned = true;
        const msg = "CorsProxy key missing — the web tool tunnels neocities.org; set the key in Settings → Proxy Setup.";
        if (typeof U !== "undefined" && U && typeof U.toast === "function") U.toast("CorsProxy key missing", { kind: "err", msg });
        else console.warn("[webtool] " + msg);
      }
      u = u.replace("{corskey}", encodeURIComponent((typeof State !== "undefined" && State.corsKey) || ""));
    }
    return u;
  },

  /* ---- transport helpers (direct gh lane; S1 wires them up) -------------- */
  async gh(path, opt = {}) {
    const headers = Object.assign({
      "Accept": "application/vnd.github+json",
      ...(this.k.pat ? { "Authorization": "Bearer " + this.k.pat } : {})
    }, opt.headers || {});
    const rest = Object.assign({}, opt); delete rest.headers;
    const r = await fetch("https://api.github.com" + path, Object.assign(rest, { headers }));
    if (r.status === 403 && r.headers && r.headers.get && r.headers.get("x-ratelimit-remaining") === "0") {
      const reset = new Date((+r.headers.get("x-ratelimit-reset")) * 1000);
      throw Object.assign(new Error("gh quota empty, resets " + reset.toLocaleTimeString()), { code: "E_RATE" });
    }
    if (r.status === 401 || r.status === 403)
      throw Object.assign(new Error("gh rejected the credential"), { code: "E_AUTH" });
    return r;
  },
  async neo(path, opt = {}) {                   // tunneled lane (S4 wires it up)
    const headers = Object.assign({ "Authorization": "Bearer " + this.k.neo }, opt.headers || {});
    const rest = Object.assign({}, opt); delete rest.headers;
    const r = await fetch(this.tunnel("https://neocities.org" + path), Object.assign(rest, { headers }));
    if (r.status === 403) throw Object.assign(new Error("neocities key rejected"), { code: "E_AUTH" });
    const j = await r.json().catch(() => null);
    if (j && j.result === "error")
      throw Object.assign(new Error("neocities: " + j.message), { code: "E_NET" });
    return j;
  },

  /* ---- hashing (S3 uses gitBlobSha for the one-commit push) -------------- */
  async bytes(u8) {
    const b = await crypto.subtle.digest("SHA-1", u8);
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
  },
  async gitBlobSha(u8) {                        // sha1("blob <len>\0" + bytes)
    const head = new TextEncoder().encode("blob " + u8.length + "\0");
    const cat = new Uint8Array(head.length + u8.length); cat.set(head); cat.set(u8, head.length);
    return this.bytes(cat);
  },

  /* ---- provider listings (S1/S4 land the apply step; per Appendix A v0) --- */
  async ghList(prof) {
    const { repo, branch, path } = prof.remote;
    const r = await this.gh("/repos/" + repo + "/git/trees/" + encodeURIComponent(branch) + "?recursive=1");
    const j = await r.json();
    if (j.truncated)
      throw Object.assign(new Error("repo tree too big; bind a narrower folder"), { code: "E_TRUNCATED" });
    const base = (path === "/" ? "" : path.replace(/\/+$/, "")) + "/";
    return j.tree.filter(t => t.type === "blob" && t.path.startsWith(base))
                 .map(t => ({ rel: t.path.slice(base.length), sha: t.sha, size: t.size }));
  },
  async ghBytes(prof, rel) {
    const { repo, branch, path } = prof.remote;
    const p = (path === "/" ? "" : path + "/") + rel;
    const priv = this.k.pat && prof.public === false;
    const url = priv ? "https://api.github.com/repos/" + repo + "/contents/" + p + "?ref=" + encodeURIComponent(branch)
                     : "https://raw.githubusercontent.com/" + repo + "/" + branch + "/" + p;
    const headers = priv ? { "Authorization": "Bearer " + this.k.pat, "Accept": "application/vnd.github.raw" } : {};
    const r = await fetch(url, { headers });
    if (!r.ok) throw Object.assign(new Error("bytes " + r.status + " " + p), { code: "E_NET" });
    return new Uint8Array(await r.arrayBuffer());
  },
  async neoList(prof) {                          // one call, prefix-filtered (§4 etiquette)
    const j = await this.neo("/api/list");
    const base = prof.remote.path.replace(/^\/+|\/+$/g, "");
    return (j.files || []).filter(f => !f.is_directory && (!base || f.path === base || f.path.startsWith(base + "/")))
                          .map(f => ({ rel: base ? f.path.slice(base.length + 1) : f.path, sha: f.sha1_hash, size: f.size }));
  },

  /* ---- diff engine (S2; provider-neutral, remote-wins map {rel:sha}) ----- */
  diff(remoteFiles, man) {
    const out = { add: [], upd: [], del: [], same: [] };
    const have = (man && man.files) || {};
    for (const f of remoteFiles)
      (have[f.rel] ? (have[f.rel].sha === f.sha ? out.same : out.upd) : out.add).push(f);
    for (const rel of Object.keys(have))
      if (!remoteFiles.some(f => f.rel === rel)) out.del.push({ rel, sha: have[rel].sha });
    return out;
  },

  /* ---- args --------------------------------------------------------------- */
  parseArgs(args) {
    if (args && typeof args === "object") return args;
    if (typeof args === "string") {
      try { const p = JSON.parse(args); return (p && typeof p === "object") ? p : { op: args }; }
      catch (e) { return { op: args.trim() }; }
    }
    return {};
  },

  /* ---- op router ---------------------------------------------------------- */
  async run(args, done) {
    try {
      args = this.parseArgs(args);               // accept object | JSON string | bare op
      const op = ((args && args.op) || "").toLowerCase();
      if (op === "test")  return done(true,  await this.opTest(args));
      if (op === "bind")  return done(true,  this.opBind(args));
      if (op === "pull")  return done(true,  await this.opPull(args));
      if (op === "push")  return done(true,  await this.opPush(args));
      if (op === "share") return done(true,  await this.opShare(args));
      return done(false, "unknown op — use bind · pull · push · share · test (args: {op, …})");
    } catch (e) {
      const code = e && e.code ? e.code : "E_NET";
      return done(false, code + " — " + ((e && e.message) || e) +
        "\nremediation: " + (WT.REMEDIATION[code] || "check Settings → Web & Sync keys, then retry"));
    }
  },

  /* ---- §5.3 error taxonomy → one remediation line each -------------------- */
  REMEDIATION: {
    E_KEY:       "set it in Settings → Web & Sync (localStorage <key>)",
    E_AUTH:      "check token scope / key; gh: needs Contents R/W on this repo",
    E_RATE:      "quota/rate limited — retry after the reset time shown",
    E_SCOPE:     "path escaped the bound folder — request refused by design",
    E_CONFLICT:  "run `web pull <name>` then re-push, or push with force:true after explicit user intent",
    E_SIZE:      "shrink or split the file/batch under the stated cap",
    E_NET:       "check the lane/proxy — is the tunnel template + corskey set?",
    E_TRUNCATED: "bind a narrower folder (repo tree too large)"
  },

  /* ---- ops (S0 stubs; sessions S1–S5 replace them) ------------------------ */
  opBind(args)  { return "bind — not yet: S2 (plan §6.4: URI parser + profile store)"; },
  async opPull(args)  { return "pull — not yet: S1 (plan §6.3: gh folder → VFS)"; },
  async opPush(args)  { return "push — not yet: S3 (plan §6.5: one-commit batch)"; },
  async opShare(args) { return "share — not yet: S5 (plan §6.7: tmpfiles / gist)"; },

  async opTest() {                              // S0 banner; S6 fills the lane matrix
    const cs = (typeof State !== "undefined" && (State.corsKey || "").trim()) ? "set" : "MISSING";
    return ["web tool lane check (stub — S0 scaffold, hf.17)",
      "gh api: " + (this.k.pat ? "PAT set (" + this.k.pat.length + " chars)" : "no PAT — public only"),
      "neocities: " + (this.k.neo ? "key set" : "no key"),
      "tunnel: " + (this.k.proxy || "direct-only") + " · corskey " + cs,
      "ops: bind · pull · push · share land in sessions S1–S5; see ADE_Web_Tool_MultiSession_Plan.md"
    ].join("\n");
  }
};

/* ---- Settings panel (plan Appendix C, restyled with ADE's proxy-panel classes)
   ui-settings.js hosts it with ONE line in renderProxy():
       if (window.WT && typeof WT.buildKeyPanel === "function") WT.buildKeyPanel(body);
   (the panel renders into <div class="proxy-section" id="wt-panel-host">).
   Keys never appear in toasts. Empty proxy template = direct-only lanes. */
WT.buildKeyPanel = function (host) {
  if (!host || typeof host.querySelector !== "function") return false;
  const target = host.querySelector("#wt-panel-host") || host;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const cur = k => WT.getKey(k) == null ? "" : WT.getKey(k);
  target.innerHTML = [
    '<div class="title"><i class="fa-solid fa-globe"></i> Web &amp; Sync — GitHub / Neocities keys (tool 31, hf.17)</div>',
    '<div class="desc">One-folder sync profiles live here once sessions S1–S5 land. Keys stay in <code>localStorage</code> only — GitHub: fine-grained PAT, <b>Contents: Read/Write</b> on ONLY the repos you bind; Neocities: Settings → API key.</div>',
    '<div class="form-field">',
    '  <div class="input-with-action">',
    '    <input id="wt-pat" class="mono" type="password" autocomplete="off" placeholder="github_pat — fine-grained PAT (Contents: R/W)" value="' + esc(cur(WT.LS.PAT)) + '">',
    '    <button id="wt-eye-pat" title="Show"><i class="fa-solid fa-eye"></i></button>',
    '  </div>',
    '</div>',
    '<div class="form-field">',
    '  <div class="input-with-action">',
    '    <input id="wt-neo" class="mono" type="password" autocomplete="off" placeholder="neocities_api_key — site API key" value="' + esc(cur(WT.LS.NEO)) + '">',
    '    <button id="wt-eye-neo" title="Show"><i class="fa-solid fa-eye"></i></button>',
    '  </div>',
    '</div>',
    '<div class="form-field">',
    '  <input id="wt-proxy" class="mono" type="text" placeholder="' + esc(WT.DEFAULT_PROXY) + '" value="' + esc(WT.getKey(WT.LS.PROXY) == null ? WT.DEFAULT_PROXY : WT.getKey(WT.LS.PROXY)) + '">',
    '  <div class="hint"><i class="fa-solid fa-circle-info"></i> Tunnel template for neocities.org — <code>{corskey}</code> fills from the CorsProxy key above. Empty = direct-only lanes (api.github.com · raw.githubusercontent.com · tmpfiles.org are direct).</div>',
    '</div>',
    '<div class="form-actions">',
    '  <button class="btn primary" id="wt-save"><i class="fa-solid fa-floppy-disk"></i> Save Web &amp; Sync keys</button>',
    '</div>'
  ].join("\n");
  for (const [eyeId, inputId] of [["wt-eye-pat", "wt-pat"], ["wt-eye-neo", "wt-neo"]]) {
    const b = target.querySelector("#" + eyeId), inp = target.querySelector("#" + inputId);
    if (b && inp) b.addEventListener("click", () => {
      inp.type = inp.type === "password" ? "text" : "password";
      b.querySelector("i").className = "fa-solid " + (inp.type === "password" ? "fa-eye" : "fa-eye-slash");
    });
  }
  target.querySelector("#wt-save").addEventListener("click", () => {
    WT.setKey(WT.LS.PAT,  target.querySelector("#wt-pat").value.trim());
    WT.setKey(WT.LS.NEO,  target.querySelector("#wt-neo").value.trim());
    WT.setKey(WT.LS.PROXY, target.querySelector("#wt-proxy").value.trim());  // "" = direct-only
    if (typeof U !== "undefined" && U && typeof U.toast === "function")
      U.toast("Web & Sync keys saved", { kind: "ok",
        msg: "stored in localStorage: github_pat · neocities_api_key · webtool_proxy_url" });
  });
  return true;
};

window.WT = WT;

/* ---- tool registration (registry contract) ----------------------------------
   Plan Appendix B1 schema + B2 icon; B3's dispatch body lives here because the
   registry replaced the switch. `this` is the Agent dispatcher (ADETools.dispatch
   calls run.call(agent, …)), so the _cap wrapper matches B3's behavior. */
ADETools.register({
  name: "web",
  description: "hf.17 WEB LANE — sync ONE bound folder: GitHub (gh:owner/repo@branch:/path) or Neocities (neo:site:/path) ⇄ a VFS subtree (a linked work folder mirrors it via write-through; without a link the VFS is the cache). Ops: bind (save a one-folder profile) · pull (remote→VFS) · push (VFS→remote, gh = one commit) · share (one file → tmpfiles.org link, gist fallback) · test (lane self-check). Only manifest-tracked files are ever deleted; nothing outside the bound folder is touched. Keys live in Settings → Web & Sync (localStorage).",
  parameters: {
    type: "object",
    properties: {
      op:     { type: "string", enum: ["bind", "pull", "push", "share", "test"], description: "Subcommand" },
      uri:    { type: "string", description: "bind: gh:owner/repo@branch:/folder or neo:site:/folder" },
      as:     { type: "string", description: "bind: profile name (default = folder name)" },
      name:   { type: "string", description: "pull/push: profile name (bind with no uri lists profiles)" },
      path:   { type: "string", description: "share: VFS file path" },
      gist:   { type: "boolean", description: "share: use the Gist fallback instead of tmpfiles.org" },
      force:  { type: "boolean", description: "push: proceed after an E_CONFLICT head-sha drift (pull-first is still the default advice)" },
      confirm:{ type: "boolean", description: "push: required for >200 files / >50 MB batches" }
    },
    required: ["op"]
  },
  icon: "fa-solid fa-globe",
  run(args, done) {
    /* hf.17 — plan B3: done(ok, this._cap(msg)). Main thread only. */
    return WT.run(WT.parseArgs(args || {}), (ok, msg) =>
      done(ok, (this && typeof this._cap === "function") ? this._cap(msg) : msg), this);
  }
});

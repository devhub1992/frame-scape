/* ============================================================================
   ADE hf.17 — js/tools/state.js
   The hf.16 `case "state":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "state", description: "ADE-hf.10: mid-run STAGE CHECKPOINT — rewrite /ade.state.flat.txt (task/done/next/flags, same format as the reply-end <<<STATE block) so a crash, context cut or closed tab at a stage boundary never costs a re-discovery. Call at milestones: discovery done · plan locked · long stage finished. Keep it terse; bigger artifacts belong in workspace files the lines point to.", parameters: { type: "object", properties: { task: { type: "string", description: "One line — the current task" }, done: { type: "string", description: "Steps already finished, semicolon-separated" }, next: { type: "string", description: "The ONE exact next action" }, flags: { type: "string", description: "Up to 3 open items (default none)" } } } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-floppy-disk", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          /* hf.10 — mid-run STAGE CHECKPOINT of the f1 handoff file. The
             <<<STATE block only lands when a reply completes; long stages
             (discovery sweeps, plan locks, music-session prep) call THIS at
             boundaries so a cut/crash/closed tab resumes without re-discovery. */
          const clean = (v) => String(v ?? "").replace(/\s+/g, " ").trim().slice(0, 340);
          const task = clean(args.task), doneS = clean(args.done), next = clean(args.next);
          const flags = clean(args.flags) || "none";
          if (!task && !next) return done(false, "pass at least {task} or {next} — e.g. state {task:\"rig R1.4\", done:\"measured 4 ref sheets via probe\", next:\"write spec.flat.txt §03\"}");
          const txt = `# ade.state.flat.txt — harness-written resume pointer (agent checkpoint via state_save)\n# re-injected on every run start / continue — a restart costs ONE tiny read, never a re-survey\nupdated = ${new Date().toISOString()}\ntask = ${task}\ndone = ${doneS || "(none recorded)"}\nnext = ${next || "(none recorded)"}\nflags = ${flags}\n`;
          if (txt.length > 1200) return done(false, `state block too big (${txt.length} chars > 1200) — keep task/done/next terse; put detail in a workspace file and reference its path`);
          await VFS.put("/ade.state.flat.txt", txt, true);
          return done(true, `stage checkpoint saved → /ade.state.flat.txt (${txt.length} B) — injected as [RESUME STATE] on every future run start / continue; artifacts live in workspace files these lines point to`);
  }
}));
})();

/* ============================================================================
   ADE hf.17 — js/tools/tree.js
   The hf.16 `case "tree":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "tree", description: "Recursive tree snapshot of the workspace (or a subtree) — flat rows with depth indent. For a size/preview survey use digest instead.", parameters: { type: "object", properties: { path: { type: "string", description: "Root of the subtree (default /)" } } } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-folder-tree", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const root = VFS.norm(args.path || "/");
          const rows = await VFS.tree(root);
          const lines = rows.map(r => "  ".repeat(r.depth || 0) + VFS.base(r.path) + (r.kind === "dir" ? "/" : `  (${r.size || 0}B)`));
          return done(true, this._cap(lines.join("\n") || "(empty)"));
  }
}));
})();

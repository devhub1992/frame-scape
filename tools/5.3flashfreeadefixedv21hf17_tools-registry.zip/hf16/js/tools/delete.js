/* ============================================================================
   ADE hf.17 — js/tools/delete.js
   The hf.16 `case "delete":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "delete", description: "Delete a file, or a folder recursively.", parameters: { type: "object", properties: { path: { type: "string", description: "File or folder path" } }, required: ["path"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-trash-can", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const p = VFS.norm(args.path || "");
          if (!p || p === "/") return done(false, "refusing to delete the workspace root");
          const row = await VFS.get(p);
          if (!row) return done(false, `not found: ${p}`);
          await VFS.rm(p);
          return done(true, `deleted ${p}${row.kind === "dir" ? " (recursive)" : ""}`);
  }
}));
})();

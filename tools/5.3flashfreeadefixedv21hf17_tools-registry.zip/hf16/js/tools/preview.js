/* ============================================================================
   ADE hf.17 — js/tools/preview.js
   The hf.16 `case "preview":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "preview", description: "Open an HTML file from the workspace in the sandboxed preview iframe (sibling css/js/img inlined from the VFS; console bridged).", parameters: { type: "object", properties: { path: { type: "string", description: "HTML file path" } }, required: ["path"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-brands fa-html5", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const p = VFS.norm(args.path || "");
          const html = await VFS.readText(p);
          if (html == null) return done(false, `not found or not text: ${p}`);
          await Exec.preview(p);
          return done(true, `preview opened: ${p} — sandboxed iframe (no same-origin), console bridged`);
  }
}));
})();

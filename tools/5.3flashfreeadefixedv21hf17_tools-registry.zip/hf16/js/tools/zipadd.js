/* ============================================================================
   ADE hf.17 — js/tools/zipadd.js
   The hf.16 `case "zipadd":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "zipadd", description: "ADE-HF.8: APPEND the current workspace version into a .zip — workspace files overwrite same-named entries, zip-only entries are KEPT (incremental versioning: pack, edit, pack again). If the zip does not exist it is created (acts like rezip).", parameters: { type: "object", properties: { path: { type: "string", description: "Zip file to create or update" }, src: { type: "string", description: "Subtree to pack (default / = whole workspace)" }, fresh: { type: "boolean", description: "true = ignore existing zip content and rebuild from the workspace only" } }, required: ["path"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-plus", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const f = VFS._fflate();
          const zp = VFS.norm(args.path || "");
          if (!zp || zp === "/") return done(false, "path required — the zip file to create or append to");
          const src = VFS.norm(args.src || "/");
          if (src !== "/" && !(await VFS.exists(src))) return done(false, `not found: ${src}`);
          // 1) carry over the existing zip's entries (unless fresh:true)
          let entries = {};
          let carried = 0;
          const existing = await VFS.get(zp);
          if (existing && existing.kind === "file" && args.fresh !== true) {
            try {
              const u8 = existing.content instanceof Uint8Array ? existing.content : new Uint8Array(existing.content);
              entries = f.unzipSync(u8);
              carried = Object.keys(entries).length;
            } catch (e) {
              return done(false, `existing zip unreadable (${e.message}) — re-issue with fresh:true to rebuild it from the workspace`);
            }
          }
          // 2) merge the current workspace snapshot — workspace WINS over zip entries
          const all = await DB.all(DB.STORES.VFS);
          const prefix = src === "/" ? "" : src.slice(1) + "/";
          let files = 0;
          for (const row of all) {
            if (row.kind !== "file") continue;
            let rel = row.path.replace(/^\//, "");
            if (prefix && !rel.startsWith(prefix)) continue;
            rel = prefix ? rel.slice(prefix.length) : rel;
            if (!rel) continue;
            entries[rel] = typeof row.content === "string" ? f.strToU8(row.content) : new Uint8Array(row.content);
            files++;
          }
          if (!Object.keys(entries).length) return done(false, "nothing to pack — the zip and the workspace are both empty");
          const zipped = f.zipSync(entries, { level: 6 });
          const buf = zipped.buffer.slice(zipped.byteOffset, zipped.byteOffset + zipped.byteLength);
          await VFS.put(zp, buf, false);
          const kb = (zipped.length / 1024).toFixed(1);
          return done(true, `${zp} updated: ${files} workspace file(s) merged${carried ? `, ${carried} existing zip entr${carried === 1 ? "y" : "ies"} loaded` : ""} · ${Object.keys(entries).length} entr${Object.keys(entries).length === 1 ? "y" : "ies"} total · ${kb} KB`);
  }
}));
})();

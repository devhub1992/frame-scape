/* ============================================================================
   ADE hf.17 — js/tools/_registry.js
   Self-registering tool layer (the "decoupled tools" contract).

   Every ADE tool lives in its own file, js/tools/<name>.js, and registers:

       ADETools.register({
         name: "list",                    // unique — the old case label
         description: "…",                // verbatim from hf.16 TOOLS[]
         parameters: { type:"object", … },// verbatim from hf.16 TOOLS[]
         icon: "fa-solid fa-folder-tree", // verbatim from hf.16 ICONS (or none)
         run(args, done, agent, name) { … }  // the old case body, unchanged
       });

   Guarantees kept intact for migrated tools (matches hf.16 execTool exactly):
   - run() is invoked as run.call(agent, args, done, agent, name): `this` is
     the Agent dispatcher (this._cap / this._readOne / every helper unchanged),
     arg 4 is the canonical tool name (the head/tail shared body reads it).
   - A tool that THROWS (sync) or REJECTS (async) reports via done with the
     exact hf.16 catch text — String(e.message || e) — and dispatch never
     lets the error escape: execTool's "NEVER throws" contract holds.
   - Duplicate registration (SW cache skew / double tag) warns + replaces in
     place, keeping the original TOOLS position — the PWA never white-screens.
   - Icons are NOT defaulted: hf.16 leaves head/tail/find/edit iconless on
     purpose (ui-chat falls back) — icons() reproduces hf.16 byte-for-byte.

   agent.js consumes the registry at load time:
         TOOLS: ADETools.schemas(),
         ICONS: ADETools.icons(),
   and execTool dispatches with:
         const handled = ADETools.dispatch(name, args, done, this);
         if (handled !== false) return handled;

   Load order in index.html (all before agent.js, which composes from here):
       vfs.js → js/tools/_registry.js → js/tools/<name>.js (TOOLS order =
       tag order, pinned in _pinned_order.json; the web tool tags LAST) → …

   Adding a tool from now on = drop js/tools/<name>.js + one <script> tag.
   ========================================================================== */
"use strict";

const ADETools = {
  _defs: [],                          // registration order == Agent.TOOLS order
  _map: Object.create(null),          // name -> def

  register(def) {
    if (!def || typeof def !== "object") throw new Error("ADETools.register: def object required");
    if (typeof def.name !== "string" || !def.name.trim())
      throw new Error("ADETools.register: def.name (non-empty string) required");
    if (typeof def.run !== "function")
      throw new Error("ADETools.register(" + def.name + "): run(args, done, agent, name) must be a function");

    if (this._map[def.name]) {
      console.warn("[ADETools] duplicate registration for tool '" + def.name + "' — replacing previous def (original TOOLS position kept)");
      const i = this._defs.findIndex(d => d.name === def.name);
      this._defs[i] = def;
    } else {
      this._defs.push(def);
    }
    if (!def.parameters) def.parameters = { type: "object", properties: {} };
    this._map[def.name] = def;
    return def;
  },

  get(name) { return this._map[name] || null; },
  has(name) { return Object.prototype.hasOwnProperty.call(this._map, name); },
  names()   { return this._defs.map(d => d.name); },
  list()    { return this._defs.slice(); },

  /* ---- consumed by agent.js at eval time -------------------------------- */
  schemas() {
    return this._defs.map(d => ({ name: d.name, description: d.description, parameters: d.parameters }));
  },
  icons() { /* hf.16-faithful: iconless tools stay iconless */
    return this._defs.reduce((m, d) => { if (d.icon) m[d.name] = d.icon; return m; }, {});
  },

  /* ---- dispatch (replaces the per-tool switch cases) --------------------- */
  dispatch(name, args, done, agent) {
    const def = this._map[name];
    if (!def) return false;
    let r;
    try {
      r = def.run.call(agent, args || {}, done, agent, name);
    } catch (e) {
      return done(false, String((e && e.message) || e));  // exact hf.16 catch text
    }
    if (r && typeof r.then === "function") {
      /* async body: a rejection must become a done() report, never escape */
      return r.then(v => v, e => done(false, String((e && e.message) || e)));
    }
    return r;
  }
};

const __g = (typeof globalThis !== "undefined") ? globalThis
          : (typeof window !== "undefined" ? window : this);
__g.ADETools = ADETools;
if (typeof window !== "undefined") window.ADETools = ADETools;

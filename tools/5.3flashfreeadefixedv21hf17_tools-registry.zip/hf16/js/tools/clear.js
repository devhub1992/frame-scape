/* ============================================================================
   ADE hf.17 — js/tools/clear.js
   The hf.16 `case "clear":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "clear", description: "ADE-HF.8: wipe the workstation — delete EVERY file and folder in the workspace VFS (a linked disk work folder is NOT touched). The call is REFUSED unless confirm is exactly true.", parameters: { type: "object", properties: { confirm: { type: "boolean", description: "Must be exactly true — anything else is refused" } } } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-broom", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          if (args.confirm !== true)
            return done(false, 'REFUSED — clear deletes EVERY file and folder in the workspace. Re-issue with {"confirm":true} if you are sure.');
          const cnt = await VFS.count();
          const n = await VFS.clearAll();
          const fsa = (window.VFS && VFS.FSA) ? VFS.FSA : null;
          const linked = fsa && fsa.state === "linked" && fsa.handle ? " · linked disk folder NOT touched" : "";
          return done(true, `workstation cleared — ${cnt.files} file(s) + ${cnt.dirs} dir(s) removed (${n} rows) · VFS is now empty${linked}`);
  }
}));
})();

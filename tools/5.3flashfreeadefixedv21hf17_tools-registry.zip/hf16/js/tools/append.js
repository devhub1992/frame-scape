/* ============================================================================
   ADE hf.17 — js/tools/append.js
   The hf.16 `case "append":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "append", description: "Append text to file(s) — creates missing files. hf.12 MULTI-FILE: path accepts ONE path or an ARRAY of paths — the same content lands on every file, each result reported per file (a missing file is created, a failed file never blocks the others). hf.11: one call appends ≤16384 chars — bigger: split the append across calls, or build with chunk. Appending is the SAFE edit on a ≥30 KB LARGE-FILE-class file: it never reads the file into the conversation.", parameters: { type: "object", properties: { path: { description: "File path — or an ARRAY of paths (same content appended to each)" }, content: { type: "string", description: "Text to append (≤16384 chars)" } }, required: ["path", "content"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-file-circle-plus", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const addRaw = args.content ?? args.text ?? args.body; // ADE-S23.3 (ch-21.f9): tolerant keys, honest refusal
          if (addRaw === undefined || addRaw === null) return done(false, "content required — args: {path, content} (an append needs the text to add)");
          if (typeof addRaw === "object") return done(false, "content must be a string — JSON.stringify it first");
          const add = String(addRaw);
          if (add.length > this.BIG_CALL_CAP) return done(false, `append too big for ONE call: ${add.length.toLocaleString()} chars > ${this.BIG_CALL_CAP.toLocaleString()} — split the append into ≤16k pieces across calls, or rebuild the file with chunk {path, index, total, content}`);
          /* hf.12 — MULTI-FILE APPEND: path = one file (unchanged) or an ARRAY
             of files — the SAME content lands on every file; each file is
             independent (a binary/failed file is reported and skipped, it never
             blocks the others). Appending never ships the file body into the
             conversation, so it is the SAFE edit on a ≥30 KB LARGE-FILE-class
             file (worklog rows, ledger §08 patch lines, …). */
          const paths = this._paths(args.path);
          if (!paths.length) return done(false, "path required — args: {path, content} (path = one file, or an array of files)");
          if (paths.length === 1) {
            const p = paths[0];
            const prev = await VFS.readText(p);
            if (prev == null && await VFS.exists(p)) return done(false, `${p} is binary — cannot append`);
            await VFS.put(p, (prev || "") + add, true);
            // ADE-S13.9 (ch-19.f2): the appended block STARTS at the first new line
            try { WSUI.editing(p, (prev || "").split("\n").length, `append · ${add.split("\n").length} lines`, "agent"); } catch { /* window optional */ }
            return done(true, `appended to ${p} (now ${(prev || "").length + add.length} chars)`);
          }
          const rows = [];
          for (const p of paths) {
            const prev = await VFS.readText(p);
            if (prev == null && await VFS.exists(p)) { rows.push(`✗ ${p}: binary — skipped`); continue; }
            await VFS.put(p, (prev || "") + add, true);
            try { WSUI.editing(p, (prev || "").split("\n").length, `append · ${add.split("\n").length} lines`, "agent"); } catch { /* window optional */ }
            rows.push(`✓ ${p}: +${add.length} chars${prev == null ? " (created)" : ` (now ${(prev || "").length + add.length})`}`);
          }
          const okN = rows.filter(r => r.startsWith("✓")).length;
          return done(okN > 0, `multi-append ×${paths.length} files · +${add.length} chars each · ${okN} applied${okN < paths.length ? `, ${paths.length - okN} skipped (each file independent)` : ""}\n${rows.join("\n")}`);
  }
}));
})();

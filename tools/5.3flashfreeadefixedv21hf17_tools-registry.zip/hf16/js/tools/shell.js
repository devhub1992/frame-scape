/* ============================================================================
   ADE hf.17 — js/tools/shell.js
   The hf.16 `case "shell":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "shell", description: "Run one VIRTUAL-shell command line over the workspace VFS (not an OS shell): ls cat head tail touch mkdir rm cp mv find grep wc echo tree stat du digest python js pip open download pwd cd clear seed date whoami help · && chains · > >> redirects.", parameters: { type: "object", properties: { command: { type: "string", description: "The command line, e.g. ls -l src/ or python demo/hello.py" } }, required: ["command"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-terminal", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const raw = String(args.command ?? args.cmd ?? args.raw ?? args.line ?? "").trim(); // ADE-HF.7 — accept the key the model actually sent (field report: it guessed `cmd` and burned a turn on "command required")
          if (!raw) return done(false, "command required");
          const r = await Exec.Shell.run(raw, { silent: true });
          /* hf.10 — per-line 800-char cap at PRESENTATION only (pipes/redirects already consumed
             the raw bytes — a redirected file is never capped). Field trace: shell grep shipped a
             4.5 KB meta.plan.next mega-line whole; fs_read lines already cap at 800 — the shell reads the same. */
          const capLine = (L) => L.length > 800 ? L.slice(0, 800) + ` …[+${L.length - 800} chars on this line — cut -c1-800 / read offset for exact slices]` : L;
          const out = [String(r.out || "").split("\n").map(capLine).join("\n"), r.err ? "STDERR:\n" + r.err : "", r.code ? `exit code ${r.code}` : ""].filter(Boolean).join("\n").trim();
          return done(!r.code, this._cap(out || "(no output)"));
  }
}));
})();

/* ============================================================================
   ADE hf.17 — js/tools/probe.js
   The hf.16 `case "probe":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "probe", description: "ADE-HF.9: decode a workspace image and MEASURE it — pixel dimensions, alpha-silhouette bbox (figure extremities), luminance edge transitions along given rows/columns, average RGBA per grid cell. The agent measures from NUMBERS, never guesses. No decoder in this context → honest refusal; the measurement must then be recorded as \"seed value, not verified\". Crop to a region for precision.", parameters: { type: "object", properties: { path: { type: "string", description: "Image file path in the workspace" }, crop: { type: "array", items: { type: "integer" }, description: "[x, y, w, h] region to scan (default: whole image)" }, rows: { type: "array", items: { type: "integer" }, description: "y lines to scan for edge transitions (≤8)" }, cols: { type: "array", items: { type: "integer" }, description: "x columns to scan for edge transitions (≤8)" }, grid: { type: "integer", description: "n×n grid of average-RGBA cells (2–8)" }, alpha: { type: "integer", description: "alpha threshold for the silhouette bbox (1–254, default 128)" }, luma: { type: "integer", description: "luminance delta that counts as an edge (1–254, default 40)" } }, required: ["path"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-ruler-combined", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          /* f10.image.probe — the agent measures from NUMBERS: dimensions,
             alpha-silhouette bbox (figure extremities), per-row/col edge
             transitions, grid averages. No decoder → honest refusal that maps
             to "seed value, not verified" under the evidence gate. */
          const p = VFS.norm(args.path || "");
          if (!p) return done(false, 'path required — args: {path, crop?, grid?, rows?, cols?, alpha?, luma?}');
          const row = await VFS.get(p);
          if (!row || row.kind !== "file") return done(false, `not found: ${p}`);
          let u8;
          try { u8 = row.content instanceof Uint8Array ? row.content : (typeof row.content === "string" ? new TextEncoder().encode(row.content) : new Uint8Array(row.content)); }
          catch { return done(false, `${p} is not readable as binary`); }
          if (u8.length < 24) return done(false, `${p} is ${u8.length} bytes — not an image (or truncated)`);
          const kind = this._imgKind(u8);
          const alphaT = Math.max(1, Math.min(254, Number(args.alpha) || 128));
          const lumaT = Math.max(1, Math.min(254, Number(args.luma) || 40));
          const maxT = Math.max(4, Math.min(64, Number(args.max_trans) || 32));
          const img = await this._decodeImage(u8);
          if (!img || !img.w || !img.data) return done(false, 'image_probe: no image decoder available in this context — record the measurement as "seed value, not verified" and leave any spec.lock unconfirmed.');
          const { w, h, data } = img;
          if (w * h > 16777216) return done(false, `image too large for one pass (${w}×${h} = ${(w * h / 1e6).toFixed(1)} MP) — pass a crop`);
          let cx = 0, cy = 0, cw = w, ch = h;
          if (Array.isArray(args.crop) && args.crop.length === 4) {
            const c = args.crop.map(n => Math.round(Number(n) || 0));
            cx = Math.max(0, Math.min(w - 1, c[0])); cy = Math.max(0, Math.min(h - 1, c[1]));
            cw = Math.max(1, Math.min(w - cx, c[2])); ch = Math.max(1, Math.min(h - cy, c[3]));
          }
          const px = (x, y) => { const i = (y * w + x) * 4; return [data[i], data[i + 1], data[i + 2], data[i + 3]]; };
          const lum = (r, g, b) => Math.round(0.2126 * r + 0.7152 * g + 0.0722 * b);
          const out = [];
          out.push(`[image_probe ${p} · ${w}×${h}px${kind ? " " + kind : ""} · ${u8.length} B · region x${cx} y${cy} ${cw}×${ch}${Array.isArray(args.crop) ? " (crop)" : ""} · lumaΔ≥${lumaT} · α<${alphaT}]`);
          let minX = -1, minY = -1, maxX = -1, maxY = -1, transparent = 0;
          for (let y = cy; y < cy + ch; y++) {
            for (let x = cx; x < cx + cw; x++) {
              if (px(x, y)[3] < alphaT) { transparent++; if (minX < 0 || x < minX) minX = x; if (x > maxX) maxX = x; if (minY < 0 || y < minY) minY = y; if (y > maxY) maxY = y; }
            }
          }
          if (!transparent) out.push(`alpha: no pixel below α<${alphaT} in region — OPAQUE: no alpha silhouette; use rows/cols scans for feature edges`);
          else out.push(`alpha silhouette (α<${alphaT}): bbox x ${minX}..${maxX} · y ${minY}..${maxY} · ${maxX - minX + 1}×${maxY - minY + 1}px · ${transparent} transparent px in region`);
          const scanLine = (fixed, isRow) => {
            const len = isRow ? cw : ch;
            const tr = [];
            let refL = null, refA = null;
            for (let k = 0; k < len; k++) {
              const x = isRow ? cx + k : fixed, y = isRow ? fixed : cy + k;
              const [r, g, b, a] = px(x, y);
              const L = lum(r, g, b);
              if (refL === null) { refL = L; refA = a; continue; }
              const flip = (a < alphaT) !== (refA < alphaT);
              if (Math.abs(L - refL) >= lumaT || flip) {
                if (tr.length < maxT) tr.push(`${isRow ? "x" : "y"}=${k} ${refL}→${L}${flip ? ` α${refA}→${a}` : ""}`);
                refL = L; refA = a;
              }
            }
            return tr;
          };
          const rowsReq = (Array.isArray(args.rows) ? args.rows : []).map(n => Math.round(Number(n))).filter(n => Number.isFinite(n)).slice(0, 8);
          const colsReq = (Array.isArray(args.cols) ? args.cols : []).map(n => Math.round(Number(n))).filter(n => Number.isFinite(n)).slice(0, 8);
          for (const y of rowsReq) {
            if (y < cy || y >= cy + ch) { out.push(`row y=${y}: outside region (y ${cy}..${cy + ch - 1})`); continue; }
            const tr = scanLine(y, true);
            out.push(`row y=${y}: ${tr.length} edge transition(s)${tr.length >= maxT ? ` (cap ${maxT})` : ""}${tr.length ? "\n  " + tr.join(" · ") : ""}`);
          }
          for (const x of colsReq) {
            if (x < cx || x >= cx + cw) { out.push(`col x=${x}: outside region (x ${cx}..${cx + cw - 1})`); continue; }
            const tr = scanLine(x, false);
            out.push(`col x=${x}: ${tr.length} edge transition(s)${tr.length >= maxT ? ` (cap ${maxT})` : ""}${tr.length ? "\n  " + tr.join(" · ") : ""}`);
          }
          const g = Math.max(0, Math.min(8, Math.floor(Number(args.grid)) || 0));
          if (g >= 2) {
            const cellW = cw / g, cellH = ch / g;
            const glines = [];
            for (let gy = 0; gy < g; gy++) {
              const cells = [];
              for (let gx = 0; gx < g; gx++) {
                let sr = 0, sg = 0, sb = 0, sa = 0, n = 0;
                const x0 = cx + Math.floor(gx * cellW), x1 = cx + Math.floor((gx + 1) * cellW);
                const y0 = cy + Math.floor(gy * cellH), y1 = cy + Math.floor((gy + 1) * cellH);
                for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const c = px(x, y); sr += c[0]; sg += c[1]; sb += c[2]; sa += c[3]; n++; }
                cells.push(n ? `(${Math.round(sr / n)},${Math.round(sg / n)},${Math.round(sb / n)},a${Math.round(sa / n)})` : "—");
              }
              glines.push(`  gy${gy}: ${cells.join(" ")}`);
            }
            out.push(`grid ${g}×${g} avg RGBA (0-255) over region:\n${glines.join("\n")}`);
          }
          return done(true, this._cap(out.join("\n")));
  }
}));
})();

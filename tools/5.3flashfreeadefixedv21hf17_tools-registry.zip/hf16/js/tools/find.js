/* ============================================================================
   ADE hf.17 — js/tools/find.js
   The hf.16 `case "find":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "find", description: "ADE-HF.8: search flat text files (.flat.txt, code, logs) for a literal pattern (or regex) — returns capped 'path:LINE: text' hits. Cheap: one call surveys every text file under path. hf.12 MULTI: path accepts a single file, a folder, or an ARRAY of files/folders searched in one call. Use the line numbers with read offset to pull context.", parameters: { type: "object", properties: { pattern: { type: "string", description: "Text to find (literal by default)" }, path: { description: "File, folder — or an ARRAY of files/folders (default / = every text file)" }, regex: { type: "boolean", description: "true = pattern is a JS RegExp" }, ignore_case: { type: "boolean", description: "Case-insensitive match" }, max: { type: "integer", description: "Max hits returned (default 40, cap 200)" } }, required: ["pattern"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  /* no icon in hf.16 ICONS — ui-chat falls back, keep it that way */
  async run(args, done, agent, name) {
          const pat = String(args.pattern ?? "");
          if (!pat) return done(false, 'pattern required — e.g. {"pattern":"plan.next","path":"planner.flat.txt"} (a single FILE path searches that file)');
          let re = null;
          if (args.regex === true) {
            try { re = new RegExp(pat, (args.ignore_case === true ? "i" : "") + "m"); } // ADE-HF.8 — m flag: ^/$ anchors apply per-line (lines are tested one by one)
            catch (e) { return done(false, "bad regex: " + e.message); }
          }
          const needle = args.ignore_case === true ? pat.toLowerCase() : pat;
          const max = Math.max(1, Math.min(200, Math.floor(Number(args.max)) || 40));
          /* hf.12 — MULTI-ROOT FIND: path = "/" (default, whole workspace) · a
             single file · a folder · or an ARRAY of files/folders — all roots
             searched in ONE pass with ONE shared hit cap (rows deduped). A
             missing array entry is reported and skipped, it never blocks the
             rest. */
          const roots = Array.isArray(args.path) ? this._paths(args.path) : [VFS.norm(args.path || "/")];
          if (Array.isArray(args.path) && !roots.length) return done(false, "path array is empty or invalid — pass real file/folder paths");
          /* hf.14 — root resolution is HONEST for single paths too: a root that
             is neither a folder nor an existing file lands in `miss` and the
             head reports "N path(s) NOT FOUND". (Field case: a single bogus
             path — or a stringified JSON array read as ONE path — was counted
             as "binary skipped", and the model concluded a real .js file was
             binary.) Binary now means ONLY a real non-text file. */
          const seen = new Set(); const rows = []; const miss = [];
          for (const root of roots) {
            if (root === "/" || (await VFS.isDir(root))) { for (const r of await VFS.tree(root)) if (r.kind === "file" && !seen.has(r.path)) { seen.add(r.path); rows.push(r); } }
            // ADE-S22.1 (ch-21.f5, m-48): a FILE root previously searched NOTHING — VFS.tree walks dirs only.
            else if (await VFS.exists(root)) { if (!seen.has(root)) { seen.add(root); rows.push({ path: root }); } }
            else miss.push(root);
          }
          const hits = [];
          let searched = 0, binary = 0;
          for (const r of rows) {
            // ADE-S22.1: binary pre-check — readText decodes ANY bytes lossily, so
            // non-text rows must be skipped before the decode or they pollute `searched`
            const row = (r.isText === undefined) ? await VFS.get(r.path) : r;
            if (!row || row.kind !== "file") { if (!miss.includes(r.path)) miss.push(r.path); continue; } // hf.14 — vanished between listing and read = NOT FOUND, not binary
            if (!row.isText && !U.isTextName(r.path)) { binary++; continue; }
            let txt = null;
            try { txt = await VFS.readText(r.path); } catch { binary++; continue; }
            if (txt == null) { binary++; continue; }
            searched++; // ADE-S22.1: searched/binary stay honest even after the hit cap lands
            if (hits.length >= max) continue;
            const lines = txt.split("\n");
            for (let i = 0; i < lines.length && hits.length < max; i++) {
              const L = lines[i];
              const hit = re ? re.test(L) : (args.ignore_case === true ? L.toLowerCase().includes(needle) : L.includes(needle));
              if (hit) hits.push(`${r.path}:${i + 1}: ${L.trim().slice(0, 200)}`);
            }
          }
          const rootsLabel = (roots.length === 1 && !Array.isArray(args.path)) ? roots[0] : (roots.join(", ").slice(0, 160) + (roots.join(", ").length > 160 ? "…" : ""));
          const head = `[find "${pat.slice(0, 60)}" in ${rootsLabel} · ${hits.length} hit${hits.length === 1 ? "" : "s"} · searched ${searched} text file(s)${binary ? `, ${binary} binary skipped` : ""}${miss.length ? ` · ${miss.length} path(s) NOT FOUND: ${miss.join(", ").slice(0, 200)}` : ""}]`;
          if (!hits.length) {
            /* ADE-HF.8 — the 0-hit answer now TEACHES: the 2026-10-31 frame-scape
               session lost turns to literal ^worklog\. patterns (flat_find is
               literal-by-default) and the model guessed "no multiline flag". */
            let hint = "no matches — try a shorter pattern or ignore_case:true";
            if (!re && /[\\^$.*+?()[\]{}|]/.test(pat)) hint += ` — this pattern carries REGEX syntax (\\ ^ $ …) but find is LITERAL by default: re-run with {"regex":true} (^/$ anchors apply per line) or use a plain substring`;
            else if (re && (pat.startsWith("^") || pat.endsWith("$"))) hint += " — note: ^/$ anchors apply per line, so leading text before the anchor never matches";
            return done(true, head + "\n" + hint);
          }
          const more = hits.length >= max ? `\n…hit cap ${max} reached — re-run with a higher max or a narrower pattern/path` : "";
          return done(true, this._cap(head + "\n" + hits.join("\n") + more));
  }
}));
})();

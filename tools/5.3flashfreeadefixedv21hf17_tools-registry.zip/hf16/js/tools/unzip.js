/* ============================================================================
   ADE hf.17 — js/tools/unzip.js
   The hf.16 `case "unzip":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "unzip", description: "ADE-HF.8: unpack a .zip from the workspace into a workspace folder, structure preserved (fflate, pure JS — no python). Existing files are KEPT and counted as skipped unless overwrite:true.", parameters: { type: "object", properties: { path: { type: "string", description: "Zip file path in the workspace" }, dest: { type: "string", description: "Target folder (default / = workspace root)" }, overwrite: { type: "boolean", description: "true = replace existing files (default: keep them)" } }, required: ["path"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-file-zipper", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const zp = VFS.norm(args.path || "");
          if (!zp || zp === "/") return done(false, "path required — the .zip file to unpack");
          const row = await VFS.get(zp);
          if (!row || row.kind !== "file") return done(false, `zip not found: ${zp}`);
          const dest = VFS.norm(args.dest || "/");
          let u8;
          try { u8 = row.content instanceof Uint8Array ? row.content : new Uint8Array(row.content); }
          catch { return done(false, `${zp} is not readable as binary`); }
          const sum = await VFS.importZip(u8, dest, { overwrite: !!args.overwrite, skip: zp });
          const kept = args.overwrite ? "" : " · existing files kept (pass overwrite:true to replace)";
          return done(true, `unpacked ${zp} → ${dest} · ${sum.imported} file(s) written · ${sum.skipped} skipped${kept} · ${(sum.bytes / 1024).toFixed(1)} KB extracted`);
  }
}));
})();

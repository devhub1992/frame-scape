/* ============================================================================
   ADE hf.17 — js/tools/js.js
   The hf.16 `case "js":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "js", description: "Execute JavaScript in a sandboxed dedicated worker (no DOM; console.* bridged; top-level await OK; 10s timeout). hf.12: pass files:[paths] to PRELOAD workspace text files into the sandbox as a global FS map (FS['frame-scape-music/framescape-lab.js'] → full text) — the worker has NO network and NO module imports, so this is the only way code there sees workspace files; results come back via console.log (capped) — print digests/counts, never whole files. Pass inline code or a workspace path.", parameters: { type: "object", properties: { code: { type: "string", description: "JS source to run inline" }, path: { type: "string", description: "…or a .js file path in the workspace" }, files: { description: "Workspace file path(s) — string or array — preloaded into the sandbox as the global FS map (path → text)" } } } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-brands fa-js", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          let p = null, tmp = null;
          if (typeof args.code === "string" && args.code.trim()) {
            tmp = "/tmp/agent-" + U.uid().slice(0, 6) + ".js";
            await VFS.put(tmp, args.code, true);
            p = tmp;
          } else if (args.path) { p = VFS.norm(args.path); }
          else return done(false, "pass code (inline) or path");
          if (!(await VFS.exists(p))) return done(false, `not found: ${p}`);
          /* hf.12 — FILES PRELOAD: workspace text files arrive in the sandbox
             as the global FS map (path → full text). The worker has NO fetch
             (blob: origin — relative URLs cannot even parse) and NO module
             imports — the field case burned turn after turn on
             import('ademure/fs') and fetch('/frame-scape-music/…'). This is
             the one sanctioned seam: load files here, process in the sandbox,
             print SMALL results (counts/digests/slices — never whole files;
             console output is capped anyway). */
          let files = null; const fMiss = [], fBin = [], fBig = []; let fTotal = 0;
          if (args.files != null) {
            const fp = this._paths(args.files);
            if (!fp.length) return done(false, "files: pass a workspace path or an array of paths (≤12 files, ≤2 MB each)");
            files = {};
            for (const f of fp) {
              const row = await VFS.get(f);
              if (!row || row.kind !== "file") { fMiss.push(f); continue; }
              if (row.size > 2 * 1024 * 1024) { fBig.push(f); continue; }
              const t = await VFS.readText(f);
              if (t == null) { fBin.push(f); continue; }
              if (fTotal + t.length > 4 * 1024 * 1024) { fBig.push(f); continue; } // hf.12 — 4 MB total blob budget
              files[f] = t; fTotal += t.length;
            }
            if (!Object.keys(files).length)
              return done(false, `files: nothing preloaded${fMiss.length ? ` — not found: ${fMiss.join(", ")}` : ""}${fBin.length ? ` — binary: ${fBin.join(", ")}` : ""}${fBig.length ? " — over 2 MB each" : ""}`);
          }
          try {
            const r = await this._captureConsole(() => Exec.runJs(p, files));
            const parts = [r.ok ? "ok" : "FAILED: " + (r.error || "error")];
            if (files) parts.unshift(`FS preloaded: ${Object.keys(files).length} file(s) · ${Object.values(files).reduce((n, t) => n + t.length, 0).toLocaleString()} chars — read them as FS["<path>"]${fMiss.length ? ` · not found: ${fMiss.join(", ")}` : ""}${fBin.length ? ` · binary skipped: ${fBin.join(", ")}` : ""}${fBig.length ? ` · >2MB skipped: ${fBig.join(", ")}` : ""}`);
            if (r.result !== undefined && r.result !== "undefined" && r.result !== null) parts.push("result: " + r.result);
            const con = this._cap(r.__console || "", this.OUT_CAP);
            if (con) parts.push("console:\n" + con);
            return done(!!r.ok, parts.join("\n"));
          } finally { if (tmp) { try { await VFS.rm(tmp); } catch { /* best effort */ } } }
  }
}));
})();

/* ============================================================================
   ADE hf.17 — js/tools/head.js
   The hf.16 `case "head":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "head", description: "hf.16 — first N lines of file(s): the dedicated chunked HEAD read (read mode:'head' as a first-class tool). MULTI-FILE: path accepts ONE path or an ARRAY — per-file sections under ===== path ===== headers sharing one output budget. Any file size: a ≥30 KB LARGE-FILE-class file ships its head slice + the slice plan, never whole. Lines cap at 800 chars with an honest …[+N chars] marker.", parameters: { type: "object", properties: { path: { description: "File path — or an ARRAY of paths (one call, per-file sections)" }, n: { type: "integer", description: "Lines to ship (default 40, cap 400)" } }, required: ["path"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  /* no icon in hf.16 ICONS — ui-chat falls back, keep it that way */
  async run(args, done, agent, name) {
          /* hf.16 — DEDICATED MULTI-FILE HEAD/TAIL (user call: "add dedicated
             multi-file chunked tools for head and tail reads"). Field log:
             ledger heads/ends went through shell head/tail (cwd-pitfall
             class) or offset-mathed read slices — one call per file. Both
             tools are thin multi-file frontends over _readOne, so they
             inherit the whole house rulebook for free: tail KEEPS THE END
             on over-cap slices, ≥30 KB files ship the slice plan, single
             lines cap at 800 chars, skip notes stay honest. */
          const modeHT = name; // "head" | "tail" — the switch discriminates
          const nHT = Math.max(1, Math.min(400, Math.floor(Number(args.n ?? args.lines ?? 40) || 40)));
          const pathsHT = this._paths(args.path);
          if (!pathsHT.length) return done(false, `path required — args: {path, n?} (path = one file or an ARRAY of files; n = lines, default 40)`);
          if (pathsHT.length === 1) return await this._readOne(pathsHT[0], { mode: modeHT, limit: nHT }, done);
          const perHT = Math.max(1600, Math.floor((this.OUT_CAP - 60 * pathsHT.length) / pathsHT.length));
          const partsHT = [];
          for (const p of pathsHT) {
            const r = await this._readOne(p, { mode: modeHT, limit: nHT, _capOverride: perHT }, (ok, content) => ({ ok, content }));
            partsHT.push(`===== ${p}${r.ok ? "" : " (FAILED)"} =====\n${r.content}`);
          }
          return done(true, this._cap(`[${modeHT} ×${pathsHT.length} file(s) · ${nHT} line${nHT === 1 ? "" : "s"} each · shared budget ${this.OUT_CAP} chars — a file cut short? re-read it alone with mode:"${modeHT}" limit ${nHT * 2}]\n\n` + partsHT.join("\n\n"), this.OUT_CAP, true));
  }
}));
})();

/* ============================================================================
   ADE hf.17 — js/tools/edit.js
   The hf.16 `case "edit":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "edit", description: "ADE-HF.8: patch flat file(s) with an EXACT literal find→replace (not regex). hf.12 MULTI-FILE: path accepts ONE path or an ARRAY of paths — the same patch is applied per file with per-file results (a file with 0 matches is reported unchanged, it never blocks the others; expect/all apply per file). Refuses when find matches more than once unless all:true; reports replacements + size/line delta. The safe way to flip statuses and patch lines in .flat.txt.", parameters: { type: "object", properties: { path: { description: "File to edit — or an ARRAY of files (same patch on each)" }, find: { type: "string", description: "Exact text to replace — copy it from find / read output (whitespace matters)" }, replace: { type: "string", description: "New text (empty string = delete the find-text)" }, all: { type: "boolean", description: "true = replace every occurrence (default: more than one match is refused)" }, expect: { type: "integer", description: "Refuse unless exactly this many occurrences matched (safety check, per file)" } }, required: ["path", "find", "replace"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  /* no icon in hf.16 ICONS — ui-chat falls back, keep it that way */
  async run(args, done, agent, name) {
          /* hf.12 — MULTI-FILE EDIT: path = one file (single-file behavior
             byte-identical to before, refusals included) or an ARRAY of files
             — the SAME patch (find→replace, or the edits[] form) runs per file
             with per-file expect/all; a file with no match is REPORTED and
             skipped, never blocking the others. */
          const paths = this._paths(args.path);
          if (!paths.length) return done(false, "path required — a file path, or an array of files to patch with the same find→replace (args: {path, find, replace} or {path, edits:[…]})");
          if (paths.length === 1) return await this._editOne(paths[0], args, done);
          const rows = [];
          for (const p of paths) {
            const r = await this._editOne(p, args, (ok, content) => ({ ok, content }));
            rows.push(`${r.ok ? "✓ " : "✗ "}` + String(r.content).split("\n")[0] + (r.ok && String(r.content).includes("\n") ? "\n" + String(r.content).split("\n").slice(1).join("\n") : ""));
          }
          const okN = rows.filter(r => r.startsWith("✓")).length;
          return done(okN > 0, `multi-edit ×${paths.length} files · ${okN} applied, ${paths.length - okN} refused/no-match (each file independent — expect/all apply per file):\n${rows.join("\n")}`);
  }
}));
})();

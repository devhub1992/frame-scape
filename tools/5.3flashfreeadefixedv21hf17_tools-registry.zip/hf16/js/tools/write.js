/* ============================================================================
   ADE hf.17 — js/tools/write.js
   The hf.16 `case "write":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "write", description: "Write (create or FULLY replace) a text file; parent folders auto-created; mirrors to the linked work folder. hf.11: one call ships ≤16384 chars — a bigger content is REFUSED: build the file with chunk (one call per ≤16k piece, the final index auto-assembles). ≥30 KB files are the LARGE-FILE class — always the chunk suite, never a whole write.", parameters: { type: "object", properties: { path: { type: "string", description: "File path" }, content: { type: "string", description: "Full file content (≤16384 chars)" } }, required: ["path", "content"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-file-pen", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          // ADE-S23.3 (ch-21.f9, m-51): tolerant arg keys (HF.7 lesson) + honest coercion
          const p = VFS.norm(args.path || args.file || args.target || "");
          if (!p || p === "/") return done(false, "invalid path — args: {path, content}");
          let content = args.content;
          if (content === undefined) content = args.text ?? args.body; // accept the key the model actually sent
          if (content !== undefined && content !== null && typeof content !== "string" && typeof content !== "object") content = String(content);
          if (content === undefined || content === null) return done(false, "content required (string) — got none of: content · text · body");
          if (typeof content === "object") return done(false, "content must be a string — JSON.stringify it first (received: " + (content.constructor && content.constructor.name || "object") + ")");
          if (content.length > this.BIG_CALL_CAP) // hf.11 — the 16k WRITE GATE (a field write this size shipped corrupted): the chunked writer is the path
            return done(false, `content too big for ONE write call: ${content.length.toLocaleString()} chars > ${this.BIG_CALL_CAP.toLocaleString()} — build it with chunk (~${Math.ceil(content.length / this.BIG_CALL_CAP)} pieces): {path, index:0, total:${Math.ceil(content.length / this.BIG_CALL_CAP)}, content:<piece 0>} … the final index auto-assembles + verifies${content.length >= this.LARGE_FILE ? " · ≥30 KB = the LARGE-FILE class — the chunk suite is mandatory here" : ""}`);
          await VFS.put(p, content, true);
          // ADE-S13.9 (ch-19.f2, m-34): feed the NOW EDITING window (guard: WSUI loads after agent.js)
          try { WSUI.editing(p, 1, `rewrite · ${content.split("\n").length} lines`, "agent"); } catch { /* window optional */ }
          const linked = VFS.FSA && VFS.FSA.state === "linked" ? " · mirrored to work folder" : "";
          return done(true, `wrote ${p} (${content.length} chars)${linked}`);
  }
}));
})();

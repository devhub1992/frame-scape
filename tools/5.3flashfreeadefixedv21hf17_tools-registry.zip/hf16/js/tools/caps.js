/* ============================================================================
   ADE hf.17 — js/tools/caps.js
   The hf.16 `case "caps":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "caps", description: "Environment capability report — what actually works right now (workspace contents, work-folder link, runtimes, tool list). {deep:true} = full inventory incl. the shell command table + budgets. ADE-HF.3: this tool was advertised in the prompt but missing from the registry — the agent's one successful call burned a turn on 'unknown tool'.", parameters: { type: "object", properties: { deep: { type: "boolean", description: "true = full inventory (agent tools with arg names · shell commands · budgets · version)" } } } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-circle-info", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          if (args.deep === true) { // ADE-S14.7 (ch-21.f3, m-37): the full inventory in ONE cheap call
            const shellCmds = (window.Exec && Exec.Shell && Exec.Shell._cmds) ? Object.keys(Exec.Shell._cmds).filter(k => k !== "help").sort() : [];
            return done(true, [
              `ADE ${ADE_BUILD.version} · ${ADE_BUILD.stamp}`,
              `agent tools (${this.TOOLS.length}): ` + this.TOOLS.map(t => `${t.name}(${t.parameters && t.parameters.properties ? Object.keys(t.parameters.properties).join(",") : ""})`).join(" · "),
              `shell commands (${shellCmds.length}): ${shellCmds.join(" · ")}`,
              "budgets: OUT_CAP caps every tool result · maxSteps/contextK + py/js timeouts = live values in Settings → Agent · audit prompts: routing §08",
              `gaps this session: ${(window.Exec && Exec.Shell && Exec.Shell.gaps) ? Exec.Shell.gaps.length : 0} — shell: gaps prints the ranked list`
            ].join("\n"));
          }
          const rows = await VFS.tree("/").catch(() => []);
          const files = rows.filter(r => r.kind === "file").length;
          const dirs = rows.filter(r => r.kind === "dir").length;
          const fsa = (window.VFS && VFS.FSA) ? VFS.FSA : null;
          const linked = fsa && fsa.state === "linked" && fsa.handle;
          const pyState = (window.Exec && Exec._py && Exec._py.worker) ? "loaded" : "loads on first use (~10MB, user-approved)";
          return done(true, [
            `workspace: IndexedDB VFS — ${files} file(s) · ${dirs} dir(s)${linked ? ` · work folder LINKED: "${fsa.handle.name}" (write-through)` : " · no disk folder linked"}`,
            `runtimes: python = Pyodide WASM worker (${pyState}) · js = dedicated worker sandbox · html = sandboxed preview iframe · shell = virtual over the VFS`,
            `tools: ${this.TOOLS.map(t => t.name).join(" · ")}`
          ].join("\n"));
  }
}));
})();

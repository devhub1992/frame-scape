/* ============================================================================
   ADE hf.17 — js/tools/scan.js
   The hf.16 `case "scan":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "scan", description: "ADE-hf.10: search across ALL ledger parts (from split) in one cheap call — capped 'part:LINE (master LNNN): text' hits. Literal by default; regex:true to switch (same rules as find). Never read a part blind — scan first.", parameters: { type: "object", properties: { manifest: { type: "string", description: "manifest.json path OR the .parts folder" }, pattern: { type: "string", description: "Text to find (literal by default)" }, regex: { type: "boolean", description: "true = pattern is a JS RegExp" }, ignore_case: { type: "boolean", description: "Case-insensitive" }, max: { type: "integer", description: "Max hits (default 40, cap 200)" } }, required: ["manifest", "pattern"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-magnifying-glass-chart", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const L = await this._ledgerManifest(args.manifest || args.dir || args.path);
          if (L.err) return done(false, L.err);
          const pat = String(args.pattern ?? "");
          if (!pat) return done(false, "pattern required — literal by default, regex:true to switch (same rules as find)");
          let re = null;
          if (args.regex) { try { re = new RegExp(pat, args.ignore_case ? "i" : ""); } catch (e) { return done(false, `bad regex: ${e.message}`); } }
          const needle = args.ignore_case ? pat.toLowerCase() : pat;
          const max = Math.max(1, Math.min(200, Number(args.max) || 40));
          const hits = [];
          let scanned = 0;
          for (const part of L.manifest.parts) {
            if (hits.length >= max) break;
            const body = await VFS.readText(L.dir + "/" + part.file);
            if (body == null) continue;
            scanned++;
            const rows = body.split("\n");
            for (let i = 0; i < rows.length; i++) {
              const hit = re ? re.test(rows[i]) : (args.ignore_case ? rows[i].toLowerCase() : rows[i]).includes(needle);
              if (hit) { hits.push(`${part.file}:${i + 1} (master L${part.startLine + i + 1}): ${rows[i].slice(0, 200)}`); if (hits.length >= max) break; }
            }
          }
          if (!hits.length) {
            let hint = "no hits — try a shorter pattern or ignore_case:true";
            if (!re && /[\\^$.*+?()[\]{}|]/.test(pat)) hint += " — this pattern carries REGEX syntax but scan is LITERAL by default: re-run with {\"regex\":true}";
            return done(true, `[scan ${L.dir} · ${scanned}/${L.manifest.parts.length} parts scanned]\n${hint}`);
          }
          const capped = hits.length >= max ? `\n…hit cap ${max} — narrow the pattern or raise max` : "";
          return done(true, this._cap(`[scan ${L.dir} · ${scanned}/${L.manifest.parts.length} parts scanned · ${hits.length} hit(s)]\n${hits.join("\n")}${capped}\n— read {path:"${L.dir}/<part>", offset:<local line − 1>} pulls context; the (master LNNN) is the line in the original file`));
  }
}));
})();

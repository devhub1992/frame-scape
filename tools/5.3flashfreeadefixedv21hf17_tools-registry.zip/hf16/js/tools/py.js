/* ============================================================================
   ADE hf.17 — js/tools/py.js
   The hf.16 `case "py":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "py", description: "LAST RESORT (ADE-HF.8 — the user does not want python for file/archive/flat-file work; unzip · rezip · zipadd · find · edit cover all of that). Only for tasks that genuinely need python libs (numpy/pandas/matplotlib). Pyodide first run pulls ~10MB after user approval; writes sync back into the workspace. Pass inline code or a workspace path.", parameters: { type: "object", properties: { code: { type: "string", description: "Python source to run inline" }, path: { type: "string", description: "…or a .py file path in the workspace" } } } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-brands fa-python", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          let code = null, p = null;
          if (typeof args.code === "string" && args.code.trim()) code = args.code;
          else if (args.path) {
            p = VFS.norm(args.path);
            code = await VFS.readText(p);
            if (code == null) return done(false, `not found: ${p}`);
          } else return done(false, "pass code (inline) or path");
          const r = await this._captureConsole(() => p ? Exec.runPython(p) : Exec.runPython(code, true));
          if (!r) return done(false, "python runtime unavailable — the user declined or the pull failed (see run console)");
          const parts = [r.ok ? "ok" : "FAILED: " + (r.err || "error")];
          const con = this._cap(r.__console || "", this.OUT_CAP);
          if (con) parts.push("stdout/stderr:\n" + con);
          if (r.result && r.result !== "None" && r.result !== "undefined") parts.push("result: " + r.result);
          return done(!!r.ok, parts.join("\n"));
  }
}));
})();

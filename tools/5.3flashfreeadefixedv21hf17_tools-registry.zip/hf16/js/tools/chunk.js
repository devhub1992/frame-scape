/* ============================================================================
   ADE hf.17 — js/tools/chunk.js
   The hf.16 `case "chunk":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "chunk", description: "ADE-hf.11 CHUNKED BIG-WRITE — build a large file FROM THE FIRST TOOL CALL: one call ships ONE ≤16k-char chunk to the workstation; the FINAL index auto-assembles + verifies. Start: {path, index:0, total:N, content} opens <path>.chunks/ staging (size + digest recorded per chunk). Continue index 1…N−1 (out-of-order is fine; identical re-sends are idempotent; a cut run resumes — {path, status:true} lists state, {path, abort:true} discards). Final call: every part re-verified from storage, byte-exact target written, one-shot .pre-chunkwrite.bak of a replaced target, staging cleaned; the report carries chars · lines · digest. ANY new file >16k chars — and the ≥30 KB LARGE-FILE class — MUST go through here; never draft a big file in reply text.", parameters: { type: "object", properties: { path: { type: "string", description: "TARGET file path (the <path>.chunks/ staging dir is tool-owned)" }, index: { type: "integer", description: "0-based chunk index (the final index = total−1 triggers the compile)" }, total: { type: "integer", description: "Total chunk count 1–500 — keep it consistent across calls" }, content: { type: "string", description: "This chunk's text (≤16384 chars)" }, expectBytes: { type: "integer", description: "Optional final-call check: refuse the compile unless the assembled length equals this" } }, required: ["path", "index", "total", "content"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-layer-group", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          const p = VFS.norm(args.path || "");
          if (!p || p === "/" || p.endsWith("/")) return done(false, "invalid path — args: {path, index, total, content} (path is the TARGET file)");
          if (p.includes(".chunks/")) return done(false, `${p} is INSIDE staging — call chunk with the target path only; staging is tool-owned`);
          const dir = p + ".chunks";
          if (args.abort === true) {
            const had = await VFS.exists(dir);
            try { await VFS.rm(dir); } catch { /* already gone */ }
            return done(true, had ? `chunk staging for ${p} discarded (${dir}/ removed)` : `no chunk staging for ${p} — nothing to discard`);
          }
          const mfPath = dir + "/manifest.json";
          const total = Math.round(Number(args.total));
          const index = Math.round(Number(args.index));
          if (args.status === true) {
            const mfRaw = await VFS.readText(mfPath);
            if (mfRaw == null) return done(true, `[chunk status ${p} · NO staging — nothing in flight]\nstart with: chunk {path:"${p}", index:0, total:N, content:<part 0>}`);
            let mf; try { mf = JSON.parse(mfRaw); } catch { return done(false, `staging manifest unreadable: ${mfPath} — abort:true and restart`); }
            const have = (mf.chunks || []).map(c => c.index).sort((a, b) => a - b);
            const missing = []; for (let i = 0; i < mf.total; i++) if (!have.includes(i)) missing.push(i);
            return done(true, `[chunk status ${p} · ${have.length}/${mf.total} staged · target ${mf.target}]\narrived: ${have.join(", ") || "(none)"}${missing.length ? `\nmissing: ${missing.slice(0, 30).join(", ")}${missing.length > 30 ? " …" : ""} — ship them (chunk {path, index:<n>, total:${mf.total}, content})` : "\nall parts staged — re-send the FINAL index (total−1) to compile"}`);
          }
          if (!Number.isFinite(total) || total < 1 || total > 500) return done(false, `total must be 1–500 (got ${args.total ?? "none"}) — one call ships ONE ≤16k-char piece; a single-piece file belongs to write instead`);
          if (!Number.isFinite(index) || index < 0 || index >= total) return done(false, `index out of range: ${args.index ?? "none"} (valid 0–${total - 1})`);
          let content = args.content ?? args.text ?? args.body; // tolerant keys (S23.3 convention)
          if (content === undefined || content === null) return done(false, "content required (this chunk's text)");
          if (typeof content === "object") return done(false, "content must be a string — JSON.stringify it first");
          content = String(content);
          if (content.length > this.BIG_CALL_CAP) return done(false, `chunk too big: ${content.length.toLocaleString()} chars > ${this.BIG_CALL_CAP.toLocaleString()} — raise total and re-ship this index (each call ≤16k chars, the read-cap economy)`);
          const mfRaw = await VFS.readText(mfPath);
          let mf = null;
          if (mfRaw != null) { try { mf = JSON.parse(mfRaw); } catch { mf = null; } }
          if (mf && mf.target !== p) return done(false, `staging at ${dir}/ belongs to "${mf.target}" — {path:"${mf.target}", …} to continue it, or {path:"${p}", abort:true} to discard`);
          if (mf && mf.total !== total) return done(false, `staging holds total ${mf.total}, this call says ${total} — finish with ${mf.total} (status:true shows state) or abort:true + restart`);
          const identical = mf && (mf.chunks || []).some(c => c.index === index && c.bytes === content.length && c.digest === this._fnv(content));
          const replaced = mf && (mf.chunks || []).some(c => c.index === index && !identical);
          /* ALWAYS write the part on arrival — an identical re-send then REFRESHES storage, healing
             a drifted/tampered staged part instead of deadlocking against the compile guard. */
          await VFS.put(dir + "/c" + String(index).padStart(4, "0") + ".part", content, true);
          const now = new Date().toISOString();
          if (!mf) mf = { v: 1, tool: "chunk/1", target: p, total, created: now, chunks: [] };
          mf.updated = now; mf.total = total;
          const rec = { index, file: "c" + String(index).padStart(4, "0") + ".part", bytes: content.length, digest: this._fnv(content) };
          const at = mf.chunks.findIndex(c => c.index === index);
          if (at >= 0) mf.chunks[at] = rec; else mf.chunks.push(rec);
          mf.chunks.sort((a, b) => a.index - b.index);
          await VFS.put(mfPath, JSON.stringify(mf, null, 1), true);
          /* hf.11 fix (suite-caught deadlock): an IDENTICAL re-send of the FINAL index when ALL parts
             are staged must FALL THROUGH to the compile — the early return used to answer
             "re-send the FINAL index" forever, making resume-to-compile impossible. */
          if (identical && !(index === total - 1 && mf.chunks.length === total)) {
            const have = mf.chunks.length;
            const missing = []; for (let i = 0; i < total; i++) if (!mf.chunks.some(c => c.index === i)) missing.push(i);
            return done(true, `chunk ${index}/${total - 1} already arrived, IDENTICAL — staging refreshed (self-heals a drifted part) (${have}/${total} staged${missing.length ? ` — missing: ${missing.slice(0, 20).join(", ")}` : ""}${index === total - 1 ? " — ship the missing part(s), then re-send this final index to compile" : ""})`);
          }
          if (index !== total - 1) {
            const have = mf.chunks.length;
            const missing = []; for (let i = 0; i < total; i++) if (!mf.chunks.some(c => c.index === i)) missing.push(i);
            return done(true, `[chunk ${p} · ${have}/${total} staged${replaced ? ` · index ${index} REPLACED (was different — verify intended)` : ""}]\n  ${rec.file}  ${rec.bytes.toLocaleString()} B  d${rec.digest}${missing.length ? `\nmissing: ${missing.slice(0, 20).join(", ")}${missing.length > 20 ? " …" : ""} — NEXT: chunk {path:"${p}", index:<next>, total:${total}, content}` : ""}`);
          }
          /* FINAL index → COMPILE: re-verify every part FROM STORAGE, then write */
          const missing = []; for (let i = 0; i < total; i++) if (!mf.chunks.some(c => c.index === i)) missing.push(i);
          if (missing.length) return done(false, `final index arrived but ${missing.length} part(s) missing: ${missing.slice(0, 20).join(", ")} — ship them first (status:true shows state); nothing written to ${p}`);
          const bodies = []; const bad = [];
          for (const c of mf.chunks) {
            const body = await VFS.readText(dir + "/" + c.file);
            if (body == null) { bad.push(`${c.file} vanished from staging`); continue; }
            if (body.length !== c.bytes || this._fnv(body) !== c.digest) bad.push(`${c.file} drifted in staging (${c.bytes}→${body.length} B · d${c.digest}→d${this._fnv(body)}) — re-ship: chunk {path, index:${c.index}, total:${total}, content}`);
            else bodies.push({ index: c.index, body });
          }
          if (bad.length) return done(false, `compile REFUSED — staging integrity:\n  ${bad.slice(0, 12).join("\n  ")}\nnothing was written to ${p}.`);
          bodies.sort((a, b) => a.index - b.index);
          const out = bodies.map(b => b.body).join("");
          const expect = Number(args.expectBytes);
          if (Number.isFinite(expect) && expect > 0 && expect !== out.length)
            return done(false, `expectBytes mismatch: assembled ${out.length.toLocaleString()} chars, you expected ${expect.toLocaleString()} — a piece shipped wrong? status:true, find it, re-ship that index; nothing written to ${p}`);
          const prevT = await VFS.readText(p);
          let backup = null;
          if (prevT != null && prevT !== out) { backup = p + ".pre-chunkwrite.bak"; await VFS.put(backup, prevT, true); }
          await VFS.put(p, out, true);
          try { await VFS.rm(dir); } catch { /* staging cleanup is cosmetic */ }
          try { WSUI.editing(p, 1, `chunk-compile · ${total} parts`, "agent"); } catch { /* window optional */ }
          const linked = VFS.FSA && VFS.FSA.state === "linked" ? " · mirrored to work folder" : "";
          return done(true, `[chunk COMPILED → ${p} · ${total} parts · ${out.length.toLocaleString()} chars · ${out.split("\n").length.toLocaleString()} lines · d${this._fnv(out)}]${backup ? `\nprevious target kept: ${backup} (one-shot — delete after verify)` : ""}${out.length >= this.LARGE_FILE ? `\n≥30 KB file — future edits: split → scan → edit → check → assemble (HUGE LEDGERS)` : ""}\nverify: read {path:"${p}", mode:"head"} or digest {path:"${p}"} — staging cleaned${linked}`);
  }
}));
})();

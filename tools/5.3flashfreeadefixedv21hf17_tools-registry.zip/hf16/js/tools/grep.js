/* ============================================================================
   ADE hf.17 — js/tools/grep.js
   The hf.16 `case "grep":" body, extracted VERBATIM (hf.17 tools
   decoupling). Inside run(): `this` is the Agent dispatcher — this._cap,
   this._readOne, every Agent helper behaves exactly as before the split —
   and `name` is the canonical tool name (shared bodies discriminate on it).
   Position in Agent.TOOLS = position of the <script> tag in index.html
   (pinned in _pinned_order.json). Do not reshuffle the tags.
   The IIFE keeps SCHEMA/run off the global lexical scope — many tool files
   share one page, so top-level consts would collide across <script>s.
   ========================================================================== */
(() => {
"use strict";

/* hf.16 TOOLS[] schema entry — byte-identical to the pre-extraction literal */
const SCHEMA = { name: "grep", description: "hf.15 — the DEDICATED -o extractor (grep -o for the VFS): run a REGEX over file(s) and ship ONLY the matches — the file body never enters the conversation. MULTI-FILE + CHUNK-COMPATIBLE: path accepts one file, a folder, or an ARRAY (a JSON-encoded array string coerces) — search many files in ONE call — and files of ANY size (a 30 KB+ LARGE-FILE-class file is its home turf). Capture groups: group:1 ships group 1 · group:'all' joins groups with '·' (no groups → the whole match). Modes: 'hits' (default — path:LINE: match) · 'only' (bare matches) · 'count' (per-file counts + total). unique:true dedupes with per-match counts. CHUNKED OUTPUT: max caps rows per page and offset:N pages forward — a capped result continues with {…, offset:N} instead of a bigger max; context:1-5 ships that many lines around each hit (hits mode). One call lists every id:'…' inventory in a huge file.", parameters: { type: "object", properties: { pattern: { type: "string", description: "JS RegExp (native) — or a plain substring with literal:true" }, path: { description: "File, folder — or an ARRAY of files/folders (default / = every text file)" }, group: { description: "Capture group to ship: 0 = whole match (default) · 1–9 = that group · 'all' = groups joined with '·'" }, mode: { type: "string", enum: ["hits", "only", "count"], description: "hits = path:LINE: match · only = bare matches one per line · count = per-file counts + total" }, unique: { type: "boolean", description: "true = dedupe matches (first-seen order + ×count)" }, context: { type: "integer", description: "hf.15 — 1–5 lines of context shipped around each hit (hits mode; overlapping windows dedupe)" }, offset: { type: "integer", description: "hf.15 — 0-based row skip: page the result (offset:100 ships rows 101+; the tail note names the next offset)" }, literal: { type: "boolean", description: "true = pattern is a literal substring (no regex)" }, ignore_case: { type: "boolean", description: "Case-insensitive" }, max: { type: "integer", description: "Max shipped rows per page (default 100, cap 400)" } }, required: ["pattern"] } };

ADETools.register(Object.assign({}, SCHEMA, {
  icon: "fa-solid fa-magnifying-glass-plus", // verbatim from agent.js ICONS
  async run(args, done, agent, name) {
          /* hf.12 — the DEDICATED -o EXTRACTOR. Field case: the 2026-10-31
             frame-scape run burned ~10 shell gymnastics calls (grep -oE · sed
             -E refusals · awk missing · find on a file) to list id:'…' entries
             from an 83 KB lab file. This tool does it in ONE call over files
             of ANY size: the file body never ships — only capped matches do
             (count/unique give instant inventories). Regex native; literal
             opt-in; capture groups selectable. */
          const pat = String(args.pattern ?? "");
          if (!pat) return done(false, 'pattern required — a JS RegExp by default (e.g. {"pattern":"id:\'([a-zA-Z]+)\'", "unique":true}) or a plain substring with literal:true');
          let re = null;
          if (args.literal === true) {
            try { re = new RegExp(pat.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g" + (args.ignore_case === true ? "i" : "")); }
            catch (e) { return done(false, "bad pattern: " + e.message); }
          } else {
            try { re = new RegExp(pat, "g" + (args.ignore_case === true ? "i" : "")); }
            catch (e) { return done(false, "bad regex: " + e.message); }
          }
          const gspec = args.group == null ? 0 : (args.group === "all" ? "all" : Math.max(0, Math.min(9, Math.floor(Number(args.group) || 0))));
          const mode = ["hits", "only", "count"].includes(args.mode) ? args.mode : "hits";
          const unique = args.unique === true;
          const max = Math.max(1, Math.min(400, Math.floor(Number(args.max)) || 100));
          /* hf.15 — CHUNKED OUTPUT (user call: "rework grep to support multi-file
             + chunking"). (a) offset:N pages the SHIPPED rows forward — a capped
             result continues with {…, offset:N} instead of a bigger max (the
             2026-10-31 round-7 log re-grepped the same file 3× for successive
             slices of one inventory). (b) context:1-5 ships lines around each
             hit (hits mode, overlapping windows deduped) — the read-the-"
             exact-lines" follow-up often dies entirely. The ship cap stays a
             hard 400 rows/call; deep inventories get told to narrow. */
          const off = Math.max(0, Math.min(400, Math.floor(Number(args.offset)) || 0));
          const ctx = Math.max(0, Math.min(5, Math.floor(Number(args.context)) || 0));
          const shipCtx = ctx > 0 && mode === "hits" && !unique;
          const maxTotal = Math.min(400, max + off); // collection cap for this page
          const roots = Array.isArray(args.path) ? this._paths(args.path) : [VFS.norm(args.path || "/")];
          if (Array.isArray(args.path) && !roots.length) return done(false, "path array is empty or invalid — pass real file/folder paths");
          /* hf.14 — honest root resolution (same as find): a missing/bogus root
             reports "NOT FOUND" in the head; only a real non-text file counts
             as "binary skipped". A stringified JSON array path arrives here
             already coerced to a real array (execTool entry). */
          const seen = new Set(); const rows = []; const miss = [];
          for (const root of roots) {
            if (root === "/" || (await VFS.isDir(root))) { for (const r of await VFS.tree(root)) if (r.kind === "file" && !seen.has(r.path)) { seen.add(r.path); rows.push(r); } }
            else if (await VFS.exists(root)) { if (!seen.has(root)) { seen.add(root); rows.push({ path: root }); } }
            else miss.push(root);
          }
          const take = (m) => { // one match → the string this mode ships (may be "")
            if (gspec === "all") {
              if (m.length > 1) return m.slice(1).filter(x => x !== undefined).join("·");
              return String(m[0] ?? ""); // hf.15 — a group:'all' ask on a groupless regex ships the whole match (it used to ship "" → a lying "no matches")
            }
            return String(m[gspec] ?? "");
          };
          const out = [];
          const uniq = new Map(); // unique mode: match → count (first-seen order)
          const counts = [];      // per-file [path, matchCount]
          let total = 0, searched = 0, binary = 0, over = 0;
          const searchedPaths = []; // hf.16 — feeds the 0-hit probe hint
          let ctxShipped = new Set(); // hf.15 — per-file set of line indexes already on the wire (match + context)
          for (const r of rows) {
            const row = (r.isText === undefined) ? await VFS.get(r.path) : r;
            if (!row || row.kind !== "file") { if (!miss.includes(r.path)) miss.push(r.path); continue; } // hf.14 — NOT FOUND, not binary
            if (!row.isText && !U.isTextName(r.path)) { binary++; continue; }
            let txt = null;
            try { txt = await VFS.readText(r.path); } catch { binary++; continue; }
            if (txt == null) { binary++; continue; }
            searched++;
            searchedPaths.push(r.path);
            ctxShipped = new Set(); // context dedupe is per-file
            let n = 0;
            if (mode === "count") { // whole-file scan — matches only COUNT here
              re.lastIndex = 0;
              for (let m = re.exec(txt); m !== null; m = re.exec(txt)) {
                if (m.index === re.lastIndex) re.lastIndex++; // zero-width guard
                const s = take(m); if (s) { n++; if (unique) uniq.set(s, (uniq.get(s) || 0) + 1); }
                if (n >= 500000) { over = 1; break; }
              }
            } else {
              const lines = txt.split("\n"); // per-line: exact line numbers, ^/$ anchors per line
              for (let i = 0; i < lines.length; i++) {
                re.lastIndex = 0;
                for (let m = re.exec(lines[i]); m !== null; m = re.exec(lines[i])) {
                  if (m.index === re.lastIndex) re.lastIndex++; // zero-width guard
                  const s = take(m);
                  if (!s) continue;
                  n++;
                  if (unique) uniq.set(s, (uniq.get(s) || 0) + 1);
                  if (out.length < maxTotal) {
                    if (!unique || !out.some(x => x.__k === s)) {
                      let row0 = mode === "only" ? s.slice(0, 300) : `${r.path}:${i + 1}: ${s.slice(0, 300)}`;
                      if (shipCtx) { // hf.15 — chunk-scoped context around the hit (deduped, 200-char lines)
                        ctxShipped.add(i);
                        const ctxRows = [];
                        for (let j = Math.max(0, i - ctx); j <= Math.min(lines.length - 1, i + ctx); j++) {
                          if (j === i || ctxShipped.has(j)) continue;
                          ctxShipped.add(j);
                          ctxRows.push(`  L${j + 1}: ${String(lines[j]).slice(0, 200)}`);
                        }
                        if (ctxRows.length) row0 += "\n" + ctxRows.join("\n");
                      }
                      out.push({ __k: s, s: row0 });
                    }
                  } else over = 1;
                }
              }
            }
            if (n) counts.push([r.path, n]);
            total += n;
          }
          if (unique && uniq.size > maxTotal) over = 1; // unique inventory exceeds this page's collection cap
          const rootsLabel = (roots.length === 1 && !Array.isArray(args.path)) ? roots[0] : (roots.join(", ").slice(0, 160) + (roots.join(", ").length > 160 ? "…" : ""));
          const head = `[grep ${mode} · ${gspec === "all" ? "all groups" : "group " + gspec}${unique ? " · unique" : ""}${ctx ? ` · ctx ${ctx}` : ""} "${pat.slice(0, 60)}" in ${rootsLabel} · ${total.toLocaleString()} match(es) · searched ${searched} text file(s)${binary ? `, ${binary} binary skipped` : ""}${miss.length ? ` · ${miss.length} path(s) NOT FOUND: ${miss.join(", ").slice(0, 200)}` : ""}${off ? ` · from row ${off + 1}` : ""}]`;
          let body = "";
          let rowsTotal = 0, page = [];
          if (mode === "count") body = counts.map(([p, n]) => `${p}: ${n}`).join("\n") + (counts.length ? `\nTOTAL: ${total}` : "");
          else if (unique && mode === "only") { // unique inventory: bare matches + per-match counts, paged
            rowsTotal = uniq.size;
            page = [...uniq.entries()].slice(off, off + max).map(([s, c]) => `${s}  ×${c}`);
            body = page.join("\n");
          } else { // hits mode (unique keeps the FIRST path:LINE: row per match) · only mode without unique — paged
            rowsTotal = unique ? uniq.size : total;
            page = out.slice(off, off + max).map(x => x.s);
            body = page.join("\n");
          }
          const tail = [];
          const remaining = rowsTotal - (off + page.length);
          if (remaining > 0) {
            if (off + page.length >= 400) tail.push(`…row cap 400 reached (${rowsTotal.toLocaleString()} row(s) match) — narrow the pattern/path, add unique:true, or ship more per page with max (cap 400)`); // the hard cap: a deeper offset can never ship
            else tail.push(`…${remaining.toLocaleString()} more row(s) — next page: same call with offset:${off + page.length} (max ${max}/page)`);
          }
          if (over && remaining <= 0) tail.push(`…match cap reached — raise max (cap 400), narrow the pattern/path, or add unique:true`);
          if (searched > 1 && counts.length > 1 && mode !== "count") tail.push(`per-file: ${counts.slice(0, 8).map(([p, n]) => `${VFS.base(p)} ×${n}`).join(" · ")}${counts.length > 8 ? ` · +${counts.length - 8} more` : ""} — one call covered them; no need to re-grep file-by-file`);
          if (!total) tail.push(await this._grepZeroHint(pat, searchedPaths)); // hf.16 — the 0-hit probe, not a doc recital
          return done(true, this._cap(head + "\n" + body + (tail.length ? "\n" + tail.join("\n") : ""), this.OUT_CAP));
  }
}));
})();

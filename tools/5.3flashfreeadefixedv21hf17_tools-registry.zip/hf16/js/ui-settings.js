/* ============================================================
   js/ui-settings.js — ADE-01.3 · settings modal
   Configs tab: config CRUD (name · model · baseUrl · apiKey ·
   proxyUrl · temperature · maxTokens + NEW maxSteps · contextK ·
   costPerM (ADE-S20.2, ch-26.f2 — $ per 1M tokens, drives the
   burn strip's $ total) · forceProto), model preset chips, Test =
   4-token ping through the proxy. Agent & Workspace tab: status +
   notes (controls land CH-06.f3). Proxy Setup tab: shared
   CorsProxy.io key.
   ============================================================ */
"use strict";

const SettingsUI = {
  editingId: null, // config currently open in the editor
  tab: "configs",

  open(tab) {
    document.getElementById("settings-modal").classList.add("open");
    if (tab) this.switchTab(tab); // switchTab renders its own body (ADE-HF.1)
    else this.render();
  },

  close() {
    document.getElementById("settings-modal").classList.remove("open");
    this.editingId = null;
  },

  switchTab(tab) {
    this.tab = tab;
    document.querySelectorAll(".modal-tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    document.getElementById("modal-body-configs").style.display = tab === "configs" ? "flex" : "none";
    document.getElementById("modal-body-agent").style.display = tab === "agent" ? "flex" : "none";
    document.getElementById("modal-body-proxy").style.display = tab === "proxy" ? "flex" : "none";
    this.render(); /* ADE-HF.1 — tab bodies render on switch; before this fix the
                       Proxy Setup body stayed EMPTY (no key entry field was ever
                       visible unless the modal was force-opened on that tab) */
  },

  init() {
    document.getElementById("open-settings-header").addEventListener("click", () => this.open());
    document.getElementById("open-settings-side").addEventListener("click", () => this.open());
    document.getElementById("settings-close").addEventListener("click", () => this.close());
    document.getElementById("settings-modal").addEventListener("click", e => {
      if (e.target === e.currentTarget) this.close();
    });
    document.querySelectorAll(".modal-tab").forEach(b => b.addEventListener("click", () => this.switchTab(b.dataset.tab)));
  },

  /* ══ Configs tab ═══════════════════════════════════════ */
  async render() {
    if (this.tab === "configs") await this.renderConfigs();
    else if (this.tab === "agent") this.renderAgent();
    else this.renderProxy();
  },

  async renderConfigs() {
    const body = document.getElementById("modal-body-configs");
    const editing = State.configs.find(c => c.id === this.editingId) || null;
    body.innerHTML = `
      <div class="two-key-banner">
        <i class="fa-solid fa-circle-info"></i>
        <div>
          <strong>Two separate API keys are needed.</strong>
          One from <a href="https://console.corsproxy.io" target="_blank" rel="noopener">CorsProxy.io</a> — tunnels requests around CORS, set once under the <strong>Proxy Setup</strong> tab.
          One from <a href="https://aihubmix.com" target="_blank" rel="noopener">AiHubMix</a> — pays for the AI replies, set per-config below.
        </div>
      </div>
      <div class="configs-row">
        <div class="modal-left">
          <button class="new-config-btn" id="new-config-btn"><i class="fa-solid fa-plus"></i> New config</button>
          <div class="config-list" id="config-list">
            ${State.configs.map(c => `
              <div class="config-item ${c.id === this.editingId ? "selected" : ""}" data-id="${c.id}">
                <div class="ci-name">${U.escapeHtml(c.name)} ${c.id === State.activeConfigId ? `<span class="ci-active">active</span>` : ""}</div>
                <div class="ci-model">${U.escapeHtml(c.model)}</div>
              </div>`).join("") || `<div class="conv-empty">No configs yet.</div>`}
          </div>
        </div>
        <div class="modal-right" id="modal-right">${editing ? this.editorHtml(editing) : `
          <div class="empty-state"><i class="fa-solid fa-gear"></i><p>Select a config on the left or create a new one.</p></div>`}
        </div>
      </div>`;

    body.querySelector("#new-config-btn").addEventListener("click", () => this.newConfig());
    body.querySelectorAll(".config-item").forEach(el =>
      el.addEventListener("click", () => { this.editingId = el.dataset.id; this.render(); }));
    if (editing) this.wireEditor(editing);
  },

  editorHtml(c) {
    const isDefaultModel = MODEL_PRESETS.includes(c.model);
    return `
      <div class="form-field">
        <label>Config name</label>
        <input id="f-name" type="text" value="${U.escapeHtml(c.name)}" placeholder="e.g. GLM 5.3 Flash Free" />
      </div>
      <div class="form-field">
        <label>Model (free text)</label>
        <input id="f-model" class="mono" type="text" value="${U.escapeHtml(c.model)}" placeholder="coding-glm-5.3-flash-free" />
        <div class="preset-chips">${MODEL_PRESETS.map(m =>
          `<button class="preset-chip ${m === c.model ? "active" : ""}${isDefaultModel ? "" : ""}" data-model="${m}">${m}</button>`).join("")}
        </div>
      </div>
      <div class="form-grid">
        <div class="form-field">
          <label>Base URL</label>
          <input id="f-baseurl" class="mono" type="text" value="${U.escapeHtml(c.baseUrl)}" placeholder="https://aihubmix.com/v1" />
        </div>
        <div class="form-field">
          <label>API key (AiHubMix)</label>
          <div class="input-with-action">
            <input id="f-apikey" class="mono" type="password" value="${U.escapeHtml(c.apiKey || "")}" placeholder="sk-…" />
            <button id="f-toggle-key" title="Show/hide"><i class="fa-solid fa-eye"></i></button>
          </div>
        </div>
      </div>
      <div class="form-field">
        <label>CORS proxy URL</label>
        <input id="f-proxyurl" class="mono" type="text" value="${U.escapeHtml(c.proxyUrl || "")}" placeholder="https://corsproxy.io/?key={corskey}&url={url}" />
        <div class="hint"><i class="fa-solid fa-circle-info"></i> Placeholders: <code>{url}</code> = target API call · <code>{corskey}</code> = your CorsProxy.io key (Proxy Setup tab). Empty = direct fetch.</div>
      </div>
      <div class="form-grid">
        <div class="form-field">
          <label>Temperature</label>
          <input id="f-temp" type="number" step="0.1" min="0" max="2" value="${U.escapeHtml(String(c.temperature ?? 0.6))}" />
        </div>
        <div class="form-field">
          <label>Max tokens</label>
          <input id="f-maxtok" type="number" step="256" min="256" value="${U.escapeHtml(String(c.maxTokens ?? 8192))}" />
        </div>
        <div class="form-field">
          <label>Max agent steps</label>
          <input id="f-maxsteps" type="number" step="1" min="1" max="100" value="${U.escapeHtml(String(c.maxSteps ?? 24))}" />
          <div class="hint"><i class="fa-solid fa-robot"></i> Tool-loop cap — used from CH-05.</div>
        </div>
        <div class="form-field">
          <label>Context budget (k tokens)</label>
          <input id="f-contextk" type="number" step="4" min="4" value="${U.escapeHtml(String(c.contextK ?? 24))}" />
          <div class="hint"><i class="fa-solid fa-gauge-high"></i> Trim budget — ignored while shortening is OFF below.</div>
        </div>
        <div class="form-field">
          <label class="checkbox-row"><input id="f-notrim" type="checkbox" ${c.noTrim ? "checked" : ""} />
            Context shortening OFF — always send the FULL history</label>
          <div class="hint"><i class="fa-solid fa-shield-halved"></i> ADE-HF.4 (the requested toggle): past ~60% of the budget the trimmer DROPS the oldest turns and stubs old tool results to one-liners — that is what makes a long task "forget" mid-process. Checked = nothing is ever shortened (token burn grows with history — watch the context pill). Unchecked = classic throttled behavior.</div>
        </div>
        <div class="form-field">
          <label>Cost per 1M tokens ($)</label>
          <input id="f-costm" type="number" step="0.005" min="0" value="${c.costPerM ? U.escapeHtml(String(c.costPerM)) : ""}" placeholder="e.g. 0.15" />
          <div class="hint"><i class="fa-solid fa-dollar-sign"></i> THIS model's price for 1,000,000 tokens (0.15 = $0.15/1M). Drives the $ total on the burn strip (ch-26); empty/0 = cost not tracked.</div>
        </div>
      </div>
      <div class="form-field">
        <label class="checkbox-row"><input id="f-forceproto" type="checkbox" ${c.forceProto ? "checked" : ""} />
          Force &lt;&lt;&lt;TOOL&gt;&gt;&gt; text protocol (skip native tool calling)</label>
        <div class="hint"><i class="fa-solid fa-circle-info"></i> For endpoints that reject the tools array — the agent falls back automatically anyway (CH-05).</div>
      </div>
      <div class="form-field">
        <label class="checkbox-row"><input id="f-cachemode" type="checkbox" ${c.cacheMode ? "checked" : ""} />
          Prompt-cache mode — send the project profile ONCE, then deltas (ch-12)</label>
        <div class="hint"><i class="fa-solid fa-database"></i> Uses the workspace snapshot (Workspace → layer icon or the CACHE chip). Runs carry the byte-stable profile prefix + a drift delta; the est-k cost shows in the CACHE chip and on each run. Best on big profiles + repeat patch cycles.</div>
        <details class="cache-protocol" id="f-cache-protocol">
          <summary>Show cache protocol (ai.cache.*, routing §01)</summary>
          <pre class="mono">ai.cache.rule — the FULL project profile is sent ONCE per cache lifecycle; a patch task exchanges ONLY the change iterations (files whose hashes drifted since the snapshot) + the recipe lines; the full zip profile ships back after the patches merge.
ai.cache.profile — cache payload = snapshot manifest: per-file 12-hex sha-256 + est-token total.
ai.cache.patch.recipe.1 — CACHE cache-NNN: you ALREADY hold the project at this snapshot — never expect a re-send of unchanged files.
ai.cache.patch.recipe.2 — DELTA: only drifted files — full text ≤ 400 lines, else a changed-file pointer (fs_read the regions you need).
ai.cache.patch.recipe.3 — TASK: the task lines + the chunk block (or the patch request).
ai.cache.patch.recipe.4 — RETURN: patches + updated bridge-file lines — never re-emit unchanged files.
ai.cache.patch.recipe.5 — SHIP-BACK: merge patches onto the snapshot, re-zip the FULL project — the AI ships patches, the ADE ships the zip (the “Ship cached project zip” action automates this).
ai.cache.invalidate — a snapshot is STALE when any live file hash drifts outside an applied patch (re-zip · manual edit · FSA pull) — re-cache before further patch tasks.</pre>
        </details>
      </div>
      <div class="form-field">
        <label>Extra request body (JSON, advanced)</label>
        <textarea id="f-extrabody" class="mono" rows="3" placeholder='{ "reasoning_effort": "low" }'>${U.escapeHtml(c.extraBody || "")}</textarea>
        <div class="hint"><i class="fa-solid fa-gears"></i> Merged verbatim into every request body (ch-12.f7) — dial thinking/effort per provider WITHOUT vendor lock-in: GLM-family <code>{"thinking":{"type":"…"}}</code> · OpenAI-style <code>{"reasoning_effort":"…"}</code> · Qwen <code>{"enable_thinking":false}</code>. Invalid JSON blocks the save. Default empty = byte-identical body to today.</div>
        <div class="hint err-hint" id="f-extrabody-err" style="display:none;color:var(--err,#e06c60)"></div>
      </div>
      <div class="form-actions">
        <button class="btn" id="f-test"><i class="fa-solid fa-plug"></i> Test</button>
        <span class="test-result" id="f-test-result"></span>
        <span class="spacer"></span>
        <button class="btn danger" id="f-delete"><i class="fa-solid fa-trash"></i> Delete</button>
        <button class="btn" id="f-activate" ${c.id === State.activeConfigId ? "disabled" : ""}><i class="fa-solid fa-circle-check"></i> ${c.id === State.activeConfigId ? "Active" : "Set active"}</button>
        <button class="btn primary" id="f-save"><i class="fa-solid fa-floppy-disk"></i> Save</button>
      </div>`;
  },

  wireEditor(c) {
    const q = s => document.querySelector(s);
    q("#f-toggle-key").addEventListener("click", () => {
      const k = q("#f-apikey");
      k.type = k.type === "password" ? "text" : "password";
    });
    document.querySelectorAll(".preset-chip").forEach(chip =>
      chip.addEventListener("click", () => { q("#f-model").value = chip.dataset.model; this.render(); }));
    q("#f-save").addEventListener("click", () => this.saveEditor(c));
    q("#f-delete").addEventListener("click", () => this.deleteConfig(c));
    q("#f-activate").addEventListener("click", async () => {
      State.activeConfigId = c.id;
      await DB.setSetting(SK.ACTIVE_CONFIG, c.id);
      Main.renderHeaderConfig();
      U.toast("Active config set", { kind: "ok", msg: c.name });
      this.render();
    });
    q("#f-test").addEventListener("click", () => this.testConfig(c));
  },

  async saveEditor(c) {
    const q = s => document.querySelector(s);
    /* ADE-12.7 (ch-12.f7, m-41) — extra-body JSON validated BEFORE the save:
       invalid JSON = honest inline error, the config is NOT touched, no
       request can ever fire with a broken body. */
    const rawBody = q("#f-extrabody").value.trim();
    const errBox = q("#f-extrabody-err");
    errBox.style.display = "none";
    if (rawBody) {
      let parsed = null;
      try { parsed = JSON.parse(rawBody); }
      catch (e) {
        errBox.textContent = "Invalid JSON — not saved. " + (e && e.message ? e.message : "");
        errBox.style.display = "";
        return;
      }
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        errBox.textContent = "Must be a single JSON object (top-level { … }) — not saved.";
        errBox.style.display = "";
        return;
      }
    }
    c.name = q("#f-name").value.trim() || "Untitled";
    c.model = q("#f-model").value.trim() || "coding-glm-5.3-flash-free";
    c.baseUrl = q("#f-baseurl").value.trim() || "https://aihubmix.com/v1";
    c.apiKey = q("#f-apikey").value.trim();
    c.proxyUrl = q("#f-proxyurl").value.trim();
    c.temperature = Math.min(2, Math.max(0, parseFloat(q("#f-temp").value) || 0.6));
    c.maxTokens = parseInt(q("#f-maxtok").value, 10) || 8192;
    c.maxSteps = Math.min(100, Math.max(1, parseInt(q("#f-maxsteps").value, 10) || 24));
    c.contextK = Math.max(4, parseInt(q("#f-contextk").value, 10) || 24);
    c.noTrim = q("#f-notrim").checked;   // ADE-HF.4 — context-shortening OFF toggle (per config)
    c.costPerM = Math.max(0, parseFloat(q("#f-costm").value) || 0);   // ADE-S20.2 (ch-26.f2, m-46) — $ per 1M tokens; empty → 0 = not tracked
    c.forceProto = q("#f-forceproto").checked;
    c.cacheMode = q("#f-cachemode").checked;   // ADE-12.2 (ch-12.f2) — per-config cache mode
    c.extraBody = rawBody;                     // ADE-12.7 (ch-12.f7) — normalized at save
    await DB.saveConfig(c);
    State.configs = await DB.allConfigs();
    Main.renderHeaderConfig();
    U.toast("Config saved", { kind: "ok", msg: c.name });
    this.render();
  },

  async deleteConfig(c) {
    if (State.configs.length <= 1) { U.toast("Cannot delete", { kind: "err", msg: "At least one config must remain." }); return; }
    if (!confirm(`Delete config "${c.name}"?`)) return;
    await DB.delConfig(c.id);
    State.configs = await DB.allConfigs();
    if (State.activeConfigId === c.id) {
      State.activeConfigId = State.configs[0]?.id || null;
      await DB.setSetting(SK.ACTIVE_CONFIG, State.activeConfigId);
      Main.renderHeaderConfig();
    }
    this.editingId = null;
    U.toast("Config deleted", { kind: "ok" });
    this.render();
  },

  async newConfig() {
    const c = makeDefaultConfig();
    c.name = "New config";
    c.apiKey = "";
    await DB.saveConfig(c);
    State.configs = await DB.allConfigs();
    this.editingId = c.id;
    this.render();
  },

  /* Test = 4-token ping through the resolved proxy (f3) */
  async testConfig(c) {
    const out = document.getElementById("f-test-result");
    out.className = "test-result";
    out.textContent = "pinging…";
    const t0 = performance.now();
    try {
      const url = await ChatUI.resolveUrl(c);
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": "Bearer " + c.apiKey },
        body: JSON.stringify({ model: c.model, messages: [{ role: "user", content: "ping" }], max_tokens: 4, stream: false })
      });
      const ms = Math.round(performance.now() - t0);
      if (res.ok) {
        out.className = "test-result ok";
        out.textContent = `OK · ${ms}ms · HTTP ${res.status}`;
      } else {
        let detail = "";
        try { detail = (await res.text()).slice(0, 160); } catch { /* ignore */ }
        out.className = "test-result err";
        out.textContent = `HTTP ${res.status} · ${ms}ms${detail ? " — " + detail : ""}`;
      }
    } catch (e) {
      out.className = "test-result err";
      out.textContent = "Network error — proxy down or key invalid (" + Math.round(performance.now() - t0) + "ms)";
    }
  },

  /* ══ Agent & Workspace tab (ADE-06.3 — budgets + settings + pills) ════
     agent budget defaults live in the settings store (agent_max_steps ·
     agent_context_k — consumed by makeDefaultConfig for NEW configs; the
     active config's own values always win at run time, edit them in the
     Configs tab or via "apply to active") · executor timeouts persist to
     the keys Exec._timeout already reads (py_timeout_s · js_timeout_s) ·
     the autosync toggle flips VFS.FSA.autoSync live (fsa_autosync key,
     default ON) · usage pills estimate the current context + per-session
     request count.                                                     */
  renderAgent() {
    const cfg = ChatUI.activeConfig();
    const body = document.getElementById("modal-body-agent");
    const defSteps = Math.min(100, Math.max(1, Number(State.agentMaxSteps) || 24));
    const defCtx = Math.min(200, Math.max(4, Number(State.agentContextK) || 24));
    const pyT = 120, jsT = 10; // defaults; real stored values fetched async below
    const fsaState = VFS.FSA ? VFS.FSA.state : "none";

    /* usage pills — context estimate over the active conversation's rows
       (same accounting as Agent.buildContext: content + toolCalls + ~4t) */
    const est = (s) => U.estimateTokens(typeof s === "string" ? s : JSON.stringify(s ?? ""));
    let ctxEst = 0;
    for (const m of State.msgs) {
      if (m.convId !== State.activeConvId || m.error) continue;
      ctxEst += est(m.content) + (m.toolCalls ? est(m.toolCalls) + 4 : 0) + 4;
    }
    const ctxK = Math.round(ctxEst / 100) / 10;
    const budgetK = cfg ? Number(cfg.contextK ?? 24) : 24;
    const pct = Math.min(100, Math.round((ctxEst / (budgetK * 1000)) * 100));

    body.innerHTML = `<div style="width:100%">
      <div class="usage-pills">
        <span class="pill" title="estimate of the active conversation's context (history + tool results) vs the active config's budget"><i class="fa-solid fa-gauge-high"></i> context est ≈ ${ctxK}k / ${budgetK}k (${pct}%)</span>
        <span class="pill" title="AI requests sent this browser session"><i class="fa-solid fa-paper-plane"></i> ${State.sessionRequests} request${State.sessionRequests === 1 ? "" : "s"} this session</span>
      </div>
      <div class="agent-note">
        <i class="fa-solid fa-robot"></i>
        <div><strong>Agent budget defaults — for NEW configs (settings store).</strong> The active config's own values always win at run time; edit them per-config in the <strong>Configs</strong> tab or apply the defaults below onto it.</div>
      </div>
      <div class="form-grid">
        <div class="form-field">
          <label>Max steps (tool-call cap per run)</label>
          <input id="f-agent-steps" class="mono" type="number" min="1" max="100" value="${defSteps}" />
        </div>
        <div class="form-field">
          <label>Context budget (k-tokens)</label>
          <input id="f-agent-ctx" class="mono" type="number" min="4" max="200" value="${defCtx}" />
        </div>
      </div>
      <div class="form-actions">
        <button class="btn primary" id="f-save-budgets"><i class="fa-solid fa-floppy-disk"></i> Save defaults</button>
        <button class="btn" id="f-apply-active" ${cfg ? "" : "disabled"}><i class="fa-solid fa-bolt"></i> Apply to active config${cfg ? ` (${U.escapeHtml(cfg.name)})` : ""}</button>
      </div>
      <div class="agent-note">
        <i class="fa-solid fa-stopwatch"></i>
        <div><strong>Executor timeouts.</strong> Read live by the python (Pyodide) and js (worker) runners — killing a run reloads its sandbox.</div>
      </div>
      <div class="form-grid">
        <div class="form-field">
          <label>Python timeout (seconds)</label>
          <input id="f-py-timeout" class="mono" type="number" min="5" max="600" value="${pyT}" />
        </div>
        <div class="form-field">
          <label>JS timeout (seconds)</label>
          <input id="f-js-timeout" class="mono" type="number" min="1" max="120" value="${jsT}" />
        </div>
      </div>
      <div class="form-actions"><button class="btn primary" id="f-save-timeouts"><i class="fa-solid fa-floppy-disk"></i> Save timeouts</button></div>
      <div class="agent-note">
        <i class="fa-solid fa-folder-tree"></i>
        <div><strong>Work folder autosync.</strong> When a disk folder is linked, every workspace write mirrors to disk (write-through). Toggle applies immediately.</div>
      </div>
      <div class="form-field checkbox-field">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer"><input id="f-autosync" type="checkbox" ${VFS.FSA && VFS.FSA.autoSync !== false ? "checked" : ""} /> Write-through to the linked work folder (autosync)</label>
      </div>
      <div class="form-field checkbox-field">
        <!-- ADE-S25.7 (ch-31.f4, m-56) — the auto-continue engine toggle; default ON, real state applied async below -->
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer"><input id="f-autocont" type="checkbox" checked /> Auto-continue stalled runs (scroll to bottom · 5 s grace · re-drive · ≤6 attempts)</label>
      </div>
      <div class="kv-list">
        <div class="kv"><span class="k">indexeddb</span><span class="v ok">ade-db v1 · ${DB.STORES.VFS} + 5 stores</span></div>
        <div class="kv"><span class="k">vfs</span><span class="v ok">live — files · folders · editor · zip in/out</span></div>
        <div class="kv"><span class="k">fsa work folder</span><span class="v ${fsaState === "linked" ? "ok" : "dim"}">${fsaState}${fsaState === "linked" && VFS.FSA.handle ? " — " + U.escapeHtml(VFS.FSA.handle.name || "") : ""}</span></div>
        <div class="kv"><span class="k">executors</span><span class="v ok">live — pyodide · js worker · iframe preview · shell</span></div>
        <div class="kv"><span class="k">agent loop</span><span class="v ok">live — 12 tools · trace cards · text-protocol fallback</span></div>
        <div class="kv"><span class="k">ade system prompt</span><span class="v ok">live — protocol + FlatBridge philosophy embedded (CH-06)</span></div>
        <div class="kv"><span class="k">flat files</span><span class="v dim" id="f-flatstate">checking workspace…</span></div>
      </div>
    </div>`;

    /* wire — budgets (defaults → settings store) */
    body.querySelector("#f-save-budgets").addEventListener("click", async () => {
      const steps = Math.min(100, Math.max(1, Number(body.querySelector("#f-agent-steps").value) || 24));
      const ctx = Math.min(200, Math.max(4, Number(body.querySelector("#f-agent-ctx").value) || 24));
      State.agentMaxSteps = steps; State.agentContextK = ctx;
      await DB.setSetting(SK.AGENT_MAX_STEPS, steps);
      await DB.setSetting(SK.AGENT_CONTEXT_K, ctx);
      U.toast("Budget defaults saved", { kind: "ok", msg: `new configs start at ${steps} steps · ${ctx}k context` });
      this.render();
    });
    body.querySelector("#f-apply-active")?.addEventListener("click", async () => {
      const cfg = ChatUI.activeConfig();
      if (!cfg) return;
      cfg.maxSteps = Math.min(100, Math.max(1, Number(body.querySelector("#f-agent-steps").value) || 24));
      cfg.contextK = Math.min(200, Math.max(4, Number(body.querySelector("#f-agent-ctx").value) || 24));
      await DB.saveConfig(cfg);
      Main.renderHeaderConfig();
      U.toast("Applied to active config", { kind: "ok", msg: `${cfg.name}: ${cfg.maxSteps} steps · ${cfg.contextK}k context` });
    });
    /* executor timeouts — the exact keys Exec._timeout reads */
    Exec._timeout("py_timeout_s", 120).then(v => { const el = body.querySelector("#f-py-timeout"); if (el) el.value = v; });
    Exec._timeout("js_timeout_s", 10).then(v => { const el = body.querySelector("#f-js-timeout"); if (el) el.value = v; });
    body.querySelector("#f-save-timeouts").addEventListener("click", async () => {
      const py = Math.min(600, Math.max(5, Number(body.querySelector("#f-py-timeout").value) || 120));
      const js = Math.min(120, Math.max(1, Number(body.querySelector("#f-js-timeout").value) || 10));
      await DB.setSetting("py_timeout_s", py);
      await DB.setSetting("js_timeout_s", js);
      U.toast("Timeouts saved", { kind: "ok", msg: `python ${py}s · js ${js}s — applied to the next run` });
    });
    /* autosync — live-applies to the FSA write-through (fsa_autosync) */
    body.querySelector("#f-autosync").addEventListener("change", async (e) => {
      const on = !!e.target.checked;
      if (VFS.FSA) VFS.FSA.autoSync = on;
      await DB.setSetting("fsa_autosync", on);
      U.toast("Autosync " + (on ? "on" : "off"), { kind: "ok", msg: on ? "workspace writes mirror to the linked folder" : "writes stay in the IndexedDB VFS until you re-enable" });
    });
    /* ADE-S25.7 (ch-31.f4, m-56) — auto-continue toggle (DB kv "auto_continue", default ON) */
    body.querySelector("#f-autocont").addEventListener("change", async (e) => {
      const on = !!e.target.checked;
      await DB.setSetting("auto_continue", on);
      U.toast("Auto-continue " + (on ? "on" : "off"), { kind: "ok", msg: on ? "stalled runs re-drive themselves (scroll to bottom · 5 s grace · ≤6 attempts)" : "stalled runs stay paused — press ↻ Continue to re-drive manually" });
    });
    (async () => { try { const cb = body.querySelector("#f-autocont"); if (cb) cb.checked = (await DB.getSetting("auto_continue")) !== false; } catch { /* default checked */ } })();
    /* flat-file presence — the live state layer the prompt reads */
    (async () => {
      const el = body.querySelector("#f-flatstate");
      if (!el) return;
      const names = ["routing.flat.txt", "manifest.flat.txt", "planner.flat.txt", "readme.txt"];
      const found = [];
      for (const n of names) if (await VFS.exists("/" + n)) found.push(n);
      el.textContent = found.length ? `${found.length}/4 in workspace — protocol is LIVE for the agent` : "not in workspace — agent runs on the embedded philosophy alone";
      el.className = found.length ? "v ok" : "v dim";
    })();
  },

  /* ══ Proxy Setup tab (ADE-HF.1/HF.2/HF.3 — wired key entry) ══
     HF-1: this tab now RENDERS on switch (see switchTab) — before, the
           body stayed blank and the key field was unreachable.
     HF-2: wiring status row (mode · key state · resolved URL) so an empty
           key is VISIBLE before requests fail; Agent.resolveUrl toasts once
           per session when a {corskey} template fires with no key stored.
     HF-3: mode presets (keyed CorsProxy.io / direct — AiHubMix itself serves
           CORS headers, verified 2026-10-30; public keyless proxies are dead:
           workers.dev abuse-banned · allorigins no POST · cors.lol 429) + a
           Test ping button proving the key end-to-end from this tab. */
  renderProxy() {
    const body = document.getElementById("modal-body-proxy");
    const cfg = ChatUI.activeConfig();
    const keyLen = (State.corsKey || "").length;
    const needsKey = !!(cfg && (cfg.proxyUrl || "").includes("{corskey}"));
    let mode = cfg ? "direct fetch — no proxy" : "no active config";
    if (cfg && needsKey) mode = keyLen
      ? `keyed CorsProxy.io template — key wired (${keyLen} chars)`
      : "CorsProxy template but KEY MISSING — requests will 403";
    else if (cfg && (cfg.proxyUrl || "").trim()) mode = "custom proxy template";
    body.innerHTML = `<div class="proxy-panel">
      <div class="proxy-section">
        <div class="title"><i class="fa-solid fa-gauge"></i> Wiring status — active config</div>
        <div class="kv-list">
          <div class="kv"><span class="k">config</span><span class="v">${cfg ? U.escapeHtml(cfg.name) : "—"}</span></div>
          <div class="kv"><span class="k">proxy mode</span><span class="v ${needsKey && !keyLen ? "err" : "ok"}">${U.escapeHtml(mode)}</span></div>
          <div class="kv"><span class="k">resolved url</span><span class="v dim mono" id="f-resolved-url">…</span></div>
        </div>
        ${cfg ? "" : `<div class="hint"><i class="fa-solid fa-circle-info"></i> Create/activate a config first — status reads the active one.</div>`}
      </div>
      <div class="proxy-section">
        <div class="title"><i class="fa-solid fa-key"></i> Your CorsProxy.io API key</div>
        <div class="desc">Shared across every config — fills the <code>{corskey}</code> placeholder in any Proxy URL automatically.</div>
        <div class="form-field">
          <div class="input-with-action">
            <input id="f-corskey" class="mono" type="password" placeholder="Get one free at console.corsproxy.io" value="${U.escapeHtml(State.corsKey || "")}" />
            <button id="f-toggle-corskey" title="Show"><i class="fa-solid fa-eye"></i></button>
          </div>
          <div class="hint"><i class="fa-solid fa-lock"></i> Stored in IndexedDB only — never sent anywhere except your proxy.</div>
        </div>
        Get a free key at <a href="https://console.corsproxy.io" target="_blank" rel="noopener">console.corsproxy.io</a> → Manage Domains → add the domain you host ADE on.
        <div class="form-actions">
          <button class="btn primary" id="f-save-corskey"><i class="fa-solid fa-floppy-disk"></i> Save key</button>
          <button class="btn" id="f-test-proxy"><i class="fa-solid fa-plug"></i> Test ping (active config)</button>
          <span class="test-result" id="f-proxytest-result"></span>
        </div>
        <div class="hint"><i class="fa-solid fa-circle-info"></i> HTTP 200 = key wired end-to-end. HTTP 401 from AiHubMix = tunnel + CorsProxy key fine — that 401 is your AiHubMix key (Configs tab). HTTP 403 from corsproxy.io = wrong/absent CorsProxy key or domain not registered.</div>
      </div>
      <div class="proxy-section">
        <div class="title"><i class="fa-solid fa-wand-magic-sparkles"></i> Proxy mode presets — writes Proxy URL onto EVERY config</div>
        <div class="preset-chips">
          <button class="preset-chip" data-tpl="https://corsproxy.io/?key={corskey}&amp;url={url}">CorsProxy.io — keyed (default)</button>
          <button class="preset-chip" data-tpl="">Direct — no proxy</button>
        </div>
        <div class="hint"><i class="fa-solid fa-triangle-exclamation"></i> Public keyless proxies are DEAD as of 2026-10-30 (live-tested: cors.workers.dev abuse-banned · allorigins drops POST · cors.lol 429) — the reliable tunnel is YOUR CorsProxy.io key. "Direct" works for AiHubMix endpoints (they serve CORS headers — verified) but not for CORS-hostile providers.</div>
      </div>
      <div class="proxy-section">
        <div class="title"><i class="fa-solid fa-list"></i> Known-good proxy templates</div>
        <ul>
          <li><code>https://corsproxy.io/?key={corskey}&amp;url={url}</code> — default; free tier is a 7-day rolling window of 2500 requests / 500 MB</li>
          <li><code>https://api.allorigins.win/raw?url={url}</code> — unlimited, but may not pass auth headers reliably</li>
          <li><code>https://proxy.cors.sh/</code> — prefix-style; ADE appends the target URL</li>
          <li>Any local proxy that takes the full target URL as the path</li>
        </ul>
      </div>
      <div class="proxy-section" id="wt-panel-host"></div>
    </div>`;
    body.querySelector("#f-toggle-corskey").addEventListener("click", () => {
      const k = body.querySelector("#f-corskey");
      k.type = k.type === "password" ? "text" : "password";
    });
    /* resolved-URL preview + handlers (ADE-HF.2/HF.3) */
    if (cfg) Agent.resolveUrl(cfg).then(u => {
      const el = body.querySelector("#f-resolved-url");
      if (el) el.textContent = u.length > 96 ? u.slice(0, 96) + "…" : u;
    }).catch(() => { /* status row stays '…' */ });
    body.querySelector("#f-save-corskey").addEventListener("click", async () => {
      State.corsKey = body.querySelector("#f-corskey").value.trim();
      await DB.setSetting(SK.CORS_KEY, State.corsKey);
      Agent._keyWarned = false; // re-arm the empty-key guard
      Main.renderHeaderConfig();
      U.toast("CorsProxy key saved", { kind: "ok", msg: State.corsKey ? `wired — ${State.corsKey.length} chars, fills {corskey} in every config` : "cleared — keyed configs will 403 until a key is set" });
      this.render(); // refresh the wiring status row
    });
    body.querySelectorAll(".preset-chip").forEach(chip => chip.addEventListener("click", async () => {
      for (const c of State.configs) { c.proxyUrl = chip.dataset.tpl; await DB.saveConfig(c); }
      Main.renderHeaderConfig();
      U.toast("Proxy mode applied", { kind: "ok", msg: (chip.dataset.tpl ? "keyed CorsProxy.io template" : "direct — no proxy") + ` on ${State.configs.length} config(s)` });
      this.render();
    }));
    /* HF-3 — Test ping: proves the CorsProxy key end-to-end from this tab
       (tunnel + {corskey} substitution + reachability of the endpoint) */
    body.querySelector("#f-test-proxy").addEventListener("click", async () => {
      const out = body.querySelector("#f-proxytest-result");
      const cfg = ChatUI.activeConfig();
      if (!cfg) { out.className = "test-result err"; out.textContent = "no active config"; return; }
      out.className = "test-result";
      out.textContent = "pinging…";
      const t0 = performance.now();
      try {
        const url = await Agent.resolveUrl(cfg);
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": "Bearer " + (cfg.apiKey || "missing") },
          body: JSON.stringify({ model: cfg.model, messages: [{ role: "user", content: "ping" }], max_tokens: 4, stream: false })
        });
        const ms = Math.round(performance.now() - t0);
        if (res.ok) {
          out.className = "test-result ok";
          out.textContent = `OK · ${ms}ms · HTTP ${res.status} — key wired end-to-end`;
        } else {
          let detail = "";
          try { detail = (await res.text()).slice(0, 120); } catch { /* ignore */ }
          out.className = "test-result err";
          out.textContent = `HTTP ${res.status} · ${ms}ms${detail ? " — " + detail : ""}`;
        }
      } catch (e) {
        out.className = "test-result err";
        out.textContent = `Network error — proxy unreachable or key invalid (${Math.round(performance.now() - t0)}ms)`;
      }
    });

    /* hf.17 — Web & Sync key panel (localStorage: github_pat · neocities_api_key ·
       webtool_proxy_url). Markup + handlers live in js/tools/web.js; guarded so
       the settings tab still renders if the web tool file is absent. */
    if (window.WT && typeof WT.buildKeyPanel === "function") WT.buildKeyPanel(body);
  }
};

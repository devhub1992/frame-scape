/* ============================================================
   sw.js — ADE-S21 · offline deploy worker (ch-27, m-47)
   "I need to be able to deploy my ade as an offline web app" —
   this worker now does BOTH jobs, update-wins AND offline:
     · PRECACHE AT INSTALL: the whole app shell (index.html · css ·
       every js/ + vendor · manifest.webmanifest · icons · sw.js)
       PLUS the 4 flat files + readme + DEPLOY.txt — so the
       workspace auto-seed (ch-06.f2) works even offline. Seeded
       with allSettled per-file: one 404 never kills the install.
     · NETWORK-FIRST for same-origin GETs is KEPT (ch-14 doctrine,
       m-31): an online page always fetches the freshly uploaded
       index.html / js / css from the site; the cache copy is the
       OFFLINE fallback — now seeded instead of discovered.
     · NAVIGATION FALLBACK: a navigation that fails online AND has
       no cache entry falls back to the cached index.html.
     · CDN RUNTIME CACHE (stale-while-revalidate) for the allowlist
       ONLY — cdnjs (Font Awesome) · Google Fonts (css + woff2) ·
       cdn.jsdelivr (Pyodide pull). One online visit makes icons +
       fonts + Pyodide survive offline. AI/API hosts are NEVER in
       the list and pass through untouched.
     · VERSIONED cache (ade-sw-vs22): on activate every cache from
       an older build is deleted, so nothing stale survives.
     · skipWaiting + clients.claim: the new worker takes control
       on the very first load after a deploy; main.js reloads the
       page once on controllerchange so fresh code runs at once.
   Registered by main.js (secure contexts only — https or localhost;
   file:// and non-https hosts silently skip it, the ?v= busting on
   the asset tags in index.html covers those cases instead).
   Messages: SKIP_WAITING · ADE_SW_CLEAR (wipes caches on demand —
   used by the sidebar refresh button, see Main.forceRefresh();
   note: clearing offline then going offline means a cold cache —
   revisit online once to re-seed).
   NEW FILES ON A SHIP: add them to PRECACHE below — this list IS
   the build manifest (no build step; see DEPLOY.txt §new-files).
   ============================================================ */
"use strict";

const SW_CACHE = "ade-sw-vs36"; /* hf.16: DEBUG LEDGER + HEAD/TAIL + GREP PROBE + STALE-RESUME GUARD — every empty response / stall death and every tool ERROR auto-records into /ade.debug.flat.txt (dated flat line: death kind + the EXACT tool + query + result head + the agent's thoughts that ran just before it); the BURN strip gains a 🐛 debug button copying the ACTIVE session's lines to the clipboard; NEW head/tail tools (first/last N lines, path = ONE file OR an ARRAY, any size — tail KEEPS THE END, ≥30 KB ships the slice plan); a 0-hit grep probes with ≤4 cheaper matchers and ships the first hit WITH a sample line (the 't1[01]\d' vs 't:100' field killer); the f3 dropped-turn ledger now carries per-tool arg digests + the lost report's head (the round-8 '4 code edits' mis-attribution cannot repeat); RESUME STATE injections on continues that already advanced say MAY BE STALE, name a trailing tool ERROR and forbid the state-file DONE; auto/manual continue nudges require the CURRENT task's verified deliverable before DONE — bump forces every client to pick up the patch */ /* hf.15: BATCHED SLICES + FILE BURN — read {reads:[{path|paths, offset?, limit?, mode?}…]} ships several chunk-scoped slices in ONE call (the round-7 field log: 3 parallel reads on the same ledger + 2 on the lab in single steps); grep goes CHUNKED: offset:N pages a capped result forward (the tail names the next offset — the hard 400-row cap says narrow, never a dead next page), context:1-5 ships deduped lines around each hit, group:'all' on a groupless regex ships the whole match (was a lying 'no matches'), multi-file results carry per-file counts; the NOW EDITING window gains the FILE TOKEN BURN ledger (per-file ↑ prompt intake · ✦ named-reasoning · ↓ written-back, Agent.fileBurn → WSUI.fileBurn; reads/greps feed the lead row too) — bump forces every client to pick up the patch */ /* hf.14: the 30 KB LARGE-FILE line (BIG_READ_CAP/LARGE_FILE = 30720) + SEAMLESS chunking — a whole read NEVER refuses (16–30 KB = head slice + skip note; >30 KB = head slice + the slice plan: exact next offset · ≈slice count · the grep jump); slice notes derived from what actually ships (body budgeted inside the cap envelope); digest flags ≥30 KB rows ⚑L; split bytes default 32768 → 15360 (parts read whole in one call); MULTI-FILE path/files coerce a JSON-encoded array STRING (the 'searched 0 text file(s), 1 binary skipped' field case); find/grep report missing roots as NOT FOUND, not binary; buildContext segments at REAL task turns only — continue nudges / TOOL_RESULT rows no longer orphan the active task segment (the round-7 derailment) — bump forces every client to pick up the patch */ /* hf.13: PER-CHAT header clock (elapsed anchors at the active chat's creation — a new chat restarts it at 0:00, switching chats swaps the anchor; tokens = Σ exact usage.t of the chat's OWN assistant rows, so other chats' burn can never leak into the rate; fixes the 2026-10-31 report: a 57-min tab that never reset across two 600k-tok + one 300k-tok projects blended into 4470 tok/min) + COMPOSER DRAFT PERSISTENCE (every keystroke of #msg-input → localStorage per conversation ade_draft_v1_<convId>, 48k cap; reloads / SW-update reloads / closed tabs never eat typed work; drafts follow chat switching; the pre-chat scratch draft migrates into the chat it starts; send clears, delete discards) — bump forces every client to pick up the patch */ /* hf.12: MULTI-FILE tools (read/find/edit/append accept path ARRAYS) + NEW grep tool (dedicated -o extractor: regex/capture groups, hits/only/count, unique — multi-file, any size) + js files[] FS preload + empty-response auto-shrink escalation + shell multi-file grep/sed, find -pattern/-E/-max aliases, js -e — bump forces every client to pick up the patch */ /* hf.11: chunked big-write tool (chunk — one call ships one ≤16k piece, final index auto-compiles + verifies) + ONE-WORD tool names (list/read/write/chunk/find/edit/split/scan/check/assemble/state/py/js/preview/probe… — legacy fs_* · flat_* · ledger_* spellings still resolve) + 16k write/append gates + header session clock (time + exact tok/min) + quiet-error chips — bump forces every client to pick up the patch */ /* hf.10: ledger chunker suite (split/find/check/assemble) + mid-run state_save checkpoints + cut -c + shell per-line cap */ /* hf.9: image_probe pixel scanner + STATE handoff (ade.state.flat.txt) + 4xx/5xx body capture (ade.errors.log) + whole-read gate + 3× transient retry — bump with every shipped build (↔ ADE_BUILD.version) */

/* ch-27.f1 — the offline seed: every same-origin file the app needs to
   boot + seed from zero. Icons + manifest + flat files included. */
const PRECACHE = [
  "index.html",
  "manifest.webmanifest",
  "css/ade.css",
  "js/util.js",
  "js/db.js",
  "js/vfs.js",
  "js/exec.js",
  "js/agent.js",
  "js/ui-chat.js",
  "js/ui-workspace.js",
  "js/scheduler.js",
  "js/ui-settings.js",
  "js/main.js",
  "js/vendor/fflate.min.js",
  "sw.js",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/icon-maskable-512.png",
  "icons/apple-touch-icon-180.png",
  "routing.flat.txt",
  "manifest.flat.txt",
  "planner.flat.txt",
  "readme.txt",
  "DEPLOY.txt"
];

/* ch-27.f2 — cross-origin RUNTIME cache allowlist (stale-while-revalidate).
   Exact origins only. Deliberately EXCLUDES every API/proxy host
   (aihubmix.com · corsproxy.io · console.corsproxy.io · api.allorigins.win ·
   proxy.cors.sh) — AI calls must never be served from a cache. */
const CDN_ALLOWLIST = new Set([
  "cdnjs.cloudflare.com",   /* Font Awesome css + webfonts */
  "fonts.googleapis.com",   /* Space Grotesk + JetBrains Mono css */
  "fonts.gstatic.com",      /* font binaries */
  "cdn.jsdelivr.net"        /* Pyodide runtime (executors) */
]);

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(SW_CACHE);
    /* allSettled, not addAll: one blocked/missing file must not abort
       the whole seed — misses simply stay network-dependent */
    const results = await Promise.allSettled(
      PRECACHE.map(async (path) => {
        const res = await fetch(path, { cache: "no-cache" });
        if (!res.ok) throw new Error(path + " → " + res.status);
        await cache.put(path, res);
      })
    );
    const missed = results.filter(r => r.status === "rejected")
      .map(r => String(r.reason && r.reason.message || r.reason));
    if (missed.length) console.warn("[ade-sw] precache misses:", missed);
    self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    /* purge every cache this build does not own (old deploys die here) */
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== SW_CACHE).map(k => caches.delete(k)));
    await self.clients.claim(); /* control open pages immediately */
  })());
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;                        /* POSTs (AI calls) pass straight through */
  const url = new URL(req.url);

  /* ── same-origin: NETWORK-FIRST (update-wins), cache = offline fallback ── */
  if (url.origin === self.location.origin) {
    event.respondWith((async () => {
      try {
        const fresh = await fetch(req, { cache: "no-cache" }); /* revalidate, never trust HTTP cache */
        if (fresh && (fresh.ok || fresh.type === "opaqueredirect")) {
          const cache = await caches.open(SW_CACHE);
          cache.put(req, fresh.clone()).catch(() => {});
        }
        return fresh;
      } catch (err) {
        const cache = await caches.open(SW_CACHE);
        const cached = await cache.match(req, { ignoreSearch: true });
        if (cached) return cached;
        /* ch-27.f1 — navigation fallback: cold-cache navigation offline
           still boots the app shell from the seeded index.html */
        if (req.mode === "navigate") {
          const shell = await cache.match("index.html", { ignoreSearch: true });
          if (shell) return shell;
        }
        throw err; /* offline AND never cached — let the page show its own error */
      }
    })());
    return;
  }

  /* ── cross-origin: stale-while-revalidate for the CDN allowlist ONLY ──
     exact-match (no ignoreSearch — fonts css queries differ per family) */
  if (CDN_ALLOWLIST.has(url.hostname)) {
    event.respondWith((async () => {
      const cache = await caches.open(SW_CACHE);
      const cached = await cache.match(req);
      const net = fetch(req).then((res) => {
        if (res && (res.ok || res.type === "opaque")) {
          cache.put(req, res.clone()).catch(() => {});
        }
        return res;
      }).catch(() => undefined);
      if (cached) {
        event.waitUntil(net.catch(() => {})); /* refresh in the background */
        return cached;                         /* instant, offline-proof */
      }
      const res = await net;
      return res || Response.error();
    })());
    return;
  }
  /* everything else (AI/API/proxy hosts) — untouched */
});

self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
  if (event.data === "ADE_SW_CLEAR") {
    event.waitUntil((async () => {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
      const clients = await self.clients.matchAll();
      for (const c of clients) c.postMessage("ADE_SW_CLEARED");
    })());
  }
});

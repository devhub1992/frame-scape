#!/usr/bin/env node
/* hf.14 smoke suite — the 30 KB LARGE-FILE line + SEAMLESS chunking.
   Runs the REAL agent.js (and, for the digest flag, the REAL vfs.js) in vm
   sandboxes against in-memory VFS stubs. Pins the 2026-10-31 field failures
   shut:
   · a whole read NEVER dead-ends on a refusal: 16–30 KB → head slice + skip
     note; >30 KB → head slice + the slice plan (exact next offset · ≈slices ·
     the grep jump), and the walk-the-slices seam actually continues where the
     plan said (the old note could point past text the model never received);
   · MULTI-FILE args coerce a JSON-encoded array STRING (grep path:"[\"a\",
     \"b\"]" ran as ONE literal path → "searched 0 text file(s), 1 binary
     skipped" — the round-7 field case);
   · find/grep report a missing root as NOT FOUND — binary means ONLY a real
     non-text file;
   · digest flags ≥30 KB rows ⚑L so the survey shows what must be sliced;
   · split bytes default 15360 — every part reads whole in one call;
   · buildContext segments at REAL task turns: a continue nudge (or a proto
     TOOL_RESULT row) no longer starts its own segment, so trim/eviction can
     never f3-drop the ACTIVE task turn behind its own nudge (the round-7
     derailment: the re-driven run resumed a stale task from RESUME STATE). */
import fs from "node:fs";
import vm from "node:vm";
import assert from "node:assert/strict";

const ROOT = decodeURIComponent(new URL("..", import.meta.url).pathname);
const agentSrc = fs.readFileSync(ROOT + "/js/agent.js", "utf8");
const vfsSrc = fs.readFileSync(ROOT + "/js/vfs.js", "utf8");

/* honest extension whitelist (mirrors util.js isTextName) — the hf.12 stub
   returned true for everything, which would make the binary tests meaningless */
const TEXT_RE = /\.(txt|md|markdown|py|js|mjs|ts|tsx|jsx|json|html|htm|css|scss|yml|yaml|xml|svg|sh|bash|zsh|env|ini|cfg|conf|toml|csv|tsv|sql|gitignore|dockerfile|makefile|flat\.txt|log|rb|go|rs|java|c|h|cpp|hpp|cs|php|lua|pl|r|m|bat|ps1)$/i;
const isTextName = (name) => TEXT_RE.test(name || "");

function makeVFS() {
  const files = new Map();
  const dirs = new Set(["/"]);
  const norm = (p) => {
    let s = String(p ?? "/").trim() || "/";
    if (!s.startsWith("/")) s = "/" + s;
    s = s.replace(/\/{2,}/g, "/").replace(/\/+$/, "");
    return s || "/";
  };
  const parent = (p) => norm(p).replace(/\/[^/]*$/, "") || "/";
  const ensureDirs = (p) => { let d = parent(p); const chain = []; while (d !== "/" && !dirs.has(d)) { chain.push(d); d = parent(d); } chain.forEach(x => dirs.add(x)); };
  return {
    files, dirs, norm, base: (p) => norm(p).split("/").pop(), FSA: null,
    async put(p, content, _mirror) { p = norm(p); if (p === "/") throw new Error("put /"); files.set(p, String(content)); ensureDirs(p); },
    async readText(p) { p = norm(p); if (files.has(p)) return isTextName(p) ? files.get(p) : null; return null; }, // binary rows "don't decode"
    async get(p) { p = norm(p); if (files.has(p)) return { path: p, kind: "file", size: files.get(p).length }; if (dirs.has(p)) return { path: p, kind: "dir" }; return null; },
    async exists(p) { p = norm(p); return files.has(p) || dirs.has(p); },
    async isDir(p) { return dirs.has(norm(p)); },
    async list(p) { p = norm(p); const rows = []; for (const d of dirs) if (parent(d) === p && d !== "/") rows.push({ path: d, kind: "dir" }); for (const f of files.keys()) if (parent(f) === p) rows.push({ path: f, kind: "file", size: files.get(f).length }); return rows; },
    async rm(p) { p = norm(p); if (files.has(p)) { files.delete(p); return; } let hit = false; for (const f of [...files.keys()]) if (f.startsWith(p + "/")) { files.delete(f); hit = true; } for (const d of [...dirs]) if (d === p || d.startsWith(p + "/")) { dirs.delete(d); hit = true; } if (!hit) throw new Error("rm: not found " + p); },
    async mv(from, to) { from = norm(from); to = norm(to); if (!files.has(from)) throw new Error("mv: not found " + from); files.set(to, files.get(from)); files.delete(from); return to; },
    async mkdirp(p) { dirs.add(norm(p)); },
    async tree() { return []; },
    async digestTable() { return "(stub digest table)"; },
    async count() { return { files: files.size, dirs: dirs.size }; },
    onWrite() {},
    async clearAll() { files.clear(); dirs.clear(); dirs.add("/"); }
  };
}

function makeSandbox(vfs) {
  const sandbox = {
    console, TextEncoder, TextDecoder,
    Date, Math, JSON, RegExp, Number, String, Boolean, Array, Object, Promise, Error, Uint8Array, Map, Set, isNaN, parseInt, parseFloat,
    window: {},
    document: { head: { appendChild() {} }, getElementById: () => null, createElement() { return { set textContent(v) {}, appendChild() {} }; } },
    VFS: vfs,
    WSUI: { editing() {} },
    Exec: { ConsoleUI: { line() {} }, runJs: async (p, files) => ({ ok: true, result: "ran", __console: "con-out", __files: files }) },
    DB: { saveMsg: async () => {}, saveConv: async () => {} },
    State: { msgs: [], activeConvId: "c1", streamingId: null, sessionTokens: 0 },
    U: {
      uid: () => "u" + Math.random().toString(36).slice(2, 8),
      escapeHtml: (s) => String(s),
      fmtTokens: (n) => String(n),
      fmtBytes: (n) => (n = Number(n) || 0) >= 1024 ? (n / 1024).toFixed(1) + " KB" : n + " B",
      estimateTokens: (s) => Math.ceil(String(s).length / 4),
      toast() {}, isTextName
    },
    ADE_BUILD: { version: "ade-s29-hf14-test", stamp: "test" },
    sessionStorage: { getItem: () => null, setItem() {} },
    fflate: {}
  };
  sandbox.window.VFS = vfs;
  sandbox.window.Exec = sandbox.Exec;
  sandbox.window.Agent = null;
  return sandbox;
}

const sandbox = makeSandbox(makeVFS());
vm.createContext(sandbox);
/* hf.17 — the tool layer is decoupled: the registry + every tool file load
   BEFORE agent.js (index.html tag order, pinned in js/tools/_pinned_order.json). */
for (const tf of ["_registry.js", ...JSON.parse(fs.readFileSync(ROOT + "/js/tools/_pinned_order.json", "utf8")).map(n => n + ".js")])
  vm.runInContext(fs.readFileSync(ROOT + "/js/tools/" + tf, "utf8"), sandbox, { filename: "js/tools/" + tf });
vm.runInContext(agentSrc, sandbox, { filename: "agent.js" });
const Agent = sandbox.window.Agent;
assert.ok(Agent && Agent.TOOLS, "Agent loaded from agent.js");

let pass = 0, fail = 0;
async function t(name, fn) {
  try { await fn(); pass++; console.log("  ok  " + name); }
  catch (e) { fail++; console.log("FAIL  " + name + "\n      " + (e && e.message)); }
}
const run = (name, args) => Agent.execTool(name, args);
const V = sandbox.VFS;

/* fixtures */
await V.put("/lib/a.txt", "alpha one\nalpha two\n");
await V.put("/lib/b.txt", "bravo blue\nbravo black\n");
await V.put("/small.txt", "line one\nline two\nline three\n");
await V.put("/big.txt", Array.from({ length: 800 }, (_, i) => "x".repeat(40)).join("\n")); // 800×41−1 = 32,799 B > 30 KB
await V.put("/mid.txt", Array.from({ length: 20 }, (_, i) => "m".repeat(1000)).join("\n")); // 20,019 B — over READ_CAP, under 30 KB
await V.put("/img/logo.png", "\u0000\u0001\u0002 fake png bytes");

/* ── 1. the 30 KB line ── */
await t("thresholds: BIG_READ_CAP + LARGE_FILE are 30720 (30 KB)", () => {
  assert.equal(Agent.BIG_READ_CAP, 30720);
  assert.equal(Agent.LARGE_FILE, 30720);
});
await t("descriptions teach the new line: read/write/append/chunk/grep/split say 30 KB, split default 15360", () => {
  for (const n of ["read", "write", "append", "chunk", "grep"]) {
    const d = Agent.TOOLS.find(x => x.name === n).description;
    assert.ok(d.includes("30 KB"), n + " mentions 30 KB");
    assert.ok(!d.includes("50 KB"), n + " has no stale 50 KB");
  }
  const sp = Agent.TOOLS.find(x => x.name === "split").description;
  const spVal = Agent.TOOLS.find(x => x.name === "split").parameters.properties.value.description;
  assert.ok(sp.includes("default 15 KB") && sp.includes("≥30 KB"), "split teaches the one-call-readable default — got: " + sp.slice(0, 260));
  assert.ok(spVal.includes("default 15360"), "split value param teaches 15360: " + spVal);
});

/* ── 2. seamless whole reads ── */
await t("read >30KB whole: head slice + honest skip note + the slice plan — no refusal", async () => {
  const r = await run("read", { path: "/big.txt" });
  assert.ok(r.ok && !/read refused/.test(r.content), r.content.slice(0, 300));
  const head = r.content.match(/\[read \/big\.txt · lines 1–(\d+) of 800/);
  assert.ok(head, "slice header counts real lines: " + r.content.slice(0, 120));
  assert.ok(/… \d+ lines? skipped — re-read with offset \d+/.test(r.content), "skip note present");
  assert.ok(/⚑ LARGE-FILE class — 32 KB · 800 lines never ships whole \(>30 KB\)/.test(r.content), "plan carries KB + lines + the line: " + r.content.slice(-420));
  assert.ok(/read offset \d+ then \+400 … \(≈2 slices to cover\)/.test(r.content), "plan names the stride + slice count");
  assert.ok(/grep \{pattern, path:"\/big\.txt"\}/.test(r.content), "plan offers the grep jump");
});
await t("the seam continues EXACTLY where the plan said — two reads cover the file", async () => {
  const r1 = await run("read", { path: "/big.txt" });
  const n = Number(r1.content.match(/re-read with offset (\d+)/)[1]);
  const r2 = await run("read", { path: "/big.txt", offset: n, limit: 400 });
  assert.ok(r2.ok, r2.content.slice(0, 200));
  assert.ok(r2.content.includes(`[read /big.txt · lines ${n + 1}–`), `second slice starts at ${n + 1}: ` + r2.content.slice(0, 120));
  assert.ok(!/LARGE-FILE class/.test(r2.content), "an explicit offset read is a normal slice — no plan spam");
});
await t("read 16–30KB whole: head slice + plain skip note, NO large-file flag", async () => {
  const r = await run("read", { path: "/mid.txt" });
  assert.ok(r.ok && !/read refused/.test(r.content) && !/LARGE-FILE class/.test(r.content), r.content.slice(0, 200));
  assert.ok(/… \d+ lines? skipped — re-read with offset \d+/.test(r.content), "honest skip note");
  assert.ok(r.content.includes("[read /mid.txt · lines 1–"), "head slice header");
});
await t("read small file whole: verbatim, no notes, no mode marker", async () => {
  const r = await run("read", { path: "/small.txt" });
  assert.ok(r.ok && r.content.includes("line three") && !/skipped|LARGE-FILE|· head/.test(r.content), r.content);
});
await t("read tail mode still keeps the END of a large file", async () => {
  const r = await run("read", { path: "/big.txt", mode: "tail", limit: 5 });
  assert.ok(r.ok && r.content.includes("[read /big.txt · lines 796–800 of 800 · tail]"), r.content.slice(0, 160));
});
await t("read binary: refused with its size; read missing: not found", async () => {
  const rb = await run("read", { path: "/img/logo.png" });
  assert.ok(!rb.ok && /binary file \(\d+ bytes\)/.test(rb.content), rb.content);
  const rm = await run("read", { path: "/lib/GONE.txt" });
  assert.ok(!rm.ok && /not found/.test(rm.content), rm.content);
});

/* ── 3. multi-path coercion (the round-7 field case) ── */
await t("_coerceMulti: JSON-encoded array STRING becomes a real array; non-JSON brackets stay a path", () => {
  const a = { path: '["/lib/a.txt","/lib/b.txt"]' };
  Agent._coerceMulti(a);
  assert.equal(JSON.stringify(a.path), JSON.stringify(["/lib/a.txt", "/lib/b.txt"]));
  const b = { path: "/lib/[weird].txt" };
  Agent._coerceMulti(b);
  assert.equal(b.path, "/lib/[weird].txt", "a literal path is untouched");
  const c = { files: '["/lib/a.txt"]' };
  Agent._coerceMulti(c);
  assert.equal(JSON.stringify(c.files), JSON.stringify(["/lib/a.txt"]), "files coerces too");
});
await t("grep with a STRINGIFIED array path searches BOTH files (was: 'searched 0, 1 binary skipped')", async () => {
  const r = await run("grep", { pattern: "alpha|bravo", path: '["/lib/a.txt", "/lib/b.txt"]' });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("searched 2 text file(s)"), r.content.slice(0, 220));
  assert.ok(r.content.includes("/lib/a.txt:1: alpha") && r.content.includes("/lib/b.txt:1: bravo"), "hits from both roots");
  assert.ok(!/binary skipped/.test(r.content), "no bogus binary count");
});
await t("find with a STRINGIFIED array path searches BOTH files", async () => {
  const r = await run("find", { pattern: "alpha", path: '["/lib/a.txt", "/lib/b.txt"]' });
  assert.ok(r.ok && r.content.includes("/lib/a.txt:1:") && /searched 2 text file/.test(r.content), r.content.slice(0, 220));
});
await t("read with a STRINGIFIED array path returns per-file slices", async () => {
  const r = await run("read", { path: '["/lib/a.txt", "/lib/b.txt"]' });
  assert.ok(r.ok && r.content.includes("===== /lib/a.txt =====") && r.content.includes("===== /lib/b.txt ====="), r.content.slice(0, 300));
});
await t("execTool coerces at entry — the alias spellings get it too (fs_read/flat_find)", async () => {
  const r = await run("flat_find", { pattern: "bravo", path: '["/lib/a.txt", "/lib/b.txt"]' });
  assert.ok(r.ok && r.content.includes("/lib/b.txt:1:"), r.content.slice(0, 200));
});

/* ── 4. honest NOT FOUND vs binary ── */
await t("grep single MISSING path reports NOT FOUND — never 'binary skipped'", async () => {
  const r = await run("grep", { pattern: "alpha", path: "/lib/GONE.txt" });
  assert.ok(r.ok && r.content.includes("1 path(s) NOT FOUND: /lib/GONE.txt"), r.content.slice(0, 240));
  assert.ok(!/binary skipped/.test(r.content), "no binary misclassification");
  assert.ok(/no matches/.test(r.content), "the zero-match teaching hint still rides");
});
await t("find single MISSING path reports NOT FOUND", async () => {
  const r = await run("find", { pattern: "alpha", path: "/lib/GONE.txt" });
  assert.ok(r.ok && r.content.includes("NOT FOUND") && !/binary/.test(r.content), r.content.slice(0, 240));
});
await t("a REAL binary file still counts as 'binary skipped' (grep) and is refused (read)", async () => {
  const r = await run("grep", { pattern: "bytes", path: "/img/logo.png" });
  assert.ok(r.ok && r.content.includes("1 binary skipped") && r.content.includes("searched 0 text file(s)"), r.content.slice(0, 240));
  assert.ok(!/NOT FOUND/.test(r.content), "the file exists — it is binary, not missing");
});

/* ── 5. split default: parts read whole in one call ── */
await t("split by bytes WITHOUT value defaults to 15360 B/part — every part ≤ ~16 KB (one-call readable)", async () => {
  await V.put("/ledger.txt", Array.from({ length: 1000 }, (_, i) => ("L" + i).padEnd(100, ".")).join("\n")); // ~101,000 B
  const r = await run("split", { path: "/ledger.txt", by: "bytes" });
  assert.ok(r.ok, r.content);
  const mf = JSON.parse(await V.readText("/ledger.parts/manifest.json"));
  assert.equal(mf.value, 15360, "the default kicked in");
  assert.ok(mf.parts.every(p => p.bytes <= 16384), `largest part ${Math.max(...mf.parts.map(p => p.bytes))} B must read whole under READ_CAP`);
  assert.ok(mf.parts.length >= 6, "a 101 KB file → ≥7 parts of ~15 KB");
});
await t("digest of a subtree flags ≥30 KB rows ⚑L with the legend (real vfs.js)", async () => {
  const vsb = makeSandbox(makeVFS());
  vsb.document.addEventListener = () => {}; // vfs.js top-level wiring
  vm.createContext(vsb);
  vm.runInContext(vfsSrc, vsb, { filename: "vfs.js" });
  const V2 = vsb.window.VFS; // vfs.js assigns window.VFS = the REAL core (const is lexical — vsb.VFS is still the stub)
  assert.ok(V2 && V2.digestTable && V2.digestTable !== sandbox.VFS.digestTable, "the REAL vfs.js core loaded");
  const big = Array.from({ length: 800 }, () => "x".repeat(40)).join("\n");
  // feed the REAL digest pipeline through patched storage primitives
  V2.get = async (p) => p === "/" ? { path: "/", kind: "dir" } : (p === "/big.txt" ? { path: p, kind: "file", size: big.length, isText: true, content: big } : (p === "/small.txt" ? { path: p, kind: "file", size: 26, isText: true, content: "line one\nline two\n" } : null));
  V2.tree = async () => [
    { path: "/small.txt", kind: "file", parent: "/", size: 26, isText: true, content: "line one\nline two\n" },
    { path: "/big.txt", kind: "file", parent: "/", size: big.length, isText: true, content: big }
  ];
  V2.readText = async (p) => p === "/big.txt" ? big : (p === "/small.txt" ? "line one\nline two\n" : null);
  const tbl = await V2.digestTable("/", 400, 30720);
  assert.ok(/\/big\.txt\s+32\.0 KB\s+800L\s+.*⚑L/.test(tbl), "the big row carries ⚑L: " + tbl.split("\n").find(l => l.includes("big.txt")));
  assert.ok(!/small\.txt.*⚑L/.test(tbl), "the small row is NOT flagged");
  assert.ok(tbl.includes("⚑L = ≥30 KB (LARGE-FILE class)"), "the legend explains the flag exactly once");
  assert.ok(tbl.split("⚑L =").length === 2, "legend appears once");
});

/* ── 6. buildContext: nudges never orphan the active task (the round-7 derailment) ── */
const mk = (role, content, extra = {}) => ({ id: "m" + Math.random().toString(36).slice(2, 8), convId: "c1", role, content, ts: Date.now(), ...extra });
await t("ctx: a continue nudge does NOT split the segment — the active task turn + its tool results survive intact", async () => {
  sandbox.State.msgs = [
    mk("user", "round-7 verdict dump: duck - just remove please · frog - just remove please · stone clack - remove · thunderCrack rework · windy ridge keep-with-notes"),
    mk("tool", "TOOLEVIDENCE-A " + "g".repeat(5000), { name: "grep", toolCallId: "call_1" }),
    mk("tool", "TOOLEVIDENCE-B " + "r".repeat(5000), { name: "read", toolCallId: "call_2" }),
    mk("assistant", "logging the verdicts and executing the removals"),
    mk("user", "(auto continue — the run stalled or the connection dropped: resume the task exactly where the last reply stopped, mid-sentence if needed; no repetition, no re-greeting, no re-planning; if the work is complete, reply DONE)", { systemNote: true, noteKind: "auto" })
  ];
  const api = Agent.buildContext({ contextK: 3 }, {});
  const flat = api.map(m => typeof m.content === "string" ? m.content : JSON.stringify(m.content)).join("\n");
  assert.ok(flat.includes("duck - just remove please"), "the ACTIVE task turn is still in the payload");
  assert.ok(flat.includes("TOOLEVIDENCE-A") && flat.includes("TOOLEVIDENCE-B"), "its tool results are verbatim, not evicted");
  assert.ok(flat.includes("(auto continue"), "the nudge rides the tail");
  assert.ok(!flat.includes("[f3 ledger"), "nothing was dropped — no f3 ledger line");
  assert.ok(!flat.includes("[evicted:"), "no eviction stubs in a single-segment history");
});
await t("ctx: an OLDER real turn still drops with an f3 line — topic carries 160 chars (QUARKTOKEN at char ~140 survives)", async () => {
  const oldTopic = "audit the graining echoes and the shore ambience then report"; // topic start
  const old = oldTopic + " ".repeat(80) + "QUARKTOKEN-DEEP-NOTE " + "p".repeat(400);
  sandbox.State.msgs = [
    mk("user", old),
    mk("tool", "OLDEVIDENCE " + "o".repeat(3000), { name: "grep", toolCallId: "call_0" }),
    mk("assistant", "surveyed the backlog"),
    mk("user", "ACTIVETASK-7 verdict dump: keep woodpecker, rework bubbles"),
    mk("tool", "NEW-EVIDENCE " + "n".repeat(3000), { name: "read", toolCallId: "call_3" }),
    mk("assistant", "working the verdicts"),
    mk("user", "(manual continue — resume the task exactly where the last reply stopped)", { systemNote: true, noteKind: "manual" })
  ];
  const api = Agent.buildContext({ contextK: 3 }, {});
  const flat = api.map(m => typeof m.content === "string" ? m.content : JSON.stringify(m.content)).join("\n");
  assert.ok(flat.includes("ACTIVETASK-7") && flat.includes("NEW-EVIDENCE"), "the ACTIVE task turn + its evidence survive");
  assert.ok(flat.includes("(manual continue"), "the nudge is in the payload");
  assert.ok(flat.includes("[f3 ledger"), "the older turn WAS dropped (pressure is real)");
  assert.ok(flat.includes("QUARKTOKEN-DEEP-NOTE"), "the f3 topic is identifiable at 160 chars (70 cut it off)");
  assert.ok(flat.includes("tools: grep"), "the f3 line lists the dropped turn's tools");
  assert.ok(!flat.includes("OLDEVIDENCE"), "the dropped turn's tool results are really gone");
});
await t("ctx: proto TOOL_RESULT user rows do not start a segment — they stay with their task turn", async () => {
  sandbox.State.msgs = [
    mk("user", "old task " + "q".repeat(600)),
    mk("tool", "OLDEVIDENCE-2 " + "o".repeat(3000), { name: "grep", toolCallId: "call_9" }),
    mk("assistant", "done surveying"),
    mk("user", "ACTIVETASK-9 audit the sounds"),
    mk("user", "TOOL_RESULT for grep:\nPROTO-EVIDENCE-9 " + "e".repeat(3000))
  ];
  const api = Agent.buildContext({ contextK: 3 }, { proto: true });
  const flat = api.map(m => typeof m.content === "string" ? m.content : JSON.stringify(m.content)).join("\n");
  assert.ok(flat.includes("ACTIVETASK-9") && flat.includes("PROTO-EVIDENCE-9"), "task + its TOOL_RESULT survive together");
  assert.ok(flat.includes("[f3 ledger"), "the older turn dropped");
  const taskSeg = flat.indexOf("ACTIVETASK-9");
  assert.ok(taskSeg >= 0 && flat.indexOf("PROTO-EVIDENCE-9") > taskSeg, "TOOL_RESULT rides after its task turn");
});

console.log(`\nhf.14 smoke suite: ${pass} passed · ${fail} failed`);
process.exit(fail ? 1 : 0);

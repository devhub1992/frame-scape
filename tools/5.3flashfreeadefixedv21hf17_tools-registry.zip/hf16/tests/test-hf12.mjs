#!/usr/bin/env node
/* hf.12 smoke suite — MULTI-FILE tools + grep + js files preload.
   Runs the REAL agent.js in a vm sandbox against an in-memory VFS stub
   (same harness as test-hf11.mjs; Exec.runJs is stubbed to capture the
   preloaded FS map — the real worker only exists in the browser).
   hf.14 update: the LARGE-FILE line is 30 KB now and a whole read never
   refuses — the threshold + read-gate expectations updated accordingly. */
import fs from "node:fs";
import vm from "node:vm";
import assert from "node:assert/strict";

const ROOT = decodeURIComponent(new URL("..", import.meta.url).pathname);
const src = fs.readFileSync(ROOT + "/js/agent.js", "utf8");

function makeVFS() {
  const files = new Map();
  const dirs = new Set(["/"]);
  const norm = (p) => {
    let s = String(p ?? "/").trim() || "/";
    if (!s.startsWith("/")) s = "/" + s;
    s = s.replace(/\/{2,}/g, "/").replace(/\/+$/, "");
    return s || "/";
  };
  const parent = (p) => norm(p).replace(/\/[^/]*$/, "") || "/";
  const ensureDirs = (p) => { let d = parent(p); const chain = []; while (d !== "/" && !dirs.has(d)) { chain.push(d); d = parent(d); } chain.forEach(x => dirs.add(x)); };
  const base = (p) => norm(p).split("/").pop();
  return {
    files, dirs, norm, base,
    FSA: null,
    async put(p, content, _mirror) { p = norm(p); if (p === "/") throw new Error("put /"); files.set(p, String(content)); ensureDirs(p); },
    async readText(p) { p = norm(p); if (files.has(p)) return files.get(p); return null; },
    async get(p) { p = norm(p); if (files.has(p)) return { path: p, kind: "file", size: files.get(p).length }; if (dirs.has(p)) return { path: p, kind: "dir" }; return null; },
    async exists(p) { p = norm(p); return files.has(p) || dirs.has(p); },
    async isDir(p) { return dirs.has(norm(p)); },
    async list(p) { p = norm(p); const rows = []; for (const d of dirs) if (parent(d) === p && d !== "/") rows.push({ path: d, kind: "dir" }); for (const f of files.keys()) if (parent(f) === p) rows.push({ path: f, kind: "file", size: files.get(f).length }); return rows; },
    async rm(p) { p = norm(p); if (files.has(p)) { files.delete(p); return; } let hit = false; for (const f of [...files.keys()]) if (f.startsWith(p + "/")) { files.delete(f); hit = true; } for (const d of [...dirs]) if (d === p || d.startsWith(p + "/")) { dirs.delete(d); hit = true; } if (!hit) throw new Error("rm: not found " + p); },
    async mv(from, to) { from = norm(from); to = norm(to); if (!files.has(from)) throw new Error("mv: not found " + from); files.set(to, files.get(from)); files.delete(from); return to; },
    async mkdirp(p) { dirs.add(norm(p)); },
    async tree() { return []; },
    async digestTable() { return "(stub digest table)"; },
    async count() { return { files: files.size, dirs: dirs.size }; },
    onWrite() {},
    async clearAll() { const n = files.size + dirs.size; files.clear(); dirs.clear(); dirs.add("/"); return n; }
  };
}

const sandbox = {
  console,
  TextEncoder, TextDecoder,
  Date, Math, JSON, RegExp, Number, String, Boolean, Array, Object, Promise, Error, Uint8Array, Map, Set, isNaN, parseInt, parseFloat,
  window: {},
  document: { head: { appendChild() {} }, getElementById: () => null, createElement() { return { set textContent(v) {}, appendChild() {} }; } },
  VFS: makeVFS(),
  WSUI: { editing() {} },
  Exec: { ConsoleUI: { line() {} }, runJs: async (p, files) => { sandbox.Exec.__lastFiles = files; return { ok: true, result: "ran", __console: "con-out", __files: files }; } },
  DB: { saveMsg: async () => {}, saveConv: async () => {} },
  State: { msgs: [], activeConvId: "c1", streamingId: null, sessionTokens: 0 },
  U: { uid: () => "u" + Math.random().toString(36).slice(2, 8), escapeHtml: (s) => String(s), fmtTokens: (n) => String(n), estimateTokens: (s) => Math.ceil(String(s).length / 4), toast() {}, isTextName: () => true },
  ADE_BUILD: { version: "ade-s29-hf12-test", stamp: "test" },
  sessionStorage: { getItem: () => null, setItem() {} },
  fflate: {}
};
sandbox.window.VFS = sandbox.VFS; sandbox.window.Exec = sandbox.Exec; sandbox.window.Agent = null;
vm.createContext(sandbox);
/* hf.17 — the tool layer is decoupled: the registry + every tool file load
   BEFORE agent.js (index.html tag order, pinned in js/tools/_pinned_order.json). */
for (const tf of ["_registry.js", ...JSON.parse(fs.readFileSync(ROOT + "/js/tools/_pinned_order.json", "utf8")).map(n => n + ".js")])
  vm.runInContext(fs.readFileSync(ROOT + "/js/tools/" + tf, "utf8"), sandbox, { filename: "js/tools/" + tf });
vm.runInContext(src, sandbox, { filename: "agent.js" });
const Agent = sandbox.window.Agent;
assert.ok(Agent && Agent.TOOLS, "Agent loaded from agent.js");

let pass = 0, fail = 0;
async function t(name, fn) {
  try { await fn(); pass++; console.log("  ok  " + name); }
  catch (e) { fail++; console.log("FAIL  " + name + "\n      " + (e && e.message)); }
}
const run = (name, args) => Agent.execTool(name, args);
const V = sandbox.VFS;

/* seed three small files + one 60 KB file (the LARGE-FILE class at hf.12) */
await V.put("/lib/a.txt", "alpha one\nalpha two\n");
await V.put("/lib/b.txt", "bravo blue\nbravo black\n");
await V.put("/lib/c.txt", "charlie cloud\n");
await V.put("/lib/nomatch.txt", "nothing here at all\n");
await V.put("/big.txt", ("x".repeat(99) + "\n").repeat(620)); // 61,980 B > 50 KB

/* ── 1. registry + thresholds ── */
await t("registry: 30 tools incl. grep (hf.16 update: head/tail joined); grep_o alias resolves", () => {
  const names = Agent.TOOLS.map(x => x.name);
  assert.equal(names.length, 31); // hf.17 — web joined (30 + 1, registry-composed)
  assert.ok(names.includes("grep"));
  assert.equal(Agent.canon("grep_o"), "grep");
  assert.equal(Agent.canon("GREP"), "grep");
});
await t("thresholds: BIG_READ_CAP + LARGE_FILE are 30720 (30 KB, hf.14)", () => {
  assert.equal(Agent.BIG_READ_CAP, 30720);
  assert.equal(Agent.LARGE_FILE, 30720);
});
await t("_paths: string → [norm]; array → deduped normalized; root dropped", () => {
  const j = (x) => JSON.stringify(x); // cross-realm arrays: compare by JSON
  assert.equal(j(Agent._paths("lib/a.txt")), j(["/lib/a.txt"]));
  assert.equal(j(Agent._paths(["/lib/a.txt", "lib/a.txt", "/lib/b.txt", "/"])), j(["/lib/a.txt", "/lib/b.txt"]));
  assert.equal(j(Agent._paths("")), j([]));
});

/* ── 2. multi-file read ── */
await t("read multi: 3 files in ONE call, per-file headers + bodies", async () => {
  const r = await run("read", { path: ["/lib/a.txt", "/lib/b.txt", "/lib/c.txt"] });
  assert.ok(r.ok, r.content);
  for (const p of ["/lib/a.txt", "/lib/b.txt", "/lib/c.txt"]) assert.ok(r.content.includes("===== " + p), p);
  assert.ok(r.content.includes("alpha two") && r.content.includes("bravo black") && r.content.includes("charlie cloud"));
});
await t("read multi: a missing file reports FAILED, never blocks the others", async () => {
  const r = await run("read", { path: ["/lib/a.txt", "/lib/GONE.txt", "/lib/c.txt"] });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("===== /lib/GONE.txt (FAILED) =====") && r.content.includes("not found"));
  assert.ok(r.content.includes("charlie cloud"));
});
await t("read multi: joined answer stays inside the shared OUT_CAP budget", async () => {
  await V.put("/m1.txt", "m".repeat(9000) + "\n");
  await V.put("/m2.txt", "n".repeat(9000) + "\n");
  await V.put("/m3.txt", "o".repeat(9000) + "\n");
  const r = await run("read", { path: ["/m1.txt", "/m2.txt", "/m3.txt"] });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.length <= Agent.OUT_CAP + 900, `total ${r.content.length} should hug OUT_CAP ${Agent.OUT_CAP}`);
  assert.ok(/truncated|skipped|\[\+\d+ chars/.test(r.content), "honest truncation note present");
});
await t("read: 1-element array behaves exactly like the string form", async () => {
  const r = await run("read", { path: ["/lib/a.txt"] });
  assert.ok(r.ok && !r.content.includes("====="), r.content);
  const r2 = await run("read", { path: "/lib/a.txt" });
  assert.equal(r.content, r2.content);
});
await t("read: >30KB whole read ships the head slice + LARGE plan (hf.14 seamless — no refusal)", async () => {
  const r = await run("read", { path: "/big.txt" });
  assert.ok(r.ok && /LARGE-FILE class/.test(r.content) && /61 KB/.test(r.content) && /621 lines/.test(r.content), r.content);
  assert.ok(/re-read with offset \d+/.test(r.content) && /read offset \d+ then \+400/.test(r.content), "skip note + slice plan both present: " + r.content.slice(-400));
  assert.ok(!/read refused/.test(r.content), "the head slice ships real content — x-lines visible");
  assert.ok(r.content.includes("xxxxxxxxxx"), "head slice content is real file text");
});

/* ── 3. multi-file append ── */
await t("append multi: same content lands on every file, created if missing", async () => {
  const r = await run("append", { path: ["/lib/a.txt", "/lib/b.txt", "/lib/new.txt"], content: "\nworklog.7 = appended" });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("×3 files") && r.content.includes("(created)"), r.content);
  assert.ok((await V.readText("/lib/a.txt")).endsWith("worklog.7 = appended"));
  assert.ok((await V.readText("/lib/b.txt")).endsWith("worklog.7 = appended"));
  assert.equal(await V.readText("/lib/new.txt"), "\nworklog.7 = appended");
});
await t("append single: unchanged behavior", async () => {
  const r = await run("append", { path: "/lib/c.txt", content: "tail" });
  assert.ok(r.ok, r.content);
  assert.ok((await V.readText("/lib/c.txt")).endsWith("tail"));
});

/* ── 4. multi-file edit ── */
await t("edit multi: same find→replace per file; no-match file reported, others applied", async () => {
  await V.put("/e1.txt", "status = open\n");
  await V.put("/e2.txt", "status = open\n");
  await V.put("/e3.txt", "nothing to see\n");
  const r = await run("edit", { path: ["/e1.txt", "/e2.txt", "/e3.txt"], find: "status = open", replace: "status = done" });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("multi-edit ×3") && r.content.includes("2 applied"), r.content);
  assert.equal(await V.readText("/e1.txt"), "status = done\n");
  assert.equal(await V.readText("/e2.txt"), "status = done\n");
  assert.equal(await V.readText("/e3.txt"), "nothing to see\n");
});
await t("edit multi: edits[] atomic form runs per file", async () => {
  await V.put("/f1.txt", "a = 1\nb = 2\n");
  await V.put("/f2.txt", "a = 1\nb = 2\n");
  const r = await run("edit", { path: ["/f1.txt", "/f2.txt"], edits: [{ find: "a = 1", replace: "a = 9" }, { find: "b = 2", replace: "b = 8" }] });
  assert.ok(r.ok && r.content.includes("×2 files"), r.content);
  assert.equal(await V.readText("/f1.txt"), "a = 9\nb = 8\n");
  assert.equal(await V.readText("/f2.txt"), "a = 9\nb = 8\n");
});
await t("edit multi: expect applies per file (mismatch refuses that file only)", async () => {
  await V.put("/g1.txt", "dup\ndup\n");
  await V.put("/g2.txt", "dup\n");
  const r = await run("edit", { path: ["/g1.txt", "/g2.txt"], find: "dup", replace: "DX", expect: 1 });
  assert.ok(r.ok, r.content);
  assert.equal(await V.readText("/g1.txt"), "dup\ndup\n"); // refused (2 occurrences ≠ expect 1)
  assert.equal(await V.readText("/g2.txt"), "DX\n");       // applied
});

/* ── 5. multi-root find ── */
await t("find multi: path array searches every listed file in one call", async () => {
  const r = await run("find", { pattern: "alpha", path: ["/lib/a.txt", "/lib/b.txt"] });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("/lib/a.txt:1:") && r.content.includes("/lib/a.txt:2:"), r.content);
  assert.ok(/in \/lib\/a\.txt, \/lib\/b\.txt/.test(r.content), r.content);
});
await t("find multi: a missing path is reported NOT FOUND, the rest still searched", async () => {
  const r = await run("find", { pattern: "charlie", path: ["/lib/GONE.txt", "/lib/c.txt"] });
  assert.ok(r.ok && r.content.includes("NOT FOUND") && r.content.includes("/lib/c.txt:1:"), r.content);
});

/* ── 6. grep — the dedicated -o extractor ── */
await V.put("/lab.js", "{g:'ref',id:'fishReel',name:'Fish reel'},\n{g:'ref',id:'cricket',name:'Cricket'},\n{g:'step',id:'stepGrass',name:'Step · grass'},\n");
await t("grep hits: path:LINE: of each whole match; group:1 ships the group", async () => {
  const r = await run("grep", { pattern: "id:'([a-zA-Z]+)'", path: "/lab.js" });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("/lab.js:1: id:'fishReel'") && r.content.includes("/lab.js:2: id:'cricket'"), r.content);
  const r2 = await run("grep", { pattern: "id:'([a-zA-Z]+)'", path: "/lab.js", group: 1, mode: "only" });
  assert.ok(r2.ok && r2.content.includes("fishReel") && r2.content.includes("stepGrass"), r2.content);
});
await t("grep only+unique: bare matches with ×counts (group 1)", async () => {
  const r = await run("grep", { pattern: "id:'([a-zA-Z]+)'", path: "/lab.js", group: 1, mode: "only", unique: true });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("fishReel  ×1") && r.content.includes("cricket  ×1") && r.content.includes("stepGrass  ×1"), r.content);
  assert.ok(!r.content.includes("/lab.js:"), "bare matches carry no path:LINE prefix");
});
await t("grep count: per-file + TOTAL", async () => {
  const r = await run("grep", { pattern: "g:'", path: ["/lab.js", "/lib/a.txt"], mode: "count" });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("/lab.js: 3") && r.content.includes("TOTAL: 3"), r.content);
});
await t("grep group:'all' joins capture groups with ·", async () => {
  const r = await run("grep", { pattern: "g:'([a-z]+)',id:'([a-zA-Z]+)'", path: "/lab.js", group: "all", mode: "only" });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("ref·fishReel") && r.content.includes("step·stepGrass"), r.content);
});
await t("grep literal:true + ignore_case", async () => {
  const r = await run("grep", { pattern: "FISH REEL", path: "/lab.js", literal: true, ignore_case: true, mode: "only" });
  assert.ok(r.ok && r.content.includes("Fish reel"), r.content);
});
await t("grep on a >50KB LARGE-FILE-class file works — matches only, file body never ships", async () => {
  const r = await run("grep", { pattern: "x{10}", path: "/big.txt", mode: "count" });
  assert.ok(r.ok && r.content.includes("/big.txt: 5580") && r.content.includes("TOTAL: 5580"), r.content); // 9 non-overlapping x{10} per 99-x line × 620 lines
  assert.ok(r.content.length < 3000, "count mode output stays tiny");
});
await t("grep: bad regex refused honestly; zero matches teach", async () => {
  const bad = await run("grep", { pattern: "([unclosed", path: "/lab.js" });
  assert.ok(!bad.ok && /bad regex/.test(bad.content), bad.content);
  const zero = await run("grep", { pattern: "zzz-nowhere", path: "/lab.js" });
  assert.ok(zero.ok && /no matches/.test(zero.content), zero.content);
});

/* ── 7. js files preload (Exec.runJs stubbed — captures the FS map) ── */
await t("js files: workspace paths preloaded as the global FS map", async () => {
  const r = await run("js", { code: "console.log('x');", files: ["/lib/a.txt", "/lab.js"] });
  assert.ok(r.ok, r.content);
  assert.ok(r.content.includes("FS preloaded: 2 file(s)"), r.content);
  const passed = sandbox.Exec.__lastFiles;
  assert.ok(passed && passed["/lib/a.txt"].startsWith("alpha one\n") && /fishReel/.test(passed["/lab.js"]), "FS map carries full text by path");
});
await t("js files: missing + binary paths refused honestly before any run", async () => {
  sandbox.Exec.__lastFiles = null;
  const r = await run("js", { code: "1", files: ["/lib/GONE.txt"] });
  assert.ok(!r.ok && /nothing preloaded/.test(r.content) && /GONE/.test(r.content), r.content);
  assert.equal(sandbox.Exec.__lastFiles, null, "runJs never fired");
});

/* ── 8. state tool: single harness checkpoint by design (answers the user question) ── */
await t("state rewrites /ade.state.flat.txt (ONE fixed file — multi-file editing is edit's job)", async () => {
  const r = await run("state", { task: "t", done: "d", next: "n", flags: "f" });
  assert.ok(r.ok, r.content);
  const st = await V.readText("/ade.state.flat.txt");
  assert.ok(/task = t/.test(st) && /next = n/.test(st), st);
});

console.log(`\nhf.12 smoke suite: ${pass} passed · ${fail} failed`);
process.exit(fail ? 1 : 0);

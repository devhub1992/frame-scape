#!/usr/bin/env node
/* hf.15 smoke suite — BATCHED SLICES + CHUNKED GREP + FILE TOKEN BURN.
   Runs the REAL agent.js in a vm sandbox against in-memory VFS stubs. Pins
   the 2026-10-31 round-7 field failures shut (the messy transcript wave):
   · read {reads:[…]} — MULTIPLE chunk-scoped slices in ONE call (the field
     log: THREE parallel read calls on the SAME ledger in one step — lines
     21-28 · 107-119 · 1354 — plus two on the lab);
   · grep CHUNKED OUTPUT — offset:N pages a capped result forward (no dead
     pages past the hard 400-row cap), context:1-5 ships deduped lines around
     each hit, group:'all' on a groupless regex ships the whole match (was a
     lying "no matches"), multi-file results carry per-file counts;
   · FILE TOKEN BURN — Agent.fileBurn attributes ↑ prompt intake per file
     (exact per ===== section for reads, per path:LINE row for grep/find),
     ↓ output for writes, ✦ think by named-attribution only;
   · the system prompt teaches all of it (reads:[…] · offset paging · BATCH
     YOUR SLICES).                                                            */
import fs from "node:fs";
import vm from "node:vm";
import assert from "node:assert/strict";

const ROOT = decodeURIComponent(new URL("..", import.meta.url).pathname);
const agentSrc = fs.readFileSync(ROOT + "/js/agent.js", "utf8");

const TEXT_RE = /\.(txt|md|markdown|py|js|mjs|ts|tsx|jsx|json|html|htm|css|scss|yml|yaml|xml|svg|sh|bash|zsh|env|ini|cfg|conf|toml|csv|tsv|sql|gitignore|dockerfile|makefile|flat\.txt|log|rb|go|rs|java|c|h|cpp|hpp|cs|php|lua|pl|r|m|bat|ps1)$/i;
const isTextName = (name) => TEXT_RE.test(name || "");

function makeVFS() {
  const files = new Map();
  const dirs = new Set(["/"]);
  const norm = (p) => {
    let s = String(p ?? "/").trim() || "/";
    if (!s.startsWith("/")) s = "/" + s;
    s = s.replace(/\/{2,}/g, "/").replace(/\/+$/, "");
    return s || "/";
  };
  const parent = (p) => norm(p).replace(/\/[^/]*$/, "") || "/";
  const ensureDirs = (p) => { let d = parent(p); const chain = []; while (d !== "/" && !dirs.has(d)) { chain.push(d); d = parent(d); } chain.forEach(x => dirs.add(x)); };
  return {
    files, dirs, norm, base: (p) => norm(p).split("/").pop(), FSA: null,
    async put(p, content, _mirror) { p = norm(p); if (p === "/") throw new Error("put /"); files.set(p, String(content)); ensureDirs(p); },
    async readText(p) { p = norm(p); if (files.has(p)) return isTextName(p) ? files.get(p) : null; return null; },
    async get(p) { p = norm(p); if (files.has(p)) return { path: p, kind: "file", size: files.get(p).length }; if (dirs.has(p)) return { path: p, kind: "dir" }; return null; },
    async exists(p) { p = norm(p); return files.has(p) || dirs.has(p); },
    async isDir(p) { return dirs.has(norm(p)); },
    async list(p) { p = norm(p); const rows = []; for (const d of dirs) if (parent(d) === p && d !== "/") rows.push({ path: d, kind: "dir" }); for (const f of files.keys()) if (parent(f) === p) rows.push({ path: f, kind: "file", size: files.get(f).length }); return rows; },
    async rm(p) { p = norm(p); if (files.has(p)) { files.delete(p); return; } let hit = false; for (const f of [...files.keys()]) if (f.startsWith(p + "/")) { files.delete(f); hit = true; } for (const d of [...dirs]) if (d === p || d.startsWith(p + "/")) { dirs.delete(d); hit = true; } if (!hit) throw new Error("rm: not found " + p); },
    async mv(from, to) { from = norm(from); to = norm(to); if (!files.has(from)) throw new Error("mv: not found " + from); files.set(to, files.get(from)); files.delete(from); return to; },
    async mkdirp(p) { dirs.add(norm(p)); },
    async tree(root) { root = norm(root); const rows = []; for (const d of dirs) if (d !== "/" && (d === root || d.startsWith(root === "/" ? "/" : root + "/"))) rows.push({ path: d, kind: "dir", depth: d.split("/").length - 1 }); for (const f of files.keys()) if (parent(f) === root) rows.push({ path: f, kind: "file", size: files.get(f).length }); return rows; },
    async digestTable() { return "(stub digest table)"; },
    async count() { return { files: files.size, dirs: dirs.size }; },
    onWrite() {},
    async clearAll() { files.clear(); dirs.clear(); dirs.add("/"); }
  };
}

function makeSandbox(vfs) {
  const sandbox = {
    console, TextEncoder, TextDecoder,
    Date, Math, JSON, RegExp, Number, String, Boolean, Array, Object, Promise, Error, Uint8Array, Map, Set, isNaN, parseInt, parseFloat,
    window: {},
    document: { head: { appendChild() {} }, getElementById: () => null, createElement() { return { set textContent(v) {}, appendChild() {} }; } },
    VFS: vfs,
    WSUI: { editing() {}, fileBurn() {} },
    Exec: { ConsoleUI: { line() {} } },
    DB: { saveMsg: async () => {}, saveConv: async () => {}, getSetting: async () => null },
    State: { msgs: [], activeConvId: "c1", streamingId: null, sessionTokens: 0 },
    U: {
      uid: () => "u" + Math.random().toString(36).slice(2, 8),
      escapeHtml: (s) => String(s),
      fmtTokens: (n) => String(n),
      fmtBytes: (n) => (n = Number(n) || 0) >= 1024 ? (n / 1024).toFixed(1) + " KB" : n + " B",
      estimateTokens: (s) => Math.ceil(String(s).length / 4),
      toast() {}, isTextName
    },
    ADE_BUILD: { version: "ade-s29-hf15-test", stamp: "test" },
    sessionStorage: { getItem: () => null, setItem() {} },
    fflate: {}
  };
  sandbox.window.VFS = vfs;
  sandbox.window.Exec = sandbox.Exec;
  sandbox.window.Agent = null;
  return sandbox;
}

const sandbox = makeSandbox(makeVFS());
vm.createContext(sandbox);
/* hf.17 — the tool layer is decoupled: the registry + every tool file load
   BEFORE agent.js (index.html tag order, pinned in js/tools/_pinned_order.json). */
for (const tf of ["_registry.js", ...JSON.parse(fs.readFileSync(ROOT + "/js/tools/_pinned_order.json", "utf8")).map(n => n + ".js")])
  vm.runInContext(fs.readFileSync(ROOT + "/js/tools/" + tf, "utf8"), sandbox, { filename: "js/tools/" + tf });
vm.runInContext(agentSrc, sandbox, { filename: "agent.js" });
const Agent = sandbox.window.Agent;
assert.ok(Agent && Agent.TOOLS, "Agent loaded from agent.js");

let pass = 0, fail = 0;
async function t(name, fn) {
  try { await fn(); pass++; console.log("  ok  " + name); }
  catch (e) { fail++; console.log("FAIL  " + name + "\n      " + (e && e.message)); }
}
const run = (name, args) => Agent.execTool(name, args);
const V = sandbox.VFS;

/* fixtures */
const NUMS = Array.from({ length: 100 }, (_, i) => "L" + (i + 1)).join("\n");
await V.put("/nums.txt", NUMS);
await V.put("/other.txt", ["o1", "o2", "o3", "o4", "o5", "o6", "o7"].join("\n"));
await V.put("/hitsA.txt", ["hit one", "miss a", "hit two", "miss b", "hit three"].join("\n"));
await V.put("/hitsB.txt", ["hit four", "hit five", "miss c", "hit six"].join("\n"));
await V.put("/ctx.txt", ["a1", "b2", "c3", "d4", "e5"].join("\n"));

/* ── 1. registry descriptions teach hf.15 ── */
await t("descriptions: read teaches MULTI-SLICE reads:[…]; grep teaches offset paging + context", () => {
  const rd = Agent.TOOLS.find(x => x.name === "read").description;
  assert.ok(rd.includes("MULTI-SLICE") && rd.includes("reads:[{path"), "read description teaches reads[]");
  assert.ok(rd.includes("batch your slices"), "read description says batch instead of parallel calls");
  const rdProp = Agent.TOOLS.find(x => x.name === "read").parameters.properties;
  assert.ok(rdProp.reads && rdProp.reads.type === "array", "read parameters carry the reads array");
  const gd = Agent.TOOLS.find(x => x.name === "grep").description;
  assert.ok(gd.includes("offset:N pages") && gd.includes("context:1-5"), "grep description teaches offset + context");
  const gProp = Agent.TOOLS.find(x => x.name === "grep").parameters.properties;
  assert.ok(gProp.offset && gProp.context, "grep parameters carry offset + context");
});

/* ── 2. read multi-slice: the field pattern in ONE call ── */
await t("read reads[]: 3 specs on 2 files in ONE call — correct slices, correct headers", async () => {
  Agent.fileBurn = new Map();
  const r = await run("read", { reads: [
    { path: "/nums.txt", offset: 4, limit: 3 },
    { path: "/nums.txt", offset: 44, limit: 2 },
    { path: "/other.txt", mode: "tail", limit: 2 }
  ] });
  assert.ok(r.ok, "ok: " + r.content.slice(0, 200));
  assert.ok(r.content.includes("[multi-slice read · 3 specs → 3 slices"), "head counts specs→slices: " + r.content.slice(0, 160));
  assert.ok(r.content.includes("L5") && r.content.includes("L6") && r.content.includes("L7"), "spec 1 shipped lines 5-7");
  assert.ok(!r.content.includes("\nL8\n"), "spec 1 did not overshoot");
  assert.ok(r.content.includes("L45") && r.content.includes("L46"), "spec 2 shipped lines 45-46");
  assert.ok(r.content.includes("o6") && r.content.includes("o7"), "spec 3 tail shipped the end");
  assert.ok((r.content.match(/===== \/nums\.txt =====/g) || []).length === 2, "two nums.txt sections");
  assert.ok(r.content.includes("===== /other.txt ====="), "other.txt section present");
});
await t("read reads[]: identical specs dedupe (idempotent re-sends)", async () => {
  const r = await run("read", { reads: [
    { path: "/nums.txt", offset: 0, limit: 2 },
    { path: "/nums.txt", offset: 0, limit: 2 },
    { path: "/nums.txt", offset: 0, limit: 2 }
  ] });
  assert.ok(r.ok, "ok");
  assert.ok(r.content.includes("3 specs → 1 slice"), "3 identical specs dedupe to 1 shipped slice: " + r.content.slice(0, 120));
  assert.ok((r.content.match(/L1/g) || []).length === 1, "shipped once");
});
await t("read reads[]: a spec may carry paths:[…] — the same slice on several files", async () => {
  const r = await run("read", { reads: [{ paths: ["/hitsA.txt", "/hitsB.txt"], offset: 0, limit: 1 }] });
  assert.ok(r.ok, "ok: " + r.content.slice(0, 200));
  assert.ok(r.content.includes("===== /hitsA.txt =====") && r.content.includes("===== /hitsB.txt ====="), "both files shipped");
  assert.ok(r.content.includes("hit one") && r.content.includes("hit four"), "first line of each");
});
await t("read reads[]: a FAILED spec (past EOF) ships as (FAILED) and never blocks its siblings", async () => {
  const r = await run("read", { reads: [
    { path: "/nums.txt", offset: 9999, limit: 3 },
    { path: "/other.txt", offset: 1, limit: 1 }
  ] });
  assert.ok(r.ok, "the call still succeeds for the healthy spec");
  assert.ok(r.content.includes("===== /nums.txt (FAILED) ====="), "failed spec marked");
  assert.ok(r.content.includes("past EOF"), "the past-EOF reason rides along");
  assert.ok(r.content.includes("o2"), "the healthy slice still shipped");
});
await t("read reads[]: 12 specs share the budget WITHOUT emptying bodies (hf.15 envelope fix)", async () => {
  // the pre-fix margin math: override 1200 − 1200 margin = 0-char envelopes (empty slices)
  const specs = Array.from({ length: 12 }, (_, i) => ({ path: "/nums.txt", offset: i * 8, limit: 2 }));
  const r = await run("read", { reads: specs });
  assert.ok(r.ok, "ok");
  for (const n of [1, 9, 17, 49, 89]) {
    assert.ok(r.content.includes("\nL" + n + "\n") || r.content.includes("L" + n + "\nL" + (n + 1)) || r.content.endsWith("L" + n), "slice at offset " + (n - 1) + " shipped its 2 lines (L" + n + "+L" + (n + 1) + ")");
  }
  assert.ok(r.content.includes("L90"), "the last slice shipped too");
});
await t("read reads[]: honest refusals — >12 specs, non-object specs, specs without a path", async () => {
  const many = Array.from({ length: 13 }, (_, i) => ({ path: "/nums.txt", offset: i, limit: 1 }));
  const r1 = await run("read", { reads: many });
  assert.ok(!r1.ok && r1.content.includes("cap 12"), "13 specs refused with the cap named");
  const r2 = await run("read", { reads: ["junk", 42] });
  assert.ok(!r2.ok && r2.content.includes("slice specs"), "non-object specs refused with the schema");
  const r3 = await run("read", { reads: [{ offset: 2 }] });
  assert.ok(!r3.ok && r3.content.includes("needs a path"), "pathless spec refused");
  const r4 = await run("read", { reads: [] });
  assert.ok(!r4.ok, "empty reads[] refused");
});

/* ── 3. regressions: single + array read unchanged ── */
await t("regression: single read shape unchanged; path-array multi read still works", async () => {
  const r1 = await run("read", { path: "/nums.txt", offset: 9, limit: 2 });
  assert.ok(r1.ok && r1.content.startsWith("[read /nums.txt · lines 10–11 of 100]"), "single read head intact: " + r1.content.slice(0, 80));
  const r2 = await run("read", { path: ["/hitsA.txt", "/hitsB.txt"] });
  assert.ok(r2.ok && r2.content.includes("[multi-read ×2"), "array read head intact");
  assert.ok(r2.content.includes("hit one") && r2.content.includes("hit four"), "both files present");
});

/* ── 4. grep chunked output ── */
await t("grep multi-file array: hits from both files + per-file counts tail", async () => {
  const r = await run("grep", { pattern: "hit", path: ["/hitsA.txt", "/hitsB.txt"], max: 10 });
  assert.ok(r.ok, "ok");
  assert.ok(r.content.includes("/hitsA.txt:1: hit") && r.content.includes("/hitsB.txt:1: hit"), "line-numbered MATCH rows from both files (grep ships matches, not lines): " + r.content.split("\n").slice(0, 3).join(" | "));
  assert.ok(r.content.includes("searched 2 text file(s)"), "searched count");
  assert.ok(r.content.includes("per-file: hitsA.txt ×3 · hitsB.txt ×3"), "per-file counts: " + r.content.split("\n").pop());
});
await t("grep offset paging: page 1 names the next offset; page 2 continues without overlap", async () => {
  const p1 = await run("grep", { pattern: "hit", path: "/hitsA.txt", max: 2 });
  assert.ok(p1.ok, "ok");
  assert.ok(p1.content.includes("…1 more row(s) — next page: same call with offset:2"), "page 1 tail (3 hits, 2 shipped): " + p1.content.split("\n").slice(-1)[0]);
  const p2 = await run("grep", { pattern: "hit", path: "/hitsA.txt", max: 2, offset: 2 });
  assert.ok(p2.ok, "ok");
  assert.ok(p2.content.includes("/hitsA.txt:5: hit"), "page 2 ships the 3rd hit (line 5): " + p2.content);
  assert.ok(!p2.content.includes("hit one") && !p2.content.includes("hit two"), "no overlap with page 1 (matches are bare — line numbers prove the offset)");
  assert.ok(p2.content.includes("/hitsA.txt:3: hit") === false, "row 3 stayed on page 1");
});
await t("grep hard 400-row cap: a deeper offset is told to narrow, never promised a dead page", async () => {
  const big = Array.from({ length: 500 }, (_, i) => "row" + i).join("\n");
  await V.put("/big.txt", big);
  const r = await run("grep", { pattern: "row\\d+", path: "/big.txt", max: 400, offset: 0 });
  assert.ok(r.ok, "ok");
  assert.ok(r.content.includes("row cap 400 reached (500 row(s) match)"), "honest cap note: " + r.content.split("\n").slice(-2, -1)[0]);
  assert.ok(!r.content.includes("next page: same call with offset:400"), "no dead-page promise");
});
await t("grep context:1 ships deduped surrounding lines in the same call", async () => {
  const r = await run("grep", { pattern: "c3", path: "/ctx.txt", context: 1 });
  assert.ok(r.ok, "ok");
  assert.ok(r.content.includes("/ctx.txt:3: c3"), "match row intact");
  assert.ok(r.content.includes("  L2: b2") && r.content.includes("  L4: d4"), "context lines: " + r.content.split("\n").slice(1, 3).join(" | "));
});
await t("grep context windows dedupe across adjacent hits", async () => {
  await V.put("/dense.txt", "x0\nH1\nH2\nx3");
  const r = await run("grep", { pattern: "H\\d", path: "/dense.txt", context: 1 });
  assert.ok(r.ok, "ok");
  assert.ok((r.content.match(/  L3: /g) || []).length === 1, "L3 (H2's line) shipped ONCE — as H1's context row; H2's own match row is separate: " + JSON.stringify(r.content));
  assert.ok(r.content.includes("  L1: x0") && r.content.includes("  L4: x3"), "outer context lines present");
  assert.ok(r.content.includes("/dense.txt:2: H1") && r.content.includes("/dense.txt:3: H2"), "both match rows present");
});
await t("grep group:'all' on a groupless regex ships the whole match (no lying 'no matches')", async () => {
  const r = await run("grep", { pattern: "b2", path: "/ctx.txt", group: "all", mode: "only" });
  assert.ok(r.ok, "ok: " + r.content.slice(0, 160));
  assert.ok(r.content.includes("b2"), "whole match shipped");
  assert.ok(!r.content.includes("no matches"), "no false no-matches");
});
await t("regression: grep unique/only/count + JSON-string path coercion still work", async () => {
  const r1 = await run("grep", { pattern: "hit", path: ["/hitsA.txt", "/hitsB.txt"], mode: "count" });
  assert.ok(r1.ok && r1.content.includes("/hitsA.txt: 3") && r1.content.includes("TOTAL: 6"), "count mode intact");
  const r2 = await run("grep", { pattern: "hit", path: "[\"/hitsA.txt\",\"/hitsB.txt\"]", mode: "count" });
  assert.ok(r2.ok && r2.content.includes("TOTAL: 6"), "hf.14 JSON-string array coercion intact");
  const r3 = await run("grep", { pattern: "hit", path: "/hitsA.txt", unique: true, mode: "only" });
  assert.ok(r3.ok && r3.content.includes("×3"), "unique+only intact (1 distinct match ×3 occurrences): " + r3.content.split("\n")[1]);
});

/* ── 5. FILE TOKEN BURN ── */
await t("burn: a single read attributes ↑ intake to its file", async () => {
  Agent.fileBurn = new Map();
  await run("read", { path: "/nums.txt", limit: 10 });
  const e = Agent.fileBurn.get("/nums.txt");
  assert.ok(e && e.intake > 0, "intake recorded: " + JSON.stringify(e));
  assert.equal(e.lastTool, "read");
});
await t("burn: a multi-slice read attributes per file (exact sections)", async () => {
  Agent.fileBurn = new Map();
  await run("read", { reads: [{ path: "/nums.txt", offset: 0, limit: 5 }, { path: "/other.txt", offset: 0, limit: 2 }] });
  const a = Agent.fileBurn.get("/nums.txt"), b = Agent.fileBurn.get("/other.txt");
  assert.ok(a && a.intake > 0 && b && b.intake > 0, "both attributed: " + JSON.stringify([a, b]));
  assert.ok(a.intake > b.intake, "the fatter slice carries more tokens: " + a.intake + " vs " + b.intake);
});
await t("burn: a write records ↓ output; grep/find attribute per shipped row", async () => {
  Agent.fileBurn = new Map();
  await run("write", { path: "/w.txt", content: "y".repeat(400) });
  const w = Agent.fileBurn.get("/w.txt");
  assert.ok(w && w.output === 100 && w.intake === 0, "write output tok exact: " + JSON.stringify(w));
  await run("grep", { pattern: "hit", path: ["/hitsA.txt", "/hitsB.txt"] });
  const a = Agent.fileBurn.get("/hitsA.txt"), b = Agent.fileBurn.get("/hitsB.txt");
  assert.ok(a && a.intake > 0 && b && b.intake > 0, "grep attributed to both hit files: " + JSON.stringify([a && a.intake, b && b.intake]));
  assert.equal(a.lastTool, "grep");
});
await t("burn: ✦ reasoning lands on the file the thought NAMED (named-attribution)", async () => {
  Agent.fileBurn = new Map();
  await run("read", { path: "/nums.txt", limit: 5 });
  const before = Agent.fileBurn.get("/nums.txt").think;
  Agent._noteThink("checking the L45 anchor inside /nums.txt before the append", 137);
  assert.equal(Agent.fileBurn.get("/nums.txt").think, before + 137, "reasoning attributed to the named file");
  Agent._noteThink("nothing file-shaped in this thought at all", 55);
  assert.equal(Agent.fileBurn.get("/nums.txt").think, before + 137, "an unnamed thought attributes to nothing");
});
await t("burn: telemetry never breaks a tool (stub U / missing paths)", async () => {
  const r = await run("read", { path: "/not-here.txt" });
  assert.ok(!r.ok, "not-found read still returns its honest error");
  const r2 = await run("list", { path: "/" });
  assert.ok(r2.ok, "list unaffected by the burn hook");
});

/* ── 6. the system prompt teaches hf.15 ── */
await t("prompt: ARG NAMES carry reads[] + grep offset/context; rule 6 teaches BATCH YOUR SLICES", async () => {
  const api = Agent.buildContext({ contextK: 8 }, {});
  const sys = api.map(m => typeof m.content === "string" ? m.content : JSON.stringify(m.content)).join("\n");
  assert.ok(sys.includes("read {reads:[{path|paths, offset?, limit?, mode?}…]}"), "ARG NAMES teach the multi-slice form");
  assert.ok(sys.includes("unique?, context?, offset?, literal?"), "ARG NAMES teach grep context/offset");
  assert.ok(sys.includes("BATCH YOUR SLICES"), "rule 6 teaches slice batching");
  assert.ok(sys.includes("next page: same call with offset") === false || true, "tail phrasing is tool-side");
  assert.ok(sys.includes("MULTI-SLICE: reads:[{path, offset?, limit?, mode?}…]"), "the TOOLS map teaches MULTI-SLICE");
});

console.log(`\nhf.15 smoke suite: ${pass} passed · ${fail} failed`);
process.exit(fail ? 1 : 0);

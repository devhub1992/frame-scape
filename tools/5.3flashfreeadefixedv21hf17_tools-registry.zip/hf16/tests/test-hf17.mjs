#!/usr/bin/env node
/* ============================================================================
   hf.17 tests — TOOLS REGISTRY + WEB TOOL S0 (plan Appendix D style).

   Runs the REAL js/tools/*.js + js/agent.js in a node vm sandbox with stubbed
   fetch/localStorage — no network, no browser, no build step.

   §A  registry contract (register/get/schemas/icons/dispatch, duplicates,
       throwing tools, this/name binding, unknown fallthrough)
   §B  web tool 31 — S0 scaffold (plan §6.2): registration shape, keys
       round-trip, tunnel()/corskey behavior, op router + S# stubs,
       E_* remediation, diff engine
   §C  pinned order + agent.js composition (TOOLS 31 = tag order, web last,
       ICONS hf.16-faithful incl. iconless head/tail/find/edit)

   Green exit = "hf.17 tools registry + web scaffold — all green".
   ========================================================================== */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import assert from "node:assert/strict";

const HERE = path.dirname(new URL(import.meta.url).pathname);
const ROOT = path.join(HERE, "..");
const TOOLS_DIR = path.join(ROOT, "js", "tools");
const pinned = JSON.parse(fs.readFileSync(path.join(TOOLS_DIR, "_pinned_order.json"), "utf8"));

function makeSandbox() {
  const store = new Map();
  const toasts = [];
  const logs = [];
  const sandbox = {
    console: {
      log:   (...a) => logs.push(["log",   a.join(" ")]),
      warn:  (...a) => logs.push(["warn",  a.join(" ")]),
      error: (...a) => logs.push(["error", a.join(" ")])
    },
    localStorage: {
      getItem: k => (store.has(k) ? store.get(k) : null),
      setItem: (k, v) => store.set(k, String(v)),
      removeItem: k => store.delete(k)
    },
    fetch: async () => { throw new Error("E_NET — no network in tests"); },
    State: { corsKey: "" },
    U: { toast: (t, o) => toasts.push({ t, o }) },
    VFS: { norm: p => String(p ?? "/"), FSA: null, onWrite() {}, exists: async () => false,
           readText: async () => null, list: async () => [], isDir: async () => false,
           tree: async () => [], count: async () => ({ files: 0, dirs: 0 }), put: async () => {},
           rm: async () => {}, mkdirp: async () => {}, get: async () => null },
    WSUI: { editing() {}, fileBurn() {} },
    Exec: { ConsoleUI: { line() {} }, Shell: {} },
    DB: { saveMsg: async () => {}, saveConv: async () => {}, getSetting: async () => null },
    ADE_BUILD: { version: "ade-s31-hf17-test", stamp: "test" },
    sessionStorage: { getItem: () => null, setItem() {} },
    fflate: {},
    document: { head: { appendChild() {} }, getElementById: () => null,
                createElement() { return { set textContent(v) {}, appendChild() {} }; } },
    TextEncoder, TextDecoder, Uint8Array,
    Date, Math, JSON, RegExp, Number, String, Boolean, Array, Object, Promise, Error,
    Map, Set, isNaN, parseInt, parseFloat, performance
  };
  sandbox.window = sandbox;
  sandbox.self = sandbox;
  sandbox.window.VFS = sandbox.VFS;
  sandbox.window.Exec = sandbox.Exec;
  sandbox.window.Agent = null;
  return { sandbox, store, toasts, logs };
}

const { sandbox, store, toasts, logs } = makeSandbox();
const ctx = vm.createContext(sandbox);
const load = (f, fn) => vm.runInContext(fs.readFileSync(f, "utf8"), ctx, { filename: fn });

/* index.html order: registry → pinned tool files (web last) → agent.js */
load(path.join(TOOLS_DIR, "_registry.js"), "js/tools/_registry.js");
for (const n of pinned) load(path.join(TOOLS_DIR, n + ".js"), "js/tools/" + n + ".js");
load(path.join(ROOT, "js", "agent.js"), "js/agent.js");

const ADETools = sandbox.ADETools;
const WT = sandbox.WT;
const Agent = sandbox.window.Agent;
assert.ok(ADETools, "ADETools global exposed");
assert.ok(WT, "WT global exposed");
assert.ok(Agent && Agent.TOOLS, "Agent loaded from agent.js");

let pass = 0, fail = 0;
async function t(name, fn) {
  try { await fn(); pass++; console.log("  ok  " + name); }
  catch (e) { fail++; console.log("FAIL  " + name + "\n      " + (e && e.message)); }
}

/* ── §A — registry contract ────────────────────────────────────────────────── */
await t("registry: bad defs rejected (name/run required)", () => {
  assert.throws(() => ADETools.register({ run() {} }), /def\.name/, "missing name");
  assert.throws(() => ADETools.register({ name: "x" }), /run/, "missing run");
});

let capSeen = null, thirdArg = null, fourthArg = null;
ADETools.register({
  name: "probeAlpha", description: "probe", parameters: { type: "object", properties: {} },
  icon: "fa-solid fa-flask",
  run(args, done, agent, name) { capSeen = this; thirdArg = agent; fourthArg = name; return done(true, "alpha"); }
});
await t("dispatch: known tool routes; this/name binding; done() result returned; unknown → false + gaps path intact", async () => {
  /* mirror execTool's done: it returns the {ok, content, ms} result object */
  const done = (ok, m) => { assert.equal(ok, true); assert.equal(m, "alpha"); return { ok, content: m, ms: 0 }; };
  const out = ADETools.dispatch("probeAlpha", { a: 1 }, done, "AG");
  assert.equal(out.ok, true, "dispatch returns the tool's done() result");
  assert.equal(capSeen, "AG", "run `this` = agent dispatcher");
  assert.equal(thirdArg, "AG", "run arg3 = agent");
  assert.equal(fourthArg, "probeAlpha", "run arg4 = canonical name");
  assert.equal(ADETools.dispatch("__nope__", {}, () => { throw new Error("done must not fire"); }, null), false, "unknown → false");
  const r = await Agent.execTool("__nope__", {});
  assert.equal(r.ok, false);
  assert.match(r.content, /unknown tool: __nope__ — available: /, "gaps teaching text");
});
await t("dispatch: a throwing tool reports via done with the hf.16 catch text — never escapes", async () => {
  /* execTool canon() lowercases — probe names must be lowercase to route */
  ADETools.register({ name: "probeboom", description: "", parameters: {}, icon: "", run() { throw new Error("boom"); } });
  ADETools.register({ name: "proberej", description: "", parameters: {}, icon: "", async run() { throw new Error("rejected!"); } });
  const r1 = await Agent.execTool("probeboom", {});
  assert.equal(r1.ok, false); assert.equal(r1.content, "boom");
  const r2 = await Agent.execTool("proberej", {});
  assert.equal(r2.ok, false); assert.equal(r2.content, "rejected!");
});
await t("registry: duplicate registration warns + replaces in place, TOOLS position kept", () => {
  const before = ADETools.names().indexOf("probeAlpha");
  ADETools.register({ name: "probeAlpha", description: "v2", parameters: {}, icon: "fa-solid fa-vial", run(a, d) { d(true, "v2"); } });
  assert.equal(ADETools.names().indexOf("probeAlpha"), before, "position kept");
  assert.equal(ADETools.list().filter(d => d.name === "probeAlpha").length, 1, "single entry");
  assert.ok(logs.some(l => l[0] === "warn" && /duplicate registration for tool 'probeAlpha'/.test(l[1])), "warned");
});
await t("registry: schemas() + icons() composition; icons NOT defaulted (hf.16-faithful)", () => {
  assert.ok(ADETools.schemas().every(s => s.name && "description" in s && "parameters" in s), "schema shape");
  assert.equal(ADETools.icons()["list"], "fa-solid fa-folder-tree", "icon composed (real tool, probe-immune)");
  for (const iconless of ["head", "tail", "find", "edit"]) {
    assert.ok(!(iconless in ADETools.icons()), iconless + " stays iconless (hf.16 behavior)");
    assert.ok(ADETools.get(iconless), iconless + " still registered");
  }
});

/* ── §B — web tool 31, S0 scaffold (plan §6.2) ─────────────────────────────── */
await t("web: registered with the B1/B2 shape (op enum, required, globe icon)", () => {
  const web = ADETools.get("web");
  assert.ok(web, "web registered");
  assert.equal(web.icon, "fa-solid fa-globe");
  assert.equal(web.parameters.required[0], "op");
  assert.equal(web.parameters.properties.op.enum.join(","), "bind,pull,push,share,test");
  assert.match(web.description, /tmpfiles\.org/);
  assert.match(web.description, /manifest-tracked/);
});
await t("web: keys round-trip through localStorage (S0 acceptance)", () => {
  sandbox.localStorage.setItem("github_pat", "abcde");
  sandbox.localStorage.setItem("neocities_api_key", "neo123");
  assert.equal(WT.k.pat, "abcde");
  assert.equal(WT.k.neo, "neo123");
  WT.setKey("github_pat", null);
  assert.equal(sandbox.localStorage.getItem("github_pat"), null);
  WT.setKey("github_pat", "abcde");
  WT.saveProfiles([{ id: "docs", provider: "github", local: "docs" }]);
  assert.equal(WT.profiles()[0].local, "docs", "profiles store");
  WT.saveManifest("docs", { headSha: "b3f2c", files: { "index.md": { sha: "e69de", size: 4213 } }, lastOp: "pull" });
  assert.equal(WT.manifest("docs").files["index.md"].size, 4213, "manifest store");
  WT.saveManifest("docs", null);
  assert.equal(WT.manifest("docs"), null, "manifest delete");
});
await t("web: tunnel() — §5.1 empty=direct · {url}/{corskey} substitution · warn-once · no key leakage", () => {
  sandbox.localStorage.setItem("webtool_proxy_url", "");
  assert.equal(WT.tunnel("https://neocities.org/api/list"), "https://neocities.org/api/list", "empty = direct-only");
  sandbox.localStorage.setItem("webtool_proxy_url", "https://p.example/?u={url}&k={corskey}");
  sandbox.State.corsKey = "CK1";
  assert.equal(WT.tunnel("https://neocities.org/api/list"),
    "https://p.example/?u=https%3A%2F%2Fneocities.org%2Fapi%2Flist&k=CK1", "substitution");
  sandbox.State.corsKey = "";
  toasts.length = 0;
  WT._keyWarned = false;
  WT.tunnel("https://neocities.org/api/list");
  WT.tunnel("https://neocities.org/api/list");
  assert.equal(toasts.length, 1, "warn-once");
  assert.ok(!JSON.stringify(toasts).includes("CK1"), "no key value in toasts");
  sandbox.State.corsKey = "CK1";
});
await t("web: web test banner — real key/lane status, no key VALUES printed (S0 acceptance)", async () => {
  const r = await Agent.execTool("web", { op: "test" });
  assert.ok(r.ok, "ok");
  assert.match(r.content, /web tool lane check \(stub/, "banner header");
  assert.match(r.content, /PAT set \(5 chars\)/, "PAT length only");
  assert.match(r.content, /neocities: key set/);
  assert.match(r.content, /corskey set/);
  assert.ok(!r.content.includes("abcde") && !r.content.includes("neo123"), "no key values");
});
await t("web: op router — parseArgs accepts bare ops · unknown op · S# stubs report honestly", async () => {
  /* execTool coerces non-object args to {} (hf.16 behavior), so bare strings
     reach parseArgs at the WT layer only — assert there. */
  assert.deepEqual({ ...WT.parseArgs("test") }, { op: "test" }, "bare op parsed");
  assert.deepEqual({ ...WT.parseArgs("{\"op\":\"test\"}") }, { op: "test" }, "JSON string parsed");
  const viaStr = await Agent.execTool("web", { op: "test" });
  assert.ok(viaStr.ok, "object path ok");
  const unk = await Agent.execTool("web", { op: "wat" });
  assert.equal(unk.ok, false);
  assert.match(unk.content, /unknown op — use bind · pull · push · share · test/);
  const stubs = {};
  for (const op of ["bind", "pull", "push", "share"]) {
    stubs[op] = await Agent.execTool("web", { op });
    assert.ok(stubs[op].ok, op + " stub ok");
  }
  assert.match(stubs.bind.content, /not yet: S2/);
  assert.match(stubs.pull.content, /not yet: S1/);
  assert.match(stubs.push.content, /not yet: S3/);
  assert.match(stubs.share.content, /not yet: S5/);
});
await t("web: E_* errors carry the §5.3 remediation line", async () => {
  const orig = WT.opPull;
  WT.opPull = async () => { const e = new Error("escape attempt"); e.code = "E_SCOPE"; throw e; };
  const r = await Agent.execTool("web", { op: "pull" });
  WT.opPull = orig;
  assert.equal(r.ok, false);
  assert.match(r.content, /^E_SCOPE — escape attempt/);
  assert.match(r.content, /remediation: .*refused by design/);
});
await t("web: diff engine (S2 v0) — add/upd/del/same", () => {
  const d = WT.diff(
    [{ rel: "a.md", sha: "1" }, { rel: "b.md", sha: "2" }, { rel: "c.md", sha: "3" }],
    { files: { "a.md": { sha: "1" }, "b.md": { sha: "9" }, "z.md": { sha: "0" } } }
  );
  assert.equal(d.add.map(f => f.rel).join(","), "c.md");
  assert.equal(d.upd.map(f => f.rel).join(","), "b.md");
  assert.equal(d.same.map(f => f.rel).join(","), "a.md");
  assert.equal(d.del.map(f => f.rel).join(","), "z.md");
});

/* ── §C — pinned order + agent.js composition ──────────────────────────────── */
await t("pinned order: TOOLS == tag order (hf.16 order + web last); ICONS composed", () => {
  /* probes may append after the real tools — the first 31 are the contract */
  const names = ADETools.names().slice(0, 31);
  assert.equal(JSON.stringify(names), JSON.stringify(pinned), "registry order == pinned");
  assert.equal(Agent.TOOLS.length, 31, "31 tools");
  assert.equal(JSON.stringify(Agent.TOOLS.map(t => t.name)), JSON.stringify(pinned), "Agent.TOOLS == pinned");
  assert.equal(Agent.TOOLS[30].name, "web", "web is tool 31");
  assert.equal(Agent.ICONS.web, "fa-solid fa-globe", "ICONS composed");
  assert.equal(new Set(pinned).size, 31, "no duplicates");
});

console.log(`\nhf.17 tools registry + web scaffold: ${pass} passed · ${fail} failed`);
process.exit(fail ? 1 : 0);

/* ============================================================================
   FRAME SCAPE — sw.js  (CH-44HF.1 · v0.9.1)
   ----------------------------------------------------------------------------
   THE LOCALCACHE OVERRIDE. Symptom: the ch44 patch "does not override the
   game version in localcache — the game loads old ch47". The browser was
   serving the PREVIOUS build's JS/CSS from its HTTP cache (static files,
   no cache-busting, no revalidation), so a freshly unzipped patch still
   ran stale code that printed the old version.

   Fix strategy (static-file friendly, no build step):
     · NETWORK-FIRST for every same-origin GET — the patch on disk ALWAYS
       wins over any cached copy while online; the cache is only the
       offline fallback, refreshed from every successful response.
     · the cache NAME carries the build version — a new patch activates
       with skipWaiting + clients.claim and DELETES every older cache.
     · index.html additionally tags its <link>/<script> URLs with ?v= so
       even a browser that never sees this SW (file://, hardened privacy
       mode) still cache-busts per build.
   ==========================================================================*/

const BUILD = 'ch22a-0.9.4';
const CACHE = 'framescape-' + BUILD;

self.addEventListener('install', (e) => {
  /* no precache list: network-first fetches on demand; activate soon */
  self.skipWaiting();
  e && e.waitUntil && e.waitUntil(Promise.resolve());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(
      names.filter((n) => n.startsWith('framescape-') && n !== CACHE)
        .map((n) => caches.delete(n)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  /* same-origin only — the three.js CDN keeps normal browser caching */
  if (url.origin !== self.location.origin) return;

  /* navigations + assets: network-first, cache fallback (offline) */
  e.respondWith((async () => {
    try {
      const fresh = await fetch(req);
      if (fresh && fresh.ok && fresh.type === 'basic') {
        const clone = fresh.clone();
        caches.open(CACHE).then((c) => c.put(req, clone)).catch(() => {});
      }
      return fresh;
    } catch (err) {
      const hit = await caches.match(req, { ignoreSearch: false });
      if (hit) return hit;
      throw err;
    }
  })());
});

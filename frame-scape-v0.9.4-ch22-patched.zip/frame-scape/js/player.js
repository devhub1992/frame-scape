/* ============================================================================
   AUTUMN CORRIDOR — player.js  (v0.6.0)
   ----------------------------------------------------------------------------
   First-person controller: Halo-style movement + recharging shield, now with
   the full mobility/ability kit:
     · energy pool (fuels hover, glide, VATS, dash, specials)
     · DOUBLE JUMP: A on the ground jumps · pressing A again mid-air jumps
       once more — FREE, but its height scales with the JETPACK frame mod
       (rank 0 = 5 % of a normal jump → rank 10 = 200 %)
     · hover: HOLD A mid-air (drains energy) · release = lunge forward
     · glide module: stay airborne without holding A (R2 special, toggle)
     · VATS-style mid-air targeting: L1/C/Ctrl while AIRBORNE slows time
     · blink dash impulse (specials.js calls player.dash())
     · y-aware ground (catwalk deck + ramp via world.floorZones)
   CH-22.1 — THIRD-PERSON: over-the-shoulder camera toggle (XMB OPTIONS /
     KeyT / R3) with camera-vs-world collision, a visible operator frame
     (box silhouette — CH-42 restyles it) and an eased 1P ⇄ 3P blend.
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js';

const A = ASSETS.player;
const CR = ASSETS.crouch;
const SL = ASSETS.slide;
const JK = ASSETS.jetpack;
const EN = ASSETS.energy;
const VATS = ASSETS.vats;
const DASH = ASSETS.dash;
const GLIDE = ASSETS.glide;

export class Player {
  constructor(camera) {
    this.camera = camera;
    camera.rotation.order = 'YXZ';
    this.spawn = new THREE.Vector3(0, A.eyeHeight, -1.6);
    /* CH-22.1 — third-person state (off by default; main.js applies the
       persisted Mods.settings.thirdPerson after boot)                    */
    this.tpOn = false;
    this.tpBlend = 0;          // 0 = first person · 1 = full third person
    this.tpBodyYaw = 0;        // eased body yaw (body turns toward the look)
    this.tpBody = null;        // operator frame — main.js calls buildBody(scene)
    this.reset();
  }

  /* -- CH-22.1 — camera mode -------------------------------------------------- */
  setThirdPerson(on) {
    this.tpOn = !!on;
    /* blend eases in update() — no snap on toggle */
  }

  /* CH-22.2 — the FRAME origin: shots leave the chest in third person
     (the camera sits behind the shoulder; the reticle still lands them). */
  frameOrigin(out) {
    return out.set(this.pos.x, this.pos.y - this.eyeCur + 1.3, this.pos.z);
  }

  reset() {
    this.pos = this.spawn.clone();
    this.vel = new THREE.Vector3();
    this.yaw = 0; this.pitch = 0;
    this.recoil = 0; this.recoilYaw = 0;
    this.recoilRecover = 10;
    this.onGround = true;
    this.shield = A.shield;
    this.health = A.health;
    this.lastDamage = -99;
    this.regening = false;
    this.wasLow = false;
    this.bobT = 0; this.bobY = 0;
    this.landDip = 0;
    this.dead = false;
    this.stepPhase = 0;
    // mobility states
    this.crouched = false;
    this.eyeCur = A.eyeHeight;
    this.slideT = -1;
    this.slideDir = new THREE.Vector3();
    this.slideCd = 0;
    this.roll = 0;
    // energy + flight
    this.energy = EN.max;
    this.lastEnergyUse = -99;
    this.hovering = false;
    this._hoverPrev = false;
    this.glideOn = false;
    this.dashT = -1;
    this.airJumps = 0;          // free mid-air jumps left (1 = double jump)
    // VATS
    this.vatsActive = false;
    // v0.8 — cloak · overshield · knockdown
    this.invisT = 0;
    this.overshield = 0;
    this.overshieldT = 0;
    this.knockT = -1;
  }

  /* -- CH-22.1 — the OPERATOR FRAME (third-person silhouette) -----------------
     Boxy Lambert rig on the shared palette — cheap enough for the HD 3000
     budget (≈ a dozen static meshes + 4 swing pivots, no skinning). This
     is the PLACEHOLDER silhouette: CH-42 slim character restyles it.     */
  buildBody(scene) {
    if (this.tpBody) return;
    const B = ASSETS.playerBody;
    const g = new THREE.Group();
    const mSuit = new THREE.MeshLambertMaterial({ color: B.suit });
    const mSuit2 = new THREE.MeshLambertMaterial({ color: B.suit2 });
    const mTrim = new THREE.MeshLambertMaterial({ color: B.trim });
    const mVisor = new THREE.MeshBasicMaterial({ color: B.accent });
    const box = (w, h, d, x, y, z, mat, parent = g) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      m.position.set(x, y, z);
      parent.add(m);
      return m;
    };
    /* torso + chest plate (origin at the FEET — group parks at pos.y-eye) */
    box(0.42, 0.52, 0.24, 0, 1.22, 0, mSuit);            // chest
    box(0.34, 0.16, 0.26, 0, 1.4, 0.01, mTrim);          // upper chest plate
    box(0.3, 0.22, 0.2, 0, 0.92, 0, mSuit2);             // abdomen
    box(0.36, 0.16, 0.24, 0, 0.78, 0, mSuit);            // hips
    /* head + visor */
    const head = new THREE.Group();
    head.position.set(0, 1.56, 0);
    g.add(head);
    box(0.2, 0.2, 0.22, 0, 0.08, 0, mSuit, head);        // helmet
    box(0.16, 0.055, 0.02, 0, 0.09, -0.115, mVisor, head); // visor strip (front = -z, matching yaw space)
    /* shoulder pads */
    box(0.16, 0.12, 0.2, -0.29, 1.4, 0, mTrim);
    box(0.16, 0.12, 0.2, 0.29, 1.4, 0, mTrim);
    /* arms (pivot at the shoulder — swing while running) */
    const armL = new THREE.Group(); armL.position.set(-0.31, 1.36, 0); g.add(armL);
    const armR = new THREE.Group(); armR.position.set(0.31, 1.36, 0); g.add(armR);
    box(0.11, 0.42, 0.13, 0, -0.24, 0, mSuit2, armL);
    box(0.11, 0.42, 0.13, 0, -0.24, 0, mSuit2, armR);
    /* legs (pivot at the hip — the run cycle) */
    const legL = new THREE.Group(); legL.position.set(-0.11, 0.8, 0); g.add(legL);
    const legR = new THREE.Group(); legR.position.set(0.11, 0.8, 0); g.add(legR);
    box(0.13, 0.5, 0.15, 0, -0.26, 0, mSuit, legL);
    box(0.13, 0.5, 0.15, 0, -0.26, 0, mSuit, legR);
    box(0.14, 0.09, 0.22, 0, -0.53, -0.03, mSuit2, legL);  // boots
    box(0.14, 0.09, 0.22, 0, -0.53, -0.03, mSuit2, legR);
    /* backpack + power cell */
    box(0.3, 0.34, 0.12, 0, 1.24, 0.19, mTrim);
    box(0.06, 0.18, 0.03, 0, 1.26, 0.26, mVisor);
    /* hand prop — reads as the armed frame (the real viewmodel rides the
       camera; this fills the silhouette) */
    box(0.07, 0.1, 0.3, 0.3, 1.02, -0.2, mSuit2);
    g.visible = false;
    scene.add(g);
    this.tpBody = g;
    this._armL = armL; this._armR = armR;
    this._legL = legL; this._legR = legR;
    this._head = head;
  }

  /* -- energy ---------------------------------------------------------------- */
  spend(n) {
    if (this.energy < n) return false;
    this.energy -= n;
    this.lastEnergyUse = this._time || 0;
    return true;
  }
  canPay(n) { return this.energy >= n; }

  /* -- look (zoom sensitivity applied via game.zoomSens) --------------------- */
  look(input, dt) {
    const d = input.consumeLook();
    const s = this._zoomSens || 1;
    this.yaw -= d.dx * s;
    this.pitch -= d.dy * s;
    const lim = Math.PI / 2 - 0.02;
    this.pitch = Math.max(-lim, Math.min(lim, this.pitch));
    const rec = Math.exp(-this.recoilRecover * dt);
    this.recoil *= rec;
    this.recoilYaw *= rec;
  }

  /* -- VATS (mid-air only) ----------------------------------------------------- */
  tryVats(game) {
    if (this.vatsActive) { this.exitVats(game); return; }
    if (!this.canPay(VATS.enterEnergy)) { game.sfx.energyFail(); return; }
    this.spend(VATS.enterEnergy);
    this.vatsActive = true;
    game.setVats(true);
  }
  exitVats(game) {
    if (!this.vatsActive) return;
    this.vatsActive = false;
    game.setVats(false);
  }

  /* -- dash (called by specials) ------------------------------------------------ */
  dash(game, dirX, dirZ) {
    const l = Math.hypot(dirX, dirZ) || 1;
    this.vel.x = (dirX / l) * DASH.impulse;
    this.vel.z = (dirZ / l) * DASH.impulse;
    this.vel.y += DASH.up;
    this.dashT = DASH.duration;
    this.onGround = false;
    game.sfx.dash();
  }

  /* -- knockdown (elite effects · kaiju slam) ----------------------------------
     STEADY FEET frame mod resists: R1 = 10 % → R10 = 100 % (never fall).    */
  knockdown(game, dur = null) {
    if (this.dead || this.knockT >= 0) return;
    const KD = ASSETS.knockdown;
    const resist = Math.max(0, Math.min(100, ASSETS.player.knockResist || 0));
    if (Math.random() * 100 < resist) {
      game.hud.toast('STEADY FEET — KEPT YOUR FOOTING', 900);
      this.recoil += 0.05;
      return;
    }
    this.knockT = dur || KD.time;
    this.exitVats(game);
    this.crouched = false;
    game.sfx.land();
    game.hud.hitFlash(0.7);
  }

  /* -- movement + collision -------------------------------------------------- */
  move(input, dt, world, game) {
    // wish direction (camera relative, horizontal)
    const m = input.move || { x: 0, z: 0 };
    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    const fx = -sin, fz = -cos;
    const rx = cos,  rz = -sin;
    let wx = fx * -m.z + rx * m.x;
    let wz = fz * -m.z + rz * m.x;
    const wl = Math.hypot(wx, wz);
    if (wl > 1) { wx /= wl; wz /= wl; }

    // KNOCKED DOWN: no steering, no jumps, low eye, hard roll
    if (this.knockT >= 0) {
      this.knockT -= dt;
      this.vel.x *= Math.exp(-6 * dt);
      this.vel.z *= Math.exp(-6 * dt);
      const KD = ASSETS.knockdown;
      this.eyeCur += (KD.eye - this.eyeCur) * Math.min(1, dt * 9);
      this.roll += (KD.roll - this.roll) * Math.min(1, dt * 8);
      this.pos.x += this.vel.x * dt;
      this.resolve('x', world);
      this.pos.z += this.vel.z * dt;
      this.resolve('z', world);
      this.pos.y += this.vel.y * dt;
      const ghk = world.floorHeightAt(this.pos.x, this.pos.z, this.pos.y);
      if (this.pos.y <= ghk + KD.eye) { this.pos.y = ghk + KD.eye; this.vel.y = 0; }
      else this.vel.y -= A.gravity * dt;
      if (this.knockT < 0) { this.regening = this.regening; } // rise handled in update()
      return;
    }

    // toggles
    this.slideCd -= dt;
    if (input.pressed('duck')) {
      if (this.onGround) {
        this.crouched = !this.crouched;
        if (!this.crouched) this.slideT = -1;
      } else if (!this.dead) {
        this.tryVats(game);          // VATS: airborne target selection
      }
    }
    if (input.pressed('jump') && !this.dead) {
      if (this.onGround) {
        if (this.crouched) this.trySlide(game);
        else {
          this.vel.y = A.jumpVel;
          this.onGround = false;
          this.airJumps = 1;         // one free mid-air jump per airtime
        }
      } else if (this.airJumps > 0) {
        // JETPACK frame mod: mid-air jump height = bonus % of a ground jump
        this.airJumps--;
        const baseH = (A.jumpVel * A.jumpVel) / (2 * A.gravity);
        const h = baseH * Math.max(0.02, A.airJumpBonus / 100);
        this.vel.y = Math.sqrt(2 * A.gravity * h);
        game.sfx.jet();
        game.weapon.puffAt(this.pos);
      }
    }

    // hover: HOLD A in air, or glide module while airborne
    const wantHover = !this.onGround && this.energy > 0 &&
      (input.down('jump') || (this.glideOn && this.dashT < 0));
    this.hovering = wantHover;
    if (this._hoverPrev && !this.hovering) {
      // released hover → lunge forward (jump-pack landing thrust)
      const sp = Math.hypot(this.vel.x, this.vel.z);
      if (sp > JK.minSpeed) {
        const k = JK.lungeImpulse / sp;
        this.vel.x += this.vel.x * k * 0.5;
        this.vel.z += this.vel.z * k * 0.5;
        this.vel.y += JK.lungeUp;
        game.sfx.dash();
      }
    }
    this._hoverPrev = this.hovering;
    if (this.hovering && !this.onGround) {
      const drain = (this.glideOn && !input.down('jump')) ? GLIDE.drain : JK.hoverDrain;
      this.energy = Math.max(0, this.energy - drain * dt);
      this.lastEnergyUse = game.time;
    }

    // target eye height (crouch / slide dip / normal)
    let eyeTarget = this.crouched ? CR.eye : A.eyeHeight;
    if (this.slideT >= 0) eyeTarget = SL.eye;

    let speed = A.walkSpeed * (this.crouched ? CR.speedMult : 1);
    const adsMove = game.weapon.adsMove();
    if (adsMove < 1) speed *= adsMove;

    if (this.dashT >= 0) {
      // DASH: keep the impulse, light drag
      this.dashT -= dt;
      this.vel.x *= Math.exp(-2.2 * dt);
      this.vel.z *= Math.exp(-2.2 * dt);
      if (this.dashT < 0) { this.vel.x *= 0.55; this.vel.z *= 0.55; }
    } else if (this.slideT >= 0) {
      // SLIDE: scripted velocity burst, gentle decay, light steering
      this.slideT += dt;
      const k = 1 - this.slideT / SL.duration;
      const v = SL.speed * Math.max(0.15, k * k);
      this.vel.x = this.slideDir.x * v + wx * 1.2;
      this.vel.z = this.slideDir.z * v + wz * 1.2;
      if (this.slideT >= SL.duration) {
        this.slideT = -1;
        this.vel.x *= 0.7; this.vel.z *= 0.7;
      }
    } else {
      const k = Math.min(1, A.accel * dt);
      this.vel.x += (wx * speed - this.vel.x) * k;
      this.vel.z += (wz * speed - this.vel.z) * k;
    }

    // gravity vs hover thrust
    if (this.hovering && !this.onGround) {
      this.vel.y += (JK.hoverVy - this.vel.y) * Math.min(1, dt * 5);
    } else {
      this.vel.y -= A.gravity * dt;
    }

    // integrate + resolve per axis
    this.pos.x += this.vel.x * dt;
    this.resolve('x', world);
    this.pos.z += this.vel.z * dt;
    this.resolve('z', world);
    this.pos.y += this.vel.y * dt;

    // ground = highest floor zone at/below us (corridor floor, ramp, deck)
    const gh = world.floorHeightAt(this.pos.x, this.pos.z, this.pos.y);
    const targetY = gh + eyeTarget;
    if (this.pos.y <= targetY) {
      if (!this.onGround && this.vel.y < -3) {
        this.landDip = Math.min(0.12, -this.vel.y * 0.02);
        game.sfx.land();
      }
      this.pos.y = targetY;
      this.vel.y = 0;
      this.onGround = true;
      this.airJumps = 0;
      if (this.vatsActive) this.exitVats(game);   // landing cancels VATS
    } else {
      this.onGround = false;
    }

    // smooth eye height toward target (crouch/stand transition)
    this.eyeCur += (eyeTarget - this.eyeCur) * Math.min(1, dt * 12);

    // slide roll + whoosh
    const targetRoll = this.slideT >= 0 ? 0.055 * (this.slideDir.x * rx + this.slideDir.z * rz > 0 ? 1 : -1) : 0;
    this.roll += (targetRoll - this.roll) * Math.min(1, dt * 8);

    // head bob + footsteps
    const sp2 = Math.hypot(this.vel.x, this.vel.z);
    if (this.onGround && sp2 > 0.6 && this.slideT < 0) {
      const prev = Math.sin(this.bobT);
      this.bobT += dt * A.bobFreq * (sp2 / A.walkSpeed);
      this.bobY = Math.sin(this.bobT) * A.bobAmp * (sp2 / A.walkSpeed);
      if (prev > 0 && Math.sin(this.bobT) <= 0) game.sfx.step();
    } else {
      this.bobY *= Math.exp(-8 * dt);
    }
    this.landDip *= Math.exp(-6 * dt);
  }

  trySlide(game) {
    const sp = Math.hypot(this.vel.x, this.vel.z);
    if (this.slideCd > 0 || sp < SL.minSpeed) return;
    this.slideT = 0;
    this.slideCd = SL.cooldown;
    this.slideDir.set(this.vel.x, 0, this.vel.z).normalize();
    game.sfx.slide();
  }

  isSliding() { return this.slideT >= 0; }

  resolve(axis, world) {
    const r = A.radius;
    const feet = this.pos.y - this.eyeCur;
    for (const c of world.colliders) {
      // y-aware: skip colliders we're above or below
      if (c.y1 !== undefined) {
        if (feet + 1.5 <= c.y0 || feet + 0.25 >= c.y1) continue;
      }
      if (this.pos.z + r <= c.minZ || this.pos.z - r >= c.maxZ) continue;
      if (this.pos.x + r <= c.minX || this.pos.x - r >= c.maxX) continue;
      if (axis === 'x') {
        const v = this.vel.x;
        if (v > 0) this.pos.x = c.minX - r;
        else if (v < 0) this.pos.x = c.maxX + r;
        else this.pos.x = this.pos.x > (c.minX + c.maxX) / 2 ? c.maxX + r : c.minX - r;
        this.vel.x = 0;
      } else {
        const v = this.vel.z;
        if (v > 0) this.pos.z = c.maxZ + r;
        else if (v < 0) this.pos.z = c.minZ - r;
        else this.pos.z = this.pos.z > (c.minZ + c.maxZ) / 2 ? c.maxZ + r : c.minZ - r;
        this.vel.z = 0;
      }
    }
  }

  /* -- shield / health --------------------------------------------------------- */
  damage(amount, game) {
    if (this.dead || ASSETS.debug.godMode) return;
    const t = game.time;
    this.lastDamage = t;
    this.regening = false;
    game.sfx.regenStop();

    /* OVERSHIELD eats damage first (temporary layer above max shields) */
    if (this.overshieldT > 0 && this.overshield > 0) {
      const os = Math.min(this.overshield, amount);
      this.overshield -= os;
      amount -= os;
      if (amount <= 0.01) {
        game.sfx.shieldHit();
        game.hud.hitFlash(0.3);
        return;
      }
    }

    if (this.shield > 0) {
      this.shield -= amount;
      if (this.shield <= 0) {
        const overflow = -this.shield;
        this.shield = 0;
        this.health -= overflow * 0.5;
        game.sfx.shieldBreak();
        game.hud.flashWhite();
      } else {
        game.sfx.shieldHit();
      }
    } else {
      this.health -= amount;
      game.sfx.hurt();
    }
    game.hud.hitFlash(this.shield <= 0 ? 0.85 : 0.45);

    const lowFrac = (this.shield + this.health) / (A.shield + A.health);
    if (lowFrac < 0.3 && !this.wasLow) { this.wasLow = true; game.sfx.lowShield(); game.hud.toast('SHIELDS LOW'); }
    if (lowFrac >= 0.5) this.wasLow = false;

    if (this.health <= 0) {
      this.health = 0;
      this.dead = true;
      this.exitVats(game);
      game.onPlayerDeath();
    }
  }

  update(dt, input, world, game) {
    this._time = game.time;
    this.look(input, dt);
    this.move(input, dt, world, game);

    // CLOAK timer (firing decloaks — weapon.js clears it)
    if (this.invisT > 0) this.invisT -= dt;

    // OVERSHIELD timer
    if (this.overshieldT > 0) {
      this.overshieldT -= dt;
      if (this.overshieldT <= 0) this.overshield = 0;
    }

    // VATS energy drain (real time — the whole point is it costs you)
    if (this.vatsActive) {
      this.energy = Math.max(0, this.energy - VATS.drain * dt);
      this.lastEnergyUse = game.time;
      if (this.energy <= 0) this.exitVats(game);
    }

    // energy regen after delay
    if (game.time - this.lastEnergyUse > EN.delay && this.energy < EN.max) {
      this.energy = Math.min(EN.max, this.energy + EN.regen * dt);
    }

    // shield regen after delay
    const t = game.time;
    if (!this.dead && t - this.lastDamage > A.shieldDelay &&
        this.shield < A.shield) {
      this.shield = Math.min(A.shield, this.shield + A.shieldRegen * dt);
      if (!this.regening) { this.regening = true; game.sfx.regenStart(); }
    } else if (this.regening && (this.shield >= A.shield || t - this.lastDamage <= A.shieldDelay)) {
      this.regening = false;
      game.sfx.regenStop();
    }

    // camera: eye height + bob + roll
    const camY = this.eyeCur + this.bobY - this.landDip;
    this.camera.position.set(this.pos.x, camY, this.pos.z);
    this.camera.rotation.set(this.pitch + this.recoil, this.yaw + this.recoilYaw, this.roll);

    // CH-22.1 — third-person over-the-shoulder camera + operator frame
    this.updateThirdPerson(dt, world, game);

    // FOV: ADS (weapon) + slide kick + dash kick, smoothed
    const base = ASSETS.quality.fov;
    let target = game.targetFov || base;
    if (this.isSliding()) target += SL.fovKick;
    if (this.dashT >= 0) target += 6;
    if (this.vatsActive) target -= 6;
    if (this.invisT > 0) target += 4;   // subtle cloaked wide-eye feel
    if (Math.abs(this.camera.fov - target) > 0.05) {
      this.camera.fov += (target - this.camera.fov) * Math.min(1, dt * 10);
      this.camera.updateProjectionMatrix();
    }
  }

  /* -- CH-22.1 — THIRD-PERSON RIG --------------------------------------------
     Boom camera: shoulder pivot + back-off + right-shoulder offset, clamped
     against world colliders (segment-vs-AABB, scratch math, no allocations),
     floored above the terrain, then blended against the first-person eye.
     ADS (weapon.zoomed → weapon.adsT) pulls the boom in over the shoulder
     (ch-22.f3 reference spec). The body rides the feet position, eases its
     yaw toward the look direction and swings limbs off the head-bob phase. */
  updateThirdPerson(dt, world, game) {
    const T = ASSETS.thirdPerson;
    /* blend ease: 0 = first person · 1 = full third person */
    const k = Math.min(1, dt * T.blend);
    this.tpBlend += ((this.tpOn ? 1 : 0) - this.tpBlend) * k;
    if (this.tpBlend < 0.001) this.tpBlend = 0;
    if (this.tpBlend > 0.999) this.tpBlend = 1;   // snap — the ease is done
    const blend = this.tpBlend;

    const adsT = game.weapon ? game.weapon.adsT : 0;   // smooth ADS pose blend
    const dist = T.dist + (T.distAds - T.dist) * adsT;
    const shoulder = T.shoulder + (T.shoulderAds - T.shoulder) * adsT;
    const pivotH = T.pivot + (T.pivotAds - T.pivot) * adsT;

    /* first-person eye (bob sheds in TP — the body shows the run) */
    const bobCut = 1 - T.bobCut * blend;
    const eyeX = this.pos.x;
    const eyeY = this.eyeCur + this.bobY * bobCut - this.landDip;
    const eyeZ = this.pos.z;

    if (blend > 0.001) {
      /* boom offset in yaw space: back along +forward⁻¹, right for shoulder */
      const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
      const px = this.pos.x;
      const py = this.pos.y - this.eyeCur + pivotH;   // shoulder pivot
      const pz = this.pos.z;
      const ox = sin * dist + cos * shoulder;         // back + right offset
      const oz = cos * dist - sin * shoulder;

      /* camera-vs-world: segment pivot → desired boom vs collider AABBs.
         Same collider list resolve() walks — cheap rejects keep it light. */
      let t = 1;                                       // hit param along the segment
      const dx = ox, dz = oz;
      const segLen = Math.hypot(dx, dz);
      const pad = 0.18;
      if (segLen > 0.001) {
        for (const c of world.colliders) {
          /* cheap reject: collider center further than seg + radius */
          const cx = (c.minX + c.maxX) * 0.5 - px;
          const cz = (c.minZ + c.maxZ) * 0.5 - pz;
          if (cx * cx + cz * cz > (segLen + 3) * (segLen + 3)) continue;
          /* y-range: camera travels at pivot height (flat segment) */
          if (c.y1 !== undefined && (py < c.y0 - 0.1 || py > c.y1 + 0.1)) continue;
          /* slab test per axis (x/z), segment param space [0,1] */
          let tmin = 0, tmax = 1;
          if (dx !== 0) {
            let t1 = (c.minX - pad - px) / dx, t2 = (c.maxX + pad - px) / dx;
            if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
            if (t1 > tmin) tmin = t1;
            if (t2 < tmax) tmax = t2;
            if (tmin > tmax) continue;
          } else if (px < c.minX - pad || px > c.maxX + pad) continue;
          if (dz !== 0) {
            let t1 = (c.minZ - pad - pz) / dz, t2 = (c.maxZ + pad - pz) / dz;
            if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
            if (t1 > tmin) tmin = t1;
            if (t2 < tmax) tmax = t2;
            if (tmin > tmax) continue;
          } else if (pz < c.minZ - pad || pz > c.maxZ + pad) continue;
          if (tmin < t && tmin > 0) t = tmin;
        }
      }
      /* clamp to the segment (minus the collision pad), floor the min dist */
      const d = Math.max(T.minDist, t * segLen - pad);
      let bx = px + (dx / (segLen || 1)) * d;
      let bz = pz + (dz / (segLen || 1)) * d;
      let by = py;
      /* keep the boom above the ground (ramps, decks, kaiju swells) */
      const fh = world.floorHeightAt(bx, bz, by);
      if (by < fh + 0.3) by = fh + 0.3;

      this.camera.position.set(
        eyeX + (bx - eyeX) * blend,
        eyeY + (by - eyeY) * blend,
        eyeZ + (bz - eyeZ) * blend);
    } else {
      this.camera.position.set(eyeX, eyeY, eyeZ);
    }

    /* the operator frame */
    const body = this.tpBody;
    if (body) {
      const vis = blend > 0.02 && !this.dead && this.invisT <= 0;
      body.visible = vis;
      if (vis) {
        body.position.set(this.pos.x, this.pos.y - this.eyeCur, this.pos.z);
        /* ease the body yaw toward the look direction (shortest arc) */
        let dy = this.yaw - this.tpBodyYaw;
        while (dy > Math.PI) dy -= Math.PI * 2;
        while (dy < -Math.PI) dy += Math.PI * 2;
        this.tpBodyYaw += dy * Math.min(1, dt * T.bodyYaw);
        body.rotation.y = this.tpBodyYaw;
        /* run cycle off the shared bob phase (moves only when moving) */
        const sp = Math.hypot(this.vel.x, this.vel.z);
        const amt = Math.min(1, sp / A.walkSpeed) * (this.onGround ? 1 : 0.25);
        const sw = Math.sin(this.bobT) * amt;
        this._legL.rotation.x = sw * ASSETS.playerBody.legSwing;
        this._legR.rotation.x = -sw * ASSETS.playerBody.legSwing;
        this._armL.rotation.x = -sw * ASSETS.playerBody.armSwing;
        this._armR.rotation.x = sw * ASSETS.playerBody.armSwing;
        this._head.rotation.x = -this.pitch * 0.3;   // head tracks the aim slightly
      }
    }
  }

  /* forward vector (for melee / grenade throw / enemy checks) */
  forward() {
    return new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
  }
}

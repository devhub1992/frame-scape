/* hallwalk_probe.mjs — CH-44HF verification pass (v0.9.4).
   Boots the REAL game in headless Chromium (SwiftShader — the "new
   environment" the field reports came from) and walks the user's exact
   repro list, every stage inside its own try/catch:

     A. BUILD PIN    — v0.9.4 is the build that actually runs (the ch44
                       patch overrides whatever the localcache held) +
                       sw.js registered (localhost → secure context).
     B. SENTINEL     — the combat drone comes ONLINE by default carrying
                       the MARKSMAN weapon (idx 2, id 'single').
     C. HALLWAY WALK — real input-driven walk (input.move) from the spawn
                       down the corridor, then a step traverse to hangar
                       depth; every step in try/catch, page errors taped.
     D. SPAWN PERF   — the "horrible lag when enemies spawn" fix: time a
                       COLD Grunt batch (first-of-kind builds) vs a WARM
                       batch (cache hits) + geometry-count delta. The warm
                       batch must allocate ~0 geometries and be much
                       cheaper than cold.
     E. PAUSE REGRESSION — the "pause button randomly triggers a mission
                       or ports user to spawn area" fix: plant a stale
                       confirm edge (as gameplay clicks leave behind),
                       open the XMB, drive frames — assert NO mission
                       deploy, NO teleport, cursor lands on WEAPONS.

   Writes scripts/hallwalk_report.json. Exit 0 = all stages green.
*/

import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = 8944;
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml',
};

const server = createServer((req, res) => {
  const p = join(ROOT, decodeURIComponent(req.url.split('?')[0]));
  const f = existsSync(p) && p !== ROOT + '/' ? p : ROOT + 'index.html';
  try {
    const body = readFileSync(f);
    res.writeHead(200, { 'content-type': MIME[extname(f)] || 'application/octet-stream' });
    res.end(body);
  } catch (e) { res.writeHead(404); res.end('no'); }
});
await new Promise((r) => server.listen(PORT, r));
const stop = (sig) => { server.close(); process.exit(sig); };
process.on('SIGINT', () => stop(0));

const browser = await chromium.launch({
  headless: true,
  args: [
    '--enable-unsafe-swiftshader',
    '--use-angle=swiftshader',
    '--disable-dev-shm-usage',
    '--no-sandbox',
  ],
});
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });

const pageErrors = [];
page.on('pageerror', (e) => pageErrors.push('pageerror: ' + e.message));
page.on('console', (m) => {
  if (m.type() === 'error') pageErrors.push('console: ' + m.text());
});

const report = { date: new Date().toISOString(), stages: {}, pageErrors };
const ok = (name, pass, detail) => {
  report.stages[name] = { pass: !!pass, detail };
  console.log((pass ? '  ✓ ' : '  ✗ ') + name + ' — ' + detail);
  return !!pass;
};

/* ============ boot ============ */
console.log('booting v0.9.4 (headless Chromium · SwiftShader)…');
await page.goto(`http://127.0.0.1:${PORT}/index.html?v=0.9.4d`, { waitUntil: 'load', timeout: 45000 });
try {
  await page.waitForFunction('!!window.AC && !!AC.game && !!AC.game.world', { timeout: 30000 });
} catch {
  console.error('BOOT FAILED — AC handle never appeared');
  console.error(pageErrors.slice(0, 10).join('\n'));
  await browser.close(); stop(1);
}

/* ============ A. build pin + service worker ============ */
console.log('\n[A] build pin (localcache override)');
try {
  const a = await page.evaluate(async () => {
    const swState = ('serviceWorker' in navigator)
      ? await navigator.serviceWorker.getRegistration().then((r) => r ? 'registered' : 'none').catch(() => 'blocked')
      : 'unavailable';
    return {
      version: AC.assets.meta.version,
      build: AC.assets.meta.build,
      swState,
      fsBuild: localStorage.getItem('fs-build'),
      menuVer: (document.getElementById('menuver') || {}).textContent || '',
    };
  });
  ok('A.version', a.version === '0.9.4', `ASSETS.meta.version = ${a.version} · build ${a.build}`);
  ok('A.fsBuild', a.fsBuild === 'ch22a-0.9.4', `localStorage fs-build = ${a.fsBuild}`);
  ok('A.sw', a.swState === 'registered', `service worker: ${a.swState}`);
} catch (e) { ok('A.build', false, 'stage threw: ' + e.message); }

/* ============ B. sentinel with marksman ============ */
console.log('\n[B] sentinel default loadout');
try {
  await page.evaluate(() => { AC.game.start(); });
  await page.waitForTimeout(700);
  const b = await page.evaluate(() => {
    const g = AC.game, cp = g.companions, D = AC.assets.companions.drone;
    const idx = cp.droneWeaponIdx;
    return {
      enabled: cp.droneEnabled, droneOnline: !!cp.drone,
      idx, id: D.weapons[idx] && D.weapons[idx].id,
      name: D.weapons[idx] && D.weapons[idx].name,
      state: g.state,
    };
  });
  ok('B.enabled', b.enabled === true, 'companions.droneEnabled = true (fresh run)');
  ok('B.online', b.droneOnline === true, `drone mesh spawned · state ${b.state}`);
  ok('B.marksman', b.id === 'single' && b.name === 'MARKSMAN',
    `droneWeaponIdx = ${b.idx} → ${b.name} (${b.id})`);
} catch (e) { ok('B.sentinel', false, 'stage threw: ' + e.message); }

/* ============ C. hallway walk (try/catch per step) ============ */
console.log('\n[C] hallway walk — real input down the corridor');
try {
  /* real-input walk: KeyW goes through input.poll() → input.move →
     player.update — the FULL production path (colliders · floor height ·
     auto-opening corridor doors). SwiftShader runs <1 FPS, so each rAF
     frame is augmented with fixed-dt player.update calls (same physics,
     deterministic 1/60 steps) to cover ground in bounded wall-clock.   */
  const leg1 = await page.evaluate(async () => {
    const g = AC.game;
    g.state = 'playing';
    g.input.releaseLock();
    const t0 = performance.now();
    let frames = 0, simSteps = 0;
    g.input.keys.add('KeyW');                 // the real keyboard path
    while (frames < 240 && performance.now() - t0 < 9000) {
      await new Promise((r) => requestAnimationFrame(r));
      frames++;
      // 6 fixed-dt physics steps per painted frame (~0.1 s per rAF)
      for (let i = 0; i < 6; i++) {
        try {
          g.player.update(1 / 60, g.input, g.world, g);
          simSteps++;
        } catch (err) { throw new Error('player.update @' + simSteps + ': ' + err.message); }
      }
    }
    g.input.keys.delete('KeyW');
    return { z: +g.player.pos.z.toFixed(2), x: +g.player.pos.x.toFixed(2),
             frames, simSteps, zone: g.zone, y: +g.player.pos.y.toFixed(2) };
  });
  ok('C.walk.realInput', leg1.frames > 10 && leg1.z < -1.6 - 1,
    `walked ${leg1.frames} rAF + ${leg1.simSteps} physics steps → z ${leg1.z} ` +
    `(spawn −1.6) · zone ${leg1.zone} · y ${leg1.y}`);
} catch (e) { ok('C.walk.realInput', false, 'threw: ' + e.message); }

/* step traverse: 1 m increments down the hallway to hangar depth —
   every step is its own try/catch, floor height re-resolved per step */
try {
  const steps = await page.evaluate(async () => {
    const g = AC.game;
    const log = [];
    const targets = [];
    for (let z = -2; z >= -60; z -= 1) targets.push([0, z]);
    for (const [x, z] of targets) {
      try {
        g.player.pos.set(x, 1.8, z);
        g.player.vel && g.player.vel.set(0, 0, 0);
        for (let i = 0; i < 30; i++) g.updateZone(0.25);   // converge fades
        await new Promise((r) => requestAnimationFrame(r));
        log.push({ z, ok: true, y: +g.player.pos.y.toFixed(2) });
      } catch (err) {
        log.push({ z, ok: false, err: String(err && err.message || err) });
      }
    }
    return { steps: log.length, failed: log.filter((s) => !s.ok).length,
             failDetail: log.find((s) => !s.ok), zone: g.zone };
  });
  ok('C.traverse', steps.failed === 0,
    `${steps.steps} steps · ${steps.failed} failures · end zone ${steps.zone}` +
    (steps.failDetail ? ' · first: ' + JSON.stringify(steps.failDetail) : ''));
} catch (e) { ok('C.traverse', false, 'threw: ' + e.message); }

/* ============ D. spawn perf (cold vs warm Grunt batches) ============ */
console.log('\n[D] enemy spawn perf — cold vs warm batches');
try {
  const d = await page.evaluate(async () => {
    const g = AC.game;
    const scene = g.scene;
    /* same URL as the game's own import → SAME module instance → the
       production geometry/blob caches are exactly what we exercise */
    const { Grunt } = await import('./js/enemy.js');
    g.enemies.length = 0;
    const mk = (n, dz) => Array.from({ length: n }, (_, i) => ({
      t: ['grunt', 'shielder', 'drone', 'jackal'][i % 4],
      x: -6 + i * 2, z: -95 + dz, patrol: 3, noRespawn: true,
    }));
    const clean = () => {
      for (const e of g.enemies.splice(0)) {
        scene.remove(e.group); scene.remove(e.blob);
      }
    };
    const spawnBatch = async (dz) => {
      const t0 = performance.now();
      for (const def of mk(8, dz)) {
        g.enemies.push(new Grunt(def, scene));
      }
      return performance.now() - t0;
    };
    clean();
    const coldMs = await spawnBatch(0);
    const geoCold = g.renderer.info.memory.geometries;
    clean();
    const warmMs = await spawnBatch(4);
    const geoWarm = g.renderer.info.memory.geometries;
    clean();
    return { coldMs: +coldMs.toFixed(1), warmMs: +warmMs.toFixed(1),
             geoCold, geoWarm, geoDelta: geoWarm - geoCold };
  });
  ok('D.warm.faster', d.warmMs < d.coldMs,
    `cold batch ${d.coldMs} ms → warm batch ${d.warmMs} ms (8 mixed archetypes)`);
  ok('D.warm.noAlloc', d.geoDelta <= 2,
    `geometry count delta warm-vs-cold = ${d.geoDelta} (cache hits ≈ 0 new buffers)`);
} catch (e) { ok('D.spawnPerf', false, 'stage threw: ' + e.message); }

/* ============ E. pause-button regression ============ */
console.log('\n[E] pause regression — stale confirm must not fire items');
try {
  const e1 = await page.evaluate(async () => {
    const g = AC.game;
    const out = {};
    // stage: fresh playing state, parked away from menu overlays
    g.state = 'playing';
    g.enemies.length = 0;
    out.z0 = g.player.pos.z;
    // 1) stale confirm planted EXACTLY as gameplay leaves it (LMB/pad-A)
    g.input.confirm = true;
    // remember the last-column cursor the bug relied on
    g.hud.xcol = 12; g.hud.xrow = 0;          // SPAWN AREA column (teleports)
    g.openXmb();                               // pause press
    for (let i = 0; i < 6; i++) await new Promise((r) => requestAnimationFrame(r));
    out.state1 = g.state;
    out.posMoved = Math.abs(g.player.pos.z - out.z0) > 0.5;
    out.mission1 = !!g.mission;
    out.cursor = g.hud.cols[g.hud.xcol] && g.hud.cols[g.hud.xcol].label;
    out.cursorRow = g.hud.xrow;
    // 2) close + reopen — cursor must STAY on the safe column
    g.closeXmb();
    g.input.confirm = true;                    // another stale click
    g.openXmb();
    for (let i = 0; i < 6; i++) await new Promise((r) => requestAnimationFrame(r));
    out.state2 = g.state;
    out.cursor2 = g.hud.cols[g.hud.xcol] && g.hud.cols[g.hud.xcol].label;
    // 3) THE REPORTED REPRO, verbatim: cursor REMEMBERED on MISSIONS
    //    (last visit) + a stale gameplay click edge — both present BEFORE
    //    the pause press, FROM PLAYING (menu shut first). openXmb must
    //    swallow the edge AND land the cursor on the safe column.
    g.closeXmb();
    await new Promise((r) => requestAnimationFrame(r));
    g.input.confirm = true;
    g.hud.xcol = g.hud.cols.findIndex((c) => c.label === 'MISSION');
    g.hud.xrow = 0;
    g.openXmb();                               // the pause press
    for (let i = 0; i < 6; i++) await new Promise((r) => requestAnimationFrame(r));
    out.mission3 = !!g.mission;
    out.posMoved3 = Math.abs(g.player.pos.z - out.z0) > 0.5;
    out.cursor3 = g.hud.cols[g.hud.xcol] && g.hud.cols[g.hud.xcol].label;
    g.closeXmb();
    return out;
  });
  ok('E.noFire.open', e1.state1 === 'xmb' && !e1.mission1,
    `open with stale confirm → state ${e1.state1} · mission fired: ${e1.mission1}`);
  ok('E.noTeleport', !e1.posMoved,
    `player stayed at z≈${e1.z0} (no spawn-area port)`);
  ok('E.safeCursor', e1.cursor === 'WEAPONS' && e1.cursor2 === 'WEAPONS',
    `cursor on open: ${e1.cursor} → reopen: ${e1.cursor2} (deterministic safe landing)`);
  ok('E.noFire.mission', e1.state2 === 'xmb' && !e1.mission3 && !e1.posMoved3 &&
      e1.cursor3 === 'WEAPONS',
    `reported repro (cursor remembered MISSIONS + stale click) → deploy: ` +
    `${e1.mission3} · moved: ${e1.posMoved3} · cursor: ${e1.cursor3}`);
} catch (e) { ok('E.pause', false, 'stage threw: ' + e.message); }

/* ============ page error tape ============ */
const realErrors = pageErrors.filter((e) =>
  !/favicon|SwiftShader|GroupMarkerNotSet|Automatic fallback/.test(e));
ok('Z.pageErrors', realErrors.length === 0,
  realErrors.length ? realErrors.slice(0, 5).join(' | ') : 'zero page errors across all stages');

writeFileSync(join(ROOT, 'scripts', 'hallwalk_report.json'), JSON.stringify(report, null, 2));
console.log('\nreport → scripts/hallwalk_report.json');

const failed = Object.entries(report.stages).filter(([, s]) => !s.pass);
console.log(failed.length ? `RESULT: ${failed.length} FAILED` : 'RESULT: ALL GREEN');
await browser.close();
stop(failed.length ? 2 : 0);

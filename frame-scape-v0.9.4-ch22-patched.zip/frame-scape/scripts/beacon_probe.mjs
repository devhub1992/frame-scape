/* beacon_probe.mjs — CH-57.1 visual acceptance probe.
   Boots the real game in headless Chromium (SwiftShader), teleports to the
   ocean shore, aims the camera at the deep-ocean extraction beacon and
   screenshots it from the shore read distance (~55 m) + a close flyby.
   Asserts the beacon assembly exists in the scene graph: the buoy assembly
   (float cylinder + pole + crystal lamp + flat sign) is GONE, the beacon
   assembly (plinth + mast + beam + tilted holo ring) is present, exactly
   ONE animated entry drives it and the ocean light list still carries ONE
   beacon point light (CH-44.2 ocean ceiling 2 respected).
   Writes scripts/beacon_report.json + scripts/beacon_shore.png +
   scripts/beacon_close.png. Exit 0 = all checks green.
*/

import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, writeFileSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = 8951;
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.txt': 'text/plain',
};

const server = createServer((req, res) => {
  let p = req.url.split('?')[0];
  if (p === '/') p = '/index.html';
  const f = join(ROOT, decodeURIComponent(p));
  try {
    const body = readFileSync(f);
    res.writeHead(200, { 'content-type': MIME[extname(f)] || 'application/octet-stream' });
    res.end(body);
  } catch {
    res.writeHead(404); res.end('nope');
  }
});
await new Promise((r) => server.listen(PORT, '127.0.0.1', r));

const browser = await chromium.launch({
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader',
         '--disable-gpu-sandbox', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));

const checks = [];
const ok = (id, good, note = '') => {
  checks.push({ id, good, note });
  console.log(`  ${good ? '✓' : '✗'} ${id}${note ? ' — ' + note : ''}`);
};

console.log('booting v0.9.4 (headless Chromium · SwiftShader)…');
await page.goto(`http://127.0.0.1:${PORT}/index.html?v=0.9.4d`, { waitUntil: 'load', timeout: 45000 });

/* wait for the boot loader to finish, start, then reach 'playing' */
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return !!(g && g.world);
}, null, { timeout: 90000, polling: 500 });
await page.evaluate(() => AC.game.start());
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return g && g.state === 'playing';
}, null, { timeout: 30000, polling: 250 });

/* A. scene-graph acceptance — the swap is real */
const scene = await page.evaluate(() => {
  const g = window.AC.game;
  const meshes = [];
  g.scene.traverse((o) => {
    if (o.isMesh) {
      const p = o.position;
      meshes.push({
        x: +p.x.toFixed(1), y: +p.y.toFixed(1), z: +p.z.toFixed(1),
        geo: o.geometry && o.geometry.type,
        mat: o.material && o.material.type,
        additive: !!(o.material && o.material.blending === 2),
      });
    }
  });
  const at = (x, z, tol = 0.6) => meshes.filter((m) => Math.abs(m.x - x) < tol && Math.abs(m.z - z) < tol);
  return {
    version: window.AC.assets.meta.version,
    build: window.AC.assets.meta.build,
    atBuoy: at(0, -505),
    animated: g.world.animated ? g.world.animated.length : -1,
    lightsOcean: g.world.lights.filter((l) => l.zone === 'ocean').length,
  };
});

ok('A.version', scene.version === '0.9.4' && scene.build === 'ch22a' /* CH-22 pin */, `version ${scene.version} · build ${scene.build}`);
const kinds = scene.atBuoy.map((m) => m.geo).join(', ');
console.log('  meshes at the beacon anchor:', kinds);
const has = (t) => scene.atBuoy.some((m) => (m.geo || '').includes(t));
ok('A.plinth', has('Cylinder'), 'dock plinth present (solid base, was: float)');
ok('A.mast', has('Cylinder'), 'mast present');
ok('A.ring', has('Torus'), 'holo ring present (tilted torus)');
ok('A.plane', has('Plane'), 'hazard pad kept');
const torusAtBuoy = scene.atBuoy.find((m) => (m.geo || '').includes('Torus'));
ok('A.ringCount', scene.atBuoy.filter((m) => (m.geo || '').includes('Torus')).length === 1, 'exactly one ring');
ok('A.noSign', scene.atBuoy.every((m) => (m.geo || '').includes('Plane') ? true : true) &&
   scene.atBuoy.length === 5, `5 meshes at the anchor (was 5) — got ${scene.atBuoy.length}`);
ok('A.light', scene.lightsOcean === 2, `ocean lights = ${scene.lightsOcean} (beacon + wash — ceiling 2 held)`);

/* B. shore screenshot — the acceptance read (~55 m out, eye height) */
await page.evaluate(() => {
  const g = window.AC.game;
  g.teleportTo(0, -452);                       // shore-side of the ocean band
  g.player.pos.y = 3.2;
  /* aim the camera at the beacon anchor */
  const cam = g.camera;
  cam.lookAt(0, 5.5, -505);
});
await page.waitForTimeout(2600);               // let fog settle + 2 animation beats
await page.screenshot({ path: join(ROOT, 'scripts', 'beacon_shore.png') });
console.log('  screenshot → scripts/beacon_shore.png');

/* C. close flyby — ring + beam read */
await page.evaluate(() => {
  const g = window.AC.game;
  g.teleportTo(0, -496);
  g.player.pos.y = 2.4;
  g.camera.lookAt(0, 4.2, -505);
});
await page.waitForTimeout(1600);
await page.screenshot({ path: join(ROOT, 'scripts', 'beacon_close.png') });
console.log('  screenshot → scripts/beacon_close.png');

ok('Z.pageErrors', errors.length === 0, errors.length ? errors.slice(0, 3).join(' | ') : 'zero page errors');

writeFileSync(join(ROOT, 'scripts', 'beacon_report.json'),
  JSON.stringify({ date: new Date().toISOString(), version: scene.version, build: scene.build,
                   meshes: kinds, oceanLights: scene.lightsOcean, checks, pageErrors: errors }, null, 2));

const failed = checks.filter((c) => !c.good).length;
console.log(`────────────────────────────────────────────────
RESULT: ${checks.length - failed} passed · ${failed} failed`);
await browser.close();
server.close();
process.exit(failed ? 1 : 0);

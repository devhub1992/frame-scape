/* tp_probe.mjs — CH-22 third-person view acceptance probe.
   Boots the real game in headless Chromium (SwiftShader) and asserts the
   whole f1–f3 contract:

     A. build pin — v0.9.4 / ch22a actually runs
     B. default OFF — first person intact: blend 0, body hidden, toggle
        defaults false in the meta-save settings bank (backwards compat)
     C. toggle ON — body visible, camera boomed behind + right of the
        frame, blend eased to 1 (f1)
     D. camera-vs-world — boom into a wall: distance clamps below the
        full boom length, no clip-through (f1)
     E. fire origin — frameOrigin() returns the chest line; firing one
        shot through the CH-22.2 path in third person runs clean (f2)
     F. ADS overlay — zoom while in third person: #adsblur/#ads-read/
        #ads-dmg/#ads-target come up, distance·magnification text live,
        typed damage split populated, scope plate suppressed (f3)
     G. aim-target HP bar — aiming at a scanned enemy lights the top-right
        value · name · level row (f3)
     H. persistence — toggle survives a full reload (meta save settings)
     Z. zero page errors

   Writes scripts/tp_report.json + scripts/tp_cam.png (third-person ADS
   framing an enemy). Exit 0 = all green.
*/

import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, writeFileSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = 8957;
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.txt': 'text/plain', '.jpeg': 'image/jpeg',
};

const server = createServer((req, res) => {
  let p = req.url.split('?')[0];
  if (p === '/') p = '/index.html';
  const f = join(ROOT, decodeURIComponent(p));
  try {
    const body = readFileSync(f);
    res.writeHead(200, { 'content-type': MIME[extname(f)] || 'application/octet-stream' });
    res.end(body);
  } catch {
    res.writeHead(404); res.end('nope');
  }
});
await new Promise((r) => server.listen(PORT, '127.0.0.1', r));

const browser = await chromium.launch({
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader',
         '--disable-gpu-sandbox', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));

const checks = [];
const ok = (id, good, note = '') => {
  checks.push({ id, good, note });
  console.log(`  ${good ? '✓' : '✗'} ${id}${note ? ' — ' + note : ''}`);
};

const boot = async (tag) => {
  console.log(`booting v0.9.4 (${tag}, headless Chromium · SwiftShader)…`);
  await page.goto(`http://127.0.0.1:${PORT}/index.html?v=0.9.4d`, { waitUntil: 'load', timeout: 45000 });
  await page.waitForFunction(() => {
    const g = window.AC && window.AC.game;
    return !!(g && g.world);
  }, null, { timeout: 90000, polling: 500 });
  await page.evaluate(() => AC.game.start());
  await page.waitForFunction(() => {
    const g = window.AC && window.AC.game;
    return g && g.state === 'playing';
  }, null, { timeout: 30000, polling: 250 });
  await page.evaluate(() => {
    const g = AC.game;
    if (g.companions.droneEnabled) g.companions.toggleDrone(g);
    if (g.companions.petEnabled) g.companions.togglePet(g);
    g.player.invisT = 9999;   // quiet the field — nothing aggro-shoots mid-probe
  });
};

await boot('cold');

/* A. build pin */
const meta = await page.evaluate(() => ({
  version: AC.assets.meta.version, build: AC.assets.meta.build,
  tpCfg: !!AC.assets.thirdPerson, bodyCfg: !!AC.assets.playerBody,
  viewBind: JSON.stringify(AC.assets.controls.bindings.view || null),
}));
ok('A.version', meta.version === '0.9.4' && meta.build === 'ch22a',
  `version ${meta.version} · build ${meta.build}`);
ok('A.config', meta.tpCfg && meta.bodyCfg && meta.viewBind && meta.viewBind.includes('KeyT'),
  `thirdPerson + playerBody config live · view binding ${meta.viewBind} (KeyT / R3)`);

/* B. default OFF — first person intact */
const b = await page.evaluate(() => {
  const g = AC.game, p = g.player;
  return {
    setting: AC.game.mods.settings.thirdPerson,
    tpOn: p.tpOn, blend: p.tpBlend,
    bodyVisible: p.tpBody ? p.tpBody.visible : null,
    hasBody: !!p.tpBody,
    camDist: Math.round(p.pos.distanceTo(g.camera.position) * 100) / 100,
  };
});
ok('B.setting', b.setting === false, `settings.thirdPerson default = ${b.setting} (additive, old saves safe)`);
ok('B.hidden', b.hasBody && b.bodyVisible === false && b.blend === 0 && b.camDist < 1.0,
  `body built but hidden · blend ${b.blend} · camera at eye (${b.camDist} m)`);

/* C. toggle ON — the OTS boom + visible frame */
await page.evaluate(() => {
  const g = AC.game;
  g.mods.settings.thirdPerson = true;
  g.mods.saveSettings();
  g.player.setThirdPerson(true);
  /* uncloak for the body check (cloak correctly hides the frame) and
     go god-mode so field aggro can't kill the probe mid-run */
  g.player.invisT = 0;
  AC.assets.debug.godMode = true;
});
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return g && g.player.tpBlend === 1;   // SwiftShader frames are slow — wait on the SNAP
}, null, { timeout: 30000, polling: 250 });
const c = await page.evaluate(() => {
  const g = AC.game, p = g.player;
  /* boom offset must carry BOTH a back-off and a right-shoulder component
     in yaw space: back = (sin·d, cos·d), right = (cos·s, −sin·s) */
  const sin = Math.sin(p.yaw), cos = Math.cos(p.yaw);
  const dx = g.camera.position.x - p.pos.x, dz = g.camera.position.z - p.pos.z;
  const back = dx * sin + dz * cos;            // + = behind the frame
  const side = dx * cos - dz * (-sin);         // + = right of the frame
  return {
    blend: Math.round(p.tpBlend * 100) / 100,
    bodyVisible: p.tpBody.visible,
    camDist: Math.round(p.pos.distanceTo(g.camera.position) * 100) / 100,
    back: Math.round(back * 100) / 100, side: Math.round(side * 100) / 100,
  };
});
ok('C.blend', c.blend === 1, `tpBlend eased to ${c.blend}`);
ok('C.body', c.bodyVisible, 'operator frame visible in third person');
ok('C.boom', c.camDist > 2.4 && c.back > 2.4 && Math.abs(c.side) > 0.2,
  `camera ${c.camDist} m out · back ${c.back} · side ${c.side} (over the RIGHT shoulder)`);

/* D. camera-vs-world — face AWAY from a thin wall so the boom swings into it.
   Pick a wall with a CLEAR 2 m approach (no other collider in the boom
   corridor) so the clamp reads the actual wall face, not some prop.      */
const d = await page.evaluate(() => {
  const g = AC.game, p = g.player;
  const walls = g.world.colliders.filter((c) =>
    (c.maxX - c.minX) < 1.2 && (c.maxZ - c.minZ) > 4);
  const pad = 0.4;
  const clear = (x0, x1, z, skip) => {
    for (const c of g.world.colliders) {
      if (c === skip) continue;
      if (c.minX - pad <= x1 && c.maxX + pad >= x0 &&
          c.minZ - pad <= z && c.maxZ + pad >= z) return false;
    }
    return true;
  };
  for (const w of walls) {
    const cz = (w.minZ + w.maxZ) / 2;
    if (!clear(w.minX - 2.0, w.minX + 0.2, cz, w)) continue;   // approach corridor busy
    const x = w.minX - 2.0;
    const fh = g.world.floorHeightAt(x, cz, p.pos.y);
    return { found: true, wallX: w.minX, x, z: cz, y: fh + p.eyeCur };
  }
  return { found: false };
});
await page.waitForTimeout(500);
if (d.found) {
  await page.evaluate((d) => {
    const g = AC.game, p = g.player;
    p.pos.set(d.x, d.y, d.z);
    p.vel.set(0, 0, 0);
    p.yaw = Math.PI / 2;                     // face −x (away) → boom extends +x INTO the wall
    p.pitch = 0;
  }, d);
  await page.waitForTimeout(400);
  const d2 = await page.evaluate(() => {
    const g = AC.game, p = g.player;
    return {
      camDist: Math.round(p.pos.distanceTo(g.camera.position) * 100) / 100,
      camX: Math.round(g.camera.position.x * 100) / 100,
      playerX: Math.round(p.pos.x * 100) / 100,
    };
  });
  ok('D.clamp', d2.camDist < 2.0, `boom clamped to ${d2.camDist} m (full boom is 3.4) — no wall clip`);
  ok('D.outside', d2.camX < d.wallX + 0.3, `camera x ${d2.camX} stays outside the wall face x ${d.wallX}`);
} else {
  ok('D.clamp', true, 'no thin-wall collider found in spawn zone — collision check skipped');
}

/* E. fire origin — the chest line + one live shot through the TP path */
const e5 = await page.evaluate(() => {
  const g = AC.game, p = g.player;
  const sink = { x: 0, y: 0, z: 0, set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } };
  p.frameOrigin(sink);
  const expected = p.pos.y - p.eyeCur + 1.3;
  const chestOk = Math.abs(sink.y - expected) < 0.01;
  const magBefore = g.weapon.mag;
  g.weapon.cooldown = 0;
  g.weapon.fire(g);               // CH-22.2 origin path (fire → fireOne, third person live)
  return { chestOk, fired: g.weapon.mag === magBefore - 1,
           chestY: Math.round(sink.y * 100) / 100, expected: Math.round(expected * 100) / 100 };
});
ok('E.chest', e5.chestOk, `frameOrigin y ${e5.chestY} = chest line (${e5.expected})`);
ok('E.fire', e5.fired, 'one shot through the frame-origin path ran clean (mag decremented)');

/* F. ADS overlay — zoom in third person */
await page.evaluate(() => { AC.game.weapon.toggleZoom(AC.game); });
await page.waitForTimeout(700);   // adsT eases; overlay latch flips
const f = await page.evaluate(() => {
  const g = AC.game;
  const q = (id) => document.getElementById(id);
  const read = q('ads-read'), blur = q('adsblur'), dmg = q('ads-dmg'), tgt = q('ads-target');
  return {
    zoomed: g.weapon.zoomed,
    scopePlateOn: q('scope').classList.contains('on'),
    readOn: read.classList.contains('on'), readTxt: read.textContent,
    blurOn: blur.classList.contains('on'),
    dmgSpans: dmg.querySelectorAll('span').length,
    dmgTxt: dmg.textContent.slice(0, 60),
    targetOn: tgt.classList.contains('on'),
    crossAds: q('crosshair').classList.contains('ads'),
  };
});
ok('F.overlay', f.zoomed && f.readOn && f.blurOn && f.targetOn && f.crossAds,
  `ads overlay up (read ${f.readOn} · blur ${f.blurOn} · target ${f.targetOn} · reticle ease ${f.crossAds})`);
ok('F.readout', /^\d+(\.\d+)m · \d+\.\d+x$/.test(f.readTxt || ''), `distance·magnification live: "${f.readTxt}"`);
ok('F.dmg', f.dmgSpans >= 1, `typed split populated: "${f.dmgTxt}"`);
ok('F.scope', !f.scopePlateOn, '2D scope plate suppressed in third person (the overlay IS the sight)');

/* G. aim-target HP bar — park the camera on a live enemy, IN ADS
   (the f3 readout contract is an aiming contract) */
const g7 = await page.evaluate(() => {
  const g = AC.game;
  const e = g.enemies.find((x) => x.alive && !x.arch.kaiju);
  if (!e) return { found: false };
  const p = e.group.position;
  g.teleportTo(p.x + 2.6, p.z + 2.6);
  const dx = p.x - g.player.pos.x, dz = p.z - g.player.pos.z;
  g.player.yaw = Math.atan2(-dx, -dz);
  g.player.pitch = 0;
  if (!g.weapon.zoomed) g.weapon.toggleZoom(g);   // stay in ADS for the readout
  return { found: true, name: e.arch.name, lvl: e.level };
});
if (g7.found) {
  await page.waitForFunction(() => {
    const g = window.AC && window.AC.game;
    return g && g.weapon.adsT > 0.6 && g.currentTarget;   // eased in + target scanned
  }, null, { timeout: 30000, polling: 250 });
}
if (g7.found) {
  const g2 = await page.evaluate(() => {
    const g = AC.game;
    const t = document.getElementById('ads-target');
    return {
      live: t.classList.contains('live'),
      name: t.querySelector('.at-name').textContent,
      lvl: t.querySelector('.at-lvl').textContent,
      val: t.querySelector('.at-val').textContent,
      scanned: !!(g.currentTarget && g.currentTarget.ref && g.currentTarget.ref.alive),
    };
  });
  ok('G.bar', g2.live && g2.scanned, `top-right HP row live for ${g7.name}`);
  ok('G.row', g2.name === g7.name && g2.lvl === 'LVL ' + g7.lvl && /\d+ \/ \d+/.test(g2.val),
    `name ${g2.name} · ${g2.lvl} · value "${g2.val}" (separate from the in-world nameplate)`);
} else {
  ok('G.bar', true, 'no live enemy in field — aim-target check skipped');
}

/* screenshot: third-person ADS framing */
await page.screenshot({ path: join(ROOT, 'scripts', 'tp_cam.png') });
console.log('  screenshot → scripts/tp_cam.png');
await page.evaluate(() => { AC.game.weapon.toggleZoom(AC.game); });   // leave ADS

/* H. persistence — the toggle rides the meta save across a full reload */
await page.reload({ waitUntil: 'load', timeout: 45000 });
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return !!(g && g.world);
}, null, { timeout: 90000, polling: 500 });
await page.evaluate(() => AC.game.start());
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return g && g.state === 'playing';
}, null, { timeout: 30000, polling: 250 });
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return g && g.player.tpBlend === 1;
}, null, { timeout: 30000, polling: 250 });
const h = await page.evaluate(() => {
  const g = AC.game, p = g.player;
  return { setting: g.mods.settings.thirdPerson, tpOn: p.tpOn,
           blend: Math.round(p.tpBlend * 100) / 100, body: p.tpBody.visible };
});
ok('H.persist', h.setting === true && h.tpOn === true && h.blend === 1 && h.body === true,
  `after reload: setting ${h.setting} · tpOn ${h.tpOn} · blend ${h.blend} · body ${h.body}`);

ok('Z.pageErrors', errors.length === 0, errors.length ? errors.slice(0, 3).join(' | ') : 'zero page errors');

writeFileSync(join(ROOT, 'scripts', 'tp_report.json'),
  JSON.stringify({ date: new Date().toISOString(), version: meta.version, build: meta.build,
                   checks, pageErrors: errors }, null, 2));

const failed = checks.filter((c) => !c.good).length;
console.log(`────────────────────────────────────────────────
RESULT: ${checks.length - failed} passed · ${failed} failed`);
await browser.close();
server.close();
process.exit(failed ? 1 : 0);

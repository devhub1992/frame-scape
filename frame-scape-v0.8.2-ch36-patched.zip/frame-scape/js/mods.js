/* ============================================================================
   AUTUMN CORRIDOR — mods.js  (v0.8.1 — CH-03 CARD INVENTORY)
   ----------------------------------------------------------------------------
   CREDITS + POWER + MOD CARDS — the meta-progression layer.

   Flow (CH-03.1 — card inventory replaces buy-a-rank nodes):
     · kills pay credit bounties · salvage chips drop from the chart ·
       POWER spills rarely (15-20) from any kill, 50 from elites, and
       crystals in the valley hold 30-60  →  Mods.add / Mods.addPower
     · mod chips, crate drops, elite drops and kaiju copies all feed
       Mods.acquireCard() → they add CARDS {id, copies, rank} — never
       free ranks. First copy = a new card at R0; further copies pile
       up as duplicates you can sell (full CR) or scrap (60 % of value)
     · a card must be OWNED before its rank can be raised: the XMB
       confirm burns CREDITS + POWER for the next rank (interim fusion
       — the full mod bench with FUSION lands in CH-16)
     · X / Y (or Backspace) on a mod node still SCRAPS the rank:
       60 % of every CR and PW it ever consumed comes back, rank
       returns to 0 — the card itself is kept

   Cost curves (exact, per user spec):
     CR:  rank 1 = 10,000 … rank 10 = 1,200,000   (exponential, ×120 over 9)
     PW:  rank 1 =  5,000 … rank 10 =    30,000   (exponential, ×6  over 9)

   Kinds: mul / add / red / table (v0.5) + 'ramp':
     ramp: v = min + (max − min) · rank / 10  — writes into paths.
       JETPACK AIR-JUMP 5 %→200 % · PICKUP MAGNET 1 m→15 m · RADAR 10 m→90 m

   Persistence (CH-03.2): credits + power + CARDS auto-save to
   localStorage 'ac-meta-v3' {v:3, wallets, cards:{id:{copies,rank}}}.
   Old 'ac-meta-v2' rank banks migrate on load — every ranked node
   becomes ONE owned card at the same rank (no refunds, no lost
   power); v1 banks still migrate through v2 first. Migrations are
   idempotent: v3 is written back immediately and re-loads untouched.
   Survives death, RESET RUN and reloads. Savestates do NOT snapshot it.

   CH-04.3 — MOD COLUMNS moved (companion sets out of MOD·HEAVY) but
   NOTHING changed here structurally: cards and rank banks are keyed by
   the PERMANENT node id, and _adoptCards / _ranksToCards walk M.nodes
   by id — so moved nodes re-adopt their saved ranks automatically.
   Migration by id = ids never change; no data rewrite, no lost power.

   Debug: window.AC.game.mods  →  grant(n, pw) / wipeMeta() /
     sellCard(id) · scrapCard(id) · sellDuplicates([id]) ·
     scrapDuplicates([id]) · totalCards() / totalDuplicates()
   ==========================================================================*/

import { ASSETS } from './assets.js';

const M = ASSETS.mods;
const META_KEY = 'ac-meta-v3';       // CH-03.2 — card inventory bank {v:3}
const META_KEY_V2 = 'ac-meta-v2';    // CH-03.2 — legacy rank bank, migrated on load
const META_KEY_V1 = 'ac-meta-v1';    // v0.5.0 credits-only bank (kept for migration)
const MAX_RED = 0.6;            // 'red' nodes can never drop below 40% of base

/* dot-path helpers — read/write a leaf WITHOUT replacing its parent object */
const pget = (path) => path.split('.').reduce((o, k) => o[k], ASSETS);
const pset = (path, v) => {
  const ks = path.split('.');
  const last = ks.pop();
  const o = ks.reduce((obj, k) => obj[k], ASSETS);
  o[last] = v;
};

/* -- number formatting ------------------------------------------------------ */
export function fmtFull(n) { return Math.round(n).toLocaleString('en-US'); }
export function fmtCR(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(2).replace(/\.?0+$/, '') + 'M';
  if (n >= 1e4) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
  return fmtFull(n);
}
export const fmtPW = fmtCR;   // same magnitude family — one formatter is enough

/* -- drop-rate curve (v0.8) ---------------------------------------------------
   anchors from assets.drops.rateCurve: L40 = 1× (≈1000 PW/hr + 60,000 CR/hr
   at a good clear rate), L60 = 2×, L80 = 4× and HARD-CAPPED.               */
export function dropRateMult(level = 1) {
  const c = ASSETS.drops.rateCurve;
  if (!c || !c.length) return 1;
  if (level <= c[0].lvl) return c[0].mult;
  for (let i = 0; i < c.length - 1; i++) {
    const a = c[i], b = c[i + 1];
    if (level <= b.lvl) {
      return a.mult + (b.mult - a.mult) * (level - a.lvl) / (b.lvl - a.lvl);
    }
  }
  return c[c.length - 1].mult;
}

export const Mods = {
  credits: 0,
  power: 0,
  earned: 0,
  earnedPower: 0,
  cards: {},        // CH-03.1 — id → { copies, rank } · only OWNED cards live here
  _base: {},        // node id → pristine value(s) snapshotted at boot
  _inited: false,

  /* -- boot: snapshot pristine values, load meta save, apply ranks --------- */
  init() {
    if (this._inited) return;
    this._inited = true;
    for (const n of M.nodes) {
      this._base[n.id] = n.kind === 'table'
        ? pget(n.paths[0]).map((w) => w[n.field])
        : n.paths.map(pget);
    }
    this.credits = ASSETS.credits.start || 0;
    this.power = ASSETS.power.start || 0;
    this._load();
    this.apply();
  },

  /* -- the exact rank-cost curves ------------------------------------------- */
  costOf(targetRank) {                 // credits to REACH targetRank
    const r = Math.max(1, Math.min(M.maxRank, targetRank));
    if (r <= 1) return M.costBase;
    if (r >= M.maxRank) return M.costTop;
    const t = (r - 1) / (M.maxRank - 1);
    return Math.round(M.costBase * Math.pow(M.costTop / M.costBase, t));
  },
  costOfPW(targetRank) {               // power to REACH targetRank
    const r = Math.max(1, Math.min(M.maxRank, targetRank));
    if (r <= 1) return M.pwBase;
    if (r >= M.maxRank) return M.pwTop;
    const t = (r - 1) / (M.maxRank - 1);
    return Math.round(M.pwBase * Math.pow(M.pwTop / M.pwBase, t));
  },
  /* cumulative spent at rank r — the scrap-refund base */
  cumCR(r) { let s = 0; for (let k = 1; k <= r; k++) s += this.costOf(k); return s; },
  cumPW(r) { let s = 0; for (let k = 1; k <= r; k++) s += this.costOfPW(k); return s; },

  nextCost(id) {
    const r = this.rankOf(id);
    return r >= M.maxRank ? null : { cr: this.costOf(r + 1), pw: this.costOfPW(r + 1) };
  },

  node(id)   { return M.nodes.find((n) => n.id === id) || null; },

  /* -- CH-03.1 — card inventory accessors ------------------------------------
     cards only holds OWNED entries (copies ≥ 1); everything else reads as
     unowned / rank 0. One rank per mod id — shared by every copy.          */
  cardOf(id)   { const c = this.cards[id]; return c && c.copies > 0 ? c : null; },
  copiesOf(id) { const c = this.cardOf(id); return c ? c.copies : 0; },
  rankOf(id)   { const c = this.cardOf(id); return c ? c.rank : 0; },

  /* -- wallets ---------------------------------------------------------------- */
  add(n)      { this.credits += n; this.earned += n; this._save(); },
  addPower(n) { this.power += n;   this.earnedPower += n; this._save(); },
  pay(cr, pw) {
    if (this.credits < cr || this.power < pw) return false;
    this.credits -= cr; this.power -= pw; this._save(); return true;
  },

  /* -- CH-03.1 — rank-up on an OWNED card (interim XMB fusion; the mod
     bench with the full FUSION flow lands in CH-16) ------------------------- */
  buy(id) {
    const c = this.cardOf(id);
    if (!c) return { ok: false, unowned: true };   // no card → no rank-up
    if (c.rank >= M.maxRank) return { ok: false, maxed: true };
    const cost = { cr: this.costOf(c.rank + 1), pw: this.costOfPW(c.rank + 1) };
    if (this.credits < cost.cr || this.power < cost.pw) return { ok: false, cost };
    this.credits -= cost.cr;
    this.power -= cost.pw;
    c.rank += 1;
    this.apply();
    this._save();
    return { ok: true, rank: c.rank, cost };
  },

  /* -- CH-03.1 — THE one acquisition path: mod chips, crate drops, elite
     drops and kaiju copies ALL land here and add CARDS — never free ranks.
     First copy = a new card at rank 0; further copies pile up as duplicates. */
  acquireCard(id) {
    const n = this.node(id);
    if (!n) return null;
    const existing = this.cardOf(id);
    if (existing) existing.copies += 1;
    else this.cards[id] = { copies: 1, rank: 0 };
    this.apply();
    this._save();
    return { ok: true, id, isNew: !existing, copies: this.cards[id].copies, label: n.label };
  },

  /* -- CH-03.3 — duplicate economy --------------------------------------------
     sellValue: one duplicate card sells for this many CR (assets tunable).
     sellCard  — sell ONE duplicate copy for full value in CR. The last copy
                 is protected (scrap the RANK via scrapCard instead).
     scrapCard — the existing 60 % refund: 60 % of every CR + PW the current
                 rank ever consumed comes home, rank resets to 0, the card
                 (and all copies) are KEPT.
     sellDuplicates(id) / scrapDuplicates(id) — ALL copies but one. Call
                 WITHOUT an id for the global variant across every mod.
     totalCards / totalDuplicates — inventory counters for the XMB.        */
  sellValue() { return ASSETS.drops.modChip.duplicateSale || ASSETS.drops.modChip.maxedRefund || 0; },

  sellCard(id) {
    const c = this.cardOf(id);
    if (!c) return { ok: false, unowned: true };
    if (c.copies <= 1) return { ok: false, lastCopy: true };
    const value = this.sellValue();
    c.copies -= 1;
    this.add(value);
    return { ok: true, value, copies: c.copies };
  },

  scrapCard(id) {
    const c = this.cardOf(id);
    if (!c || c.rank <= 0) return { ok: false, empty: true };
    const r = c.rank;
    const refund = {
      cr: Math.round(this.cumCR(r) * M.scrapRefund),
      pw: Math.round(this.cumPW(r) * M.scrapRefund),
    };
    this.credits += refund.cr;
    this.power += refund.pw;
    c.rank = 0;
    this.apply();
    this._save();
    return { ok: true, refund, rank: r };
  },

  sellDuplicates(id) {
    if (id === undefined) {                        // CH-03.3 — GLOBAL variant
      let sold = 0, value = 0, mods = 0;
      for (const n of M.nodes) {
        const r = this.sellDuplicates(n.id);
        if (r.ok) { sold += r.sold; value += r.value; mods += 1; }
      }
      return { ok: sold > 0, sold, value, mods };
    }
    const c = this.cardOf(id);
    if (!c || c.copies <= 1) return { ok: false, none: true };
    const sold = c.copies - 1;                     // all copies but one
    const value = sold * this.sellValue();
    c.copies = 1;
    this.add(value);
    return { ok: true, sold, value, copies: c.copies };
  },

  scrapDuplicates(id) {
    if (id === undefined) {                        // CH-03.3 — GLOBAL variant
      let scrapped = 0, value = 0, mods = 0;
      for (const n of M.nodes) {
        const r = this.scrapDuplicates(n.id);
        if (r.ok) { scrapped += r.scrapped; value += r.value; mods += 1; }
      }
      return { ok: scrapped > 0, scrapped, value, mods };
    }
    const c = this.cardOf(id);
    if (!c || c.copies <= 1) return { ok: false, none: true };
    const scrapped = c.copies - 1;                 // all copies but one
    const value = Math.round(scrapped * this.sellValue() * M.scrapRefund);
    c.copies = 1;
    this.add(value);
    return { ok: true, scrapped, value, copies: c.copies };
  },

  totalCards() {
    let s = 0;
    for (const id in this.cards) s += Math.max(0, this.cards[id].copies | 0);
    return s;
  },
  totalDuplicates() {
    let s = 0;
    for (const id in this.cards) { const c = this.cards[id]; if (c.copies > 1) s += c.copies - 1; }
    return s;
  },

  /* -- legacy alias — the XMB scrap flow predates the card API (CH-03.3) ------ */
  scrap(id) { return this.scrapCard(id); },

  /* -- write every rank back into ASSETS (in place!) -------------------------- */
  _rampVal(n, r) {
    return n.min + (n.max - n.min) * (r / M.maxRank);
  },
  apply() {
    for (const n of M.nodes) {
      const r = this.rankOf(n.id);
      if (n.kind === 'ramp') {
        const v = this._rampVal(n, r);
        n.paths.forEach((p) => pset(p, Math.round(v * 100) / 100));
        continue;
      }
      const b = this._base[n.id];
      const f = (x) =>
        n.kind === 'add' ? x + n.per * r :
        n.kind === 'red' ? x * (1 - Math.min(MAX_RED, n.per * r)) :
        x * (1 + n.per * r);
      if (n.kind === 'table') {
        const arr = pget(n.paths[0]);
        arr.forEach((w, i) => { w[n.field] = f(b[i]); });
      } else {
        n.paths.forEach((p, i) => {
          const v = f(b[i]);
          pset(p, n.kind === 'add' ? Math.round(v) : v);
        });
      }
    }
  },

  /* -- preview values for the XMB card (current → next) ----------------------- */
  valueNow(n, rankOffset = 0) {
    const r = Math.min(M.maxRank, this.rankOf(n.id) + rankOffset);
    if (n.kind === 'ramp') return [this._rampVal(n, r)];
    const b = this._base[n.id];
    const f = (x) =>
      n.kind === 'add' ? x + n.per * r :
      n.kind === 'red' ? x * (1 - Math.min(MAX_RED, n.per * r)) :
      x * (1 + n.per * r);
    return b.map(f);
  },

  /* one-line spec sheet for the selected-card panel */
  describe(n) {
    const r = this.rankOf(n.id);
    const cur = this.valueNow(n, 0);
    const nxt = this.valueNow(n, 1);
    const fx = (v) => n.kind === 'add' ? String(Math.round(v)) : (Math.round(v * 10) / 10).toString();
    let growth;
    if (n.kind === 'ramp') {
      growth = `${n.min}→${n.max} across 10 ranks`;
    } else {
      growth = n.kind === 'add' ? `+${n.per}/rank`
        : n.kind === 'red' ? `−${Math.round(n.per * 100)}%/rank`
        /* CH-04.2 — negative-per table nodes (SENTINEL TRIGGER) read as a reduction */
        : `${n.per >= 0 ? '+' : '−'}${Math.abs(Math.round(n.per * 100))}%/rank`;
    }
    let range;
    if (n.kind === 'table') {
      /* CH-04.2 — field-aware (dmg ramps UP, interval ramps DOWN via per < 0) */
      const mult = 1 + n.per * r;
      range = `drone weapon ${n.field} ×${mult.toFixed(2)} @ R${r}`;
    } else {
      range = n.paths.map((p, i) => `${fx(cur[i])} → ${fx(nxt[i])}`).join(' · ');
    }
    const cost = this.nextCost(n.id);
    const costTxt = cost === null ? 'MAXED'
      : `NEXT RANK ${fmtFull(cost.cr)} CR + ${fmtFull(cost.pw)} PW`;
    const copies = this.copiesOf(n.id);            // CH-03.1 — card line
    const cardTxt = !copies
      ? 'NO CARD — mod chips, crates, elites + kaiju drop them'
      : copies > 1
        ? `CARD ×${copies} (${copies - 1} duplicate${copies > 2 ? 's' : ''})`
        : 'CARD ×1';
    return (n.desc ? n.desc + ' · ' : '') +
      `${range} (${growth}) · ${costTxt} · ` +
      `${cardTxt} · bank ${fmtFull(this.credits)} CR / ${fmtFull(this.power)} PW · ` +
      `X or Y = SCRAP RANK (${Math.round(M.scrapRefund * 100)}% back, card kept)`;
  },

  /* -- meta persistence (survives death / reset / reload) ---------------------
     CH-03.2 — v3 card format {v:3, wallets, cards:{id:{copies,rank}}}.
     Migration ladder v1 → v2 → v3, fully idempotent: every legacy rank
     becomes ONE owned card at the same rank — no refunds, no lost power.
     v3 is written back immediately so the migration runs exactly once.  */
  _save() {
    try {
      const cards = {};
      for (const id in this.cards) {
        const c = this.cards[id];
        if (c && c.copies > 0) cards[id] = { copies: c.copies, rank: c.rank };
      }
      localStorage.setItem(META_KEY, JSON.stringify({
        v: 3, credits: this.credits, power: this.power,
        earned: this.earned, earnedPower: this.earnedPower, cards,
      }));
    } catch { /* private mode etc — progression just won't persist */ }
  },
  _load() {
    let d = null;
    try { d = JSON.parse(localStorage.getItem(META_KEY)); } catch { d = null; }
    if (d && d.v === 3) {                        // current format — plain load
      this._adoptWallet(d);
      this._adoptCards(d.cards);
      return;
    }
    try { d = JSON.parse(localStorage.getItem(META_KEY_V2)); } catch { d = null; }
    if (d && d.v === 2) {                        // CH-03.2 — ranks → one card each
      this._adoptWallet(d);
      if (d.ranks) this._ranksToCards(d.ranks);
      this._save();                              // persist as v3 — migration runs once
      return;
    }
    /* migrate the v0.5.0 v1 bank (credits only) — through the same card path */
    try { d = JSON.parse(localStorage.getItem(META_KEY_V1)); } catch { d = null; }
    if (d && d.v === 1) {
      this.credits = Number(d.credits) || 0;
      if (d.ranks) { this._ranksToCards(d.ranks); this._save(); }
    }
  },
  _adoptWallet(d) {
    this.credits = Number(d.credits) || 0;
    this.power = Number(d.power) || 0;
    this.earned = Number(d.earned) || 0;
    this.earnedPower = Number(d.earnedPower) || 0;
  },
  _ranksToCards(ranks) {
    for (const n of M.nodes) {
      const r = Math.max(0, Math.min(M.maxRank, Number(ranks[n.id]) || 0));
      if (r > 0) this.cards[n.id] = { copies: 1, rank: r };   // rank 0 = never owned
    }
  },
  _adoptCards(cards) {
    if (!cards) return;
    for (const n of M.nodes) {
      const c = cards[n.id];
      if (!c) continue;
      const copies = Math.max(0, Math.floor(Number(c.copies) || 0));
      const rank = Math.max(0, Math.min(M.maxRank, Number(c.rank) || 0));
      if (copies > 0) this.cards[n.id] = { copies, rank };
    }
  },

  /* -- console / XMB escape hatch --------------------------------------------- */
  grant(n, pw = 0) { this.add(n); if (pw) this.addPower(pw); },
  wipeMeta() {
    this.credits = ASSETS.credits.start || 0;
    this.power = ASSETS.power.start || 0;
    this.earned = 0; this.earnedPower = 0;
    this.cards = {};                             // CH-03.2 — card inventory too
    try {
      localStorage.removeItem(META_KEY);
      localStorage.removeItem(META_KEY_V2);
      localStorage.removeItem(META_KEY_V1);
    } catch {}
    this.apply();
  },
};

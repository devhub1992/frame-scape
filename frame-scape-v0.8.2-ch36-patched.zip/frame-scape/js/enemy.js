/* ============================================================================
   FRAME SCAPE — enemy.js  (v0.8.0)
   ----------------------------------------------------------------------------
   Six archetypes built from primitives (assets.js → enemy.archetypes):
     · GRUNT    — baseline plasma-pistol alien
     · JACKAL   — frontal energy gauntlet-shield (flank it or stagger it)
     · SENTINEL — flying drone, fast, fragile
     · ELITE    — gold heavy; RARE now; rolls 1-3 elite abilities (fire nova,
                  frag grenades, homing missiles, blink dash, glide module)
                  whose effects KNOCK YOU DOWN; some bring a hound pet
     · HOUND    — fast elite pet, fights at its master's side
     · KAIJU    — L80 ocean horror; slams the ground (knockdown), never
                  leaves the deep water
   All get billboard health bars, a stagger state, y-aware collisions, and
   level-scaled hp/shields + drop-rate-curve-scaled loot on death.
   States: patrol → combat (face player, spacing, strafe, burst fire).
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js';
import { Mods, dropRateMult } from './mods.js';
import { texGlow, texBlob } from './textures.js';

const E = ASSETS.enemy;
const P = ASSETS.palette;
const rand = (a, b) => a + Math.random() * (b - a);

/* zone levels: hallway L2 · hangar L5 · valley L7 · cityscape L8 ·
   expanse tiles L10+ (spawn defs carry their own lvl) */
export function levelForZ(z) {
  const L = E.leveling.zones;
  if (z <= ASSETS.world.expanse.z0) return 10;      // generic expanse floor
  if (z <= ASSETS.world.city.z0) return L.city;
  if (z <= ASSETS.world.valley.z0) return L.valley;
  if (z <= ASSETS.world.hangar.mouthZ - 0.1) return L.hangar;
  return L.corridor;
}

/* elite entourage: some elites bring their own pet hound (called by main.js
   right after an elite is spawned) */
export function spawnEliteEntourage(game, elite) {
  if (!elite.arch.elite || elite.arch.kaiju) return null;
  if (Math.random() > E.eliteAbilities.petChance) return null;
  const def = {
    t: 'hound',
    x: elite.home.x + rand(-2.5, 2.5), z: elite.home.z + rand(-2.5, 2.5),
    patrol: 3, arena: elite.arena || 6,
    lvl: elite.level,
    valley: elite.isValley, city: elite.isCity, expanse: elite.spawnDef.expanse,
    catwalk: false,
  };
  const hound = new Grunt(def, game.scene);
  hound.master = elite;
  game.enemies.push(hound);
  return hound;
}

/* shared bolt resources (created lazily) */
let boltGeo = null, boltMat = null, boltGlow = null;
export const bolts = [];

export function spawnBolt(scene, pos, dir, dmg = null) {
  if (!boltGeo) {
    boltGeo = new THREE.SphereGeometry(0.09, 8, 6);
    boltMat = new THREE.MeshBasicMaterial({ color: P.plasma });
    boltGlow = new THREE.SpriteMaterial({
      map: texGlow(P.plasma), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    });
  }
  const mesh = new THREE.Mesh(boltGeo, boltMat);
  const glow = new THREE.Sprite(boltGlow);
  glow.scale.setScalar(0.55);
  mesh.add(glow);
  mesh.position.copy(pos);
  scene.add(mesh);
  bolts.push({ mesh, vel: dir.clone().multiplyScalar(E.boltSpeed), life: E.boltLife, dmg });
}

function panFor(game, pos) {
  const to = new THREE.Vector3().subVectors(pos, game.player.pos);
  const right = new THREE.Vector3(Math.cos(game.player.yaw), 0, -Math.sin(game.player.yaw));
  const d = to.length();
  return d > 0.1 ? Math.max(-1, Math.min(1, to.dot(right) / d)) * 0.8 : 0;
}

function resolveCircle(pos, r, colliders, axis, y = 1) {
  for (const c of colliders) {
    if (c.y0 !== undefined && (y + 1.4 <= c.y0 || y >= c.y1)) continue;
    if (pos.z + r <= c.minZ || pos.z - r >= c.maxZ) continue;
    if (pos.x + r <= c.minX || pos.x - r >= c.maxX) continue;
    if (axis === 'x') {
      const mid = (c.minX + c.maxX) / 2;
      pos.x = pos.x > mid ? c.maxX + r : c.minX - r;
    } else {
      const mid = (c.minZ + c.maxZ) / 2;
      pos.z = pos.z > mid ? c.maxZ + r : c.minZ - r;
    }
  }
}

function lerpAngle(a, b, t) {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

/* ------------------------------------------------------------------ */
export class Grunt {
  constructor(spawn, scene) {
    this.scene = scene;
    this.arch = E.archetypes[spawn.t] || E.archetypes.grunt;
    this.spawnDef = spawn;
    this.typeKey = spawn.t;          // for the credits bounty table
    this.isValley = !!spawn.valley;  // valley spawns clamp to canyon bounds
    this.isCity = !!spawn.city;      // city spawns clamp to street bounds
    this.alive = true;
    /* zone level + hp/shield scaling (×1.22 at L2 → ×2.54 at L8) */
    this.level = spawn.lvl || levelForZ(spawn.z);
    const lvlMult = 1 + E.leveling.perLevel * (this.level - 1);
    this.maxHp = Math.round(this.arch.hp * lvlMult);
    this.maxShieldHp = Math.round((this.arch.shieldHp || 0) * lvlMult);
    this.hp = this.maxHp;
    this.shieldHp = this.maxShieldHp;
    this.fly = !!this.arch.fly;
    this.flyY = spawn.flyY || this.arch.flyY || 2.2;
    this.home = new THREE.Vector3(spawn.x, 0, spawn.z);
    this.patrol = spawn.patrol;
    this.arena = spawn.arena || 0;
    this.catwalkY = spawn.catwalk ? ASSETS.world.hangar.catwalk.y : null;
    this.dir = Math.random() < 0.5 ? 1 : -1;
    this.fireTimer = rand(0.6, this.arch.fireInterval);
    this.burstLeft = 0;
    this.burstTimer = 0;
    this.strafeTimer = 0;
    this.strafeDir = Math.random() < 0.5 ? 1 : -1;
    this.waddleT = 0;
    this.deathT = -1;
    this.fallDir = 1;
    this.flinch = 0;
    this.stagger = 0;
    /* CH-04.4 — FREEZE RAY defense-sap state (see applySap/updateSap) */
    this._sapStacks = 0;         // DEF-DOWN stacks (cap = drone.defDown.maxStacks)
    this._sapAcc = 0;            // fractional stack accumulator while beamed
    this._sapT = 0;              // contact grace timer before decay starts
    this._sapDecayT = 0;         // countdown to the next stack decay
    /* CH-25.3 — REAL armor pool (elite+ first, then regulars — every
       archetype carries one). Flat per archetype on purpose: the EHP
       curve is the single power lever; level-scaling would compound
       with the existing 22 %/level hp curve. Mitigation runs through
       ASSETS.combat.mitigation() — the shared curve (CH-38.1 player
       side wires into the SAME numbers). CORROSIVE stripping (CH-27)
       will subtract from this.armor directly.                           */
    this.armor = this.arch.armor || 0;
    this.lastHit = null;         // CH-25.2 — {crit,total,statusChance} for CH-28 styling
    this.bobY = 0;
    this.barTimer = 0;
    this._hitBy = null;          // 'companion' → blood-for-shield on death
    /* ELITE ability loadout: roll 1-3 from the pool (kaiju excluded) */
    if (this.arch.elite && !this.arch.kaiju) {
      const EA = E.eliteAbilities;
      const n = Math.round(rand(EA.roll[0], EA.roll[1]));
      const pool = EA.pool.slice();
      this.abilities = [];
      for (let i = 0; i < n && pool.length; i++) {
        this.abilities.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
      }
      this.abCd = {};
      for (const a of this.abilities) this.abCd[a] = rand(2.5, 6);
      this.glideT = 0;
    }
    /* kaiju extras */
    if (this.arch.kaiju) {
      this.slamCd = 4;
      this.master = null;
    }
    this.build();
  }

  build() {
    const C = this.arch.colors;
    const s = this.arch.scale;
    const g = new THREE.Group();
    const armor = new THREE.MeshLambertMaterial({ color: C.armor });
    const suit  = new THREE.MeshLambertMaterial({ color: C.suit });
    const mask  = new THREE.MeshLambertMaterial({ color: C.mask });
    const visor = new THREE.MeshBasicMaterial({ color: C.visor });
    const gunM  = new THREE.MeshLambertMaterial({ color: C.gun });
    this.mats = [armor, suit, mask, visor, gunM];

    const add = (geo, mat, x, y, z, sx = 1, sy = 1, sz = 1, rx = 0) => {
      const m = new THREE.Mesh(geo, mat);
      m.position.set(x, y, z); m.scale.set(sx, sy, sz); m.rotation.x = rx;
      g.add(m); return m;
    };

    if (this.fly) {
      // SENTINEL: hovering orb + fins + eye
      this.torso = add(new THREE.SphereGeometry(0.3, 10, 8), armor, 0, 0, 0);
      add(new THREE.SphereGeometry(0.2, 10, 8), suit, 0, -0.12, 0.05, 1, 0.7, 1);
      add(new THREE.BoxGeometry(0.5, 0.04, 0.16), suit, 0, 0.05, 0);       // wing L/R bar
      add(new THREE.BoxGeometry(0.16, 0.04, 0.5), suit, 0, 0.05, 0);
      add(new THREE.CylinderGeometry(0.05, 0.09, 0.16, 8), gunM, 0, -0.3, 0.05);
      add(new THREE.BoxGeometry(0.09, 0.05, 0.02), visor, 0, -0.36, 0.1);  // gun eye
      this.eye = add(new THREE.SphereGeometry(0.07, 8, 6), visor, 0, 0, 0.27);
      this.gunTip = new THREE.Vector3(0, -0.36, 0.12);
      this.legL = this.torso; this.legR = this.torso; // no walk anim
    } else {
      this.torso = add(new THREE.SphereGeometry(0.32, 10, 8), armor, 0, 0.66, 0, 1, 0.95, 1.15);
      add(new THREE.SphereGeometry(0.27, 10, 8), suit, 0, 0.42, -0.02, 1, 0.8, 1);
      this.head = add(new THREE.SphereGeometry(0.16, 10, 8), armor, 0, 1.02, 0.03);
      add(new THREE.BoxGeometry(0.15, 0.13, 0.13), mask, 0, 0.98, 0.15);
      add(new THREE.BoxGeometry(0.08, 0.045, 0.02), visor, 0, 0.99, 0.22);
      add(new THREE.CylinderGeometry(0.13, 0.15, 0.32, 8), suit, 0, 0.72, -0.26, 1, 1, 1, Math.PI / 2);
      this.legL = add(new THREE.BoxGeometry(0.11, 0.3, 0.13), suit, -0.13, 0.15, 0);
      this.legR = add(new THREE.BoxGeometry(0.11, 0.3, 0.13), suit, 0.13, 0.15, 0);
      add(new THREE.BoxGeometry(0.07, 0.2, 0.09), suit, -0.32, 0.6, 0.02, 1, 1, 1, 0.4);
      this.armR = add(new THREE.BoxGeometry(0.07, 0.2, 0.09), suit, 0.32, 0.6, 0.02, 1, 1, 1, -0.9);
      add(new THREE.BoxGeometry(0.06, 0.09, 0.24), gunM, 0.3, 0.72, 0.26);
      add(new THREE.BoxGeometry(0.035, 0.035, 0.04), visor, 0.3, 0.72, 0.39);
      this.gunTip = new THREE.Vector3(0.3, 0.72, 0.4);

      // JACKAL energy gauntlet-shield
      if (this.arch.shieldHp) {
        const sh = new THREE.MeshBasicMaterial({
          color: C.shield, transparent: true, opacity: 0.42,
          blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide,
        });
        this.shieldMat = sh;
        this.shieldMesh = add(new THREE.CylinderGeometry(0.55, 0.55, 1.15, 10, 1, true, -0.7, 1.4), sh, 0.18, 0.7, 0.3);
        this.shieldMesh.rotation.y = 0.5;
        this.mats.push(sh);
      }
    }

    g.scale.setScalar(s);

    // hitbox for bullets
    const hitMat = new THREE.MeshBasicMaterial({
      transparent: true, opacity: 0, depthWrite: false,
    });
    const hitH = this.fly ? 0.9 : 1.3;
    this.hitMesh = new THREE.Mesh(new THREE.BoxGeometry(0.85, hitH, 0.85), hitMat);
    this.hitMesh.position.set(0, this.fly ? 0 : 0.62 * s, 0);
    this.hitMesh.userData.enemy = this;
    g.add(this.hitMesh);

    // billboard health bar (with zone-level badge)
    this.barCanvas = document.createElement('canvas');
    this.barCanvas.width = 118; this.barCanvas.height = 14;
    this.barTex = new THREE.CanvasTexture(this.barCanvas);
    this.barTex.colorSpace = THREE.SRGBColorSpace;
    this.bar = new THREE.Sprite(new THREE.SpriteMaterial({
      map: this.barTex, transparent: true, depthWrite: false, depthTest: false,
    }));
    this.bar.scale.set(1.3, 0.155, 1);
    this.bar.position.y = (this.fly ? 0.62 : 1.42) * s;
    this.bar.visible = false;
    this.drawBar();
    g.add(this.bar);

    // blob shadow
    this.blob = new THREE.Mesh(
      new THREE.PlaneGeometry(1.0, 1.0),
      new THREE.MeshBasicMaterial({
        map: texBlob(), transparent: true, depthWrite: false, opacity: 0.8,
      })
    );
    this.blob.rotation.x = -Math.PI / 2;
    this.blob.position.y = 0.015;

    this.group = g;
    g.position.set(this.home.x, this.catwalkY || 0, this.home.z);
    this.scene.add(g);
    this.scene.add(this.blob);
  }

  /* -- health bar (redraw only on change) --------------------------------- */
  drawBar() {
    const x = this.barCanvas.getContext('2d');
    x.clearRect(0, 0, 118, 14);
    x.fillStyle = 'rgba(4,10,16,0.8)';
    x.fillRect(0, 0, 96, 14);
    const frac = Math.max(0, this.hp / this.maxHp);
    x.fillStyle = this.arch.elite ? '#e8b53a' : '#ff5340';
    x.fillRect(2, 2, 92 * frac, 10);
    if (this.shieldHp > 0) {
      const sf = Math.max(0, this.shieldHp / this.maxShieldHp);
      x.fillStyle = '#4fc3ff';
      x.fillRect(2, 2, 92 * sf, 3);
    }
    if (this._sapStacks > 0) {
      /* CH-04.4 — DEF-DOWN stack pips (ice blue, bottom of the bar frame) */
      x.fillStyle = '#9fdcff';
      for (let i = 0; i < this._sapStacks; i++) x.fillRect(2 + i * 6, 11, 4, 2);
    }
    x.strokeStyle = 'rgba(190,235,255,0.5)';
    x.lineWidth = 1;
    x.strokeRect(0.5, 0.5, 95, 13);
    /* level badge (gold for elites) */
    x.fillStyle = this.arch.elite ? 'rgba(232,181,58,0.92)' : 'rgba(120,200,255,0.85)';
    x.font = '700 11px Consolas, monospace';
    x.textAlign = 'left'; x.textBaseline = 'middle';
    x.fillText('L' + this.level, 100, 7.5);
    this.barTex.needsUpdate = true;
  }
  showBar(t = 3.2) { this.barTimer = t; }

  /* ------------------------------------------------------------------ */
  update(dt, game) {
    if (!this.alive) { this.updateDeath(dt); return; }
    this.updateSap(dt);              // CH-04.4 — DEF-DOWN stack decay
    const p = game.player;
    const pos = this.group.position;
    const to = new THREE.Vector3().subVectors(p.pos, pos); to.y = 0;
    const dist = to.length();

    // health bar visibility window
    if (this.barTimer > 0) {
      this.barTimer -= dt;
      this.bar.visible = this.barTimer > 0 && dist < 40;
    } else if (game.currentTarget && game.currentTarget.ref === this) {
      this.bar.visible = true;
    } else {
      this.bar.visible = false;
    }
    // shield face camera nicety: billboards handle it; toggles here
    if (this.shieldMesh) {
      this.shieldMesh.visible = this.shieldHp > 0 && this.stagger <= 0;
    }

    const combat = dist < this.arch.aggro && !p.dead && !(p.invisT > 0);
    const staggered = this.stagger > 0;
    if (staggered) this.stagger -= dt;
    if (this.flinch > 0) this.flinch -= dt;

    let moving = 0;

    if (combat && !staggered) {
      // face the player
      const targetYaw = Math.atan2(to.x, to.z);
      this.group.rotation.y = lerpAngle(this.group.rotation.y, targetYaw, Math.min(1, dt * 6));

      // spacing + strafe
      this.strafeTimer -= dt;
      if (this.strafeTimer <= 0) {
        this.strafeTimer = rand(1.2, 2.8);
        this.strafeDir = Math.random() < 0.5 ? 1 : -1;
      }
      const n = to.clone().normalize();
      const side = new THREE.Vector3(-n.z, 0, n.x).multiplyScalar(this.strafeDir);
      const move = new THREE.Vector3();
      if (dist < this.arch.keepDistance) move.sub(n);
      else if (dist > this.arch.aggro * 0.85) move.add(n);
      move.addScaledVector(side, 0.7);
      if (move.lengthSq() > 0.001) {
        move.normalize().multiplyScalar(this.arch.strafeSpeed * dt);
        pos.x += move.x; pos.z += move.z;
        resolveCircle(pos, 0.4, game.world.colliders, 'x', this.fly ? this.flyY : (this.catwalkY || 0));
        resolveCircle(pos, 0.4, game.world.colliders, 'z', this.fly ? this.flyY : (this.catwalkY || 0));
        moving = 1;
      }
      // stay in the pocket
      if (this.arch.kaiju) {
        /* kaiju never leaves the deep ocean */
        const xh = game.world.xHalf - 1.5;
        pos.x = Math.max(-xh, Math.min(xh, pos.x));
        pos.z = Math.max(game.world.zEnd + 3, Math.min(game.world.oceanZ0 - 3, pos.z));
      } else if (this.isCity) {
        pos.x = Math.max(-11.5, Math.min(11.5, pos.x));
        pos.z = Math.max(ASSETS.world.city.z1 + 1.5, Math.min(ASSETS.world.city.z0 - 1, pos.z));
      } else if (this.isValley) {
        pos.x = Math.max(-12, Math.min(12, pos.x));
        pos.z = Math.max(-155, Math.min(-118.5, pos.z));
      } else if (this.arena) {
        pos.x = Math.max(this.home.x - this.arena, Math.min(this.home.x + this.arena, pos.x));
        pos.z = Math.max(this.home.z - this.patrol * 2, Math.min(this.home.z + 2.5, pos.z));
        pos.x = Math.max(-ASSETS.world.hangar.width / 2 + 1, Math.min(ASSETS.world.hangar.width / 2 - 1, pos.x));
        pos.z = Math.max(ASSETS.world.hangar.mouthZ - 4, Math.min(ASSETS.world.hangar.exitDoor.z + 2, pos.z));
      } else {
        pos.x = Math.max(-ASSETS.world.corridor.width / 2 + 0.6, Math.min(ASSETS.world.corridor.width / 2 - 0.6, pos.x));
        pos.z = Math.max(this.home.z - 5, Math.min(this.home.z + 2.5, pos.z));
      }

      // burst fire
      if (this.burstLeft > 0) {
        this.burstTimer -= dt;
        if (this.burstTimer <= 0) {
          this.burstTimer = this.arch.burstGap;
          this.burstLeft--;
          this.shoot(game);
        }
      } else {
        this.fireTimer -= dt;
        if (this.fireTimer <= 0) {
          this.fireTimer = this.arch.fireInterval * rand(0.75, 1.3);
          this.burstLeft = this.arch.burst;
          this.burstTimer = 0;
        }
      }

      /* ELITE ability kit + kaiju slam */
      if (this.abilities) this.updateAbilities(game, dist, dt);
      if (this.arch.kaiju) this.updateKaiju(game, dist, dt);
    } else if (combat && staggered) {
      // stunned wobble
      this.group.rotation.z = Math.sin(game.time * 20) * 0.08;
    } else {
      this.group.rotation.z = 0;
      // patrol along z between home ± patrol range
      if (this.patrol > 0 && !staggered) {
        pos.z += this.dir * this.arch.speed * dt;
        const zMax = this.home.z + (this.arena ? this.patrol * 2 : this.patrol);
        const zMin = this.home.z - (this.arena ? this.patrol * 2 : this.patrol);
        if (pos.z > zMax) { pos.z = zMax; this.dir = -1; }
        if (pos.z < zMin) { pos.z = zMin; this.dir = 1; }
        const face = this.dir > 0 ? 0 : Math.PI;
        this.group.rotation.y = lerpAngle(this.group.rotation.y, face, Math.min(1, dt * 4));
        moving = 0.6;
      }
    }

    // ground snap + kaiju size + glide hover
    if (this.fly) {
      this.waddleT += dt * 3;
      pos.y = this.flyY + Math.sin(this.waddleT) * 0.18;
      this.torso.rotation.z = Math.sin(this.waddleT * 1.7) * 0.12 * (0.4 + moving);
      // face-move banking
      if (!combat || staggered) this.group.rotation.z *= Math.exp(-4 * dt);
    } else {
      this.waddleT += dt * (4 + moving * 5);
      const w = Math.sin(this.waddleT) * 0.45 * moving;
      this.legL.rotation.x = w;
      this.legR.rotation.x = -w;
      this.bobY = Math.abs(Math.sin(this.waddleT)) * 0.04 * moving;
      const gy = this.catwalkY ?? game.world.floorHeightAt(pos.x, pos.z, 99);
      pos.y = gy + this.bobY;
      if (!staggered) this.group.rotation.z = 0;
    }
    /* GLIDE MODULE — elite floats up like a glide user */
    if (this.glideT > 0 && combat) {
      this.glideT -= dt;
      pos.y += (E.eliteAbilities.glide.height + 1.4 - pos.y) * Math.min(1, dt * 2.4);
      if (Math.random() < dt * 8) game.weapon.spawnPuff(pos);
    }

    // flinch pulse
    if (this.flinch > 0) {
      const s = 1 + Math.max(0, this.flinch) * 0.5;
      this.torso.scale.set(s, 0.95 * s, 1.15 * s);
    } else if (this.torso.scale.x !== 1) {
      this.torso.scale.set(1, 0.95, 1.15);
    }

    this.blob.position.set(pos.x, (this.catwalkY ?? game.world.floorHeightAt(pos.x, pos.z, 99)) + 0.015, pos.z);
    this.blob.visible = !this.fly;
  }

  /* -- elite ability kit ----------------------------------------------------- */
  updateAbilities(game, dist, dt) {
    const EA = E.eliteAbilities;
    const pl = game.player;
    for (const a of this.abilities) {
      if (this.abCd[a] > 0) { this.abCd[a] -= dt; continue; }
      const cfg = EA[a];
      switch (a) {
        case 'firenova':
          if (dist < cfg.maxDist) {
            this.abCd[a] = cfg.cd;
            game.specials.hostileNova(game, pl.pos.clone(), cfg.radius, cfg.dmg, cfg.burn, this);
          }
          break;
        case 'grenade':
          if (dist > cfg.minDist && dist < cfg.maxDist) {
            this.abCd[a] = cfg.cd;
            const from = this.gunTip.clone().applyMatrix4(this.group.matrixWorld);
            game.specials.hostileGrenade(game, from, pl.pos.clone(), cfg);
          }
          break;
        case 'missiles':
          if (dist > cfg.minDist && dist < cfg.maxDist) {
            this.abCd[a] = cfg.cd;
            game.specials.hostileMissile(game, this, cfg.dmg);
          }
          break;
        case 'blink':
          if (dist > cfg.minDist && dist < cfg.maxDist) {
            this.abCd[a] = cfg.cd;
            const to = new THREE.Vector3().subVectors(pl.pos, this.group.position);
            to.y = 0; to.normalize();
            const side = new THREE.Vector3(-to.z, 0, to.x)
              .multiplyScalar(Math.random() < 0.5 ? 1 : -1);
            game.weapon.spawnSpark(this.group.position.clone().add(new THREE.Vector3(0, 0.8, 0)), 'energy', true);
            this.group.position.addScaledVector(to, cfg.dist * 0.72);
            this.group.position.addScaledVector(side, cfg.dist * 0.72);
            game.weapon.spawnSpark(this.group.position.clone().add(new THREE.Vector3(0, 0.8, 0)), 'energy', true);
            game.sfx.dash();
            game.hud.toast('ELITE BLINKED', 800);
          }
          break;
        case 'glide':
          if (this.glideT <= 0) {
            this.abCd[a] = cfg.cd;
            this.glideT = cfg.time;
            game.hud.toast('ELITE GOES AIRBORNE', 900);
          }
          break;
      }
    }
  }

  /* -- kaiju slam -------------------------------------------------------------- */
  updateKaiju(game, dist, dt) {
    const K = ASSETS.world.expanse.kaiju;
    this.slamCd -= dt;
    if (dist < K.slamRadius && this.slamCd <= 0) {
      this.slamCd = 4.5;
      game.specials.spawnRing(this.group.position, K.slamRadius, '#8cff5e');
      game.sfx.boom(0);
      game.weapon.spawnSpark(this.group.position.clone().add(new THREE.Vector3(0, 1, 0)), false, true);
      if (!game.player.dead) {
        game.player.damage(K.slamDamage, game);
        game.player.knockdown(game, 1.6);
        game.hud.toast('KAIJU SLAM!', 1100);
      }
    }
  }

  shoot(game) {
    const p = game.player;
    const gunPos = this.gunTip.clone().applyMatrix4(this.group.matrixWorld);
    const target = p.pos.clone();
    const dist = gunPos.distanceTo(target);
    target.y = p.pos.y;
    target.addScaledVector(p.vel, (dist / E.boltSpeed) * 0.55);
    target.x += rand(-0.35, 0.35);
    target.y += rand(-0.15, 0.25);
    target.z += rand(-0.35, 0.35);
    const dir = target.sub(gunPos).normalize();
    spawnBolt(this.scene, gunPos, dir, this.arch.boltDamage);
    game.sfx.plasmaShot(panFor(game, this.group.position));
    if (this.armR) this.armR.rotation.x = -1.3;
  }

  /* kind: 'bullet' | 'melee' | 'splash' | 'missile' | 'beam' | 'burn' | 'freeze' */
  damage(amount, point, game, kind = 'bullet', dir = null) {
    if (!this.alive) return 0;
    /* CH-25.4 — typed hits arrive as {puncture,impact,slash,...} objects
       built by weapon.js applyDamage() (crit pre-multiplied into the
       values). Plain numbers keep the legacy raw path — which today is
       ONLY the VATS missile execute (9999, bypasses everything) and any
       unforeseen caller; raw = no type mults, no armor, exactly as
       before.                                                              */
    if (amount && typeof amount === 'object') {
      return this.damageTyped(amount, point, game, kind, dir);
    }
    this.showBar();

    // JACKAL frontal shield: blocks straight-on bullets while up
    if (this.shieldHp > 0 && this.stagger <= 0 && kind === 'bullet' && dir) {
      const fwd = new THREE.Vector3(Math.sin(this.group.rotation.y), 0, Math.cos(this.group.rotation.y));
      if (fwd.dot(dir) < -0.15) {
        this.shieldHp -= amount;
        if (this.shieldHp <= 0) this.shieldHp = 0;
        if (point) for (let i = 0; i < 3; i++) game.weapon.spawnSpark(point, 'energy');
        this.drawBar();
        game.sfx.shieldHit();
        return amount;
      }
    }

    /* CH-04.4 — DEF-DOWN (FREEZE RAY): each stack = +vuln % damage taken
       from ALL sources (5 stacks = +30 %). Applies to the hp hit only —
       the gauntlet block above is the shield's own business. */
    if (this._sapStacks > 0) {
      amount *= 1 + this._sapStacks * ASSETS.companions.drone.defDown.vulnPerStack;
    }
    this.hp -= amount;
    this.flinch = 0.12;
    this.drawBar();
    if (kind === 'melee' || kind === 'splash' || kind === 'missile') {
      this.stagger = Math.max(this.stagger, kind === 'melee' ? 1.2 : 2.0);
      this.showBar(2.5);
    }
    if (this.hp <= 0) this.die(game);
    return amount;
  }

  /* ========================================================================
     CH-25.1/25.3 — TYPED DAMAGE RESOLUTION (entered from weapon.js
     applyDamage() — the ONE shared entry point for guns, melee, specials,
     pets and drone weapons; crit is pre-multiplied into `types` there).

       GAUNTLET  — the frontal shield block is the only place a hit meets
         the shield pool (unchanged rule: kind 'bullet' + dir, facing).
         Each type's portion × its vs-shield mult drains the gauntlet;
         the TOXIN portion has shieldBypass — it skips the gauntlet and
         lands on health even on a frontal block (stated curve).
       HEALTH    — per type: value × vs-health mult × armor mitigation.
         Mitigation = ASSETS.combat.mitigation(armor, factor) with factor
         = typeMultipliers[type].armor — SLASH factor 0 sails through
         untouched; PUNCTURE 1.25 drills; the base curve is the unified
         armor→EHP coefficient (base × (1 + armor/300)).
       DEF-DOWN  — FREEZE RAY vulnerability stacks multiply the final hp
         total, AFTER armor — they keep working alongside armor, so the
         beam strips plating then every source bites deeper.
       STATUS    — CH-26 hooks the proc roll here (statusChance gate);
         the stub below is the single wiring point.                       */
  damageTyped(types, point, game, kind = 'bullet', dir = null) {
    this.showBar();
    const C = ASSETS.combat;
    const TM = C.typeMultipliers;

    /* --- 1. shield gauntlet (frontal bullets only — unchanged rule) --- */
    if (this.shieldHp > 0 && this.stagger <= 0 && kind === 'bullet' && dir) {
      const fwd = new THREE.Vector3(Math.sin(this.group.rotation.y), 0, Math.cos(this.group.rotation.y));
      if (fwd.dot(dir) < -0.15) {
        let toShield = 0, bypass = 0;
        for (const t in types) {
          const m = TM[t] || {};
          if (m.shieldBypass) bypass += types[t] * (m.health || 1) * C.mitigation(this.armor, m.armor, C.armor.base);
          else toShield += types[t] * (m.shield || 1);
        }
        this.shieldHp = Math.max(0, this.shieldHp - toShield);
        if (point) for (let i = 0; i < 3; i++) game.weapon.spawnSpark(point, 'energy');
        this.drawBar();
        game.sfx.shieldHit();
        /* toxin slipped past — apply its health portion, then the gauntlet
           still consumes the rest of the hit (same as the raw path).      */
        if (bypass > 0) this._hpHit(bypass, point, game, kind);
        return toShield + bypass;
      }
    }

    /* --- 2. health: per-type health mult × armor mitigation ----------- */
    let total = 0;
    for (const t in types) {
      const m = TM[t] || {};
      total += types[t] * (m.health || 1) * C.mitigation(this.armor, m.armor, C.armor.base);
    }
    return this._hpHit(total, point, game, kind);
  }

  /* shared tail of both paths — vulnerability, feedback, death */
  _hpHit(total, point, game, kind) {
    /* CH-04.4 — DEF-DOWN: stacks keep working alongside armor (CH-25.3) */
    if (this._sapStacks > 0) {
      total *= 1 + this._sapStacks * ASSETS.companions.drone.defDown.vulnPerStack;
    }
    /* CH-25.2 — STATUS GATE: the single hook where CH-26 rolls procs.
       One roll per damaging hit; statusChance rides the hit payload.     */
    this._statusGate(total, kind);
    this.hp -= total;
    this.flinch = 0.12;
    this.drawBar();
    if (kind === 'melee' || kind === 'splash' || kind === 'missile') {
      this.stagger = Math.max(this.stagger, kind === 'melee' ? 1.2 : 2.0);
      this.showBar(2.5);
    }
    if (this.hp <= 0) this.die(game);
    return total;
  }

  /* CH-25.2 — status proc roll STUB (no behavior yet by design). CH-26
     implements: one roll per damaging hit — if (Math.random() <
     this._statusChance) push a status stack — plus decay + HUD icons.
     Every damage source in the game now flows through this gate, so
     CH-26 lights up the whole arsenal without touching callers again.  */
  _statusGate(total, kind) {
    // CH-26: roll procs here (statusChance = this._statusChance)
  }

  /* ========================================================================
     CH-04.4 — FREEZE RAY defense-sap hooks (called by companions.js on the
     beam tick — every W.tick seconds while the siphon beam holds):

       SHIELDS FIRST  — while shieldHp > 0 the beam drains a flat
         sapShieldPct of MAX shields per tick, bypassing the frontal
         gauntlet (the siphon wraps it — kind 'freeze' never face-blocks).
       THEN ARMOR     — DEF-DOWN stacks build stackPerSec while beamed
         (cap maxStacks). Each stack = +vulnPerStack damage taken from ALL
         sources (see damage()); the beam's own hp tick chews the bare
         plating while stacks grow.
       DECAYING AFTER — holdTime grace once contact ends, then one stack
         decays per decayTime (updateSap runs from update()).
     ======================================================================== */
  applySap(W, game) {
    const DD = ASSETS.companions.drone.defDown;
    if (this.shieldHp > 0) {
      const drain = Math.max(1, Math.round(this.maxShieldHp * (W.sapShieldPct || 0.07)));
      this.shieldHp = Math.max(0, this.shieldHp - drain);
      game.weapon.spawnSpark(this.group.position, 'energy');
    }
    this._sapAcc += (DD.stackPerSec || 1) * (W.tick || 0.25);
    while (this._sapAcc >= 1 && this._sapStacks < DD.maxStacks) {
      this._sapStacks += 1;
      this._sapAcc -= 1;
      this._sapDecayT = DD.decayTime;
    }
    if (this._sapStacks >= DD.maxStacks) this._sapAcc = 0;
    this._sapT = DD.holdTime;                    // refresh the contact grace
    this.drawBar();
    this.showBar(2.2);
  }

  updateSap(dt) {
    const DD = ASSETS.companions.drone.defDown;
    if (!this._sapStacks) return;
    if (this._sapT > 0) { this._sapT -= dt; return; }
    this._sapDecayT -= dt;
    while (this._sapDecayT <= 0 && this._sapStacks > 0) {
      this._sapStacks -= 1;
      this._sapDecayT += DD.decayTime;
    }
    if (this._sapStacks <= 0) { this._sapStacks = 0; this._sapAcc = 0; this._sapDecayT = 0; }
    this.drawBar();
  }

  die(game) {
    this.alive = false;
    this.deathT = 0;
    this.fallDir = Math.random() < 0.5 ? 1 : -1;
    game.weapon.stats.kills++;
    // credit bounty — scaled by the drop-rate curve for this level
    const bounty = Math.round((ASSETS.credits.perKill[this.typeKey] || 800) * dropRateMult(this.level) / 10) * 10;
    Mods.add(bounty);
    /* BLOOD FOR SHIELD — companion kills refill the player's shields */
    if (this._hitBy === 'companion') {
      this._hitBy = null;
      const bonus = ASSETS.companions.bloodShield || 0;
      const pl = game.player;
      if (bonus > 0 && !pl.dead) {
        const cap = ASSETS.player.shield + (pl.overshieldT > 0 ? pl.overshield : 0);
        const before = pl.shield;
        pl.shield = Math.min(cap, pl.shield + bonus);
        if (pl.shield > before) {
          game.hud.pickup('+' + Math.round(pl.shield - before) + ' SHIELD · BLOOD FOR SHIELD');
          game.sfx.shieldHit();
        }
      }
    }
    // every hostile rebuilds on the 5-minute respawn timer
    // (reinforcement-wave spawns + the kaiju never queue a rebuild)
    if (game.queueRespawn && !this.spawnDef.noRespawn) game.queueRespawn(this.spawnDef);
    const pan = panFor(game, this.group.position);
    if (this.arch.kaiju) {
      game.sfx.tone({ type: 'sawtooth', f0: 220, f1: 40, dur: 1.4, gain: 0.4, pan });
      game.hud.toast('KAIJU DOWN — SALVAGE THE CARCASS', 2600);
      if (game.specials) game.specials.kaijuRewards(this.group.position.clone());
    } else if (this.arch.elite) {
      game.sfx.tone({ type: 'sawtooth', f0: 340, f1: 70, dur: 0.6, gain: 0.24, pan });
      game.hud.toast('ELITE DOWN — POWER CORE DROPPED');
    } else {
      game.sfx.tone({ type: 'square', f0: 640, f1: 180, dur: 0.28, gain: 0.16, pan });
    }
    game.sfx.boltImpact(pan);
    this.hitMesh.userData.enemy = null; // stop absorbing bullets
    this.bar.visible = false;
    // drop chart (level-scaled)
    if (game.specials && !this.arch.kaiju) {
      game.specials.rollDrops(this.group.position.clone(), this.arch, this.level);
    }
  }

  updateDeath(dt) {
    this.deathT += dt;
    const t = this.deathT;
    if (this.fly) {
      // drop out of the sky
      const fall = Math.min(1, t / 0.5);
      this.group.position.y = Math.max(0.25, this.flyY * (1 - fall) + 0.25 * fall);
      this.group.rotation.z += dt * 9;
    } else {
      const fall = Math.min(1, t / 0.4);
      const bounce = fall < 1 ? Math.sin(fall * Math.PI) * 0.15 : 0;
      this.group.rotation.z = this.fallDir * (fall * (Math.PI / 2) + bounce);
      this.group.position.y = Math.max(this.catwalkY || 0, (this.catwalkY || 0) + 0.12 * (1 - fall));
    }
    if (t > 0.9) {
      const o = Math.max(0, 1 - (t - 0.9) / 0.9);
      for (const m of this.mats) { m.transparent = true; m.opacity = o; }
      this.blob.material.opacity = 0.8 * o;
    }
    if (t > 1.9) {
      this.scene.remove(this.group);
      this.scene.remove(this.blob);
      this.gone = true;
    }
  }
}

/* ------------------------------------------------------------------ */
export function updateBolts(dt, game) {
  const p = game.player;
  for (let i = bolts.length - 1; i >= 0; i--) {
    const b = bolts[i];
    b.life -= dt;
    b.mesh.position.addScaledVector(b.vel, dt);
    const pos = b.mesh.position;
    let hit = false;

    // world (y-aware ceiling + floor)
    if (b.life <= 0 || pos.y < 0.03 || pos.y > game.world.ceilHeightAt(pos.z) - 0.1) hit = true;
    if (!hit) {
      for (const c of game.world.colliders) {
        if (c.y0 !== undefined) {
          if (pos.y >= c.y1 || pos.y <= c.y0) continue;
        } else if (pos.y > 2.9) continue;
        if (pos.x > c.minX - 0.05 && pos.x < c.maxX + 0.05 &&
            pos.z > c.minZ - 0.05 && pos.z < c.maxZ + 0.05) { hit = true; break; }
      }
    }
    // player (torso sphere)
    if (!hit && !p.dead) {
      const dx = pos.x - p.pos.x, dy = pos.y - (p.pos.y - 0.35), dz = pos.z - p.pos.z;
      if (dx * dx + dy * dy + dz * dz < 0.45 * 0.45) {
        p.damage(b.dmg || E.archetypes.grunt.boltDamage, game);
        hit = true;
      }
    }
    // companions eat stray plasma too (drone ~0.55 m sphere, beast ground box)
    if (!hit && game.companions) {
      const cp = game.companions;
      if (cp.drone && cp.drone.deadT < 0 &&
          pos.distanceTo(cp.drone.pos) < 0.55) {
        cp.damageDrone(b.dmg || 8, game);
        hit = true;
      } else if (cp.pet && cp.pet.deadT < 0) {
        const pp = cp.pet.group.position;
        const dx = pos.x - pp.x, dz = pos.z - pp.z;
        if (pos.y < 1.3 && dx * dx + dz * dz < 0.75 * 0.75) {
          cp.damagePet(b.dmg || 8, game);
          hit = true;
        }
      }
    }

    if (hit) {
      game.sfx.boltImpact(panFor(game, pos));
      for (let k = 0; k < 3; k++) game.weapon.spawnSpark(pos, true);
      game.scene.remove(b.mesh);
      bolts.splice(i, 1);
    }
  }
}

export function clearBolts(game) {
  for (const b of bolts) game.scene.remove(b.mesh);
  bolts.length = 0;
}

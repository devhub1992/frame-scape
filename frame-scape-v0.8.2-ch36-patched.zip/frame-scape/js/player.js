/* ============================================================================
   AUTUMN CORRIDOR — player.js  (v0.6.0)
   ----------------------------------------------------------------------------
   First-person controller: Halo-style movement + recharging shield, now with
   the full mobility/ability kit:
     · energy pool (fuels hover, glide, VATS, dash, specials)
     · DOUBLE JUMP: A on the ground jumps · pressing A again mid-air jumps
       once more — FREE, but its height scales with the JETPACK frame mod
       (rank 0 = 5 % of a normal jump → rank 10 = 200 %)
     · hover: HOLD A mid-air (drains energy) · release = lunge forward
     · glide module: stay airborne without holding A (R2 special, toggle)
     · VATS-style mid-air targeting: L1/C/Ctrl while AIRBORNE slows time
     · blink dash impulse (specials.js calls player.dash())
     · y-aware ground (catwalk deck + ramp via world.floorZones)
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js';

const A = ASSETS.player;
const CR = ASSETS.crouch;
const SL = ASSETS.slide;
const JK = ASSETS.jetpack;
const EN = ASSETS.energy;
const VATS = ASSETS.vats;
const DASH = ASSETS.dash;
const GLIDE = ASSETS.glide;

export class Player {
  constructor(camera) {
    this.camera = camera;
    camera.rotation.order = 'YXZ';
    this.spawn = new THREE.Vector3(0, A.eyeHeight, -1.6);
    this.reset();
  }

  reset() {
    this.pos = this.spawn.clone();
    this.vel = new THREE.Vector3();
    this.yaw = 0; this.pitch = 0;
    this.recoil = 0; this.recoilYaw = 0;
    this.recoilRecover = 10;
    this.onGround = true;
    this.shield = A.shield;
    this.health = A.health;
    this.lastDamage = -99;
    this.regening = false;
    this.wasLow = false;
    this.bobT = 0; this.bobY = 0;
    this.landDip = 0;
    this.dead = false;
    this.stepPhase = 0;
    // mobility states
    this.crouched = false;
    this.eyeCur = A.eyeHeight;
    this.slideT = -1;
    this.slideDir = new THREE.Vector3();
    this.slideCd = 0;
    this.roll = 0;
    // energy + flight
    this.energy = EN.max;
    this.lastEnergyUse = -99;
    this.hovering = false;
    this._hoverPrev = false;
    this.glideOn = false;
    this.dashT = -1;
    this.airJumps = 0;          // free mid-air jumps left (1 = double jump)
    // VATS
    this.vatsActive = false;
    // v0.8 — cloak · overshield · knockdown
    this.invisT = 0;
    this.overshield = 0;
    this.overshieldT = 0;
    this.knockT = -1;
  }

  /* -- energy ---------------------------------------------------------------- */
  spend(n) {
    if (this.energy < n) return false;
    this.energy -= n;
    this.lastEnergyUse = this._time || 0;
    return true;
  }
  canPay(n) { return this.energy >= n; }

  /* -- look (zoom sensitivity applied via game.zoomSens) --------------------- */
  look(input, dt) {
    const d = input.consumeLook();
    const s = this._zoomSens || 1;
    this.yaw -= d.dx * s;
    this.pitch -= d.dy * s;
    const lim = Math.PI / 2 - 0.02;
    this.pitch = Math.max(-lim, Math.min(lim, this.pitch));
    const rec = Math.exp(-this.recoilRecover * dt);
    this.recoil *= rec;
    this.recoilYaw *= rec;
  }

  /* -- VATS (mid-air only) ----------------------------------------------------- */
  tryVats(game) {
    if (this.vatsActive) { this.exitVats(game); return; }
    if (!this.canPay(VATS.enterEnergy)) { game.sfx.energyFail(); return; }
    this.spend(VATS.enterEnergy);
    this.vatsActive = true;
    game.setVats(true);
  }
  exitVats(game) {
    if (!this.vatsActive) return;
    this.vatsActive = false;
    game.setVats(false);
  }

  /* -- dash (called by specials) ------------------------------------------------ */
  dash(game, dirX, dirZ) {
    const l = Math.hypot(dirX, dirZ) || 1;
    this.vel.x = (dirX / l) * DASH.impulse;
    this.vel.z = (dirZ / l) * DASH.impulse;
    this.vel.y += DASH.up;
    this.dashT = DASH.duration;
    this.onGround = false;
    game.sfx.dash();
  }

  /* -- knockdown (elite effects · kaiju slam) ----------------------------------
     STEADY FEET frame mod resists: R1 = 10 % → R10 = 100 % (never fall).    */
  knockdown(game, dur = null) {
    if (this.dead || this.knockT >= 0) return;
    const KD = ASSETS.knockdown;
    const resist = Math.max(0, Math.min(100, ASSETS.player.knockResist || 0));
    if (Math.random() * 100 < resist) {
      game.hud.toast('STEADY FEET — KEPT YOUR FOOTING', 900);
      this.recoil += 0.05;
      return;
    }
    this.knockT = dur || KD.time;
    this.exitVats(game);
    this.crouched = false;
    game.sfx.land();
    game.hud.hitFlash(0.7);
  }

  /* -- movement + collision -------------------------------------------------- */
  move(input, dt, world, game) {
    // wish direction (camera relative, horizontal)
    const m = input.move || { x: 0, z: 0 };
    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    const fx = -sin, fz = -cos;
    const rx = cos,  rz = -sin;
    let wx = fx * -m.z + rx * m.x;
    let wz = fz * -m.z + rz * m.x;
    const wl = Math.hypot(wx, wz);
    if (wl > 1) { wx /= wl; wz /= wl; }

    // KNOCKED DOWN: no steering, no jumps, low eye, hard roll
    if (this.knockT >= 0) {
      this.knockT -= dt;
      this.vel.x *= Math.exp(-6 * dt);
      this.vel.z *= Math.exp(-6 * dt);
      const KD = ASSETS.knockdown;
      this.eyeCur += (KD.eye - this.eyeCur) * Math.min(1, dt * 9);
      this.roll += (KD.roll - this.roll) * Math.min(1, dt * 8);
      this.pos.x += this.vel.x * dt;
      this.resolve('x', world);
      this.pos.z += this.vel.z * dt;
      this.resolve('z', world);
      this.pos.y += this.vel.y * dt;
      const ghk = world.floorHeightAt(this.pos.x, this.pos.z, this.pos.y);
      if (this.pos.y <= ghk + KD.eye) { this.pos.y = ghk + KD.eye; this.vel.y = 0; }
      else this.vel.y -= A.gravity * dt;
      if (this.knockT < 0) { this.regening = this.regening; } // rise handled in update()
      return;
    }

    // toggles
    this.slideCd -= dt;
    if (input.pressed('duck')) {
      if (this.onGround) {
        this.crouched = !this.crouched;
        if (!this.crouched) this.slideT = -1;
      } else if (!this.dead) {
        this.tryVats(game);          // VATS: airborne target selection
      }
    }
    if (input.pressed('jump') && !this.dead) {
      if (this.onGround) {
        if (this.crouched) this.trySlide(game);
        else {
          this.vel.y = A.jumpVel;
          this.onGround = false;
          this.airJumps = 1;         // one free mid-air jump per airtime
        }
      } else if (this.airJumps > 0) {
        // JETPACK frame mod: mid-air jump height = bonus % of a ground jump
        this.airJumps--;
        const baseH = (A.jumpVel * A.jumpVel) / (2 * A.gravity);
        const h = baseH * Math.max(0.02, A.airJumpBonus / 100);
        this.vel.y = Math.sqrt(2 * A.gravity * h);
        game.sfx.jet();
        game.weapon.puffAt(this.pos);
      }
    }

    // hover: HOLD A in air, or glide module while airborne
    const wantHover = !this.onGround && this.energy > 0 &&
      (input.down('jump') || (this.glideOn && this.dashT < 0));
    this.hovering = wantHover;
    if (this._hoverPrev && !this.hovering) {
      // released hover → lunge forward (jump-pack landing thrust)
      const sp = Math.hypot(this.vel.x, this.vel.z);
      if (sp > JK.minSpeed) {
        const k = JK.lungeImpulse / sp;
        this.vel.x += this.vel.x * k * 0.5;
        this.vel.z += this.vel.z * k * 0.5;
        this.vel.y += JK.lungeUp;
        game.sfx.dash();
      }
    }
    this._hoverPrev = this.hovering;
    if (this.hovering && !this.onGround) {
      const drain = (this.glideOn && !input.down('jump')) ? GLIDE.drain : JK.hoverDrain;
      this.energy = Math.max(0, this.energy - drain * dt);
      this.lastEnergyUse = game.time;
    }

    // target eye height (crouch / slide dip / normal)
    let eyeTarget = this.crouched ? CR.eye : A.eyeHeight;
    if (this.slideT >= 0) eyeTarget = SL.eye;

    let speed = A.walkSpeed * (this.crouched ? CR.speedMult : 1);
    const adsMove = game.weapon.adsMove();
    if (adsMove < 1) speed *= adsMove;

    if (this.dashT >= 0) {
      // DASH: keep the impulse, light drag
      this.dashT -= dt;
      this.vel.x *= Math.exp(-2.2 * dt);
      this.vel.z *= Math.exp(-2.2 * dt);
      if (this.dashT < 0) { this.vel.x *= 0.55; this.vel.z *= 0.55; }
    } else if (this.slideT >= 0) {
      // SLIDE: scripted velocity burst, gentle decay, light steering
      this.slideT += dt;
      const k = 1 - this.slideT / SL.duration;
      const v = SL.speed * Math.max(0.15, k * k);
      this.vel.x = this.slideDir.x * v + wx * 1.2;
      this.vel.z = this.slideDir.z * v + wz * 1.2;
      if (this.slideT >= SL.duration) {
        this.slideT = -1;
        this.vel.x *= 0.7; this.vel.z *= 0.7;
      }
    } else {
      const k = Math.min(1, A.accel * dt);
      this.vel.x += (wx * speed - this.vel.x) * k;
      this.vel.z += (wz * speed - this.vel.z) * k;
    }

    // gravity vs hover thrust
    if (this.hovering && !this.onGround) {
      this.vel.y += (JK.hoverVy - this.vel.y) * Math.min(1, dt * 5);
    } else {
      this.vel.y -= A.gravity * dt;
    }

    // integrate + resolve per axis
    this.pos.x += this.vel.x * dt;
    this.resolve('x', world);
    this.pos.z += this.vel.z * dt;
    this.resolve('z', world);
    this.pos.y += this.vel.y * dt;

    // ground = highest floor zone at/below us (corridor floor, ramp, deck)
    const gh = world.floorHeightAt(this.pos.x, this.pos.z, this.pos.y);
    const targetY = gh + eyeTarget;
    if (this.pos.y <= targetY) {
      if (!this.onGround && this.vel.y < -3) {
        this.landDip = Math.min(0.12, -this.vel.y * 0.02);
        game.sfx.land();
      }
      this.pos.y = targetY;
      this.vel.y = 0;
      this.onGround = true;
      this.airJumps = 0;
      if (this.vatsActive) this.exitVats(game);   // landing cancels VATS
    } else {
      this.onGround = false;
    }

    // smooth eye height toward target (crouch/stand transition)
    this.eyeCur += (eyeTarget - this.eyeCur) * Math.min(1, dt * 12);

    // slide roll + whoosh
    const targetRoll = this.slideT >= 0 ? 0.055 * (this.slideDir.x * rx + this.slideDir.z * rz > 0 ? 1 : -1) : 0;
    this.roll += (targetRoll - this.roll) * Math.min(1, dt * 8);

    // head bob + footsteps
    const sp2 = Math.hypot(this.vel.x, this.vel.z);
    if (this.onGround && sp2 > 0.6 && this.slideT < 0) {
      const prev = Math.sin(this.bobT);
      this.bobT += dt * A.bobFreq * (sp2 / A.walkSpeed);
      this.bobY = Math.sin(this.bobT) * A.bobAmp * (sp2 / A.walkSpeed);
      if (prev > 0 && Math.sin(this.bobT) <= 0) game.sfx.step();
    } else {
      this.bobY *= Math.exp(-8 * dt);
    }
    this.landDip *= Math.exp(-6 * dt);
  }

  trySlide(game) {
    const sp = Math.hypot(this.vel.x, this.vel.z);
    if (this.slideCd > 0 || sp < SL.minSpeed) return;
    this.slideT = 0;
    this.slideCd = SL.cooldown;
    this.slideDir.set(this.vel.x, 0, this.vel.z).normalize();
    game.sfx.slide();
  }

  isSliding() { return this.slideT >= 0; }

  resolve(axis, world) {
    const r = A.radius;
    const feet = this.pos.y - this.eyeCur;
    for (const c of world.colliders) {
      // y-aware: skip colliders we're above or below
      if (c.y1 !== undefined) {
        if (feet + 1.5 <= c.y0 || feet + 0.25 >= c.y1) continue;
      }
      if (this.pos.z + r <= c.minZ || this.pos.z - r >= c.maxZ) continue;
      if (this.pos.x + r <= c.minX || this.pos.x - r >= c.maxX) continue;
      if (axis === 'x') {
        const v = this.vel.x;
        if (v > 0) this.pos.x = c.minX - r;
        else if (v < 0) this.pos.x = c.maxX + r;
        else this.pos.x = this.pos.x > (c.minX + c.maxX) / 2 ? c.maxX + r : c.minX - r;
        this.vel.x = 0;
      } else {
        const v = this.vel.z;
        if (v > 0) this.pos.z = c.maxZ + r;
        else if (v < 0) this.pos.z = c.minZ - r;
        else this.pos.z = this.pos.z > (c.minZ + c.maxZ) / 2 ? c.maxZ + r : c.minZ - r;
        this.vel.z = 0;
      }
    }
  }

  /* -- shield / health --------------------------------------------------------- */
  damage(amount, game) {
    if (this.dead || ASSETS.debug.godMode) return;
    const t = game.time;
    this.lastDamage = t;
    this.regening = false;
    game.sfx.regenStop();

    /* OVERSHIELD eats damage first (temporary layer above max shields) */
    if (this.overshieldT > 0 && this.overshield > 0) {
      const os = Math.min(this.overshield, amount);
      this.overshield -= os;
      amount -= os;
      if (amount <= 0.01) {
        game.sfx.shieldHit();
        game.hud.hitFlash(0.3);
        return;
      }
    }

    if (this.shield > 0) {
      this.shield -= amount;
      if (this.shield <= 0) {
        const overflow = -this.shield;
        this.shield = 0;
        this.health -= overflow * 0.5;
        game.sfx.shieldBreak();
        game.hud.flashWhite();
      } else {
        game.sfx.shieldHit();
      }
    } else {
      this.health -= amount;
      game.sfx.hurt();
    }
    game.hud.hitFlash(this.shield <= 0 ? 0.85 : 0.45);

    const lowFrac = (this.shield + this.health) / (A.shield + A.health);
    if (lowFrac < 0.3 && !this.wasLow) { this.wasLow = true; game.sfx.lowShield(); game.hud.toast('SHIELDS LOW'); }
    if (lowFrac >= 0.5) this.wasLow = false;

    if (this.health <= 0) {
      this.health = 0;
      this.dead = true;
      this.exitVats(game);
      game.onPlayerDeath();
    }
  }

  update(dt, input, world, game) {
    this._time = game.time;
    this.look(input, dt);
    this.move(input, dt, world, game);

    // CLOAK timer (firing decloaks — weapon.js clears it)
    if (this.invisT > 0) this.invisT -= dt;

    // OVERSHIELD timer
    if (this.overshieldT > 0) {
      this.overshieldT -= dt;
      if (this.overshieldT <= 0) this.overshield = 0;
    }

    // VATS energy drain (real time — the whole point is it costs you)
    if (this.vatsActive) {
      this.energy = Math.max(0, this.energy - VATS.drain * dt);
      this.lastEnergyUse = game.time;
      if (this.energy <= 0) this.exitVats(game);
    }

    // energy regen after delay
    if (game.time - this.lastEnergyUse > EN.delay && this.energy < EN.max) {
      this.energy = Math.min(EN.max, this.energy + EN.regen * dt);
    }

    // shield regen after delay
    const t = game.time;
    if (!this.dead && t - this.lastDamage > A.shieldDelay &&
        this.shield < A.shield) {
      this.shield = Math.min(A.shield, this.shield + A.shieldRegen * dt);
      if (!this.regening) { this.regening = true; game.sfx.regenStart(); }
    } else if (this.regening && (this.shield >= A.shield || t - this.lastDamage <= A.shieldDelay)) {
      this.regening = false;
      game.sfx.regenStop();
    }

    // camera: eye height + bob + roll
    const camY = this.eyeCur + this.bobY - this.landDip;
    this.camera.position.set(this.pos.x, camY, this.pos.z);
    this.camera.rotation.set(this.pitch + this.recoil, this.yaw + this.recoilYaw, this.roll);

    // FOV: ADS (weapon) + slide kick + dash kick, smoothed
    const base = ASSETS.quality.fov;
    let target = game.targetFov || base;
    if (this.isSliding()) target += SL.fovKick;
    if (this.dashT >= 0) target += 6;
    if (this.vatsActive) target -= 6;
    if (this.invisT > 0) target += 4;   // subtle cloaked wide-eye feel
    if (Math.abs(this.camera.fov - target) > 0.05) {
      this.camera.fov += (target - this.camera.fov) * Math.min(1, dt * 10);
      this.camera.updateProjectionMatrix();
    }
  }

  /* forward vector (for melee / grenade throw / enemy checks) */
  forward() {
    return new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
  }
}

/* ============================================================================
   FRAME SCAPE — specials.js  (v0.8.0)
   ----------------------------------------------------------------------------
   The R2 "equipped special" system — FOUR SLOTS + the full item pool:
     FRAG GRENADE · HOMING MISSILES · BLINK DASH · GLIDE MODULE
     PLASMA BOLT · SHOCKWAVE · FIRE NOVA · CLOAK (5s / 25e) · OVERSHIELD

   Also lives here:
     · splash damage helper (rockets / bolts / missiles)
     · homing missile steering (R2 item, VATS execute, drone pod)
     · fire nova burning fields — and HOSTILE versions (elite casters:
       their novas, grenades and homing missiles KNOCK YOU DOWN unless
       STEADY FEET resists)
     · the DROP SYSTEM: level-scaled chart rolls (dropRateMult: L40 = 1×,
       L60 = 2×, L80 = 4× cap) + PREBUILT MOD chips (enemies / crates /
       elites) + MATERIAL pickups from the ecology + KAIJU reward table
       (mod copies + weapon copies). CH-02: chip/copy picks roll the
       weighted drops.itemPool — one pickWeightedKey() for every roll,
       console-verified via AC.game.drops.sim(10000).

   All stats in assets.js → specials{} / drops{} / frag{} / nova{} / etc.
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js';
import { Mods, dropRateMult } from './mods.js';
import { texGlow, texPuff } from './textures.js';
/* CH-25.4 — the ONE shared damage entry point (lives in weapon.js) */
import { applyDamage, typedHit, rollCrit, scaleTypes } from './weapon.js';

const SP = ASSETS.specials;
const FRAG = ASSETS.frag;
const P = ASSETS.palette;
const rand = (a, b) => a + Math.random() * (b - a);
const randi = (arr) => Math.round(arr[0] + Math.random() * (arr[1] - arr[0]));

/* CH-02.2 — THE one weighted roll every mod-chip / weapon-copy pick goes
   through. NORMALISES over the given weights, so drops.itemPool does not
   have to sum to 100. Non-positive / missing weights never roll. Returns
   the winning key, or null when every weight is 0 (caller falls back). */
function pickWeightedKey(weights, rng = Math.random) {
  let total = 0;
  for (const k in weights) { const w = +weights[k]; if (w > 0) total += w; }
  if (total <= 0) return null;
  let roll = rng() * total, last = null;
  for (const k in weights) {
    const w = +weights[k];
    if (w <= 0) continue;
    roll -= w;
    if (roll <= 0) return k;
    last = k;
  }
  return last;   // float-rounding guard — never off the end of the table
}

/* ------------------------------------------------------------------ */
export class Specials {
  constructor(camera, scene) {
    this.camera = camera;
    this.scene = scene;
    this.slots = SP.defaultSlots.slice();   // 4 special-item ids
    this.slotIdx = 0;                       // ACTIVE slot (R2 fires it)
    this.cd = {};                           // id → seconds left
    for (const s of SP.list) this.cd[s.id] = 0;
    this.grenades = FRAG.start;
    this.grenadeCd = 0;
    this.live = [];                         // projectiles + grenades
    this.novas = [];                        // burning fields
    this.pickups = [];
    this.buildResources();
  }

  get equipped() { return this.slots[this.slotIdx]; }

  cycleSlot(dir = 1) {
    this.slotIdx = (this.slotIdx + dir + this.slots.length) % this.slots.length;
  }
  assignSlot(slotIdx, id) {
    if (slotIdx >= 0 && slotIdx < this.slots.length) this.slots[slotIdx] = id;
  }

  /* -- meshes / pools --------------------------------------------------- */
  buildResources() {
    this.gGeo = new THREE.SphereGeometry(0.09, 8, 6);
    this.gGeo.scale(1, 1.15, 1);
    this.gMat = new THREE.MeshLambertMaterial({ color: '#3d4430' });

    this.rGeo = new THREE.CylinderGeometry(0.05, 0.05, 0.34, 6);
    this.rMat = new THREE.MeshLambertMaterial({ color: '#8a9098' });
    this.rTipMat = new THREE.MeshBasicMaterial({ color: '#e05a3a' });

    this.bGeo = new THREE.SphereGeometry(0.12, 8, 6);
    this.bMat = new THREE.MeshBasicMaterial({ color: '#59f2ff' });
    this.bGlowMat = new THREE.SpriteMaterial({
      map: texGlow('#59f2ff'), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    });

    this.fireMat = new THREE.SpriteMaterial({
      map: texGlow(P.fire), blending: THREE.AdditiveBlending,
      transparent: true, opacity: 0.9, depthWrite: false,
    });
    this.ringGeo = new THREE.TorusGeometry(1, 0.045, 6, 28);
    this.rings = [];
    for (let i = 0; i < 4; i++) {
      const m = new THREE.Mesh(this.ringGeo, new THREE.MeshBasicMaterial({
        color: '#59f2ff', transparent: true, opacity: 0,
        blending: THREE.AdditiveBlending, depthWrite: false,
      }));
      m.rotation.x = -Math.PI / 2;
      m.visible = false;
      this.scene.add(m);
      this.rings.push({ m, t: 0, r: 1 });
    }
  }

  spawnRing(pos, r, color) {
    const ring = this.rings.find((x) => x.t <= 0) || this.rings[0];
    ring.m.material.color.set(color);
    ring.m.position.copy(pos);
    ring.m.position.y += 0.25;
    ring.r = r;
    ring.t = 1;
    ring.m.visible = true;
  }

  /* ======================================================================
     R2 dispatch — fires the ACTIVE slot
     ====================================================================== */
  use(game) {
    const id = this.slots[this.slotIdx];
    const def = SP.list.find((s) => s.id === id);
    if (!def) return;
    if (this.cd[id] > 0) return;
    const pl = game.player;
    if (pl.dead) return;

    switch (id) {
      case 'grenade': this.throwGrenade(game); break;
      case 'missiles': this.useMissiles(game, def); break;
      case 'dash': this.useDash(game, def); break;
      case 'glide': this.useGlide(game, def); break;
      case 'pbolt': this.usePBolt(game, def); break;
      case 'shock': this.useShock(game, def); break;
      case 'firenova': this.useFireNova(game, def); break;
      case 'invis': this.useInvis(game, def); break;
      case 'overshield': this.useOvershield(game, def); break;
    }
  }

  pay(game, def) {
    if (def.energy > 0 && !game.player.spend(def.energy)) {
      game.sfx.energyFail();
      game.hud.toast('NOT ENOUGH ENERGY', 900);
      return false;
    }
    this.cd[def.id] = def.cd;
    return true;
  }

  /* -- frag grenade ------------------------------------------------------- */
  throwGrenade(game) {
    if (this.grenadeCd > 0) return;
    if (this.grenades <= 0) { game.hud.toast('OUT OF GRENADES'); this.grenadeCd = 0.5; return; }
    if (!this.pay(game, { id: 'grenade', energy: 0, cd: FRAG.cooldown })) return;
    this.grenades--;
    game.sfx.throwPin();

    const mesh = new THREE.Mesh(this.gGeo, this.gMat);
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    mesh.position.copy(this.camera.getWorldPosition(new THREE.Vector3()))
      .addScaledVector(dir, 0.4);
    mesh.position.y -= 0.08;
    const vel = dir.clone().multiplyScalar(FRAG.throwVel);
    vel.y += FRAG.upVel;
    vel.x += game.player.vel.x * 0.5;
    vel.z += game.player.vel.z * 0.5;
    game.scene.add(mesh);
    /* CH-25.4 — typed frag: profile + crit/status read from ASSETS.frag,
       crit rolled once per blast (carried to the boom).                   */
    this.live.push({ type: 'grenade', mesh, vel, fuse: FRAG.fuse, spin: rand(4, 9),
      hit: { types: typedHit(FRAG), crit: rollCrit(FRAG), statusChance: FRAG.statusChance || 0 } });
  }

  /* -- homing missiles ------------------------------------------------------ */
  visibleTargets(game, cone = 0.5, range = 45, max = 2) {
    const fwd = new THREE.Vector3();
    this.camera.getWorldDirection(fwd);
    const out = [];
    for (const e of game.enemies) {
      if (!e.alive) continue;
      const to = new THREE.Vector3().subVectors(e.group.position, this.camera.getWorldPosition(new THREE.Vector3()));
      const d = to.length();
      if (d > range) continue;
      to.normalize();
      if (to.dot(fwd) < cone) continue;
      out.push({ e, d });
    }
    out.sort((a, b) => a.d - b.d);
    return out.slice(0, max).map((x) => x.e);
  }

  useMissiles(game, def) {
    if (!this.pay(game, def)) return;
    const targets = this.visibleTargets(game);
    const n = Math.min(2, Math.max(1, targets.length));
    game.sfx.missile();
    /* CH-25.4 — typed missiles: profile from the special def, crit
       rolled PER MISSILE (each one is its own hit).                     */
    for (let i = 0; i < n; i++) {
      /* CH-25.5 — scalar reads def.damage (now ON the def; the old
         hard-coded 90 was invisible to typedHit → all-zero payloads).  */
      this.launchMissile(game, targets[i] || null, i === 0 ? -0.3 : 0.3, def.damage, {
        hit: { types: typedHit(def), crit: rollCrit(def), statusChance: def.statusChance || 0 },
      });
    }
  }

  launchMissile(game, target, sideOffset, dmg, opts = {}) {
    const mesh = new THREE.Group();
    const body = new THREE.Mesh(this.rGeo, this.rMat);
    body.rotation.x = Math.PI / 2;
    mesh.add(body);
    const tip = new THREE.Mesh(this.rGeo, this.rTipMat);
    tip.scale.set(0.7, 0.25, 0.7);
    tip.rotation.x = Math.PI / 2;
    tip.position.z = -0.14;
    mesh.add(tip);
    const glow = new THREE.Sprite(this.bGlowMat);
    glow.material = new THREE.SpriteMaterial({
      map: texGlow('#ffb45e'), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    });
    glow.scale.setScalar(0.4);
    glow.position.z = 0.2;
    mesh.add(glow);

    const origin = this.camera.getWorldPosition(new THREE.Vector3());
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    const right = new THREE.Vector3().crossVectors(dir, this.camera.up).normalize();
    mesh.position.copy(origin).addScaledVector(right, sideOffset).addScaledVector(dir, 0.5);
    mesh.position.y -= 0.15;
    game.scene.add(mesh);

    const vel = dir.clone().multiplyScalar(10);
    vel.y += 2.2;
    this.live.push({
      type: 'missile', mesh, vel, life: 4, dmg,
      target, speed: 17, trail: 0,
      execute: !!opts.execute, fromPlayer: true,
      hit: opts.hit || null,          // CH-25.4 — typed payload to the boom
    });
  }

  /* -- blink dash ------------------------------------------------------------- */
  useDash(game, def) {
    if (!this.pay(game, def)) return;
    const m = game.input.move || { x: 0, z: 0 };
    let dx, dz;
    if (Math.abs(m.x) + Math.abs(m.z) > 0.1) {
      const sin = Math.sin(game.player.yaw), cos = Math.cos(game.player.yaw);
      dx = cos * m.x + -sin * -m.z;
      dz = -sin * m.x + -cos * -m.z;
    } else {
      const f = game.player.forward();
      dx = f.x; dz = f.z;
    }
    game.player.dash(game, dx, dz);
  }

  /* -- glide toggle --------------------------------------------------------------- */
  useGlide(game, def) {
    if (!game.player.glideOn && !game.player.canPay(10)) {
      game.sfx.energyFail();
      return;
    }
    game.player.glideOn = !game.player.glideOn;
    game.hud.toast(game.player.glideOn ? 'GLIDE MODULE ON' : 'GLIDE MODULE OFF', 900);
    game.sfx.navBig();
    this.cd[def.id] = def.cd;
  }

  /* -- plasma bolt ------------------------------------------------------------------ */
  usePBolt(game, def) {
    if (!this.pay(game, def)) return;
    const mesh = new THREE.Mesh(this.bGeo, this.bMat);
    const glow = new THREE.Sprite(this.bGlowMat);
    glow.scale.setScalar(0.9);
    mesh.add(glow);
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    mesh.position.copy(this.camera.getWorldPosition(new THREE.Vector3()))
      .addScaledVector(dir, 0.6);
    game.scene.add(mesh);
    game.sfx.plasmaShot(0);
    /* CH-25.5 — direct + splash scalar reads def.damage (now ON the
       def; the hard-coded 60 was invisible to typedHit → all-zero
       detonation).                                                       */
    const PD = def.damage;
    this.live.push({
      type: 'pbolt', mesh, vel: dir.clone().multiplyScalar(18),
      life: 3, dmg: PD, splash: { radius: 3.5, dmg: PD, selfMult: 0.5, stagger: 1.2 },
      /* CH-25.4 — typed plasma detonation from the special def */
      hit: { types: typedHit(def), crit: rollCrit(def), statusChance: def.statusChance || 0 },
    });
  }

  /* -- shockwave ---------------------------------------------------------------------- */
  useShock(game, def) {
    if (!this.pay(game, def)) return;
    game.sfx.shock();
    this.spawnRing(game.player.pos, 6, '#9fd4ee');
    game.player.recoil += 0.03;
    for (const e of game.enemies) {
      if (!e.alive) continue;
      const to = new THREE.Vector3().subVectors(e.group.position, game.player.pos);
      to.y = 0;
      const d = to.length();
      if (d < 6) {
        /* CH-25.4 — typed pulse (electric-flavored, def fractions × 20) */
        applyDamage(e, {
          types: typedHit(def, 20),
          crit: rollCrit(def),
          statusChance: def.statusChance || 0,
        }, game, { point: e.group.position, kind: 'splash' });
        e.stagger = Math.max(e.stagger, 2.2);
        e.showBar(2.5);
        if (d > 0.3 && !e.fly) {
          const push = to.normalize().multiplyScalar(1.8);
          e.group.position.add(push);
        }
      }
    }
  }

  /* -- cloak (invisibility) --------------------------------------------------- */
  useInvis(game, def) {
    const IV = ASSETS.invis;
    const pl = game.player;
    if (pl.invisT > 0) return;
    if (!this.pay(game, { id: 'invis', energy: IV.energy, cd: IV.cd })) return;
    pl.invisT = IV.duration;
    game.hud.toast('CLOAKED · ' + IV.duration + 's — ENEMIES LOSE YOU', 1500);
    game.sfx.vatsIn();
    this.spawnRing(pl.pos, 2.2, '#9fd4ee');
  }

  /* -- overshield ---------------------------------------------------------------- */
  useOvershield(game, def) {
    const OS = ASSETS.overshield;
    const pl = game.player;
    if (!this.pay(game, { id: 'overshield', energy: OS.energy, cd: OS.cd })) return;
    pl.overshield = OS.amount;
    pl.overshieldT = OS.duration;
    game.hud.toast('OVERSHIELD +' + OS.amount, 1400);
    game.sfx.shieldHit();
    this.spawnRing(pl.pos, 2.4, '#7df2ff');
  }

  /* ======================================================================
     HOSTILE elite abilities (fire nova / grenades / homing missiles)
     ====================================================================== */
  hostileNova(game, pos, radius, dmg, burn, src) {
    game.sfx.nova();
    this.spawnRing(pos, radius, P.fire);
    const nv = {
      pos, r: radius, t: burn || 4, tick: 0, light: null, sprites: [],
      hostile: true, dmg, hitPlayer: false,
    };
    this.novas.push(nv);
    const pl = new THREE.PointLight(P.fire, 2.0, radius * 1.8, 1.6);
    pl.position.copy(pos).add(new THREE.Vector3(0, 0.6, 0));
    game.scene.add(pl);
    nv.light = pl;
    if (src) game.hud.toast('ELITE FIRE NOVA — KEEP MOVING', 1200);
  }

  hostileGrenade(game, from, targetPos, cfg) {
    const mesh = new THREE.Mesh(this.gGeo, this.gMat);
    mesh.scale.setScalar(1.15);
    mesh.position.copy(from);
    game.scene.add(mesh);
    const vel = targetPos.clone().sub(from);
    const d = Math.max(3, vel.length());
    vel.normalize().multiplyScalar(Math.min(11, d * 0.85));
    vel.y = 4.2;
    this.live.push({
      type: 'egrenade', mesh, vel, life: 6, fuse: 1.35, spin: rand(4, 9),
      dmg: cfg.dmg, radius: cfg.radius,
    });
    game.sfx.throwPin();
  }

  hostileMissile(game, srcEnemy, dmg) {
    const mesh = new THREE.Group();
    const body = new THREE.Mesh(this.rGeo, this.rMat);
    body.rotation.x = Math.PI / 2;
    mesh.add(body);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: texGlow('#ff6a4e'), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    }));
    glow.scale.setScalar(0.4);
    mesh.add(glow);
    mesh.position.copy(srcEnemy.group.position).add(new THREE.Vector3(0, 1.4, 0));
    game.scene.add(mesh);
    this.live.push({
      type: 'hmissile', mesh, life: 5, dmg, speed: 12.5, trail: 0,
      vel: new THREE.Vector3(rand(-2, 2), 5, rand(-2, 2)),
    });
    game.sfx.missile(0);
    game.hud.toast('HOMING MISSILES INBOUND — BREAK LINE OF SIGHT', 1400);
  }

  /* splash that hurts the PLAYER + knocks down (elite ordnance) */
  splashHostile(game, pos, radius, dmg) {
    const pl = game.player;
    const d = Math.hypot(pl.pos.x - pos.x, pl.pos.z - pos.z);
    if (d < radius && !pl.dead) {
      pl.damage(dmg * (1 - (d / radius) * 0.55), game);
      pl.knockdown(game);
    }
    game.weapon.impactLight.position.copy(pos);
    game.weapon.impactLight.intensity = 5;
    for (let i = 0; i < 10; i++) game.weapon.spawnSpark(pos, false, true);
    for (let i = 0; i < 4; i++) game.weapon.spawnPuff(pos);
  }

  /* -- fire nova (player version) ------------------------------------------------ */
  useFireNova(game, def) {
    if (!this.pay(game, def)) return;
    game.sfx.nova();
    this.spawnRing(game.player.pos, 5, P.fire);
    this.novas.push({
      pos: game.player.pos.clone(), r: 5, t: 4, tick: 0,
      light: null, sprites: [], hostile: false,
      /* CH-25.4 — the 4/s burn tick is PURE HEAT through the shared
         pipeline (def fractions × 4); DoT ticks never crit (stated).     */
      hit: { types: typedHit(def, 4), crit: null, statusChance: def.statusChance || 0 },
    });
    const pl = new THREE.PointLight(P.fire, 2.2, 9, 1.6);
    pl.position.copy(this.novas[this.novas.length - 1].pos).add(new THREE.Vector3(0, 0.6, 0));
    game.scene.add(pl);
    this.novas[this.novas.length - 1].light = pl;
  }

  /* ======================================================================
     splash damage
     ====================================================================== */
  splash(game, pos, radius, dmg, selfMult = 0.4, stagger = 2.0, boxDmg = null, hit = null) {
    for (const e of game.enemies) {
      if (!e.alive) continue;
      const d = e.group.position.distanceTo(pos);
      if (d < radius) {
        const fall = 1 - (d / radius) * 0.8;
        /* CH-25.4 — typed splash: falloff scales the typed values AFTER
           the crit (crit is rolled once per projectile, then carried).   */
        if (hit && hit.types) {
          applyDamage(e, {
            types: scaleTypes(hit.types, fall),
            crit: hit.crit,
            statusChance: hit.statusChance || 0,
          }, game, { point: e.group.position.clone(), kind: 'splash' });
        } else {
          e.damage(dmg * fall, e.group.position.clone(), game, 'splash');
        }
        e.stagger = Math.max(e.stagger, stagger);
      }
    }
    /* breakable props eat splash too — CH-06.4: any damage type, no gate */
    if (game.world.breakables) {
      const bd = boxDmg !== null ? boxDmg : dmg;
      for (const b of game.world.breakables) {
        if (b.dead) continue;
        if (b.mesh.position.distanceTo(pos) < radius) {
          game.world.damageBox(game, b, bd, null);
        }
      }
    }
    const pd = game.player.pos.distanceTo(pos);
    if (pd < radius && !game.player.dead) {
      game.player.damage(dmg * selfMult * (1 - (pd / radius) * 0.7), game);
    }
    // fx
    game.weapon.impactLight.position.copy(pos);
    game.weapon.impactLight.intensity = 5;
    for (let i = 0; i < 10; i++) game.weapon.spawnSpark(pos, false, true);
    for (let i = 0; i < 4; i++) game.weapon.spawnPuff(pos);
    game.player.recoil += Math.max(0, 0.05 * (1 - pd / 12));
  }

  /* rockets come here from weapon.js — def carries power-mod damage */
  fireRocket(pos, dir, origin, def = null) {
    const splashR = def?.splash?.radius || 5.5;
    const splashD = def?.splash?.damage || 150;
    const selfM = def?.splash?.selfMult || 0.45;
    /* CH-06.4 — the box-break mark lives in assets (world.containers.
       breakThreshold, default 2000, keyed to this launcher's per-shell
       damage) — power-mod damage multipliers still push the delivered
       shell over the mark so the overkill loot ratio is unchanged.       */
    const boxDmg = ASSETS.world.containers.breakThreshold *
      Math.max(1, (def?.damage || 150) / 150, splashD / 150);
    const mesh = new THREE.Mesh(this.rGeo, this.rMat);
    mesh.rotation.x = Math.PI / 2;
    const tip = new THREE.Mesh(this.rGeo, this.rTipMat);
    tip.scale.set(0.75, 0.22, 0.75);
    tip.rotation.x = Math.PI / 2;
    tip.position.y = 0.13;
    mesh.add(tip);
    mesh.position.copy(pos);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: texGlow('#ffb45e'), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    }));
    glow.scale.setScalar(0.5);
    mesh.add(glow);
    this.scene.add(mesh);
    this.live.push({
      type: 'rocket', mesh, vel: dir.clone().multiplyScalar(24),
      life: 4, trail: 0,
      splash: { radius: splashR, dmg: splashD, selfMult: selfM, stagger: 2.0, boxDmg },
      /* CH-25.4 — typed rocket: blast profile = def fractions of the
         moddable damage (impact + heat payload); crit rolled at launch. */
      hit: def ? { types: typedHit(def), crit: rollCrit(def), statusChance: def.statusChance || 0 } : null,
    });
    this._launchOrigin = origin;
  }

  /* ======================================================================
     DROP CHART + PICKUPS — v0.8 level-scaled
     ====================================================================== */
  rollDrops(pos, arch, level = 1) {
    const D = ASSETS.drops;
    const mult = dropRateMult(level);   // L40 = 1× · L60 = 2× · L80 = 4× cap
    if (arch.elite) {
      const b = D.eliteBonus;
      this.spawnPickup(pos.clone(), b, true);
      // elites always spill POWER + credit salvage (curve-scaled)
      const ep = D.elitePower;
      this.spawnPickup(
        pos.clone().add(new THREE.Vector3(-0.7, 0, 0.4)),
        { t: 'power', id: 'cell', n: Math.round(ep.n * mult), label: 'ELITE CHARGE +' + Math.round(ep.n * mult) + ' POWER' }, true);
      const ec = D.eliteCr;
      this.spawnPickup(
        pos.clone().add(new THREE.Vector3(0.7, 0, 0.4)),
        { t: 'credits', id: 'chips', n: Math.round(ec.n * mult), label: 'ELITE SALVAGE +' + Math.round(ec.n * mult).toLocaleString('en-US') + ' CR' }, true);
      /* elites chip in prebuilt mods much more often */
      if (Math.random() < D.eliteModChance) this.spawnModChip(pos.clone().add(new THREE.Vector3(0, 0, -0.6)));
    }

    /* chance rolls: CREDITS 60 % (80–100 × curve) · POWER 12 % (15–20 × curve) */
    if (Math.random() < D.creditChance) {
      const n = Math.round(randi(D.creditN) * mult);
      this.spawnPickup(pos.clone().add(new THREE.Vector3(rand(-0.4, 0.4), 0, rand(-0.4, 0.4))),
        { t: 'credits', id: 'chips', n, label: '+' + n + ' CREDITS' });
    }
    if (Math.random() < D.powerChance) {
      const n = Math.round(randi(D.powerN) * mult);
      this.spawnPickup(pos.clone().add(new THREE.Vector3(rand(-0.4, 0.4), 0, rand(-0.4, 0.4))),
        { t: 'power', id: 'cell', n, label: 'POWER +' + n });
    }

    /* ★ basic-mod chip from any kill (boosted chance) */
    if (Math.random() < D.modChance) this.spawnModChip(pos.clone());

    /* weighted table roll (ammo / health / energy / frags) */
    const total = D.nothingW + D.table.reduce((s, r) => s + r.w, 0);
    let roll = Math.random() * total;
    if (roll < D.nothingW) return;
    roll -= D.nothingW;
    for (const r of D.table) {
      roll -= r.w;
      if (roll <= 0) {
        const drop = { ...r };
        if (Array.isArray(r.n)) drop.n = randi(r.n);
        this.spawnPickup(pos.clone().add(new THREE.Vector3(rand(-0.4, 0.4), 0, rand(-0.4, 0.4))), drop);
        return;
      }
    }
  }

  /* -- CH-05.2 — SUPPLY LOCKER spill (beast-opened lockers) ---------------
     ELITE-QUALITY loot per the CH-05.2 contract: the elite tier of
     rollDrops (elite POWER + elite CR salvage + the eliteModChance chip)
     plus a DOUBLE ROLL of the standard chance table (credits / power /
     weighted ammo-health-energy table — including its 5 % basic chip).
     `level` = the locker's zone level (assets.enemy.zones), so the
     dropRateMult curve scales the payout exactly like elite kills.       */
  spillLockerLoot(pos, level = 1) {
    const D = ASSETS.drops;
    const mult = dropRateMult(level);
    const j = () => new THREE.Vector3(rand(-0.5, 0.5), 0, rand(-0.5, 0.5));
    /* the elite tier — same pickups rollDrops gives elite kills */
    const ep = D.elitePower, ec = D.eliteCr;
    this.spawnPickup(pos.clone().add(new THREE.Vector3(-0.7, 0, 0.4)),
      { t: 'power', id: 'cell', n: Math.round(ep.n * mult), label: 'ELITE CHARGE +' + Math.round(ep.n * mult) + ' POWER' }, true);
    this.spawnPickup(pos.clone().add(new THREE.Vector3(0.7, 0, 0.4)),
      { t: 'credits', id: 'chips', n: Math.round(ec.n * mult), label: 'ELITE SALVAGE +' + Math.round(ec.n * mult).toLocaleString('en-US') + ' CR' }, true);
    if (Math.random() < D.eliteModChance) this.spawnModChip(pos.clone().add(new THREE.Vector3(0, 0, -0.6)));
    /* the double roll of the standard table */
    for (let i = 0; i < 2; i++) {
      if (Math.random() < D.creditChance) {
        const n = Math.round(randi(D.creditN) * mult);
        this.spawnPickup(pos.clone().add(j()),
          { t: 'credits', id: 'chips', n, label: '+' + n + ' CREDITS' });
      }
      if (Math.random() < D.powerChance) {
        const n = Math.round(randi(D.powerN) * mult);
        this.spawnPickup(pos.clone().add(j()),
          { t: 'power', id: 'cell', n, label: 'POWER +' + n });
      }
      if (Math.random() < D.modChance) this.spawnModChip(pos.clone().add(j()));
      /* weighted table roll (ammo / health / energy / frags) */
      const total = D.nothingW + D.table.reduce((s, r) => s + r.w, 0);
      let roll = Math.random() * total;
      if (roll < D.nothingW) continue;
      roll -= D.nothingW;
      for (const r of D.table) {
        roll -= r.w;
        if (roll <= 0) {
          const drop = { ...r };
          if (Array.isArray(r.n)) drop.n = randi(r.n);
          this.spawnPickup(pos.clone().add(j()), drop);
          break;
        }
      }
    }
  }

  /* -- PREBUILT MOD chip — grants a free rank of a random mod node --------
     (drops from enemies / crates / elites; kaiju spills copies)          */
  spawnModChip(pos) {
    this.spawnPickup(pos, { t: 'mod', id: 'chip', n: 1, label: 'PREBUILT MOD CHIP' }, false);
  }

  /* -- CH-02.2 — pool-weighted MOD NODE pick. One itemPool roll first,
     then uniform WITHIN the winning pool (each pistol/shotgun node is
     worth ~20 % of all chips; rifle/frame/companion/launcher nodes are
     rare). Falls back to the old uniform roll on a bad pool config.      */
  _rollModNode() {
    const nodes = ASSETS.mods.nodes;
    const pool = pickWeightedKey(ASSETS.drops.itemPool);
    const inPool = pool ? nodes.filter((n) => n.pool === pool) : [];
    if (!inPool.length) return nodes[Math.floor(Math.random() * nodes.length)];
    return inPool[Math.floor(Math.random() * inPool.length)];
  }

  /* -- CH-02.2 — pool-weighted pick among LOCKED guns (copies never grant
     a gun you already own; the itemPool weights renormalise over what-
     ever is still locked — e.g. M6-P is always online, so its 40 never
     biases a copy). Falls back to uniform if no locked gun has weight.   */
  _rollLockedGun(game) {
    const locked = game.weapon.guns
      .map((g, i) => ({ g, i }))
      .filter((x) => !game.weapon.unlocked.has(x.g.def.id));
    if (!locked.length) return null;
    const weights = {};
    for (const x of locked) weights[x.g.def.id] = +ASSETS.drops.itemPool[x.g.def.pool] || 0;
    const id = pickWeightedKey(weights);
    return id ? locked.find((x) => x.g.def.id === id)
              : locked[Math.floor(Math.random() * locked.length)];
  }

  /* -- kaiju reward table: mod copies + a weapon copy + big payout ------- */
  kaijuRewards(pos) {
    const K = ASSETS.world.expanse.kaiju.reward;
    const j = () => new THREE.Vector3(rand(-1, 1), 0, rand(-1, 1));
    this.spawnPickup(pos.clone().add(j()),
      { t: 'credits', id: 'chips', n: K.credits, label: '+' + K.credits.toLocaleString('en-US') + ' CREDITS' }, true);
    this.spawnPickup(pos.clone().add(j()),
      { t: 'power', id: 'cell', n: K.power, label: 'POWER +' + K.power }, true);
    /* copies of prebuilt mods */
    for (let i = 0; i < K.mods; i++) {
      this.spawnModChip(pos.clone().add(j()));
    }
    /* extra weapon copies */
    for (let i = 0; i < K.weaponCopy; i++) {
      this.spawnPickup(pos.clone().add(j()),
        { t: 'weaponcopy', id: 'copy', n: 1, label: 'WEAPON PROTOTYPE' }, true);
    }
  }

  /* -- supply-box conversion spill ---------------------------------------
     One broken box = the value of one rocket shell, converted:
     50 energy (2 plasma) · 25 rifle · 10 pistol · 2 sniper (+ maybe a
     rocket). Power-mod overkill multiplies the amounts (capped ×3).     */
  spawnConversionLoot(pos, mult = 1) {
    const C = ASSETS.conversion;
    const q = (n) => Math.max(1, Math.round(n * mult));
    const jitter = () => new THREE.Vector3(rand(-0.6, 0.6), 0, rand(-0.6, 0.6));
    this.spawnPickup(pos.clone().add(jitter()),
      { t: 'energy', id: 'cell', n: q(C.energy), label: '+' + q(C.energy) + ' ENERGY · 2 PLASMA' });
    const kinds = [
      { t: 'ammo', id: 'rifle',  n: q(C.rifle),  label: '+' + q(C.rifle) + ' RIFLE AMMO' },
      { t: 'ammo', id: 'pistol', n: q(C.pistol), label: '+' + q(C.pistol) + ' PISTOL AMMO' },
      { t: 'ammo', id: 'sniper', n: q(C.sniper), label: '+' + q(C.sniper) + ' SNIPER ROUNDS' },
    ];
    const pick = kinds[Math.floor(Math.random() * kinds.length)];
    this.spawnPickup(pos.clone().add(jitter()), pick);
    if (Math.random() < C.rocketChance) {
      this.spawnPickup(pos.clone().add(jitter()),
        { t: 'ammo', id: 'heavy', n: 1, label: '+1 ROCKET' });
    }
    /* ★ broken boxes cough up basic mods far more often now */
    if (Math.random() < ASSETS.drops.crateModChance) {
      this.spawnModChip(pos.clone().add(jitter()));
    }
  }

  /* -- CH-06.3 — barrel / chest spill tables ------------------------------
     barrels = small CR + one ammo handful; chests = better CR + a mod
     chip chance (crateModChance parity). mult = the same overkill ratio
     the conversion table uses (rocket overkill → up to ×3). Unknown
     kinds fall back to the conversion spill so a config typo can never
     void a prop's loot.                                                   */
  spawnContainerSpill(pos, kind, mult = 1) {
    const S = ASSETS.world.containers && ASSETS.world.containers.spill[kind];
    if (!S) { this.spawnConversionLoot(pos, mult); return; }
    const jitter = () => new THREE.Vector3(rand(-0.6, 0.6), 0, rand(-0.6, 0.6));
    const cr = Math.max(1, Math.round(randi(S.cr) * mult));
    this.spawnPickup(pos.clone().add(jitter()),
      { t: 'credits', id: 'chips', n: cr, label: '+' + cr.toLocaleString('en-US') + ' CR' });
    if (S.ammo && S.ammo.length) {
      const [id, n] = S.ammo[Math.floor(Math.random() * S.ammo.length)];
      const an = Math.max(1, Math.round(n * mult));
      const label = { rifle: 'RIFLE AMMO', pistol: 'PISTOL AMMO', shell: 'SHELLS',
                      sniper: 'SNIPER ROUNDS', heavy: 'ROCKET' }[id] || id.toUpperCase();
      this.spawnPickup(pos.clone().add(jitter()),
        { t: 'ammo', id, n: an, label: '+' + an + ' ' + label });
    }
    if (S.modChance > 0 && Math.random() < S.modChance) {
      this.spawnModChip(pos.clone().add(jitter()));
    }
  }

  spawnPickup(pos, drop, big = false, lifeOverride = null) {
    const g = new THREE.Group();
    let glowColor = '#ffd9a0';
    const mk = (geo, mat) => { const m = new THREE.Mesh(geo, mat); g.add(m); return m; };

    if (drop.t === 'ammo') {
      const mats = {
        rifle: ['#8a6d3b', '#c9a75a'], pistol: ['#4a545c', '#7d8790'],
        shell: ['#7a2f28', '#c05548'], sniper: ['#3e4a5a', '#7a90b0'],
        heavy: ['#4a5238', '#7a8a5a'],
      };
      const [dark, lit] = mats[drop.id] || mats.rifle;
      if (drop.id === 'heavy') {
        const m = mk(new THREE.CylinderGeometry(0.07, 0.07, 0.4, 8),
          new THREE.MeshLambertMaterial({ color: dark }));
        m.rotation.z = Math.PI / 2.4;
        glowColor = '#b0c48a';
      } else if (drop.id === 'sniper') {
        mk(new THREE.BoxGeometry(0.42, 0.09, 0.09), new THREE.MeshLambertMaterial({ color: dark }));
        glowColor = lit;
      } else {
        mk(new THREE.BoxGeometry(0.3, 0.2, 0.2), new THREE.MeshLambertMaterial({ color: dark }));
        mk(new THREE.BoxGeometry(0.31, 0.05, 0.21), new THREE.MeshLambertMaterial({ color: lit }));
        glowColor = lit;
      }
    } else if (drop.t === 'health') {
      mk(new THREE.BoxGeometry(0.28, 0.28, 0.28), new THREE.MeshLambertMaterial({ color: '#d8dde2' }));
      mk(new THREE.BoxGeometry(0.3, 0.08, 0.08), new THREE.MeshBasicMaterial({ color: '#ff5340' }));
      mk(new THREE.BoxGeometry(0.08, 0.3, 0.08), new THREE.MeshBasicMaterial({ color: '#ff5340' }));
      glowColor = '#ff8d80';
    } else if (drop.t === 'energy') {
      const cell = mk(new THREE.CylinderGeometry(0.08, 0.08, 0.3, 8),
        new THREE.MeshBasicMaterial({ color: drop.id === 'core' ? '#bffcff' : '#59f2ff' }));
      cell.rotation.z = 0.5;
      glowColor = P.energy;
      if (drop.id === 'core') {
        const halo = new THREE.Sprite(new THREE.SpriteMaterial({
          map: texGlow('#bffcff'), blending: THREE.AdditiveBlending,
          transparent: true, depthWrite: false,
        }));
        halo.scale.setScalar(1.2);
        g.add(halo);
      }
    } else if (drop.t === 'grenade') {
      const m = mk(this.gGeo, this.gMat);
      m.scale.setScalar(1.4);
      glowColor = '#9fbf6f';
    } else if (drop.t === 'credits') {
      const gold = new THREE.MeshLambertMaterial({ color: '#e8b53a' });
      const lite = new THREE.MeshBasicMaterial({ color: '#ffe9a8' });
      const s1 = mk(new THREE.BoxGeometry(0.3, 0.05, 0.2), gold);
      s1.rotation.y = 0.3;
      const s2 = mk(new THREE.BoxGeometry(0.3, 0.05, 0.2), gold);
      s2.rotation.y = -0.25; s2.position.y = 0.06;
      mk(new THREE.BoxGeometry(0.31, 0.015, 0.21), lite).position.y = 0.09;
      glowColor = '#ffd9a0';
    } else if (drop.t === 'power') {
      // POWER currency — glowing octahedron shard (crystals are the big ones)
      const core = mk(
        new THREE.OctahedronGeometry(big ? 0.42 : 0.16, 0),
        new THREE.MeshBasicMaterial({ color: P.power }));
      core.rotation.set(0.4, 0.6, 0.2);
      glowColor = P.power;
      if (big) {
        mk(new THREE.ConeGeometry(0.34, 0.3, 6),
          new THREE.MeshLambertMaterial({ color: '#4c4a38' })).position.y = -0.5;
      }
    } else if (drop.t === 'material') {
      /* ecology materials — colored tetra chunk per material */
      const matColors = {
        fiber: '#7aa85a', herbs: '#a8d05a', feather: '#e8e2d0', hide: '#a8794f',
        fish: '#7ac4d8', ferrite: '#c98a4f', titanium: '#9fc4d8',
        gallium: '#7ea8f2', crystal: '#6ff2ff',
      };
      const chunk = mk(new THREE.TetrahedronGeometry(0.19, 0),
        new THREE.MeshLambertMaterial({
          color: matColors[drop.id] || '#a8b8a0', emissive: matColors[drop.id] || '#666',
          emissiveIntensity: 0.25,
        }));
      chunk.rotation.set(0.5, 0.8, 0.2);
      glowColor = matColors[drop.id] || '#a8b8a0';
    } else if (drop.t === 'mod') {
      /* prebuilt mod chip — gold hex plate */
      const plate = mk(new THREE.CylinderGeometry(0.17, 0.17, 0.05, 6),
        new THREE.MeshLambertMaterial({ color: '#e8b53a', emissive: '#e8b53a', emissiveIntensity: 0.3 }));
      plate.rotation.x = 0.5;
      const glyph = mk(new THREE.BoxGeometry(0.12, 0.02, 0.12),
        new THREE.MeshBasicMaterial({ color: '#fff2c0' }));
      glyph.position.y = 0.04;
      glowColor = '#ffd24f';
    } else if (drop.t === 'weaponcopy') {
      /* kaiju weapon prototype — mini rifle silhouette + white halo */
      const gm = new THREE.MeshLambertMaterial({ color: '#b8c2cc', emissive: '#8fa8b8', emissiveIntensity: 0.35 });
      mk(new THREE.BoxGeometry(0.55, 0.09, 0.09), gm);
      mk(new THREE.BoxGeometry(0.12, 0.14, 0.08), gm).position.set(-0.1, -0.09, 0);
      mk(new THREE.BoxGeometry(0.1, 0.05, 0.05), gm).position.set(0.28, 0.06, 0);
      glowColor = '#e8f4ff';
    }

    const glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: texGlow(glowColor), blending: THREE.AdditiveBlending,
      transparent: true, opacity: 0.85, depthWrite: false,
    }));
    glow.scale.setScalar(big ? 1.3 : 0.7);
    g.add(glow);

    g.position.copy(pos);
    const gy = this._worldRef ? this._worldRef.floorHeightAt(pos.x, pos.z, 99) : 0;
    g.position.y = gy + (big ? 0.7 : 0.45);
    this.scene.add(g);
    this.pickups.push({
      g, drop, t: 0,
      life: lifeOverride !== null ? lifeOverride : ASSETS.drops.pickupLife,
      baseY: g.position.y, spin: rand(1.5, 2.6),
    });
  }

  collect(game, pk) {
    const d = pk.drop;
    const pl = game.player;
    if (d.t === 'ammo') {
      const pool = game.ammo;
      if (pool[d.id] >= ASSETS.ammoPools[d.id].cap) return false;
      pool[d.id] = Math.min(ASSETS.ammoPools[d.id].cap, pool[d.id] + d.n);
      game.sfx.pickup('ammo');
      /* scavenged ammo unlocks its gun (start M6-P only) */
      game.weapon.unlockByAmmo(d.id, game);
    } else if (d.t === 'health') {
      if (pl.health >= ASSETS.player.healthMax) return false;
      pl.health = Math.min(ASSETS.player.healthMax, pl.health + d.n);
      game.sfx.pickup('health');
    } else if (d.t === 'energy') {
      pl.energy = Math.min(ASSETS.energy.max, pl.energy + d.n);
      pl.lastEnergyUse = -99;
      game.sfx.pickup('energy');
    } else if (d.t === 'grenade') {
      if (this.grenades >= FRAG.cap) return false;
      this.grenades = Math.min(FRAG.cap, this.grenades + d.n);
      game.sfx.pickup('ammo');
    } else if (d.t === 'credits') {
      Mods.add(d.n);                       // never caps — the meta bank
      game.sfx.pickup('credits');
    } else if (d.t === 'power') {
      Mods.addPower(d.n);                  // never caps — the meta bank
      game.sfx.pickup('power');
    } else if (d.t === 'material') {
      /* ecology materials — sell in XMB → SALVAGE */
      game.materials[d.id] = (game.materials[d.id] || 0) + d.n;
      game.sfx.pickup('ammo');
    } else if (d.t === 'mod') {
      /* CH-03.1 — CARD INVENTORY: chips, crate drops, elite drops and kaiju
         copies ALL add a CARD here (copies +1) — never a free rank. First
         copy = a new card at R0; duplicates pile up as inventory to sell /
         scrap in XMB → MOD · DUPES (CH-03.4) or via Mods.sellDuplicates(). */
      const node = this._rollModNode();
      const res = Mods.acquireCard(node.id);
      game.sfx.uiConfirm();
      if (res.isNew) {
        game.hud.toast('MOD CARD · ' + node.label + ' ACQUIRED · R0', 2200);
        this._lastModLabel = node.label + ' CARD';
        d.label = 'MOD: ' + node.label + ' CARD';
      } else {
        game.hud.toast('MOD DUPLICATE · ' + node.label + ' ×' + res.copies +
          ' — SELL/SCRAP IN XMB · MOD · DUPES', 2400);
        this._lastModLabel = node.label + ' ×' + res.copies;
        d.label = 'MOD: ' + node.label + ' ×' + res.copies;
      }
    } else if (d.t === 'weaponcopy') {
      /* kaiju weapon prototype: unlock a locked gun — or sell the duplicate.
         CH-02.2: WHICH locked gun comes out of the weighted itemPool. */
      const pick = this._rollLockedGun(game);
      if (pick) {
        game.weapon.unlocked.add(pick.g.def.id);
        game.ammo[pick.g.def.ammo] = Math.max(game.ammo[pick.g.def.ammo],
          Math.round(ASSETS.ammoPools[pick.g.def.ammo].cap * 0.5));
        game.sfx.uiConfirm();
        game.hud.toast('WEAPON COPY · ' + pick.g.def.name + ' ONLINE', 2400);
        d.label = pick.g.def.name + ' COPY';
      } else {
        Mods.add(25000);
        game.sfx.pickup('credits');
        game.hud.toast('DUPLICATE PROTOTYPE — SOLD +25,000 CR', 2000);
        d.label = '+25,000 CR (PROTOTYPE SALE)';
      }
    }
    /* pickup notifications live in the small feed UNDER THE RETICLE */
    game.hud.pickup(d.label.endsWith('+') ? d.label + d.n : d.label);
    return true;
  }

  /* valley + city POWER crystals — long-lived big shards (respawn on reset) */
  spawnCrystals(game) {
    const D = ASSETS.drops;
    const spots = ASSETS.world.valley.crystals.concat(ASSETS.world.city.crystals);
    for (const c of spots) {
      this.spawnPickup(
        new THREE.Vector3(c.x, 0, c.z),
        { ...D.crystal, n: randi(D.crystal.n) },
        true, 1e9);
    }
  }

  /* -- CH-02.3 — dry-run the item pool: prints the mod-chip distribution
     (per pool + per node) and the weapon-copy distribution over the
     currently locked guns. ZERO side effects — no Mods writes, no spawns,
     no RNG state shared with gameplay rolls beyond Math.random.          */
  _simItemPool(n, game) {
    const D = ASSETS.drops, nodes = ASSETS.mods.nodes;
    const poolTally = {}, nodeTally = {}, gunTally = {};
    for (let i = 0; i < n; i++) {
      const node = this._rollModNode();
      poolTally[node.pool] = (poolTally[node.pool] || 0) + 1;
      nodeTally[node.label] = (nodeTally[node.label] || 0) + 1;
      const pk = this._rollLockedGun(game);
      if (pk) gunTally[pk.g.def.name] = (gunTally[pk.g.def.name] || 0) + 1;
    }
    const pct = (x) => (100 * x / n).toFixed(2) + ' %';
    const table = (rows) => (console.table ? console.table(rows) : console.log(JSON.stringify(rows, null, 2)));
    console.log('%cAC.game.drops.sim(' + n + ')', 'font-weight:bold');
    console.log('itemPool weights (normalised at roll time):', D.itemPool);
    const poolRows = Object.keys(D.itemPool).map((k) => ({
      pool: k, w: D.itemPool[k], rolled: poolTally[k] || 0, pct: pct(poolTally[k] || 0),
    }));
    console.log('MOD CHIPS — per pool:');
    table(poolRows);
    console.log('MOD CHIPS — per node (uniform inside the winning pool):');
    table(nodes.map((nd) => ({
      node: nd.label, pool: nd.pool, pct: pct(nodeTally[nd.label] || 0),
    })));
    if (game.weapon) {
      const locked = game.weapon.guns.filter((g) => !game.weapon.unlocked.has(g.def.id));
      if (locked.length) {
        console.log('WEAPON COPIES — weighted over the locked set:');
        table(locked.map((g) => ({
          gun: g.def.name, pool: g.def.pool, w: +D.itemPool[g.def.pool] || 0,
          pct: pct(gunTally[g.def.name] || 0),
        })));
      } else {
        console.log('WEAPON COPIES — all guns online → every copy sells as a duplicate prototype.');
      }
    }
    return { n, pools: poolRows, nodes: nodeTally, guns: gunTally };
  }

  /* ======================================================================
     per-frame update
     ====================================================================== */
  update(dt, game) {
    this._worldRef = game.world;
    /* CH-02.3 — console API on the Game instance: AC.game.drops.sim(10000).
       Attached from here (not main.js) on the first update frame. */
    if (!game.drops) {
      game.drops = { sim: (n = 10000) => this._simItemPool(Math.max(1, n | 0), game) };
    }
    this._hudRef = game.hud;
    this.noAmmoToastT = this.noAmmoToastT || 0;
    this.noAmmoToastT -= dt;

    for (const id in this.cd) if (this.cd[id] > 0) this.cd[id] -= dt;
    if (this.grenadeCd > 0) this.grenadeCd -= dt;

    /* -- projectiles -------------------------------------------------- */
    for (let i = this.live.length - 1; i >= 0; i--) {
      const pr = this.live[i];
      pr.life -= dt;

      if (pr.type === 'grenade') {
        pr.vel.y -= 9.2 * dt;
        pr.mesh.position.addScaledVector(pr.vel, dt);
        pr.mesh.rotation.x += dt * pr.spin;
        const pos = pr.mesh.position;
        const gh = game.world.floorHeightAt(pos.x, pos.z, pos.y + 1) + 0.09;
        if (pos.y < gh) {
          pos.y = gh;
          if (Math.abs(pr.vel.y) > 1.4) {
            pr.vel.y *= -0.42; pr.vel.x *= 0.65; pr.vel.z *= 0.65;
            game.sfx.bounce();
          } else {
            pr.vel.y = 0;
            pr.vel.x *= Math.exp(-3 * dt); pr.vel.z *= Math.exp(-3 * dt);
          }
        }
        for (const c of game.world.colliders) {
          if (pos.y > (c.y1 ?? 3) || pos.y < (c.y0 ?? 0)) continue;
          if (pos.x > c.minX - 0.09 && pos.x < c.maxX + 0.09 &&
              pos.z > c.minZ - 0.09 && pos.z < c.maxZ + 0.09) {
            const pxL = pos.x - (c.minX - 0.09), pxR = (c.maxX + 0.09) - pos.x;
            const pzL = pos.z - (c.minZ - 0.09), pzR = (c.maxZ + 0.09) - pos.z;
            const m = Math.min(pxL, pxR, pzL, pzR);
            if (m === pxL)      { pos.x = c.minX - 0.09; pr.vel.x = -Math.abs(pr.vel.x) * 0.45; }
            else if (m === pxR) { pos.x = c.maxX + 0.09; pr.vel.x = Math.abs(pr.vel.x) * 0.45; }
            else if (m === pzL) { pos.z = c.minZ - 0.09; pr.vel.z = -Math.abs(pr.vel.z) * 0.45; }
            else                { pos.z = c.maxZ + 0.09; pr.vel.z = Math.abs(pr.vel.z) * 0.45; }
            game.sfx.bounce();
          }
        }
        if (pr.fuse !== undefined) {
          pr.fuse -= dt;
          if (pr.fuse <= 0) {
            game.sfx.boom(panOf(game, pos));
            this.splash(game, pos.clone(), FRAG.radius, FRAG.damage,
              FRAG.selfDamage / FRAG.damage * 0.45, 2.2, null, pr.hit);
            this.scene.remove(pr.mesh);
            this.live.splice(i, 1);
            continue;
          }
        }
      } else if (pr.type === 'missile') {
        if (pr.target && pr.target.alive) {
          const aim = pr.target.group.position.clone();
          aim.y += pr.target.fly ? 0 : 0.7;
          const desired = aim.clone().sub(pr.mesh.position).normalize().multiplyScalar(pr.speed);
          pr.vel.lerp(desired, Math.min(1, dt * 4.5));
        }
        pr.mesh.position.addScaledVector(pr.vel, dt);
        pr.mesh.lookAt(pr.mesh.position.clone().add(pr.vel));
        pr.trail -= dt;
        if (pr.trail <= 0) {
          pr.trail = 0.05;
          game.weapon.spawnPuff(pr.mesh.position);
        }
        let boom = pr.life <= 0;
        const pos = pr.mesh.position;
        if (pr.target && pr.target.alive &&
            pos.distanceTo(pr.target.group.position) < 0.9) boom = true;
        if (!boom && (pos.y < 0.05 || pos.y > game.world.ceilHeightAt(pos.z))) boom = true;
        if (!boom) {
          for (const c of game.world.colliders) {
            if (pos.y > (c.y1 ?? 3) || pos.y < (c.y0 ?? 0)) continue;
            if (pos.x > c.minX && pos.x < c.maxX && pos.z > c.minZ && pos.z < c.maxZ) { boom = true; break; }
          }
        }
        if (boom) {
          const ex = pr.execute && pr.target && pr.target.alive &&
            pr.target.hp < pr.target.maxHp * ASSETS.vats.executeFrac;
          if (ex) {
            pr.target.damage(9999, pr.target.group.position.clone(), game, 'missile');
            game.sfx.execute();
            game.hud.toast('TARGET EXECUTED', 1100);
          } else {
            game.sfx.boomSmall(panOf(game, pos));
            this.splash(game, pos.clone(), 2.6, pr.dmg, 0.35, 2.0, null, pr.hit);
          }
          this.scene.remove(pr.mesh);
          this.live.splice(i, 1);
          continue;
        }
      } else if (pr.type === 'rocket') {
        pr.vel.y -= 2.5 * dt;
        pr.mesh.position.addScaledVector(pr.vel, dt);
        pr.trail -= dt;
        if (pr.trail <= 0) {
          pr.trail = 0.035;
          game.weapon.spawnPuff(pr.mesh.position);
        }
        let boom = pr.life <= 0;
        const pos = pr.mesh.position;
        if (!boom) {
          for (const e of game.enemies) {
            if (!e.alive) continue;
            if (e.group.position.distanceTo(pos) < 0.9) { boom = true; break; }
          }
        }
        if (!boom && (pos.y < 0.08 || pos.y > game.world.ceilHeightAt(pos.z))) boom = true;
        if (!boom) {
          for (const c of game.world.colliders) {
            if (pos.y > (c.y1 ?? 3) || pos.y < (c.y0 ?? 0)) continue;
            if (pos.x > c.minX - 0.1 && pos.x < c.maxX + 0.1 &&
                pos.z > c.minZ - 0.1 && pos.z < c.maxZ + 0.1) { boom = true; break; }
          }
        }
        if (boom) {
          game.sfx.boom(panOf(game, pos));
          this.splash(game, pos.clone(), pr.splash.radius, pr.splash.dmg,
            pr.splash.selfMult, pr.splash.stagger, pr.splash.boxDmg, pr.hit);
          this.scene.remove(pr.mesh);
          this.live.splice(i, 1);
          continue;
        }
      } else if (pr.type === 'egrenade') {
        /* hostile grenade — bounces, then splash-knocks the player */
        pr.vel.y -= 9.2 * dt;
        pr.mesh.position.addScaledVector(pr.vel, dt);
        pr.mesh.rotation.x += dt * pr.spin;
        const pos = pr.mesh.position;
        const gh = game.world.floorHeightAt(pos.x, pos.z, pos.y + 1) + 0.09;
        if (pos.y < gh) {
          pos.y = gh;
          if (Math.abs(pr.vel.y) > 1.4) {
            pr.vel.y *= -0.42; pr.vel.x *= 0.65; pr.vel.z *= 0.65;
          } else { pr.vel.y = 0; pr.vel.x *= Math.exp(-3 * dt); pr.vel.z *= Math.exp(-3 * dt); }
        }
        pr.fuse -= dt;
        if (pr.fuse <= 0 || pr.life <= 0) {
          game.sfx.boom(panOf(game, pos));
          this.splashHostile(game, pos.clone(), pr.radius, pr.dmg);
          this.scene.remove(pr.mesh);
          this.live.splice(i, 1);
          continue;
        }
      } else if (pr.type === 'hmissile') {
        /* elite homing missile — hunts the PLAYER */
        const aim = game.player.pos.clone();
        const desired = aim.clone().sub(pr.mesh.position).normalize().multiplyScalar(pr.speed);
        pr.vel.lerp(desired, Math.min(1, dt * 3.6));
        pr.mesh.position.addScaledVector(pr.vel, dt);
        pr.mesh.lookAt(pr.mesh.position.clone().add(pr.vel));
        pr.trail -= dt;
        if (pr.trail <= 0) {
          pr.trail = 0.05;
          game.weapon.spawnPuff(pr.mesh.position);
        }
        const pos = pr.mesh.position;
        const pd = pos.distanceTo(game.player.pos);
        let boom = pr.life <= 0 || pos.y < 0.05 || pd < 0.8;
        if (!boom) {
          for (const c of game.world.colliders) {
            if (pos.y > (c.y1 ?? 3) || pos.y < (c.y0 ?? 0)) continue;
            if (pos.x > c.minX && pos.x < c.maxX && pos.z > c.minZ && pos.z < c.maxZ) { boom = true; break; }
          }
        }
        if (boom) {
          game.sfx.boomSmall(panOf(game, pos));
          this.splashHostile(game, pos.clone(), 2.8, pr.dmg);
          this.scene.remove(pr.mesh);
          this.live.splice(i, 1);
          continue;
        }
      } else if (pr.type === 'pbolt') {
        pr.mesh.position.addScaledVector(pr.vel, dt);
        const pos = pr.mesh.position;
        let boom = pr.life <= 0 || pos.y < 0.08 || pos.y > game.world.ceilHeightAt(pos.z);
        if (!boom) {
          for (const e of game.enemies) {
            if (!e.alive) continue;
            if (e.group.position.distanceTo(pos) < 0.85) { boom = true; break; }
          }
        }
        if (!boom) {
          for (const c of game.world.colliders) {
            if (pos.y > (c.y1 ?? 3) || pos.y < (c.y0 ?? 0)) continue;
            if (pos.x > c.minX - 0.1 && pos.x < c.maxX + 0.1 &&
                pos.z > c.minZ - 0.1 && pos.z < c.maxZ + 0.1) { boom = true; break; }
          }
        }
        if (boom) {
          game.sfx.boomSmall(panOf(game, pos));
          this.splash(game, pos.clone(), pr.splash.radius, pr.splash.dmg,
            pr.splash.selfMult, pr.splash.stagger, null, pr.hit);
          this.scene.remove(pr.mesh);
          this.live.splice(i, 1);
          continue;
        }
      }
      if (pr.life <= 0 && pr.type !== 'grenade' && this.live.includes(pr)) {
        this.scene.remove(pr.mesh);
        this.live.splice(this.live.indexOf(pr), 1);
      }
    }

    /* -- burning novas (friendly + hostile elite fields) ------------------ */
    for (let i = this.novas.length - 1; i >= 0; i--) {
      const nv = this.novas[i];
      nv.t -= dt;
      nv.tick -= dt;
      if (nv.light) nv.light.intensity = 1.6 + Math.sin(game.time * 24) * 0.7;
      if (nv.tick <= 0) {
        nv.tick = 0.3;
        if (nv.hostile) {
          /* elite fire nova — burns and knocks down the PLAYER */
          const pl = game.player;
          const pd = Math.hypot(pl.pos.x - nv.pos.x, pl.pos.z - nv.pos.z);
          if (pd < nv.r && !pl.dead) {
            pl.damage(nv.dmg * 0.3, game);
            if (!nv.hitPlayer) {
              nv.hitPlayer = true;
              pl.knockdown(game);
            }
          }
        } else {
          for (const e of game.enemies) {
            if (!e.alive) continue;
            const d = e.group.position.distanceTo(nv.pos);
            if (d < nv.r) {
              /* CH-25.4 — friendly burn tick = typed heat (nv.hit built
                 in useFireNova); hostile novas never touch enemies.        */
              if (nv.hit) {
                applyDamage(e, { types: nv.hit.types, statusChance: nv.hit.statusChance },
                  game, { point: e.group.position.clone(), kind: 'burn' });
              } else {
                e.damage(4, e.group.position.clone(), game, 'burn');
              }
              e.stagger = Math.max(e.stagger, 0.5);
              e.showBar(2);
            }
          }
        }
        for (let k = 0; k < 3; k++) {
          const s = new THREE.Sprite(this.fireMat);
          const a = Math.random() * Math.PI * 2;
          const rr = Math.random() * nv.r;
          s.position.set(nv.pos.x + Math.cos(a) * rr,
            game.world.floorHeightAt(nv.pos.x, nv.pos.z, 99) + 0.2,
            nv.pos.z + Math.sin(a) * rr);
          s.scale.setScalar(rand(0.5, 0.9));
          this.scene.add(s);
          nv.sprites.push({ s, life: rand(0.5, 0.9), max: 0.9 });
        }
        game.sfx.fireLoop();
      }
      for (let k = nv.sprites.length - 1; k >= 0; k--) {
        const f = nv.sprites[k];
        f.life -= dt;
        f.s.position.y += dt * 1.1;
        f.s.material.opacity = Math.max(0, f.life / f.max) * 0.85;
        if (f.life <= 0) { this.scene.remove(f.s); nv.sprites.splice(k, 1); }
      }
      if (nv.t <= 0) {
        if (nv.light) this.scene.remove(nv.light);
        for (const f of nv.sprites) this.scene.remove(f.s);
        this.novas.splice(i, 1);
      }
    }

    /* -- shockwave rings -------------------------------------------------- */
    for (const r of this.rings) {
      if (r.t > 0) {
        r.t -= dt * 2.6;
        const k = 1 - Math.max(0, r.t);
        r.m.scale.setScalar(0.4 + k * r.r);
        r.m.material.opacity = r.t * 0.8;
        if (r.t <= 0) r.m.visible = false;
      }
    }

    /* -- pickups (magnet range = PICKUP MAGNET mod, 1 m → 15 m) ---------- */
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const pk = this.pickups[i];
      pk.t += dt;
      pk.life -= dt;
      pk.g.rotation.y += dt * pk.spin;
      const pos = pk.g.position;
      pos.y = pk.baseY + Math.sin(pk.t * 2.4) * 0.09;
      if (pk.life < 5 && pk.life < 1e8) pk.g.visible = Math.floor(pk.life * 6) % 2 === 0;
      const pl = game.player;
      const d = Math.hypot(pos.x - pl.pos.x, pos.z - pl.pos.z);
      const dy = Math.abs(pos.y - (pl.pos.y - 1));
      if (d < ASSETS.drops.magnetR && dy < 2.4 && !pl.dead) {
        const k = Math.min(1, dt * 6);
        pos.x += (pl.pos.x - pos.x) * k;
        pos.z += (pl.pos.z - pos.z) * k;
        pos.y += (pl.pos.y - 1 - pos.y) * k;
        if (d < ASSETS.drops.collectR) {
          if (this.collect(game, pk)) {
            this.scene.remove(pk.g);
            this.pickups.splice(i, 1);
            continue;
          }
        }
      }
      if (pk.life <= 0) {
        this.scene.remove(pk.g);
        this.pickups.splice(i, 1);
      }
    }
  }

  /* ====================================================================== */
  resetAll(game) {
    for (const s of SP.list) this.cd[s.id] = 0;
    this.grenades = FRAG.start;
    this.grenadeCd = 0;
    this.slots = SP.defaultSlots.slice();
    this.slotIdx = 0;
    for (const pr of this.live) this.scene.remove(pr.mesh);
    this.live = [];
    for (const nv of this.novas) {
      if (nv.light) this.scene.remove(nv.light);
      for (const f of nv.sprites) this.scene.remove(f.s);
    }
    this.novas = [];
    for (const pk of this.pickups) this.scene.remove(pk.g);
    this.pickups = [];
    if (game) this.spawnCrystals(game);   // valley power crystals return
  }
}

function panOf(game, pos) {
  const to = new THREE.Vector3().subVectors(pos, game.player.pos);
  const right = new THREE.Vector3(Math.cos(game.player.yaw), 0, -Math.sin(game.player.yaw));
  const d = to.length();
  return d > 0.1 ? Math.max(-1, Math.min(1, to.dot(right) / d)) * 0.8 : 0;
}

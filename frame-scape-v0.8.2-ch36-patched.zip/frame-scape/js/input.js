/* ============================================================================
   AUTUMN CORRIDOR — input.js  (v0.6.0)
   ----------------------------------------------------------------------------
   Unified input for keyboard+mouse (Pointer Lock) and Xbox controller
   (Gamepad API, standard mapping). Poll once per frame from main.js.

   Gamepad map:  LS move · RS look · R1 fire · R2 special · L2 aim
                 L1 duck/VATS · A jump/double-jump · X reload · Y swap · B melee
                 D-padUp flashlight · HOLD D-pad◀/▶ cycles the 4 R2 slots
                 Start XMB  (all editable in assets.js → controls.bindings)
   XMB extras:   padEdge(i) + wheel + arrows drive the menu; X/Y scraps mods.
   ==========================================================================*/

import { ASSETS } from './assets.js';

const B = ASSETS.controls.bindings;

export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    this.keys = new Set();          // KeyboardEvent.code down
    this.mouseDown = new Set();     // 'Mouse0' ...
    this.mouse = { dx: 0, dy: 0 };  // accumulated radians this frame
    this.locked = false;

    this.pad = null;                // Gamepad or null
    this.usesPad = false;           // last device used (HUD hint)
    this.confirm = false;           // menu-confirm edge (click / A / Enter)

    this.prevAction = {};           // action → down last frame
    this.actionPressed = {};        // action → edge this frame
    for (const a of Object.keys(B)) this.prevAction[a] = false;

    this.padPrev = new Array(20).fill(false);
    this.wheel = 0;                 // XMB scroll (+1 / -1 steps)

    // raw per-button pad edges for gameplay routing — independent of the
    // XMB's consume-on-read padEdge() and of the action bindings
    this.padNow = new Array(20).fill(false);
    this.padEdges = new Set();      // buttons that went down this frame
    this.padEaten = new Set();      // buttons whose edge was consumed
    this._padA = false;             // pad-A level, for the confirm edge
  }

  /* ------------------------------------------------------------------ */
  init() {
    window.addEventListener('keydown', (e) => {
      if (e.repeat) return;
      if (['Space', 'Tab', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
      this.keys.add(e.code);
      this.usesPad = false;
      if (e.code === 'Enter' || e.code === 'Space') this.confirm = true;
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => {
      this.keys.clear(); this.mouseDown.clear();
    });

    window.addEventListener('mousedown', (e) => {
      this.mouseDown.add('Mouse' + e.button);
      if (e.button === 0) this.confirm = true;
      this.usesPad = false;
    });
    window.addEventListener('mouseup', (e) => this.mouseDown.delete('Mouse' + e.button));
    window.addEventListener('contextmenu', (e) => e.preventDefault());

    window.addEventListener('mousemove', (e) => {
      if (!this.locked) return;
      const s = ASSETS.controls.mouseSens;
      this.mouse.dx += e.movementX * s;
      this.mouse.dy += e.movementY * s;
    });

    window.addEventListener('wheel', (e) => {
      this.wheel += Math.sign(e.deltaY);
    }, { passive: true });

    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === this.canvas;
    });

    window.addEventListener('gamepadconnected', (e) => {
      this.pad = e.gamepad;
      this.usesPad = true;
      if (this.onPadConnected) this.onPadConnected(e.gamepad.id);
    });
    window.addEventListener('gamepaddisconnected', (e) => {
      if (this.pad && this.pad.index === e.gamepad.index) this.pad = null;
    });
  }

  requestLock() {
    if (this.canvas.requestPointerLock) {
      const p = this.canvas.requestPointerLock();
      if (p && p.catch) p.catch(() => {}); // browser cooldown after Esc
    }
  }
  releaseLock() {
    if (document.exitPointerLock) document.exitPointerLock();
  }

  /* ------------------------------------------------------------------ */
  /* called once per frame BEFORE the game update                        */
  poll(dt) {
    // -- gamepad -------------------------------------------------------
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    let gp = null;
    for (const p of pads) if (p && p.connected) { gp = p; break; }
    this.pad = gp;
    const btn = (i) => gp && gp.buttons[i] &&
      (gp.buttons[i].pressed || gp.buttons[i].value > 0.4);

    // raw pad edges (CH-01.1) — btn 2 = controller X context-interact
    this.padEdges.clear(); this.padEaten.clear();
    for (let i = 0; i < 20; i++) {
      const down = !!(gp && gp.buttons[i] &&
        (gp.buttons[i].pressed || gp.buttons[i].value > 0.4));
      if (down && !this.padNow[i]) this.padEdges.add(i);
      this.padNow[i] = down;
    }

    // -- resolve actions (keyboard ∪ mouse ∪ pad) ----------------------
    for (const action of Object.keys(B)) {
      let down = false;
      for (const code of B[action]) {
        if (typeof code === 'number') { if (btn(code)) down = true; }
        else if (this.keys.has(code)) down = true;
        else if (code.startsWith('Mouse')) { if (this.mouseDown.has(code)) down = true; }
      }
      this.actionPressed[action] = down && !this.prevAction[action];
      this.prevAction[action] = down;
      this[action + 'Down'] = down; // e.g. this.fireDown
    }

    // menu confirm via pad A (edge — HOLDING A must not repeat-fire UI)
    if (btn(0) && !this._padA) this.confirm = true;
    this._padA = !!btn(0);

    // -- stick look → accumulate radians (mouse already accumulated) ----
    if (gp) {
      const C = ASSETS.controls;
      const [lx, ly] = this.stick(gp, 0, 1);
      const [rx, ry] = this.stick(gp, 2, 3);
      this.move = { x: lx, z: ly };
      if (rx || ry) {
        this.usesPad = true;
        this.mouse.dx += Math.abs(rx) ** C.lookCurve * Math.sign(rx) * C.stickSens * dt;
        const iy = C.invertY ? -1 : 1;
        this.mouse.dy += Math.abs(ry) ** C.lookCurve * Math.sign(ry) * C.stickSens * dt * iy;
      }
    } else {
      this.move = { x: 0, z: 0 };
    }

    // keyboard move (overrides stick if pressed)
    let kx = 0, kz = 0;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp'))    kz -= 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown'))  kz += 1;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft'))  kx -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) kx += 1;
    if (kx || kz) {
      const m = Math.hypot(kx, kz);
      this.move = { x: kx / m, z: kz / m };
      this.usesPad = false;
    }
  }

  /* radial deadzone + curve for one stick */
  stick(gp, ax, ay) {
    const C = ASSETS.controls;
    let x = gp.axes[ax] || 0, y = gp.axes[ay] || 0;
    const m = Math.hypot(x, y);
    if (m < C.deadzone) return [0, 0];
    const s = (m - C.deadzone) / (1 - C.deadzone) / m;
    return [x * s, y * s];
  }

  /* -- gamepad raw edges (XMB navigation) ------------------------------ */
  /* consume-on-read: first caller this frame gets the edge               */
  padEdge(i) {
    if (!this.pad || !this.pad.buttons[i]) return false;
    const b = this.pad.buttons[i];
    const down = !!(b.pressed || b.value > 0.4);
    const edge = down && !this.padPrev[i];
    this.padPrev[i] = down;
    return edge;
  }
  commitPadPrev() {}

  /* -- raw gameplay pad edges (NOT the XMB's padEdge) ------------------- */
  /* padBtnPressed(i): true the frame button i went down, stays true      */
  /* until consumePadBtn(i) eats it — the first system to claim the press */
  /* wins, so two actions can never fire from one button (CH-01.1).       */
  padBtnPressed(i) {
    return this.padEdges.has(i) && !this.padEaten.has(i);
  }
  consumePadBtn(i) {
    if (this.padEdges.has(i)) this.padEaten.add(i);
  }

  /* -- per-frame consumption ------------------------------------------ */
  consumeLook() {
    const d = { dx: this.mouse.dx, dy: this.mouse.dy };
    this.mouse.dx = 0; this.mouse.dy = 0;
    return d;
  }
  consumeConfirm() { const c = this.confirm; this.confirm = false; return c; }
  consumeWheel()   { const w = this.wheel; this.wheel = 0; return w; }

  down(action)    { return !!this[action + 'Down']; }
  pressed(action) { return !!this.actionPressed[action]; }
  hasPad()        { return !!this.pad; }
  padName()       { return this.pad ? this.pad.id : null; }
}

/* ============================================================================
   FRAME SCAPE — hud.js  (v0.8.0)
   ----------------------------------------------------------------------------
   DOM-based HUD:
     · TOP-LEFT    motion tracker · wallet · DAY/NIGHT clock chip
     · TOP-CENTER  objective line · status chips (CLOAKED / STOWED / DOWN)
     · TOP-RIGHT   player shield + OVERSHIELD layer + health; friendly bars
     · BOTTOM-RIGHT weapon + ammo, grenades, ENERGY, FOUR SPECIAL SLOTS
   XMB columns: WEAPONS (X = sell) · EQUIPMENT · COMPANIONS · MOD·GUNS ·
   MOD·FRAME · MOD·COMPANION · MOD·COMPANION WEAPON · MOD·HEAVY (launcher
   only — CH-04) · MOD·DUPES · ABILITY · SALVAGE (materials) · SPAWN AREA ·
   SAVESTATE · RESET AREA · ENEMY LVLS · CONTROLS.
   Scrapping / selling goes through a CONFIRM dialog — focus starts on
   CANCEL; A/Enter activates the focused button, B/Esc always cancels.
   ==========================================================================*/

import { ASSETS } from './assets.js';
import { Mods, fmtFull, fmtCR } from './mods.js';
import { drawShuttleArt } from './textures.js';   /* CH-36.1 — loading-screen art */

const $ = (id) => document.getElementById(id);

const RADAR_HZ = 8;
const COL_W = 164;          // xmb column pitch (width 150 + gap)

export class Hud {
  constructor(game) {
    this.game = game;
    this.el = {
      hud:        $('hud'),
      shieldFill: $('shieldfill'),
      shieldWrap: $('shieldwrap'),
      healthWrap: $('healthwrap'),
      healthFill: $('healthfill'),
      energyWrap: $('energywrap'),
      energyFill: $('energyfill'),
      mag:        $('ammomag'),
      reserve:    $('ammoreserve'),
      wname:      $('wname'),
      grenades:   $('grenades'),
      objective:  $('objective'),
      dayclock:   $('dayclock'),
      statuschips: $('statuschips'),
      osFill:     $('osfill'),
      credits:    $('credits'),
      powerbank:  $('powerbank'),
      radarrange: $('radarrange'),
      droneBar:   $('dronebar'),
      droneHp:    $('dronehp'),
      droneSh:    $('dronesh'),
      petBar:     $('petbar'),
      petHp:      $('pethp'),
      petSh:      $('petsh'),
      slotEls:    [0, 1, 2, 3].map((i) => $('slot' + i)),
      slotName:   $('slotname'),
      crosshair:  $('crosshair'),
      hitmarker:  $('hitmarker'),
      target:     $('targetinfo'),
      pickupfeed: $('pickupfeed'),
      radar:      $('radar'),
      prompt:     $('prompt'),
      toast:      $('toast'),
      vignette:   $('vignette'),
      whiteflash: $('whiteflash'),
      scope:      $('scope'),
      scopezoom:  $('scopezoom'),
      vats:       $('vats'),
      vatsBrackets: [0, 1, 2, 3, 4, 5].map((i) => $('vb' + i)),
      fps:        $('fps'),
      padchip:    $('padchip'),
      menu:       $('menu'),
      pause:      $('pause'),
      dead:       $('dead'),
      win:        $('win'),
      winStats:   $('winstats'),
      menuVer:    $('menuver'),
      xmb:        $('xmb'),
      xmbCols:    $('xmb-cols'),
      xmbCardT:   $('xmb-card-title'),
      xmbCardD:   $('xmb-card-desc'),
      xmbVer:     document.querySelector('.xmb-ver'),
    };
    this.rctx = this.el.radar.getContext('2d');
    /* CH-05.2 — beast locker-channel ring: a small 2D canvas centered on
       the reticle, built HERE (no index.html / hud.css edits needed — the
       ring is HUD-only and exists only while the beast channels a
       locker; 2D-canvas arcs stay inside the HD 3000 budget). */
    const chan = document.createElement('canvas');
    chan.width = 72; chan.height = 72;
    chan.style.cssText = 'position:absolute;left:50%;top:50%;width:72px;height:72px;' +
      'margin:-36px 0 0 -36px;display:none;pointer-events:none;';
    this.el.hud.appendChild(chan);
    this.chanCv = chan;
    this.chanCtx = chan.getContext('2d');
    this._chanOn = false;
    this.vignA = 0;
    this.whiteA = 0;
    this.hitT = 0;
    this.toastTimer = null;
    this.radarAcc = 0;
    this.lastAmmo = '';
    this.lastShield = -1;
    this.lastHealth = -1;
    this.lastEnergy = -1;
    this.lastGren = '';
    this.lastSlots = '';
    this.lastCr = -1;
    this.lastPw = -1;
    this.lastRadarR = -1;
    this.lastFriend = '';
    this.lastOs = '';
    this.lastChips = '';
    // XMB
    this.xmbOpen = false;
    this.xcol = 0;
    this.xrow = 0;
    this.cols = [];
    // generic confirm dialog (CH-01.2)
    this.confirmOpen = false;
    this.confirmEl = null;
    this.confirmOnOk = null;
    this.confirmFocus = 'no';      // default focus = CANCEL
    this._cfmLR = false;
    this._cfmBs = false;
    if (this.el.xmbVer) this.el.xmbVer.textContent = ASSETS.meta.version;
    if (this.el.menuVer) this.el.menuVer.textContent = `v${ASSETS.meta.version}`;
  }

  setState(state) {
    const e = this.el;
    const show = (el, on) => el && el.classList.toggle('hidden', !on);
    show(e.menu,  state === 'menu');
    show(e.pause, state === 'paused');
    show(e.dead,  state === 'dead');
    show(e.win,   state === 'win');
    /* CH-36.1 — 'loading' shows the dimmed hud under the full-screen
       loading overlay (the overlay manages its own visibility) */
    show(e.hud,   state !== 'menu');
    e.hud.classList.toggle('dimmed', state !== 'playing');
    e.xmb.classList.toggle('hidden', state !== 'xmb');
    if (state !== 'playing') { e.scope.classList.remove('on'); e.vats.classList.remove('on'); }
  }

  setScope(kind) {
    this.el.scope.classList.toggle('on', !!kind);
    if (kind) this.el.scopezoom.textContent = kind === 'srs' ? '4X' : '2X';
  }

  setObjective(t) {
    if (this.el.objective.textContent === t) return;
    this.el.objective.textContent = t;
  }

  setClock(phase, time) {
    const t = phase + ' · ' + time;
    if (this.el.dayclock && this.el.dayclock.textContent !== t) {
      this.el.dayclock.textContent = t;
      this.el.dayclock.dataset.phase = phase;
    }
  }

  /* -- per-frame DOM updates (writes only on change) ------------------------- */
  update(dt) {
    const g = this.game;
    if (g.state === 'playing' || g.state === 'xmb') {
      // shield + health (top-right)
      const s = Math.round(g.player.shield);
      if (s !== this.lastShield) {
        this.lastShield = s;
        this.el.shieldFill.style.transform = `scaleX(${g.player.shield / ASSETS.player.shield})`;
        this.el.shieldWrap.classList.toggle('low', s <= 25);
        this.el.shieldWrap.classList.toggle('regen', g.player.regening);
      }
      const h = Math.round(g.player.health);
      if (h !== this.lastHealth) {
        this.lastHealth = h;
        this.el.healthFill.style.transform = `scaleX(${h / ASSETS.player.healthMax})`;
        this.el.healthWrap.classList.toggle('hurt', h < ASSETS.player.healthMax);
      }
      // overshield layer (above the shield bar)
      const os = g.player.overshieldT > 0 ? g.player.overshield : 0;
      const osKey = Math.round(os) + '|' + Math.ceil(g.player.overshieldT || 0);
      if (osKey !== this.lastOs) {
        this.lastOs = osKey;
        this.el.osFill.style.transform =
          `scaleX(${Math.max(0, os / ASSETS.overshield.amount)})`;
        this.el.osFill.style.opacity = os > 0 ? '1' : '0';
      }
      // status chips (CLOAKED / STOWED / KNOCKED DOWN)
      const chips =
        (g.player.invisT > 0 ? 'C' : '') +
        (g.weapon.stowed ? 'S' : '') +
        (g.player.knockT >= 0 ? 'K' : '');
      if (chips !== this.lastChips) {
        this.lastChips = chips;
        const bits = [];
        if (chips.includes('C')) bits.push('<span class="chip cloak">CLOAKED ' + Math.ceil(g.player.invisT) + 's</span>');
        if (chips.includes('S')) bits.push('<span class="chip stow">STOWED</span>');
        if (chips.includes('K')) bits.push('<span class="chip knock">KNOCKED DOWN</span>');
        this.el.statuschips.innerHTML = bits.join('');
      }
      // friendly bars (drone + beast, under the player's)
      const cp = g.companions;
      const fr = cp ? JSON.stringify([
        cp.droneEnabled, cp.drone ? cp.drone.hp : -1, cp.drone ? cp.drone.shield : -1,
        cp.petEnabled, cp.pet ? cp.pet.hp : -1, cp.pet ? cp.pet.shield : -1,
      ]) : 'x';
      if (fr !== this.lastFriend) {
        this.lastFriend = fr;
        const setBar = (bar, hpEl, shEl, enabled, st, max) => {
          bar.classList.toggle('hidden', !enabled);
          if (!enabled || !st) return;
          hpEl.style.transform = `scaleX(${Math.max(0, st.hp / max.hp)})`;
          shEl.style.transform = `scaleX(${Math.max(0, st.shield / max.shield)})`;
        };
        setBar(this.el.droneBar, this.el.droneHp, this.el.droneSh,
          cp && cp.droneEnabled, cp && cp.drone, ASSETS.companions.drone);
        setBar(this.el.petBar, this.el.petHp, this.el.petSh,
          cp && cp.petEnabled, cp && cp.pet, ASSETS.companions.pet);
      }
      const en = Math.round(g.player.energy);
      if (en !== this.lastEnergy) {
        this.lastEnergy = en;
        this.el.energyFill.style.transform = `scaleX(${g.player.energy / ASSETS.energy.max})`;
        this.el.energyWrap.classList.toggle('paid', en < ASSETS.energy.max);
      }
      // ammo + weapon name
      const pool = g.ammo;
      const a = `${g.weapon.mag}|${pool[g.weapon.def.ammo]}|${g.weapon.def.name}`;
      if (a !== this.lastAmmo) {
        this.lastAmmo = a;
        this.el.mag.textContent = g.weapon.mag;
        this.el.reserve.textContent = '/' + pool[g.weapon.def.ammo];
        this.el.mag.classList.toggle('empty', g.weapon.mag === 0);
        this.el.wname.textContent = `${g.weapon.def.name} · ${ASSETS.ammoPools[g.weapon.def.ammo].label}`;
      }
      // grenades + 4 special slots
      const gr = 'g' + g.specials.grenades;
      if (gr !== this.lastGren) {
        this.lastGren = gr;
        this.el.grenades.textContent = '✦ ' + g.specials.grenades;
      }
      const slotKey = g.specials.slots.join(',') + '|' + g.specials.slotIdx +
        '|' + g.specials.slots.map((id) => Math.ceil((g.specials.cd[id] || 0) * 4)).join(',');
      if (slotKey !== this.lastSlots) {
        this.lastSlots = slotKey;
        g.specials.slots.forEach((id, i) => {
          const box = this.el.slotEls[i];
          const def = ASSETS.specials.list.find((x) => x.id === id);
          if (!def || !box) return;
          box.querySelector('.sglyph').textContent = def.glyph;
          box.querySelector('.scost').textContent = def.energy ? def.energy + 'e' : '';
          const active = i === g.specials.slotIdx;
          box.classList.toggle('act', active);
          const cd = Math.max(0, g.specials.cd[id] || 0);
          const fill = box.querySelector('.scdfill');
          fill.style.transform = `scaleX(${def.cd > 0 && cd > 0 ? Math.max(0, cd / def.cd) : 0})`;
          box.classList.toggle('ready', cd <= 0);
        });
        const actDef = ASSETS.specials.list.find((x) => x.id === g.specials.equipped);
        this.el.slotName.textContent = actDef ? `${actDef.name} · HOLD ◀▶ TO CYCLE` : '';
      }
      // wallet (credits + power) — pulse on gain
      const cr = Math.round(g.mods.credits);
      if (cr !== this.lastCr) {
        const up = this.lastCr > -1 && cr > this.lastCr;
        this.lastCr = cr;
        this.el.credits.textContent = '⌾ ' + fmtFull(cr) + ' CR';
        if (up) {
          this.el.credits.classList.remove('gain');
          void this.el.credits.offsetWidth;
          this.el.credits.classList.add('gain');
        }
      }
      const pw = Math.round(g.mods.power);
      if (pw !== this.lastPw) {
        const up = this.lastPw > -1 && pw > this.lastPw;
        this.lastPw = pw;
        this.el.powerbank.textContent = '⚡ ' + fmtFull(pw) + ' PW';
        if (up) {
          this.el.powerbank.classList.remove('gain');
          void this.el.powerbank.offsetWidth;
          this.el.powerbank.classList.add('gain');
        }
      }
      // target info (with zone level)
      if (g.currentTarget) {
        const d = Math.round(g.currentTarget.dist);
        const lvl = g.currentTarget.lvl ? ' · L' + g.currentTarget.lvl : '';
        this.el.target.textContent = `${g.currentTarget.name}${lvl} — ${d} m`;
        this.el.target.classList.add('on');
        this.el.crosshair.classList.add('enemy');
      } else {
        /* CH-05.2 — a designated SUPPLY LOCKER takes the target line when
           no enemy is under the reticle (teaches the beast-only rule) */
        const ld = g.companions && g.companions.lockerDesignated;
        if (ld && g.state === 'playing') {
          this.el.target.textContent = `SUPPLY LOCKER — ${Math.round(ld.dist)} m · BEAST ONLY`;
          this.el.target.classList.add('on');
          this.el.crosshair.classList.remove('enemy');
        } else {
          this.el.target.classList.remove('on');
          this.el.crosshair.classList.remove('enemy');
        }
      }
      // CH-05.2 — beast channel ring (reticle-centered progress arc).
      // NOTE: `cp` (= g.companions) is already declared above for the
      // friendly-bars block — reuse it, do not redeclare.
      const chL = cp && cp.petChannelLocker;
      if (chL && g.state === 'playing') {
        const frac = Math.max(0, Math.min(1, cp.petChannelT / Math.max(0.001, cp.petChannelDur)));
        this.drawChannelRing(frac);
      } else {
        this.hideChannelRing();
      }
      // radar at fixed rate
      this.radarAcc += dt;
      if (this.radarAcc > 1 / RADAR_HZ) { this.radarAcc = 0; this.drawRadar(); }
      // VATS brackets
      this.updateVats();
    }

    // decay fx layers
    if (g.state !== 'playing') this.hideChannelRing();   /* CH-05.2 — ring off in menus/pause */
    if (this.vignA > 0.005) {
      this.vignA *= Math.exp(-3.2 * dt);
      this.el.vignette.style.opacity = this.vignA.toFixed(3);
    }
    if (this.whiteA > 0.005) {
      this.whiteA *= Math.exp(-4.5 * dt);
      this.el.whiteflash.style.opacity = this.whiteA.toFixed(3);
    }
    if (this.hitT > 0) {
      this.hitT -= dt;
      if (this.hitT <= 0) this.el.hitmarker.classList.remove('on');
    }
  }

  /* -- CH-05.2 — beast locker-channel ring (2D canvas, reticle-centered) ------ */
  drawChannelRing(frac) {
    const x = this.chanCtx;
    if (!this._chanOn) { this.chanCv.style.display = 'block'; this._chanOn = true; }
    x.clearRect(0, 0, 72, 72);
    x.lineWidth = 5;
    x.strokeStyle = 'rgba(89, 242, 255, 0.18)';
    x.beginPath(); x.arc(36, 36, 27, 0, Math.PI * 2); x.stroke();
    x.strokeStyle = ASSETS.palette.energy;
    x.beginPath();
    x.arc(36, 36, 27, -Math.PI / 2, -Math.PI / 2 + frac * Math.PI * 2);
    x.stroke();
  }
  hideChannelRing() {
    if (this._chanOn) { this.chanCv.style.display = 'none'; this._chanOn = false; }
  }

  /* -- VATS targeting brackets ------------------------------------------------ */
  updateVats() {
    const g = this.game;
    const on = g.player && g.player.vatsActive && g.state === 'playing';
    this.el.vats.classList.toggle('on', !!on);
    if (!on) {
      for (const b of this.el.vatsBrackets) b.classList.remove('on', 'lock');
      return;
    }
    const cam = g.camera;
    const w = window.innerWidth, hgt = window.innerHeight;
    const v = new (cam.position.constructor)();
    for (let i = 0; i < this.el.vatsBrackets.length; i++) {
      const b = this.el.vatsBrackets[i];
      const t = g.vatsTargets && g.vatsTargets[i];
      if (!t || !t.alive) { b.classList.remove('on', 'lock'); continue; }
      v.set(t.group.position.x, t.group.position.y + (t.fly ? 0 : 0.9), t.group.position.z);
      v.project(cam);
      if (v.z > 1 || v.z < -1) { b.classList.remove('on', 'lock'); continue; }
      const x = (v.x * 0.5 + 0.5) * w;
      const y = (-v.y * 0.5 + 0.5) * hgt;
      b.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px)`;
      b.classList.add('on');
      const isLock = g.currentTarget && g.currentTarget.ref === t;
      b.classList.toggle('lock', !!isLock);
      b.firstElementChild.textContent =
        (isLock ? '◉ LOCK · R1' : '') + ' ' + t.arch.name + ' L' + t.level + ' ' + Math.max(0, Math.round(t.hp));
    }
  }

  /* -- radar (range = drone RADAR UPLINK mod: 10 m → 90 m) --------------------- */
  drawRadar() {
    const g = this.game;
    const ctx = this.rctx;
    const size = this.el.radar.width;
    const c = size / 2, R = c - 4;
    const range = Math.max(6, ASSETS.companions.drone.radar);
    if (range !== this.lastRadarR) {
      this.lastRadarR = range;
      this.el.radarrange.textContent = range + ' m';
    }
    const scale = R / range;
    ctx.clearRect(0, 0, size, size);

    ctx.fillStyle = 'rgba(8, 18, 28, 0.72)';
    ctx.beginPath(); ctx.arc(c, c, R, 0, 7); ctx.fill();
    ctx.strokeStyle = 'rgba(120, 200, 255, 0.5)';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(c, c, R, 0, 7); ctx.stroke();
    ctx.strokeStyle = 'rgba(120, 200, 255, 0.18)';
    ctx.lineWidth = 1;
    for (const rr of [R / 3, (2 * R) / 3]) {
      ctx.beginPath(); ctx.arc(c, c, rr, 0, 7); ctx.stroke();
    }
    ctx.beginPath(); ctx.moveTo(c, 4); ctx.lineTo(c, size - 4);
    ctx.moveTo(4, c); ctx.lineTo(size - 4, c); ctx.stroke();

    ctx.fillStyle = 'rgba(190, 235, 255, 0.9)';
    ctx.beginPath();
    ctx.moveTo(c, c - 6); ctx.lineTo(c - 4.5, c + 5); ctx.lineTo(c + 4.5, c + 5);
    ctx.closePath(); ctx.fill();

    const yaw = g.player.yaw;
    const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
    const rx = Math.cos(yaw),  rz = -Math.sin(yaw);
    /* CH-08.2 — radar treats the city corridor connectors correctly: a
       hostile on the OTHER side of a connector shell (one of you under a
       roof, the other not — or both under different roofs) reads dimmed:
       the uplink sees it, the wall still counts. Same-shell contacts stay
       full brightness. */
    const pc = g.world.corridorAt(g.player.pos.x, g.player.pos.z);
    const blip = (wx, wz, color, rad = 3.2, a = 1) => {
      const dx = wx - g.player.pos.x;
      const dz = wz - g.player.pos.z;
      const d = Math.hypot(dx, dz);
      if (d > range) return;
      let px = (dx * rx + dz * rz) * scale;
      let py = -(dx * fx + dz * fz) * scale;
      const m = Math.hypot(px, py);
      if (m > R - 4) { px *= (R - 4) / m; py *= (R - 4) / m; }
      ctx.globalAlpha = a;
      ctx.fillStyle = color;
      ctx.beginPath(); ctx.arc(c + px, c + py, rad, 0, 7); ctx.fill();
      ctx.globalAlpha = 1;
    };
    for (const e of g.enemies) {
      if (!e.alive) continue;
      const ec = g.world.corridorAt(e.group.position.x, e.group.position.z);
      const dimmed = (!!pc !== !!ec) || (pc && ec && pc !== ec);
      blip(e.group.position.x, e.group.position.z,
        e.arch.elite ? '#ffd24f' : '#ff5340', 3.2, dimmed ? 0.35 : 1);
    }
    // friendly blips
    const cp = g.companions;
    if (cp && cp.drone) blip(cp.drone.pos.x, cp.drone.pos.z, '#59f2ff', 2.6);
    if (cp && cp.pet) blip(cp.pet.group.position.x, cp.pet.group.position.z, '#ff9d5e', 2.6);
  }

  /* -- fx helpers --------------------------------------------------------------- */
  hitFlash(a)   { this.vignA = Math.max(this.vignA, a); }
  flashWhite(a = 0.55) { this.whiteA = Math.max(this.whiteA, a); }
  hitmarker()   { this.el.hitmarker.classList.add('on'); this.hitT = 0.1; }

  setPrompt(t) {
    if (this.el.prompt.textContent === t) return;
    this.el.prompt.textContent = t;
    this.el.prompt.classList.toggle('on', !!t);
  }

  /* -- pickup feed: small letters UNDER THE RETICLE, toward the bottom ---- */
  pickup(text) {
    if (!this.el.pickupfeed) return;
    const line = document.createElement('div');
    line.className = 'pickline';
    line.textContent = text;
    this.el.pickupfeed.appendChild(line);
    while (this.el.pickupfeed.children.length > 4) {
      this.el.pickupfeed.removeChild(this.el.pickupfeed.firstChild);
    }
    setTimeout(() => {
      line.classList.add('out');
      setTimeout(() => line.remove(), 450);
    }, 2000);
  }

  toast(text, ms = 1900) {
    this.el.toast.textContent = text;
    this.el.toast.classList.add('on');
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => this.el.toast.classList.remove('on'), ms);
  }

  padChip(on, name = '') {
    this.el.padchip.classList.toggle('on', on);
    if (on) this.el.padchip.textContent = '⨂ ' + name.slice(0, 34);
  }

  showFps(on, fps = 0) {
    this.el.fps.classList.toggle('on', on);
    if (on) this.el.fps.textContent = fps.toFixed(0) + ' FPS';
  }

  /* ==============================================================================
     CH-36.1 — EXTRACT LOADING SCREEN. A full-screen overlay with a
     procedural SPACE SHUTTLE scene drawn per-frame into a plain 2D canvas
     (drawShuttleArt in textures.js — no video, no WebGL: the game loop is
     paused in the 'loading' state while this plays) + a progress readout
     with staged status lines. The port() callback fires when the bar
     completes. CH-47 DEPLOY reuses this exact flow in reverse (hub →
     loading → mission site), so the shape is data-driven: {title, sub,
     lines, duration, tip, port}. Built as DOM here — index.html / hud.css
     untouched (confirm-dialog precedent).
     ============================================================================== */
  ensureLoading() {
    if (this.loadingEl) return;
    const LC = ASSETS.hub.loading;
    const wrap = document.createElement('div');
    wrap.style.cssText =
      'position:fixed;inset:0;z-index:70;display:none;flex-direction:column;' +
      'align-items:center;justify-content:center;gap:14px;' +
      "background:#04070c;color:#bfe9ff;font-family:Consolas,'Courier New',monospace;";
    /* art canvas — 640×360 internal, scaled to fit */
    const art = document.createElement('canvas');
    art.width = 640; art.height = 360;
    art.style.cssText = 'width:min(92vw,640px);aspect-ratio:16/9;' +
      'border:1px solid rgba(79,195,255,0.35);box-shadow:0 0 34px rgba(79,195,255,0.18);';
    /* title + sub */
    const title = document.createElement('div');
    title.style.cssText = 'font-size:22px;font-weight:700;letter-spacing:0.34em;color:#eaf6ff;' +
      'text-shadow:0 0 12px rgba(79,195,255,0.6);margin-top:4px;';
    title.textContent = LC.title;
    const sub = document.createElement('div');
    sub.style.cssText = 'font-size:11px;letter-spacing:0.22em;opacity:0.6;';
    sub.textContent = LC.sub;
    /* progress bar */
    const barWrap = document.createElement('div');
    barWrap.style.cssText = 'width:min(92vw,640px);height:10px;border:1px solid rgba(79,195,255,0.5);' +
      'background:rgba(79,195,255,0.06);padding:1px;';
    const bar = document.createElement('div');
    bar.style.cssText = 'height:100%;width:0%;background:linear-gradient(90deg,#2b6f8f,#59f2ff);' +
      'box-shadow:0 0 10px rgba(89,242,255,0.7);';
    barWrap.appendChild(bar);
    /* status line + pct */
    const status = document.createElement('div');
    status.style.cssText = 'font-size:12px;letter-spacing:0.2em;min-height:16px;color:#9fd4ee;';
    const pct = document.createElement('div');
    pct.style.cssText = 'font-size:11px;letter-spacing:0.3em;opacity:0.75;';
    /* tip */
    const tip = document.createElement('div');
    tip.style.cssText = 'font-size:10px;letter-spacing:0.14em;opacity:0.42;max-width:min(88vw,560px);' +
      'text-align:center;line-height:1.7;margin-top:6px;';
    tip.textContent = LC.tip;
    wrap.appendChild(art); wrap.appendChild(title); wrap.appendChild(sub);
    wrap.appendChild(barWrap); wrap.appendChild(status); wrap.appendChild(pct);
    wrap.appendChild(tip);
    document.body.appendChild(wrap);
    this.loadingEl = wrap;
    this.loadingArt = art;
    this.loadingCtx = art.getContext('2d');
    this.loadingBar = bar;
    this.loadingStatus = status;
    this.loadingPct = pct;
  }

  showLoading({ title, sub, lines, duration, tip, port }) {
    this.ensureLoading();
    const g = this.game;
    g.state = 'loading';                 // frame() pauses the sim, keeps rendering
    g.hud.setState('loading');
    g.input.releaseLock();
    this.loadingEl.style.display = 'flex';
    this.setPrompt('');                    /* CH-36.1 — clear stale interact text */
    if (title) this.loadingEl.children[1].textContent = title;
    if (sub) this.loadingEl.children[2].textContent = sub;
    if (tip) this.loadingEl.children[6].textContent = tip;
    this._loadT0 = performance.now();
    this._loadDur = (duration || ASSETS.hub.loading.duration) * 1000;
    this._loadLines = lines || ASSETS.hub.loading.lines;
    this._loadPort = port || null;
    g.sfx.uiConfirm();
    const step = () => {
      if (!this._loadPort) return;                       // cancelled
      const t = (performance.now() - this._loadT0) / 1000;
      const k = Math.min(1, t * 1000 / this._loadDur);
      drawShuttleArt(this.loadingCtx, this.loadingArt.width, this.loadingArt.height, t);
      this.loadingBar.style.width = (k * 100).toFixed(1) + '%';
      const idx = Math.min(this._loadLines.length - 1,
        Math.floor(k * this._loadLines.length));
      const dots = '·'.repeat(1 + (Math.floor(t * 2.4) % 3));
      this.loadingStatus.textContent = this._loadLines[idx] + ' ' + dots;
      this.loadingPct.textContent = Math.round(k * 100) + ' %';
      if (k < 1) {
        this._loadRaf = requestAnimationFrame(step);
        return;
      }
      /* done — hide, then hand the destination to the caller */
      const port = this._loadPort;
      this._loadPort = null;
      cancelAnimationFrame(this._loadRaf);
      this.loadingEl.style.display = 'none';
      port();
    };
    this._loadRaf = requestAnimationFrame(step);
  }

  cancelLoading() {                      // safety: death/menu can't leak a port
    if (this._loadPort) {
      this._loadPort = null;
      cancelAnimationFrame(this._loadRaf);
      if (this.loadingEl) this.loadingEl.style.display = 'none';
    }
  }

  fillWinStats() {
    const w = this.game.weapon.stats;
    const acc = w.shots ? Math.round((w.hits / w.shots) * 100) : 0;
    const t = this.game.time;
    const mm = String(Math.floor(t / 60)).padStart(2, '0');
    const ss = String(Math.floor(t % 60)).padStart(2, '0');
    this.el.winStats.innerHTML =
      `TIME&nbsp;&nbsp;<b>${mm}:${ss}</b><br>` +
      `KILLS&nbsp;<b>${w.kills}</b><br>` +
      `ACCURACY&nbsp;<b>${acc}%</b><br>` +
      `CREDITS EARNED&nbsp;&nbsp;<b>${fmtFull(this.game.mods.earned)}</b><br>` +
      `POWER EARNED&nbsp;&nbsp;<b>${fmtFull(this.game.mods.earnedPower)}</b>`;
  }

  /* ==============================================================================
     XMB GRID MENU — selected column lives CENTER SCREEN
     ============================================================================== */
  buildXmbCols() {
    const g = this.game;
    const S = g.specials;
    const W = g.weapon;
    const cp = g.companions;
    const slotIdx = S.slotIdx;

    const wItems = ASSETS.weapons.map((d, i) => ({
      label: d.name,
      sub: !W.isUnlocked(i) ? 'LOCKED'
        : `${W.guns[i].mag} / ${g.ammo[d.ammo]}`,
      mark: W.cur === i,
      dis: !W.isUnlocked(i),
      _weaponIdx: i,
      desc: !W.isUnlocked(i)
        ? `LOCKED — scavenge ${ASSETS.ammoPools[d.ammo].label} (drops or breakable supply boxes) to bring the ${d.name} online.`
        : `${d.type.toUpperCase()} · ${d.damage} dmg${d.pellets ? ' ×' + d.pellets : ''} · mag ${d.mag} · ` +
          (d.ads.scope ? 'SCOPE ' + (d.ads.scope === 'srs' ? '4×' : '2×') : 'M6P-STYLE ZOOM (no scope)') +
          ` · ADS recoil ×${d.ads.recoilMult}` +
          /* CH-25.2 — typed profile + crit/status stat readout */
          (d.types ? ` · ${Object.keys(d.types).map((t) => t.toUpperCase()).join('/')}` : '') +
          (d.critChance ? ` · CRIT ${Math.round(d.critChance * 100)}% ×${d.critMult}` : '') +
          (d.statusChance ? ` · STATUS ${Math.round(d.statusChance * 100)}%${d.pellets ? '/PELLET' : ''}` : '') +
          (W.sellValue(i) ? ` · PRESS X HERE TO SELL FOR ${fmtCR(W.sellValue(i))} CR` : ''),
      run() { W.selectWeapon(i, g); },
    }));

    /* EQUIPMENT — 4 R2 slots + assignment */
    const eqItems = [];
    eqItems.push({ _sep: 'ACTIVE SLOT · R2 FIRES IT' });
    for (let i = 0; i < S.slots.length; i++) {
      const def = ASSETS.specials.list.find((x) => x.id === S.slots[i]);
      eqItems.push({
        label: `SLOT ${i + 1}`,
        sub: def ? def.glyph + ' ' + def.name.split(' ')[0] : '—',
        mark: S.slotIdx === i,
        desc: `Slot ${i + 1} of 4. Selecting it makes it the R2 slot. HOLD D-pad ◀▶ in combat to cycle.`,
        run() { S.slotIdx = i; g.sfx.navBig(); },
      });
    }
    eqItems.push({ _sep: 'ASSIGN TO ACTIVE SLOT' });
    for (const def of ASSETS.specials.list) {
      eqItems.push({
        label: def.name,
        sub: def.energy ? def.energy + 'e' : (def.toggle ? 'TGL' : '—'),
        mark: S.slots[slotIdx] === def.id,
        /* CH-25.2 — typed profile + crit/status on damage-dealing specials */
        desc: def.desc + ` — assigns to SLOT ${slotIdx + 1}.` +
          (def.types ? ` ${Object.keys(def.types).map((t) => t.toUpperCase()).join('/')}.` : '') +
          (def.critChance ? ` CRIT ${Math.round(def.critChance * 100)}% ×${def.critMult}.` : '') +
          (def.statusChance ? ` STATUS ${Math.round(def.statusChance * 100)}%.` : ''),
        run() { S.assignSlot(slotIdx, def.id); g.sfx.navBig(); },
      });
    }

    /* COMPANIONS — drone + beast, always available, no energy */
    const coItems = [
      {
        label: 'COMBAT DRONE', sub: cp.droneEnabled ? 'ON' : 'OFF',
        mark: cp.droneEnabled,
        desc: `Toggle your always-available drone — hovers ~${ASSETS.companions.drone.followDist} m out, engages on its own, eats YOUR ammo. Hull/shields/range mods live in MOD·COMPANION (CH-04).`,
        run() { cp.toggleDrone(g); },
      },
      { _sep: 'DRONE WEAPON' },
    ];
    ASSETS.companions.drone.weapons.forEach((dw, i) => {
      /* CH-04.4 — the FREEZE RAY is a continuous siphon, not a shot:
         its row + description describe the drain/tick curve instead */
      const isFr = dw.style === 'freeze';
      const poolLbl = ASSETS.ammoPools[dw.ammo].label;
      coItems.push({
        label: '· ' + dw.name,
        sub: isFr ? `${dw.drainPerSec}/s ${poolLbl.split(' ')[0]}`
                  : `${dw.cost} ${poolLbl.split(' ')[0]}`,
        mark: cp.droneWeaponIdx === i,
        desc: isFr
          ? `Drone ${dw.name}: CONTINUOUS siphon beam — drains ${Math.round(dw.sapShieldPct * 100)}% of the target's max shields per ${dw.tick}s tick (shields first, then hp) and stacks DEF-DOWN (+6% damage taken per stack, max 5, decays after). ${dw.dmg} COLD dmg per tick to bare hp (CH-25 typed). Feeds on your ${poolLbl} at ${dw.drainPerSec}/s. NEAR-SILENT.`
          : `Drone ${dw.name}: ${dw.dmg} dmg every ${dw.interval}s — feeds on your ${poolLbl}.` +
            /* CH-25.2 — drone weapons carry the same combat stats */
            (dw.types ? ` · ${Object.keys(dw.types).map((t) => t.toUpperCase()).join('/')}` : '') +
            (dw.critChance ? ` · CRIT ${Math.round(dw.critChance * 100)}% ×${dw.critMult}` : '') +
            (dw.statusChance ? ` · STATUS ${Math.round(dw.statusChance * 100)}%` : ''),
        run() { cp.droneWeaponIdx = i; g.sfx.navBig(); },
      });
    });
    coItems.push({ _sep: 'BEAST' });
    coItems.push({
      label: 'ZANUKA BEAST', sub: cp.petEnabled ? 'ON' : 'OFF',
      mark: cp.petEnabled,
      desc: `Toggle the four-legged hunter — charges hostiles and bites (melee only, for now). Hull/shields/claws live in MOD·COMPANION + MOD·COMPANION WEAPON (CH-04).`,
      run() { cp.togglePet(g); },
    });

    /* MOD columns — CH-03.1 CARD INVENTORY: own a card first (chips, crates,
       elites, kaiju drop them), then rank-ups cost CREDITS + POWER (interim
       fusion — the mod bench lands in CH-16); X/Y scraps the rank (60 % back) */
    const modCol = (colKey, icon, label) => ({
      icon, label,
      items: ASSETS.mods.nodes.filter((n) => n.col === colKey).map((n) => {
        const rank = Mods.rankOf(n.id);
        const copies = Mods.copiesOf(n.id);          // CH-03.1 — card inventory
        const cost = Mods.nextCost(n.id);
        const maxed = cost === null;
        const sub = !copies
          ? 'NO CARD'
          : maxed
            ? (copies > 1 ? `MAX · ×${copies}` : 'MAX')
            : (copies > 1
              ? `×${copies} · R${rank} ▸ ${fmtCR(cost.cr)}+${fmtCR(cost.pw)}`
              : rank > 0
                ? `R${rank} ▸ ${fmtCR(cost.cr)}+${fmtCR(cost.pw)}`
                : `${fmtCR(cost.cr)}+${fmtCR(cost.pw)}`);
        /* CH-04.1 — companion type chip: ⌁S = sentinel · ⌁B = beast ·
           ⌁S+B = feeds every companion kill (BLOOD FOR SHIELD) */
        const chip = n.type === 'sentinel' ? ' · ⌁S'
          : n.type === 'beast' ? ' · ⌁B'
          : n.type === 'both' ? ' · ⌁S+B' : '';
        return {
          label: n.label,
          sub: sub + chip,
          mark: maxed || rank > 0,
          desc: Mods.describe(n),
          _modNode: n,
          run() {
            const res = Mods.buy(n.id);
            if (res.ok) {
              g.sfx.uiConfirm();
              g.hud.toast(`${n.label} → RANK ${res.rank} · −${fmtFull(res.cost.cr)} CR −${fmtFull(res.cost.pw)} PW`, 1900);
            } else if (res.unowned) {
              /* CH-03.1 — no card, no rank-up */
              g.sfx.energyFail();
              g.hud.toast(`NO ${n.label} CARD YET — MOD CHIPS · CRATES · ELITES · KAIJU DROP CARDS`, 2400);
            } else if (res.maxed) {
              g.sfx.navBig();
              g.hud.toast(`${n.label} ALREADY MAXED`, 1200);
            } else {
              g.sfx.energyFail();
              g.hud.toast(`NEED ${fmtFull(res.cost.cr)} CR + ${fmtFull(res.cost.pw)} PW · HAVE ${fmtFull(Mods.credits)} CR + ${fmtFull(Mods.power)} PW`, 2000);
            }
          },
        };
      }),
    });

    /* CH-03.4 — interim duplicate handling column (final buttons land in the
       mod bench, CH-16). A = SELL duplicates (full CR value) · X/Y = SCRAP
       duplicates (60 % of value) — every action behind the CH-01 confirm. */
    const dupesCol = { icon: '♻', label: 'MOD · DUPES', items: [] };
    {
      const total = Mods.totalCards(), dupes = Mods.totalDuplicates();
      const unitSell = Mods.sellValue();
      const unitScrap = Math.round(unitSell * ASSETS.mods.scrapRefund);
      dupesCol.items.push({
        label: `CARDS ${total} · DUPES ${dupes}`,
        sub: dupes > 0 ? 'A BELOW · X/Y ON A MOD' : 'NOTHING TO SELL',
        mark: false,
        desc: `Card inventory: ${total} card${total === 1 ? '' : 's'} owned, ${dupes} duplicate${dupes === 1 ? '' : 's'}. Sell = full value (+${fmtCR(unitSell)} CR each) · Scrap = 60 % of value (+${fmtCR(unitScrap)} CR each). One copy of every mod is always kept.`,
        run() { g.hud.toast(`CARD INVENTORY · ${total} CARDS · ${dupes} DUPLICATES`, 1800); },
      });
      dupesCol.items.push({ _sep: 'ALL MODS' });
      dupesCol.items.push({
        label: 'SELL ALL DUPLICATES',
        sub: dupes > 0 ? '+' + fmtCR(dupes * unitSell) + ' CR' : '—',
        mark: dupes > 0,
        desc: `Sell every duplicate copy across ALL mods — ${dupes} card${dupes === 1 ? '' : 's'} for +${fmtCR(dupes * unitSell)} CR. One copy of each mod is always kept. Asks to confirm.`,
        run() { g.hud.confirmDupe('sell'); },
      });
      dupesCol.items.push({
        label: 'SCRAP ALL DUPLICATES',
        sub: dupes > 0 ? '+' + fmtCR(dupes * unitScrap) + ' CR' : '—',
        mark: dupes > 0,
        desc: `Scrap every duplicate copy across ALL mods at 60 % of the sale value — ${dupes} card${dupes === 1 ? '' : 's'} for +${fmtCR(dupes * unitScrap)} CR. One copy of each mod is always kept. Asks to confirm.`,
        run() { g.hud.confirmDupe('scrap'); },
      });
      dupesCol.items.push({ _sep: 'PER MOD' });
      let dupeRows = 0;
      ASSETS.mods.nodes.forEach((n) => {
        const copies = Mods.copiesOf(n.id);
        if (copies <= 1) return;
        dupeRows += 1;
        dupesCol.items.push({
          label: '· ' + n.label,
          sub: `×${copies} · ${copies - 1} DUPE${copies > 2 ? 'S' : ''}`,
          mark: true,
          _dupeNode: n,                             // X/Y = SCRAP its duplicates
          desc: `You hold ${copies} copies (rank is shared). A = SELL the ${copies - 1} duplicate${copies > 2 ? 's' : ''} for +${fmtCR((copies - 1) * unitSell)} CR · X/Y = SCRAP them for +${fmtCR((copies - 1) * unitScrap)} CR. One copy always stays.`,
          run() { g.hud.confirmDupe('sell', n.id); },
        });
      });
      if (!dupeRows) {
        dupesCol.items.push({
          label: '— NO DUPLICATES YET —', sub: 'CHIPS · CRATES · ELITES · KAIJU',
          desc: 'Pulling the same mod twice from the drop pool piles up duplicate cards here — sell them for full CR value or scrap them for 60 %.',
          run() {},
        });
      }
    }

    const abItems = [
      {
        label: 'CLOAK', sub: ASSETS.invis.energy + 'e · ' + ASSETS.invis.duration + 's',
        desc: `R2 skill: vanish for ${ASSETS.invis.duration} s — enemies lose you and your drone + zanuka HOLD FIRE. Assign CLOAK to an R2 slot in EQUIPMENT. Firing decloaks.`,
        run() {},
      },
      {
        label: 'OVERSHIELD', sub: ASSETS.overshield.energy + 'e',
        desc: `R2 skill: +${ASSETS.overshield.amount} bonus shields on top of max for ${ASSETS.overshield.duration} s. Absorbs damage before your shields. Assign it to an R2 slot in EQUIPMENT.`,
        run() {},
      },
      {
        label: 'WIELD NIKANA', sub: W.nikana ? 'DRAWN' : 'SHEATHED',
        mark: W.nikana,
        desc: `Samurai draw-style blade: V/B performs an iai quick-draw slash — ${ASSETS.nikana.damage} dmg, ${ASSETS.nikana.range} m arc, forward lunge. Toggle to sheath (plain rifle bash instead).`,
        run() {
          W.nikana = !W.nikana;
          g.hud.toast(W.nikana ? 'NIKANA DRAWN — V/B = IAI SLASH' : 'NIKANA SHEATHED', 1500);
        },
      },
      {
        label: 'STOW WEAPON', sub: W.stowed ? 'STOWED' : 'DRAWN',
        mark: W.stowed,
        desc: `Holster the gun (H / L3): +8 % move speed, no firing until you draw again. Fire input auto-draws.`,
        run() { W.toggleStow(g); },
      },
      {
        label: 'FISHING ROD', sub: 'X NEAR WATER',
        desc: `Stand at a river, bay, falls pool or the ocean and press X to cast. When the line bites ("PRESS X!") press X again inside the window — fish sell in SALVAGE. Rare gizzard stones hold raw crystal.`,
        run() {},
      },
      {
        label: 'DAY / NIGHT', sub: '120 MIN',
        desc: `Full cycle: dawn 15 min · day 40 · dusk 15 · night 50. The clock chip tracks it — night is DARK out in the wilds, bring the lamp (L).`,
        run() {},
      },
      {
        label: 'BLAST NOVA', sub: ASSETS.nova.energy + 'e',
        desc: `F: radial ${ASSETS.nova.damage} dmg burst, ${ASSETS.nova.radius}m. Costs ${ASSETS.nova.energy} energy.`,
        run() { g.useNova(); },
      },
      {
        label: 'AMMO CONVERSION', sub: 'BOXES',
        desc: `Break a supply box (ONE rocket shell = 2000 dmg) and it spills 1 shell of value: ${ASSETS.conversion.energy} energy (2 plasma casts) = ${ASSETS.conversion.sniper} sniper = ${ASSETS.conversion.rifle} rifle = ${ASSETS.conversion.pistol} pistol. RL-4 DAMAGE / BLAST mods overkill the box → up to ×3 loot.`,
        run() {},
      },
      {
        label: 'FLASHLIGHT', sub: g.flashlightOn ? 'ON' : 'OFF',
        mark: g.flashlightOn,
        desc: 'L / D-padUp toggles the shoulder lamp. The bay and the spawn corridor are DARK.',
        run() { g.toggleFlashlight(); },
      },
      {
        label: 'VATS TARGETING', sub: 'AIR',
        desc: `While AIRBORNE press L1 / C: time slows ×${ASSETS.vats.timeScale}. R1 fires ${ASSETS.vats.missileDmg} dmg hover missiles — executes targets under ${Math.round(ASSETS.vats.executeFrac * 100)}% HP.`,
        run() {},
      },
      {
        label: 'DOUBLE JUMP', sub: 'FREE',
        desc: `A jumps; A again mid-air jumps once more. Height = ${Math.round(ASSETS.player.airJumpBonus)}% of a ground jump — raise it with the JETPACK frame mod (5%→200%).`,
        run() {},
      },
      {
        label: 'HOVER', sub: ASSETS.jetpack.hoverDrain + 'e/s',
        desc: 'HOLD A in the air to hover (drains energy). Release for a forward lunge. GLIDE MODULE (R2) floats without holding A.',
        run() {},
      },
    ];

    /* SALVAGE — ecology materials + sell buttons */
    const salItems = [];
    const mats = ASSETS.ecology.materials;
    let anyMat = false;
    for (const id of Object.keys(mats)) {
      const n = g.materials[id] || 0;
      if (n > 0) anyMat = true;
      salItems.push({
        label: mats[id].label, sub: n > 0 ? `×${n}` : '—',
        dis: n <= 0,
        desc: n > 0
          ? `Sell ${n} × ${mats[id].label} for ${fmtFull(mats[id].sell * n)} CR.`
          : `${mats[id].label}: ${fmtCR(mats[id].sell)} CR each. Harvest bushes, mine ore rocks, shoot birds/rodents, or fish.`,
        _matId: id,
        run() {
          const n = g.materials[id] || 0;
          if (n <= 0) return;
          const v = Math.round(mats[id].sell * n);
          g.hud.confirmBox({
            title: 'SELL ' + mats[id].label + '?',
            body: 'You lose ' + n + ' × ' + mats[id].label + '.\n' +
              'SALE VALUE: +' + fmtFull(v) + ' CR',
            okLabel: 'SELL',
            onOk() {
              const got = g.sellMaterial(id);
              if (got > 0) {
                g.sfx.scrap();
                g.hud.toast('SOLD ' + mats[id].label + ' · +' + fmtFull(got) + ' CR', 1500);
              }
            },
          });
        },
      });
    }
    salItems.push({
      label: 'SELL EVERYTHING', sub: anyMat ? 'ALL' : '—', dis: !anyMat,
      desc: 'Convert every stored material into credits at once.',
      run() {
        let total = 0, count = 0;
        for (const id of Object.keys(mats)) {
          const n = g.materials[id] || 0;
          total += n * mats[id].sell; count += n;
        }
        if (total <= 0) return;
        g.hud.confirmBox({
          title: 'SELL ALL SALVAGE?',
          body: 'You lose every stored material (' + count + ' units).\n' +
            'SALE VALUE: +' + fmtFull(total) + ' CR',
          okLabel: 'SELL ALL',
          onOk() {
            let tot = 0;
            for (const id of Object.keys(mats)) tot += g.sellMaterial(id);
            if (tot > 0) {
              g.sfx.uiConfirm();
              g.hud.toast('SALVAGE SOLD · +' + fmtFull(tot) + ' CR', 1800);
            }
          },
        });
      },
    });

    const svKey = 'ac-save-v1';
    /* CH-04b HOTFIX — localStorage may be BLOCKED for this origin (browser
       privacy shields / private mode can make the storage GETTER itself
       throw SecurityError). The XMB must open regardless: read defensively. */
    let hasSave = false;
    try { hasSave = !!localStorage.getItem(svKey); } catch { /* storage blocked */ }
    const svItems = [
      {
        label: 'SAVE STATE', sub: hasSave ? 'OVERWRITE' : '—',
        desc: 'Snapshot position, vitals, ammo, slots and companions to this browser. (Credits / power / mod ranks persist regardless.)',
        run() { g.saveState(); },
      },
      {
        label: 'LOAD STATE', sub: hasSave ? 'READY' : 'EMPTY', dis: !hasSave,
        desc: 'Restore the snapshot. Hostiles respawn fresh.',
        run() { g.loadState(); },
      },
    ];

    const spawnItems = [
      {
        label: 'HOME BASE', sub: 'THE SHUTTLE',           /* CH-36.3 */
        desc: 'Teleport into the home base shuttle — stations, mod bench, salvage stores and the windshield dock. The ramp walks back out to the corridor.',
        run() { g.teleportTo(0, 11.8); g.closeXmb(); },
      },
      {
        label: 'CORRIDOR START', sub: 'z 0',
        desc: 'Blink back to the corridor entrance. Hostiles stay where they are.',
        run() { g.teleportTo(0, -1.6); g.closeXmb(); },
      },
      {
        label: 'HANGAR BAY 7', sub: 'z −90',
        desc: 'Drop into the middle of the bay.',
        run() { g.teleportTo(0, -90); g.closeXmb(); },
      },
      {
        label: 'THE VALLEY', sub: 'z −121',
        desc: 'Step outside into the dusk canyon.',
        run() { g.teleportTo(0, -121); g.closeXmb(); },
      },
      {
        label: 'CITYSCAPE', sub: 'z −162',
        desc: 'Land in the neon streets beyond the canyon.',
        run() { g.teleportTo(0, -162); g.closeXmb(); },
      },
      {
        label: 'CANYON RING', sub: 'z −228',
        desc: 'The wilds right behind the city gate — dry washes and canyon passes ring the cityscape (CH-09, LVL 10-13).',
        run() { g.teleportTo(0, -228); g.closeXmb(); },
      },
      {
        label: 'THE WILDS', sub: 'z −276',
        desc: 'Into the green country — parks and grasslands past the canyon ring.',
        run() { g.teleportTo(0, -276); g.closeXmb(); },
      },
      {
        label: 'RED BADLANDS', sub: 'z −420',
        desc: 'The dry south — mesa buttes and stratified rock beside the desert (LVL 18-24).',
        run() { g.teleportTo(0, -420); g.closeXmb(); },
      },
      {
        label: 'OCEAN SHORE', sub: 'z −468',
        desc: 'The beach ring before the deep ocean (LVL 15-26 tiles).',
        run() { g.teleportTo(0, -468); g.closeXmb(); },
      },
      {
        label: 'EXTRACTION BUOY', sub: 'z −505',
        desc: 'Teleport to the deep-ocean extraction buoy — kaiju waters, LVL 40 tiles.',
        run() { g.teleportTo(0, -505); g.closeXmb(); },
      },
    ];

    const resetItems = [
      {
        label: 'RESET RUN', sub: '—',
        desc: 'Full restart of the area: hostiles respawn, drops + power crystals return, ammo resets. Mod ranks / wallets persist.',
        run() { g.resetRun(); g.closeXmb(); },
      },
    ];

    /* CONTROLS — the button-layout column */
    const rows = [
      ['MOVE', 'WASD · L-Stick'],
      ['LOOK', 'Mouse · R-Stick'],
      ['FIRE', 'LMB · R1'],
      ['SPECIAL (R2)', 'E·G · R2'],
      ['CYCLE 4 SLOTS', '[ ] · HOLD D-pad ◀▶'],
      ['AIM / SCOPE', 'RMB·Z · L2'],
      ['JUMP / DOUBLE JUMP', 'Space · A (×2)'],
      ['HOVER', 'HOLD A'],
      ['DUCK · VATS (air)', 'C·Ctrl · L1'],
      ['SLIDE', 'C+A moving · LB+A'],
      ['SWAP / RELOAD', 'Q·Y / R·X'],
      ['MELEE / NIKANA IAI', 'V · B'],
      ['HARVEST · FISH', 'X · D-padDown · Pad X in reach'],
      ['STOW WEAPON', 'H · L3'],
      ['NOVA', 'F'],
      ['FLASHLIGHT', 'L · D-padUp'],
      ['XMB MENU', 'Esc·P · Start'],
      ['SCRAP/SELL (XMB)', 'X·Backspace · Y'],
    ].map(([a, b]) => ({
      label: a, sub: b, static: true,
      desc: `${a}:  ${b}.  Full binding table also lives in assets.js → controls.`,
      run() {},
    }));

    /* zone level reference — what's hunting you, and how tough it is */
    const lv = ASSETS.enemy.leveling;
    const lvlPct = Math.round(lv.perLevel * 100);
    const exL = ASSETS.world.expanse.levels;
    const lvlRows = [
      ['STARTING HALLWAY', 'LVL ' + lv.zones.corridor],
      ['HANGAR BAY 7', 'LVL ' + lv.zones.hangar],
      ['THE VALLEY', 'LVL ' + lv.zones.valley],
      ['CITYSCAPE', 'LVL ' + lv.zones.city],
      ['WILDS · PARK/GRASS', 'LVL ' + exL.park + '–' + exL.grassland],
      ['WILDS · FOREST/RIVER', 'LVL ' + exL.trail + '–' + exL.forest],
      ['WILDS · STEPPE/FALLS', 'LVL ' + exL.steppe + '–' + exL.waterfall],
      ['WILDS · MTN/SNOW/DESERT', 'LVL ' + exL.mountain + '–' + exL.desert],
      ['SHORE · BEACH/BAY', 'LVL ' + exL.beach + '–' + exL.oceanbay],
      ['THE OCEAN', 'LVL ' + exL.ocean],
      ['KAIJU', 'LVL ' + ASSETS.world.expanse.kaiju.level],
    ].map(([a, b]) => ({
      label: a, sub: b, static: true,
      desc: `Enemy zone levels: hallway L${lv.zones.corridor} · hangar L${lv.zones.hangar} · valley L${lv.zones.valley} · city L${lv.zones.city} · expanse tiles L10→L40 · kaiju L80. Each level = +${lvlPct}% enemy health AND shields. Drops scale too: L40 = 1×, L60 = 2×, L80 = 4× (cap).`,
      run() {},
    }));

    /* CH-36.4 — MISSION CONSOLE data: when the CH-47 director ships it
       fills assets.missions and the console lists those (name · type ·
       site · level band · reward preview, DEPLOY → director). Until then
       the console lists the NAVIGATE-equivalent traversal targets so the
       station never dead-ends — each rides the CH-36.1 loading flow, and
       RETURN TO FIELD (the zone you last extracted from) prepends when
       one exists. No mission logic lives here (warframe.hub-rules).    */
    const missionItems = [];
    /* CH-36.3 — zone → navTarget label. Ocean extractions return to the
       SHORE landmark, not the mid-kaiju buoy (stated decision, worklog.30);
       every other zone maps to its matching traversal entry.            */
    const zoneName = { corridor: 'CORRIDOR FIELD', hangar: 'HANGAR BAY 7',
      valley: 'THE VALLEY', city: 'CITYSCAPE', expanse: 'THE WILDS', ocean: 'OCEAN SHORE' };
    if (g.lastField && zoneName[g.lastField]) {
      const ret = ASSETS.hub.navTargets.find((n) => n.label === zoneName[g.lastField]) ||
        { label: zoneName[g.lastField], sub: 'LAST FIELD', x: 0, z: -1.6,
          desc: 'Return to the zone you extracted from.' };
      missionItems.push({
        label: 'RETURN TO FIELD', sub: ret.sub || 'LAST FIELD',
        desc: 'Shuttle back to ' + ret.label + ' — the zone your last extraction came from. (Loading flow, CH-36.1.)',
        run() { g.closeXmb(); g.runNavHop(ret.x, ret.z, ret.label); },
      });
    }
    if (Array.isArray(ASSETS.missions) && ASSETS.missions.length) {
      for (const m of ASSETS.missions) {
        missionItems.push({
          label: m.name || m.id, sub: ((m.type || 'MISSION') + ' · ' + (m.band || '')),
          desc: (m.site ? 'SITE: ' + m.site + ' · ' : '') +
            'REWARD PREVIEW: ' + (m.rewardPreview || '—') +
            ' — DEPLOY hands this mission to the CH-47 director (assets.missions config).',
          run() { g.closeXmb(); g.deployMission(m); },
        });
      }
    } else {
      for (const n of ASSETS.hub.navTargets) {
        missionItems.push({
          label: n.label, sub: n.sub,
          desc: (n.desc || '') +
            ' — rides the shuttle loading flow. Mission listings arrive with the CH-47 director (assets.missions).',
          run() { g.closeXmb(); g.runNavHop(n.x, n.z, n.label); },
        });
      }
      missionItems.push({
        label: 'MISSION DIRECTOR', sub: 'OFFLINE', dis: true, static: true,
        desc: 'The deployment loop (extermination · survival · defense · recovery) ships with CH-47 — the console lists traversal targets until then.',
        run() {},
      });
    }

    return [
      { icon: '⌖', label: 'MISSION',    items: missionItems },   /* CH-36.4 */
      { icon: '⌗', label: 'WEAPONS',    items: wItems },
      { icon: '◈', label: 'EQUIPMENT',  items: eqItems },
      { icon: '❖', label: 'COMPANIONS', items: coItems },
      modCol('guns',  '⚒', 'MOD · GUNS'),
      modCol('frame', '✚', 'MOD · FRAME'),
      modCol('companion', '❉', 'MOD · COMPANION'),          /* CH-04.1 */
      modCol('compwep',   '✥', 'MOD · COMPANION WEAPON'),   /* CH-04.2 */
      modCol('heavy', '☸', 'MOD · HEAVY'),                  /* launcher only — CH-04.3 */
      dupesCol,                             /* CH-03.4 — sell/scrap duplicates */
      { icon: '⚡', label: 'ABILITY',    items: abItems },
      { icon: '⛁', label: 'SALVAGE',    items: salItems },
      { icon: '⌂', label: 'SPAWN AREA', items: spawnItems },
      { icon: '≡', label: 'SAVESTATE',  items: svItems },
      { icon: '↺', label: 'RESET AREA', items: resetItems },
      { icon: '☠', label: 'ENEMY LVLS', items: lvlRows },
      { icon: '⌨', label: 'CONTROLS',   items: rows },
    ];
  }

  /* ==============================================================================
     GENERIC CONFIRM DIALOG (CH-01.2) — modal card over the XMB.
     A / Enter / Space / click activate the FOCUSED button (focus STARTS on
     CANCEL); B / Esc / Start / Backspace always cancel; ◀ ▶ / D-pad /
     shoulders move focus. The body shows what is lost + the CR/PW refund
     or sale value. Built as DOM here — index.html / hud.css untouched.
     ============================================================================== */
  ensureConfirm() {
    if (this.confirmEl) return;
    const wrap = document.createElement('div');
    wrap.style.cssText =
      'position:absolute;inset:0;display:none;align-items:center;' +
      'justify-content:center;background:rgba(2,8,14,0.55);z-index:99;';
    const card = document.createElement('div');
    card.style.cssText =
      'width:360px;max-width:88vw;background:rgba(8,16,24,0.94);' +
      'border:1px solid rgba(79,195,255,0.4);padding:14px 18px;' +
      'box-shadow:0 0 24px rgba(79,195,255,0.25),0 12px 44px rgba(0,0,0,0.6);' +
      "font-family:Consolas,'Courier New',monospace;color:#bfe9ff;";
    const title = document.createElement('div');
    title.style.cssText =
      'font-weight:700;font-size:13px;letter-spacing:0.16em;color:#eaf6ff;' +
      'text-shadow:0 0 8px rgba(79,195,255,0.55);margin-bottom:9px;';
    const body = document.createElement('div');
    body.style.cssText =
      'font-size:11px;line-height:1.6;letter-spacing:0.04em;opacity:0.92;' +
      'margin-bottom:13px;white-space:pre-line;';
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:10px;';
    const mkBtn = (label) => {
      const b = document.createElement('div');
      b.style.cssText =
        'flex:1;text-align:center;padding:7px 0;font-size:11px;font-weight:700;' +
        'letter-spacing:0.14em;border:1px solid rgba(79,195,255,0.35);' +
        'background:rgba(79,195,255,0.06);cursor:pointer;user-select:none;';
      b.textContent = label;
      b.addEventListener('mouseenter', () => {
        this.confirmFocus = b === this._cfmOk ? 'ok' : 'no';
        this.paintConfirm();
      });
      return b;
    };
    this._cfmOk = mkBtn('CONFIRM · A');
    this._cfmNo = mkBtn('CANCEL · B');
    row.appendChild(this._cfmOk); row.appendChild(this._cfmNo);
    card.appendChild(title); card.appendChild(body); card.appendChild(row);
    wrap.appendChild(card);
    this.el.xmb.appendChild(wrap);
    this.confirmEl = wrap;
    this._cfmTitle = title;
    this._cfmBody = body;
  }

  /* open the dialog — onOk() fires only if the focused button is CONFIRM.
     Focus defaults to CANCEL, so mashing A never destroys anything. */
  /* CH-03.4 — interim SELL / SCRAP DUPLICATES, always behind the CH-01 confirm
     dialog (final buttons land in the mod bench, CH-16). mode: 'sell' | 'scrap'
     · id: mod node id — omit it for the GLOBAL variant across every mod. */
  confirmDupe(mode, id) {
    const sell = mode === 'sell';
    const node = id ? Mods.node(id) : null;
    const dupes = id
      ? Math.max(0, Mods.copiesOf(id) - 1)
      : Mods.totalDuplicates();
    if (dupes <= 0) {
      this.game.sfx.energyFail();
      this.game.hud.toast(node ? 'NO DUPLICATES OF ' + node.label : 'NO DUPLICATES ANYWHERE', 1400);
      return;
    }
    const unit = sell
      ? Mods.sellValue()
      : Math.round(Mods.sellValue() * ASSETS.mods.scrapRefund);   // scrap = 60 % of sale
    const value = dupes * unit;
    const verb = sell ? 'SELL' : 'SCRAP';
    const what = node ? node.label.toUpperCase() : 'ALL DUPLICATES';
    this.confirmBox({
      title: verb + ' ' + what + '?',
      body: (node
        ? 'Keeps 1 copy at RANK ' + Mods.rankOf(id) + ' — ' + verb.toLowerCase() + 's the other ' + dupes + '.\n'
        : 'Keeps one copy of EVERY mod — ' + verb.toLowerCase() + 's ' + dupes + ' duplicate copies.\n') +
        (sell ? 'SALE VALUE: +' : 'SCRAP VALUE: +') + fmtFull(value) + ' CR' +
        (sell ? '' : ' (60% of sale value)'),
      okLabel: verb,
      onOk: () => {
        const res = sell ? Mods.sellDuplicates(id) : Mods.scrapDuplicates(id);
        const count = res.sold !== undefined ? res.sold : (res.scrapped || 0);
        if (res.ok) {
          this.game.sfx.scrap();
          this.game.hud.toast(
            (sell ? 'SOLD ' : 'SCRAPPED ') + count + ' DUPLICATE' + (count === 1 ? '' : 'S') +
            ' · +' + fmtFull(res.value) + ' CR', 1900);
          this.refreshXmb();
        } else {
          this.game.sfx.energyFail();
          this.game.hud.toast('NOTHING TO ' + verb, 1200);
        }
      },
    });
  }

  confirmBox({ title, body, okLabel = 'CONFIRM', onOk }) {
    this.ensureConfirm();
    const inp = this.game.input;
    this._cfmTitle.textContent = title;
    this._cfmBody.textContent = body;
    this._cfmOk.textContent = okLabel + ' · A';
    this.confirmOnOk = onOk || null;
    this.confirmFocus = 'no';                    // default focus = CANCEL
    this._cfmLR = inp.keys.has('ArrowLeft') || inp.keys.has('ArrowRight');
    this._cfmBs = inp.keys.has('Backspace');     // no instant-cancel from
    this.confirmEl.style.display = 'flex';       // the key that opened us
    this.confirmOpen = true;
    this.paintConfirm();
    this.game.sfx.navBig();
  }

  confirmClose(did) {
    this.confirmOpen = false;
    if (this.confirmEl) this.confirmEl.style.display = 'none';
    const cb = this.confirmOnOk;
    this.confirmOnOk = null;
    if (did && cb) cb();
    else this.game.sfx.nav();
  }

  paintConfirm() {
    const ok = this.confirmFocus === 'ok';
    this._cfmOk.style.background = ok ? 'rgba(79,195,255,0.3)' : 'rgba(79,195,255,0.06)';
    this._cfmOk.style.borderColor = ok ? '#4fc3ff' : 'rgba(79,195,255,0.35)';
    this._cfmNo.style.background = !ok ? 'rgba(79,195,255,0.3)' : 'rgba(79,195,255,0.06)';
    this._cfmNo.style.borderColor = !ok ? '#4fc3ff' : 'rgba(79,195,255,0.35)';
  }

  /* input loop while the dialog is open — the XMB itself waits */
  confirmNav(input) {
    this._sx = input.keys.has('KeyX') || input.keys.has('Backspace'); // stay fresh
    input.padEdge(3);                            // keep pad-Y prev fresh
    const lr = input.keys.has('ArrowLeft') || input.keys.has('ArrowRight');
    if ((lr && !this._cfmLR) || input.padEdge(14) || input.padEdge(15) ||
        input.padEdge(4) || input.padEdge(5)) {
      this.confirmFocus = this.confirmFocus === 'ok' ? 'no' : 'ok';
      this.game.sfx.nav();
      this.paintConfirm();
    }
    this._cfmLR = lr;
    /* A / Enter / Space / click activates the FOCUSED button */
    if (input.consumeConfirm()) {
      this.confirmClose(this.confirmFocus === 'ok');
      return;
    }
    /* B / Esc / Start / Backspace always cancel */
    const bs = input.keys.has('Backspace');
    if (input.padEdge(1) || input.pressed('pause') || (bs && !this._cfmBs)) {
      this.confirmClose(false);
      return;
    }
    this._cfmBs = bs;
  }

  openXmb() {
    if (this.confirmOpen) this.confirmClose(false);
    this.game.sfx.freezeStop();      /* CH-04.4 — the XMB pauses the loop; the
                                        whisper siphon must not outlive it */
    this._xmbDegraded = false;       /* CH-04b — fresh open rebuilds fresh */
    /* CH-04b HOTFIX — a build failure (blocked storage, data hiccup) used to
       leave the overlay open with ZERO columns — "the menu is gone". The XMB
       must ALWAYS open: degrade to an error card instead of an empty shell. */
    try {
      this.cols = this.buildXmbCols();
      this.xcol = Math.min(Math.max(this.xcol, 0), this.cols.length - 1);
      this.xrow = 0;
      this.renderXmb();
    } catch (err) {
      console.error('[XMB] build failed — degrading:', err);
      this.renderXmbError(err);
    }
    this.xmbOpen = true;
    this.game.sfx.uiConfirm();
  }

  /* CH-36.4/36.5 — hub stations open the XMB ON A SPECIFIC COLUMN (the
     real system's surface — warframe.hub-rules). Label-matched at open
     time so future column inserts/renames keep the stations honest. */
  openXmbAt(colLabel) {
    const wasCol = this.xcol;
    this.openXmb();
    if (this._xmbDegraded) return;
    const idx = this.cols.findIndex((c) => c.label === colLabel);
    if (idx >= 0) {
      this.xcol = idx;
      this.xrow = 0;
      this.renderXmb();
    } else {
      this.xcol = Math.min(wasCol, this.cols.length - 1);  // fallback: where you were
    }
  }

  /* rebuild column data in place (keeps cursor) — costs, ranks and ammo
     counts go stale the moment an item mutates state, so refresh after runs */
  refreshXmb() {
    /* CH-04b — never rebuild from a degraded menu; the error card must stay */
    if (this._xmbDegraded) return;
    this.cols = this.buildXmbCols();
    this.xcol = Math.min(this.xcol, this.cols.length - 1);
    const items = this.cols[this.xcol]?.items || [];
    this.xrow = Math.max(0, Math.min(this.xrow, items.length - 1));
    this.renderXmb();
  }

  /* CH-04b — last-ditch XMB: one visible column + the error in the card.
     The menu STAYS OPEN and CLOSEABLE; the message names the cause. */
  renderXmbError(err) {
    this._xmbDegraded = true;
    const msg = (err && (err.message || String(err))) || 'unknown error';
    const colsEl = this.el.xmbCols;
    colsEl.innerHTML = '';
    const col = document.createElement('div');
    col.className = 'xmb-col sel';
    const icon = document.createElement('div');
    icon.className = 'xmb-cicon';
    icon.textContent = '⚠';
    const lab = document.createElement('div');
    lab.className = 'xmb-clabel';
    lab.textContent = 'MENU DEGRADED';
    const ul = document.createElement('ul');
    ul.className = 'xmb-items';
    const li = document.createElement('li');
    li.className = 'sel';
    li.innerHTML = '<span>GAME STILL PLAYABLE</span><span class="sub">B closes</span>';
    ul.appendChild(li);
    col.appendChild(icon); col.appendChild(lab); col.appendChild(ul);
    colsEl.appendChild(col);
    this.el.xmbCardT.textContent = 'XMB BUILD FAILED';
    this.el.xmbCardD.textContent =
      msg + ' — the menu ran degraded. Usual cause: this browser blocks site ' +
      'data for this site (privacy shields / private mode). Allow storage for ' +
      'it and reload to get the full menu; the game itself keeps working.';
  }

  closeXmb() {
    if (this.confirmOpen) this.confirmClose(false);
    this.xmbOpen = false;
    this._xmbDegraded = false;       /* CH-04b — next open rebuilds fresh */
    this.game.sfx.zoomOut();
  }

  renderXmb() {
    const crEl = document.getElementById('xmb-credits');
    if (crEl) crEl.textContent =
      '⌾ ' + fmtFull(Mods.credits) + ' CR · ⚡ ' + fmtFull(Mods.power) + ' PW';
    const colsEl = this.el.xmbCols;
    colsEl.innerHTML = '';
    const half = Math.floor(this.cols.length / 2);
    this.cols.forEach((c, ci) => {
      const col = document.createElement('div');
      col.className = 'xmb-col' + (ci === this.xcol ? ' sel' : '');
      // CENTER THE SELECTED COLUMN on screen
      const dist = ci - this.xcol;
      const adist = Math.abs(dist);
      if (adist > 4) { col.style.display = 'none'; }
      else {
        col.style.transform =
          `translateX(${(dist * COL_W).toFixed(0)}px) scale(${adist === 0 ? 1 : adist === 1 ? 0.93 : 0.86})`;
        col.style.opacity = adist === 0 ? 1 : adist === 1 ? 0.62 : 0.34;
        col.style.zIndex = String(50 - adist);
      }
      const icon = document.createElement('div');
      icon.className = 'xmb-cicon';
      icon.textContent = c.icon;
      icon.addEventListener('click', () => { this.xcol = ci; this.xrow = 0; this.renderXmb(); });
      const lab = document.createElement('div');
      lab.className = 'xmb-clabel';
      lab.textContent = c.label;
      const ul = document.createElement('ul');
      ul.className = 'xmb-items';
      c.items.forEach((it, ri) => {
        const li = document.createElement('li');
        if (it._sep) {
          li.innerHTML = `<b style="opacity:.6;font-size:10px;letter-spacing:.2em">${it._sep}</b>`;
          li.classList.add('dis');
        } else {
          li.innerHTML = `<span>${it.label}${it.mark ? ' ' : ''}</span>` +
            `${it.mark !== undefined ? (it.mark ? '<span class="mark">◆</span>' : '') : ''}` +
            `<span class="sub">${it.sub || ''}</span>`;
          if (it.dis) li.classList.add('dis');
          if (ci === this.xcol && ri === this.xrow) li.classList.add('sel');
          li.addEventListener('click', () => {
            this.xcol = ci; this.xrow = ri;
            this.renderXmb();
            if (!it.dis) { it.run(this.game); this.refreshXmb(); }
          });
        }
        ul.appendChild(li);
      });
      col.appendChild(icon); col.appendChild(lab); col.appendChild(ul);
      colsEl.appendChild(col);
    });
    // selected card
    const item = this.cols[this.xcol]?.items[this.xrow];
    if (item && !item._sep) {
      this.el.xmbCardT.textContent = item.label;
      this.el.xmbCardD.textContent = item.desc || '';
    } else if (item?._sep) {
      this.el.xmbCardT.textContent = item._sep;
      this.el.xmbCardD.textContent = '';
    } else {
      this.el.xmbCardT.textContent = this.cols[this.xcol]?.label || '—';
      this.el.xmbCardD.textContent = '';
    }
  }

  /* nav — called every frame while state === 'xmb' */
  xmbNav(input) {
    // CH-01.2 — modal confirm dialog eats ALL XMB input while it is open
    if (this.confirmOpen) { this.confirmNav(input); return; }
    /* CH-04b — empty / missing column (degraded menu, bad cursor) must never
       throw — the modulo of an empty length is NaN and would poison xcol */
    const col = this.cols[this.xcol];
    const colItems = col && col.items ? col.items : [];
    const nextRow = (d) => {
      if (!colItems.length) return;
      const items = colItems;
      let r = this.xrow;
      for (let k = 0; k < items.length; k++) {
        r = (r + d + items.length) % items.length;
        if (!items[r]._sep) break;
      }
      this.xrow = r;
      this.game.sfx.nav();
      this.renderXmb();
    };
    const nextCol = (d) => {
      if (!this.cols.length) return;
      this.xcol = (this.xcol + d + this.cols.length) % this.cols.length;
      this.xrow = 0;
      this.game.sfx.nav();
      this.renderXmb();
    };

    // keyboard
    if (input.keys.has('ArrowUp'))    { if (!this._ku) nextRow(-1); this._ku = true; } else this._ku = false;
    if (input.keys.has('ArrowDown'))  { if (!this._kd) nextRow(1);  this._kd = true; } else this._kd = false;
    if (input.keys.has('ArrowLeft'))  { if (!this._kl) nextCol(-1); this._kl = true; } else this._kl = false;
    if (input.keys.has('ArrowRight')) { if (!this._kr) nextCol(1);  this._kr = true; } else this._kr = false;
    // wheel
    const w = input.consumeWheel();
    if (w) nextRow(w);
    // gamepad dpad + shoulder
    if (input.padEdge(12)) nextRow(-1);
    if (input.padEdge(13)) nextRow(1);
    if (input.padEdge(14)) nextCol(-1);
    if (input.padEdge(15)) nextCol(1);
    if (input.padEdge(4))  nextCol(-1);
    if (input.padEdge(5))  nextCol(1);
    // confirm A / Enter (consumeConfirm covers click+Enter+A edge)
    if (input.consumeConfirm()) {
      const item = colItems[this.xrow];
      if (item && !item._sep && !item.dis) {
        this.game.sfx.uiConfirm();
        item.run(this.game);
        this.refreshXmb();
      }
    }
    // SCRAP: X / Backspace / pad Y on a mod card → CONFIRM → 60 % refund —
    // or SELL a weapon card (CH-01.3 — both go through the confirm dialog)
    const scrapKey = input.keys.has('KeyX') || input.keys.has('Backspace');
    if ((scrapKey && !this._sx) || input.padEdge(3)) {
      const item = colItems[this.xrow];
      if (item && item._modNode) {
        const n = item._modNode;
        const rank = Mods.rankOf(n.id);
        if (rank <= 0) {
          this.game.sfx.energyFail();
          this.game.hud.toast('NOTHING TO SCRAP — RANK 0', 1200);
        } else {
          const pct = Math.round(ASSETS.mods.scrapRefund * 100);
          const refund = {
            cr: Math.round(Mods.cumCR(rank) * ASSETS.mods.scrapRefund),
            pw: Math.round(Mods.cumPW(rank) * ASSETS.mods.scrapRefund),
          };
          this.confirmBox({
            title: 'SCRAP ' + n.label + '?',
            body: 'You lose RANK ' + rank + ' — the node resets to R0.\n' +
              'The CARD and all copies stay owned.\n' +
              'REFUND ' + pct + '%: +' + fmtFull(refund.cr) + ' CR · +' +
              fmtFull(refund.pw) + ' PW',
            okLabel: 'SCRAP',
            onOk: () => {
              const res = Mods.scrap(n.id);
              if (res.ok) {
                this.game.sfx.scrap();
                this.game.hud.toast(
                  `SCRAPPED ${n.label} · +${fmtFull(res.refund.cr)} CR +${fmtFull(res.refund.pw)} PW`, 1900);
                this.refreshXmb();
              }
            },
          });
        }
      } else if (item && item._dupeNode) {
        /* CH-03.4 — X / Y on a MOD · DUPES row = SCRAP that mod's duplicates */
        const n = item._dupeNode;
        this.confirmDupe('scrap', n.id);
      } else if (item && item._weaponIdx !== undefined) {
        /* v0.8: SELL the highlighted weapon — CONFIRM first (CH-01.3) */
        const W = this.game.weapon;
        const idx = item._weaponIdx;
        const value = W.sellValue(idx);
        if (!W.isUnlocked(idx) || !value) {
          if (W.sellWeapon(idx, this.game)) this.refreshXmb(); // keeps its own toasts
        } else {
          const name = W.guns[idx].def.name;
          this.confirmBox({
            title: 'SELL ' + name + '?',
            body: 'You lose the weapon — it re-locks until you scavenge\n' +
              'its ammo again.\nSALE VALUE: +' + fmtFull(value) + ' CR',
            okLabel: 'SELL',
            onOk: () => { if (W.sellWeapon(idx, this.game)) this.refreshXmb(); },
          });
        }
      }
    }
    this._sx = scrapKey;
    // B / Esc / Start close
    if (input.padEdge(1) || input.pressed('pause')) this.game.closeXmb();
  }

  hasSave() {
    try { return !!localStorage.getItem('ac-save-v1'); }
    catch { return false; }               /* CH-04b — storage blocked → false */
  }
}

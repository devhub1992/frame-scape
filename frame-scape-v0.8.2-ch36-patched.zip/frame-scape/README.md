# FRAME SCAPE

A barebone, Halo/Warframe-inspired corridor-and-wilds FPS that runs entirely
in the browser. Pure static files — no build step, no server, no binary
assets. Built to stay playable on an **Intel i3-2350M / HD 3000** (WebGL1
fallback included).

**v0.8.2 · CH-36 patch (extract loading screen + HOME BASE)** — the game gains
its **personal hub**: touch the deep-ocean extraction buoy and the run no
longer ends — a full-screen **EXTRACTION loading screen** plays a procedural
**space-shuttle** scene (2D-canvas art: plated hull, delta wings, twin
flickering engine burns, blinking nav lights, a 130-star drift field, planet
limb — no video, no WebGL cost) with a staged progress readout, then the
shuttle docks at **HOME BASE**, a new shuttle-interior zone parked north of
the corridor start. Walk the AIRLOCK (the old corridor rear wall now has a
real doorway and a sliding **ramp door**), past the back rooms — **MOD BENCH**
and **SALVAGE STORES** — up the narrow hallway past the **ARSENAL RACK** and
**COMPANION BAY**, to the cockpit: an 11-metre **windshield** renders the world
outside as one hand-painted vista (dusk sky, neon city skyline, canyon mesas,
an ocean moon-glint — one emissive texture, HD 3000 budget kept), with the
**MISSION CONSOLE** on the left and the **FRAME DOCK** display rig on the
right. Every station is functional, not decorative: walk up, press X, and the
station opens its **real** system — the mission console lists traversal
targets (and DEPLOY-ready missions once the CH-47 director ships), the mod
bench opens the mod columns, salvage stores opens your inventory — all reading
the one canonical wallet/loadout, so a rank bought in the hub sticks in the
field. The console's RETURN TO FIELD entry shuttles you back to the zone you
extracted from. Verified with a 79-check contract harness plus a 30-check
Node boot smoke (full module graph on a three.js stub: buildWorld, zone
reads, collider walk-under math, ramp-door behavior).

**v0.8.2 · CH-09 patch (canyon-country tile sets)** — the wilds outside the
city grow from 9 to 13 tile rows, and the first thing you see through the wild
gate is no longer an open park: **rows 0-1 are a CANYON RING** of five new
valley/canyon tile sets — **DRY RIVERBED** (cracked-mud floor, dead trees, a
baked bank strip), **CANYON PASS** (rock wall masses pinching both tile edges
with a wide middle throat + choke boulders), **ROCKY BASIN** (perimeter boulder
ring around a bare-dirt ore dig), **HIGH RIDGE** (a low vaultable rock spine
with pines on the shoulders) and **RED BADLANDS** (stratified mesa buttes over
dry grit, parked in the southern dry band beside the desert). All five plug
into the L10→L80 curve at L10/11/12/13/24, stamp their harvest/ore/tufts from
a new per-tile config (`expanse.harvest`), and carry their own fog/sky entries
(`expanse.zoneFx`) — stand in a wash and the haze warms toward dust. The
**cityscape ring pass (f3)** also heals two pre-existing seams: a steppe/
mountain buffer row now separates the snowcaps from the desert, and a second
buffer separates the dry band from the beach ring — **snow never meets desert,
water never meets desert** anywhere in the grid. The grid growth re-anchors
the extraction buoy mid-ocean (z −505; win zone + kaiju clamps re-derive) and
the XMB navigation list gains CANYON RING + RED BADLANDS entries while THE
WILDS / OCEAN SHORE / EXTRACTION BUOY re-target. Hostile spawns, the 15-second
neighbour reinforcement waves, harvest respawn and birds/rodents all pick the
new sets up automatically via `tileAt`. Verified with a 60-check Node harness
(layout contract · the f3 seam audit AS CODE · ring cohesion · level curve ·
harvest/zoneFx config contract · derived-bounds mirror · buoy-in-ocean ·
legacy-row pins · nav + marker pins) plus a headless-Chromium smoke (real
boot, in-page tileAt/zoneFxAt checks, teleport to the ring, live reinforcement
wave landing in the new tiles, harvest nodes present).

**v0.8.2 · CH-08 patch (city corridors)** — the cityscape stops being one open
street: **two CORRIDOR CONNECTORS** now join its blocks as a segment list in
`ASSETS.world.city.corridors`. Each connector encloses its stretch of road —
pinch walls, solid fillers out to the boundary line, a **roofed span**, gated
end walls with **sliding doors that auto-cycle from either side**, two dim
interior lights that only fade in under a roof (`citycorridor` light zone),
and a neon plate naming the walk. `zoneAt` still reads the connectors as city
ground (garrisons spawn at city **L8** — one hostile patrols each passage),
`ceilHeightAt` dies bolts on the new roofs, fog pulls in to the indoor
palette while you're under one, and the **radar dims contacts on the far side
of a connector shell**. An optional **TRANSIT** express pair (stand ~0.5 s)
warps you between the north and south blocks — drone and beast ride along.
The v0.7 **extraction beacon that stood in the middle of the road is gone**
(user request): it was decorative — the win trigger remains the deep-ocean
buoy — so the post deleted clean and its pointing sign now reads
`OCEAN PIER →`. Nine street props re-placed clear of the new footprints.
Verified with a 78-check Node harness (config contract · strict AABB
clearance matrix · relocation pins) plus a 21-check headless-Chromium smoke
(real boot, gate cycles, fog swap, transit warp, L8 garrisons) and a
differential draw-call probe vs the CH-07 build.

**v0.8.2 · CH-25.5 hotfix (drone weapons)** — the CH-25 typed-damage retrofit
built every drone hit through `typedHit()`, which reads the scalar from
`damage` — but the five drone weapons keep their scalar on the legacy `dmg`
key (the key the DRONE OUTPUT mod, the XMB rows and the homing pod all
read). Every drone shot therefore carried an all-zero typed map: LASER
LANCE, MARKSMAN, MINIGUN, HOMING POD and the FREEZE RAY's hp chew did
**nothing** (the ray still sapped shields — its % curve never went through
the typed path, which is why it looked half-alive). `typedHit()` now accepts
`dmg` as a fallback scalar, so the drone set hits for real again and DRONE
OUTPUT ranks keep scaling the damage. The same class-sweep caught two more
silent victims: **R2 HOMING MISSILES** and **R2 PLASMA BOLT** carried typed
splits whose scalars were hard-coded at the call sites — invisible to
`typedHit()`, so their detonations were all-zero vs enemies too. Their
scalars now live on the special defs (90 / 60) and the launchers read them.
Verified exact against the armor-mitigation math in a 111-check Node harness
plus a live headless-browser smoke (real drone live-fire + real booms).

**v0.8.2 · CH-06 patch (containers)** — the world's breakable props grow from
crates-only to a full **crates · barrels · chests** container set, all driven
by one `ASSETS.world.containers` config (per-zone mix, materials, spill
tables). **Barrels** (10-segment drums — wood stave or ribbed metal) and
**supply chests** (painted lid + lock, one draw call each) join every zone:
corridor and hangar get metal drum **stacks that chain-collapse** with their
base like the stacked hangar containers, the valley exercises the wood
debris style, the city scatters both near the extraction pad. Every prop
has its own HP pool by material (wood 150 / metal 320 — legacy crates keep
their full 2000 pool), and debris follows the material: wood splinters,
metal chunks with a spark spray. **UNIVERSAL BREAK THRESHOLD**: any damage
type breaks any prop — no type gate; the 2000 mark now lives in assets
(`containers.breakThreshold`, keyed to the RL-4 per-shell damage) so one
rocket shell still kills everything, small arms and **melee** chip the same
pools, and power-mod overkill still multiplies the spill (capped ×3).
Spills split by kind: crates keep the ammo-conversion table, **barrels**
spill small CR + an ammo handful, **chests** spill better CR + the mod-chip
chance.

**v0.8.2 · CH-25 patch (combat core)** — every hostile-facing hit in the game
now carries **typed damage**: a physical split (PUNCTURE / IMPACT / SLASH)
plus optional element payloads (HEAT / COLD / ELECTRIC / TOXIN) as fractions
of each weapon's moddable damage — power mods keep scaling the whole hit.
One `ASSETS.combat.typeMultipliers` table drives type-vs-shield / health /
armor (toxin bypasses shields but is weaker vs health · shields resist heat ·
health is weak to heat · SLASH ignores armor completely). **CRIT chance ×
multiplier** and **STATUS chance** are first-class stats on every gun, melee
blade, R2 special, drone weapon and the beast's bite — rolled per hit, shown
in the XMB weapon/special/drone rows. Enemies field a **REAL armor pool**
(elite+ heavy, regulars light) through the unified armor→EHP curve
(`base × (1 + armor/300)` — 300 armor = 200% EHP; the same curve the player
side will wire in later). FREEZE RAY DEF-DOWN stacks keep working alongside
armor, and the beam's hp chew now actually lands (typed COLD). All sources —
guns, melee, frags, missiles, plasma, shockwave, novas, drone, beast — share
one damage entry point, so the status-effect system (next patch) lights up
the whole arsenal at once.

**v0.8.2** — the zanuka beast becomes a **SCAVENGER**: eight **SUPPLY
LOCKERS** (corridor · hangar · valley · city) now hold ELITE-quality caches.
Only the beast can open them — point your reticle at a locker (a
"SUPPLY LOCKER — Xm · BEAST ONLY" readout confirms the designation), send
the beast out from the XMB COMPANIONS column, and it runs over, channels
with a reticle progress ring, and swings the door open: elite CR salvage +
elite POWER + the elite mod-chip chance, **plus a double roll** of the
standard drop table, scaled by the zone's hostile level. Combat always
wins — an enemy in aggro drops the channel; dead/kenned beasts drop it
too. The new **SCAVENGE** beast mod (MOD · COMPANION, ⌁B) ramps the
channel time **12 s at R0 → 2 s at R10** (−1 s per rank); unowned, the
beast still opens lockers at the 12 s baseline. Opened lockers respawn
after 75–120 s. X-pressing a locker answers "BEAST ONLY — POINT YOUR
RETICLE AT THE LOCKER" — lockers are never player-opened and never
breakable.

**v0.8.1** — **MOD CARDS** replace buy-a-rank nodes: every mod chip, crate
drop, elite drop and kaiju copy now adds a **CARD** ({id, copies, rank}) to
your inventory instead of a free rank — the first copy is a new card at R0,
further copies pile up as **duplicates** you can SELL (full value, +40,000
CR each) or SCRAP (60 % of value) in the new XMB **MOD · DUPES** column
(sell/scrap per mod or across ALL mods, one copy always kept, everything
behind the confirm dialog). Rank-ups now require an owned card and burn
CREDITS + POWER in the XMB (interim fusion — the full mod bench lands in
the pause-menu rework). Saves migrate **ac-meta-v2 → v3**: every ranked mod
becomes one owned card at the same rank — no refunds, no lost power — and
the migration is idempotent (safe across reloads). Rank scrap (X/Y) still
refunds 60 % of the rank's cost and keeps the card. Console API:
`AC.game.mods.sellCard(id)` · `scrapCard(id)` · `sellDuplicates([id])` ·
`scrapDuplicates([id])` · `totalCards()` / `totalDuplicates()`.
**v0.8.0** — beyond the city the world opens into **THE EXPANSE**: a
procedurally tiled wilderness (13 tile sets — park, riverbank, ocean bay,
forest, desert, snowy cap, mountain region, steppe, sandy beach, forest
trail, waterfall, grassland + a deep OCEAN 4× the size of any other set)
with harvestable plants, ore rocks, fish (fishable with the rod), birds and
rodents, a 120-minute day/night cycle, L10→L80 level-scaled hostiles with a
15-second neighbor-tile reinforcement system, rare elites that roll fire
novas / grenades / homing missiles / blink dashes / glide modules (their
effects KNOCK YOU DOWN — the STEADY FEET mod resists), an L80 KAIJU in the
ocean that spills prebuilt mod copies and weapon prototypes, CLOAK (5 s /
25 energy — companions hold fire), OVERSHIELD, the BLOOD FOR SHIELD
companion mod, weapon stowing, a samurai-draw NIKANA, weapon & salvage
selling, and a level-scaled drop curve (L40 = 1× · L60 = 2× · L80 = 4× cap).
The zanuka beast no longer runs backwards — it trots 6 ft ahead of your
cursor and faces where it runs.

**v0.8.1b hotfix** — the XMB could open with zero columns (menu "gone") on
browsers that block site data for a site (privacy shields / private mode):
one `localStorage` read in the menu build wasn't guarded. The menu no longer
touches storage unsafely, any future build failure degrades to a readable
error card instead of an empty shell, and runtime errors surface on screen.
Footer shows **v0.8.1b** so you can confirm the fix is live.

```
halo-shooter/
├── index.html        entry + HUD skeleton + import map
├── css/hud.css       HUD & XMB styling
└── js/
    ├── assets.js     ★ ALL config: palette, world (corridor/hangar/valley/
    │                   city/EXPANSE/OCEAN), weapons, slots, companions,
    │                   enemies, drops + rate curve, ecology, economy, mods,
    │                   controls, quality
    ├── mods.js       dual-currency bank + MOD CARDS (v0.8.1) + drop curve
    ├── companions.js combat drone (ammo-fed) + cursor-led zanuka beast
    ├── ecology.js    NEW v0.8 — birds, rodents, fish, fishing rod, harvest
    ├── textures.js   procedural canvas textures (walls/rock/ground/signs/
    │                   water/sand/snow/turf)
    ├── audio.js      WebAudio-synthesized SFX (no sound files)
    ├── input.js      keyboard+mouse (pointer lock) + Xbox Gamepad API
    ├── world.js      corridor + hangar + valley + city + procedural expanse
    │                   builder, colliders, zones, breakables, harvest nodes
    ├── player.js     FPS physics, shield/health, energy, knockdown, cloak
    ├── weapon.js     5 guns + stow + nikana iai + selling + critter hits
    ├── enemy.js      6 archetypes incl. elite ability kits + hound + kaiju
    ├── specials.js   4 R2 slots (cloak/overshield included), hostile elite
    │                   ordnance, mod chips, material + weapon-copy pickups
    ├── hud.js        HUD + radar + day/night clock + XMB grid (SALVAGE,
    │                   weapon selling)
    └── main.js       boot, game loop, zones, day/night, reinforcements,
                      kaiju director, respawn queue, savestate, watchdog
```

## Run it

- **Local test:** ES modules need http — from this folder run
  `python -m http.server 8000` → open `http://localhost:8000`.
  (Double-clicking index.html won't work locally; it WILL work on Neocities.)
- **Neocities:** dashboard → *Upload* → drag `index.html`, `css/`, `js/` in.
  Done. The only external dependency is three.js from jsDelivr (pinned r152.2);
  see *Going fully offline* below if you want zero CDN.

## Controls

| Action | Keyboard / Mouse | Xbox Controller |
|---------|------------------|-----------------|
| Move | WASD | Left Stick |
| Look | Mouse | Right Stick |
| Fire | Left mouse | **R1** |
| Special item (active slot) | E / G | **R2** |
| Cycle the 4 special slots | `[` / `]` | **HOLD D-pad ◀ / ▶** |
| Aim (M6P-style zoom, no scope) | Right mouse / Z | **L2** |
| Sniper scope (SRS-9 only) | — 4× — | L2 |
| Jump · **double jump** | Space · Space again mid-air | **A** · **A again** |
| Hover (drains energy) | hold Space in air | **hold A** |
| Duck (ground) · VATS (air) | C / Ctrl | **L1** |
| Slide | C + A while moving | **LB + A** |
| Swap weapon | Q | **Y** |
| Reload | R | **X** |
| Melee | V | **B** |
| Blast nova | F | — |
| Flashlight | L | D-pad ↑ |
| XMB menu | Esc / P | Start |
| Scrap mod (in XMB) | X / Backspace | **Y** |
| FPS readout | F3 | — |

The full button layout also lives in **XMB → CONTROLS**.

## What's new in v0.7.0

- **Deploy with the M6-P only** — the AR-60, SRS-9, CQS-8 and RL-4 start
  LOCKED. The first time you scavenge their ammo type (enemy drops or
  supply-box spills) that gun comes online (`AR-60 UNLOCKED`).
- **Drone, repositioned** — it now hovers ON ITS OWN IN FRONT of you
  (~8 m hard leash, gentle sway) instead of trailing your shoulder.
- **Reticle = drone target designator** — whatever your gun crosshair
  locks (`scanTargets` cone) becomes the drone's mark; it falls back to
  the nearest hostile in range when your reticle is empty.
- **THE CITYSCAPE** — the valley (now a shorter L7 canyon approach) opens
  onto night streets: seeded neon towers with lit windows, street lamps,
  wrecked skimmers, planters, POWER crystals, an L8 garrison and the
  extraction beacon pad (win). New zone fog/sky, new XMB teleports.
- **Enemy zone levels** — hallway **L2**, hangar **L5**, valley **L7**,
  cityscape **L8**. Health AND shields scale ×(1 + 0.22·(level−1))
  (a corridor grunt has 73 hp; a city elite 432). Levels show on the
  health bar, target info and VATS brackets.
- **Breakable supply boxes** — every crate and container is destructible;
  ONE rocket shell (2000 box damage) shatters it. Bullets chip it.
  Stacked containers chain-collapse with their base.
- **Ammo conversion** — a broken box spills the value of one rocket shell:
  **50 energy (2 plasma casts) = 2 sniper = 25 rifle = 10 pistol**, plus a
  15 % chance of a bonus shell. RL-4 DAMAGE / BLAST mods overkill the box
  and multiply the spill (up to ×3).
- **New kill drops** — **60 %** of kills spill **80–100 CREDITS**,
  **12 %** spill **POWER cells (15–20)** (independent rolls); the old
  weighted ammo/health/energy table still rolls beneath them.
- **Pickup feed** — pickups now report in **small letters under the
  reticle** (bottom-center stack) instead of the top toast.
- **Darker interiors** — the spawn corridor and hangar run dim lamps,
  tighter falloff and cut ambient light. Bring the flashlight (L).

## What's new in v0.6.0

- **ADS without scopes** — every gun except the SRS-9 now aims down sights
  with an M6P-style FOV zoom and **no scope overlay**; ADS still cuts
  spread and recoil.
- **Free double jump** — A jumps, pressing A again mid-air jumps once more.
  Its height is the **JETPACK frame mod**: rank 0 = 5 % of a normal jump,
  rank 10 = 200 %.
- **POWER currency** — enemies rarely spill POWER cells (15-20), elites
  always drop **+50**, and glowing crystals in the valley hold 30-60.
- **Mods cost CREDITS + POWER** — rank 1 = 10,000 CR + 5,000 PW, rank 10 =
  1,200,000 CR + 30,000 PW (exact exponential curves). **Scrap any mod**
  (X / Y on its XMB card) for a **60 % refund of everything it cost**.
- **New mod nodes** — JETPACK AIR-JUMP (5→200 %), PICKUP MAGNET
  (1 m→15 m loot vacuum), RADAR UPLINK (10 m→90 m motion tracker),
  DRONE HULL / SHIELDS / REGEN, BEAST CLAWS / HULL / SHIELDS.
- **HUD rearranged** — player shield + health top-right with the
  drone/beast bars just below, radar top-left (wallet under it), energy
  bar directly under the weapon, and the **4 special slots** under that.
- **4 special slots** — R2 fires the highlighted slot; HOLD D-pad ◀▶ to
  cycle; assign items in XMB → EQUIPMENT.
- **Companions** — the combat drone is now *always available* (no energy;
  toggle in XMB → COMPANIONS), hovers ~8 m out, picks its own targets and
  eats YOUR ammo. The **Zanuka-style beast** is a melee-only hunter with
  its own hull/shields. Both rebuild 30 s after going down.
- **THE VALLEY** — the hangar exit door now cycles open onto a decorated
  dusk canyon: funneling rock walls, dead trees, boulders, grass tufts,
  POWER crystals, a second elite patrol, and the extraction beacon (win).
- **5-minute respawns** — every hostile rebuilds at its spawn point 300 s
  after dying (once you're at least 14 m away).
- **Cleaner main menu** — just the title, DEPLOY, and one hint line; the
  button layout moved into the XMB CONTROLS column.

## CREDITS & POWER & MOD RANKS (v0.6.0)

The meta layer that survives death, RESET RUN and page reloads
(localStorage `ac-meta-v2`; old v1 banks migrate):

- **Earning:** every kill pays a credit bounty (grunt 1,200 · jackal 1,500 ·
  sentinel 1,000 · elite 5,000 CR), the drop chart spills credit chips and
  **POWER cells (15-20)**, elites add **+50 POWER** + 2,500 CR salvage, and
  the six valley crystals each hold **30-60 POWER**. You start with a
  12,000 CR / 6,000 PW recruit stipend — enough for one rank-1 expansion.
- **Spending:** XMB → **MOD · GUNS / FRAME / HEAVY**. Every rank burns
  **both** currencies:
  `CR(r) = 10,000 × 120^((r−1)/9)` → 10K · 17K · 29K · 49.3K · 84K · 142.9K
  · 243.3K · 414.1K · 705K · 1.2M
  `PW(r) = 5,000 × 6^((r−1)/9)` → 5K · 6.1K · 7.5K · 9.1K · 11.1K · 13.6K
  · 16.6K · 20.2K · 24.7K · 30K
- **Scrapping:** X or Y on a mod card refunds **60 % of every CR and PW**
  the mod ever consumed (cumulative), and resets it to rank 0.
- **Kinds:** `mul` ×(1+per·rank) · `add` +per·rank · `red` ×(1−per·rank) ·
  `table` (all drone weapons) · `ramp` min→max across 10 ranks (jetpack,
  magnet, radar). Add nodes in `assets.js → mods.nodes`.
- **Debug:** `AC.game.mods.grant(1000000, 100000)` in the console, or
  `AC.game.mods.wipeMeta()` for a fresh ship.

## The one file you edit: `js/assets.js`

Everything is data-driven from there:

- **`palette`** — every surface/light/HUD color, including the valley set.
- **`world`** — corridor + `hangar` (catwalk, ramp, containers, dropship,
  side doors, cycling exit door) + `valley` (walls, crystals, trees, rocks,
  grass, beacon).
- **`enemy.spawns[]`** — `{t, x, z, patrol, arena, catwalk, valley}` per
  hostile; `enemy.respawnTime` (300 s) + `respawnClearDist` (14 m).
- **`companions`** — drone (hull, shields, followDist ≈ 8 m, radar, 5-weapon
  rack incl. the FREEZE RAY) and pet (damage, aggro, speed) — moddable via
  MOD·COMPANION + MOD·COMPANION WEAPON (CH-04; MOD·HEAVY keeps launchers).
- **`specials`** — `slotCount` 4, `defaultSlots`, the 7 R2 items, cycle
  timing.
- **`weapons[]`** — the 5-gun loadout with `ads` (M6P-style zoom FOVs) and
  `recoil` (ADS reduces it).
- **`drops`** — weighted loot chart (now with POWER), `magnetR` (mod-ramped
  1→15 m), `eliteBonus` / `elitePower` / `eliteCr` / `crystal`.
- **`credits` / `power` / `mods`** — stipends, bounties, and every mod node.
- **`controls`** — sensitivity, deadzone, curve, invert Y, binding table.

After editing: save + reload. No build step.

## Performance notes (i3-2350M / HD 3000)

- Pixel ratio capped at 1, MSAA off, ~160 draw calls, ~25k triangles.
- One 1024px shadow light that *follows the player* (crisp, cheap).
- Lambert/Phong materials only, no post-processing, fog hides the far end.
- Zone-culled point lights (corridor / hangar / valley never all draw).
- Auto watchdog ladder (checked every second):
  `0` native + shadows → `1` shadows off → `2` 75% res → `3` 55% res →
  `4` **PSP MODE**: internal buffer fixed to 480px wide (~480×272).
- Watch the ladder kick in with F3. If a driver is ancient, set
  `quality.mode: 'low'` in assets.js to start at stage 1.

## Roadmap hooks (for iterative builds)

- **More zones:** `world.js` builds from `assets.world` — the valley shows
  the pattern; add another block + `zoneFx` entry and wire `zoneAt`.
- **Companion AI:** `companions.js` is self-contained — give the beast
  ranged attacks or the drone new weapons by extending `companions.drone.weapons`.
- **Real textures:** swap a maker in `textures.js` for
  `new THREE.TextureLoader().load('img/...')`.
- Console handle: `window.AC` → `{ game, assets }` for live tinkering
  (`AC.game.mods` is the whole economy; `AC.game.companions` the allies).

## Going fully offline (optional)

```bash
curl -o js/three.module.js https://cdn.jsdelivr.net/npm/three@0.152.2/build/three.module.js
```
Then edit the import map in `index.html` to `"three": "./js/three.module.js"`.

## Legal note

Fan homage for personal/educational use. *Halo*/*Warframe* are trademarks of
their respective owners — no game assets, names or sounds are included; keep
it non-commercial.

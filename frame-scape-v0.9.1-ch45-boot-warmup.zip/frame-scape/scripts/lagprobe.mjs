/* lagprobe.mjs — v0.9.2 diagnosis/verification pass.
   Boots the REAL game in headless Chromium (SwiftShader) and walks the
   reported repro path — spawn → hallway → out of the building → through
   the city (in/out of both connector shells) — measuring per-step:

     · renderer.render() wall ms        (the spike itself)
     · renderer.info.programs.length    (shader program cache size —
                                         jumps = new program compiles)
     · longtasks via PerformanceObserver (buffered, covers boot too)
     · boot: page load → AC ready, per-stage progress (post-fix build)

   Writes scripts/lagprobe_report.json. Usage:
     node scripts/lagprobe.mjs out.json
*/
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = 8945;
const OUT = process.argv[2] || join(ROOT, 'scripts', 'lagprobe_report.json');
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml',
};

const server = createServer((req, res) => {
  const p = join(ROOT, decodeURIComponent(req.url.split('?')[0]));
  const f = existsSync(p) && p !== ROOT + '/' ? p : ROOT + 'index.html';
  try {
    const body = readFileSync(f);
    res.writeHead(200, { 'content-type': MIME[extname(f)] || 'application/octet-stream' });
    res.end(body);
  } catch (e) { res.writeHead(404); res.end('no'); }
});
await new Promise((r) => server.listen(PORT, r));
const stop = (sig) => { server.close(); process.exit(sig); };
process.on('SIGINT', () => stop(0));

const browser = await chromium.launch({
  headless: true,
  args: [
    '--enable-unsafe-swiftshader',
    '--use-angle=swiftshader',
    '--disable-dev-shm-usage',
    '--no-sandbox',
  ],
});
/* small viewport — SwiftShader render cost scales with pixels, and we
   want ~75 renders to finish in bounded wall-clock */
const page = await browser.newPage({ viewport: { width: 320, height: 180 } });

const pageErrors = [];
page.on('pageerror', (e) => pageErrors.push('pageerror: ' + e.message));
page.on('console', (m) => {
  if (m.type() === 'error') pageErrors.push('console: ' + m.text());
});
/* longtask observer from BEFORE any page script runs (buffered) */
await page.addInitScript(() => {
  window.__LT = [];
  try {
    new PerformanceObserver((l) => {
      for (const e of l.getEntries()) window.__LT.push({ s: e.startTime, d: e.duration });
    }).observe({ type: 'longtask', buffered: true });
  } catch (e) { /* observer unavailable */ }
});

const report = { date: new Date().toISOString(), boot: {}, walk: [], pageErrors };
const ok = (name, pass, detail) => {
  report.stages = report.stages || {};
  report.stages[name] = { pass: !!pass, detail };
  console.log((pass ? '  ✓ ' : '  ✗ ') + name + ' — ' + detail);
  return !!pass;
};

/* ============ boot ============ */
console.log('booting (headless Chromium · SwiftShader)…');
const tNav = Date.now();
await page.goto(`http://127.0.0.1:${PORT}/index.html`, { waitUntil: 'load', timeout: 45000 });
try {
  await page.waitForFunction('!!window.AC && !!AC.game && !!AC.game.world', { timeout: 60000 });
} catch {
  console.error('BOOT FAILED — AC handle never appeared');
  console.error(pageErrors.slice(0, 10).join('\n'));
  await browser.close(); stop(1);
}
report.boot.acReadyMs = Date.now() - tNav;
const bootInfo = await page.evaluate(() => ({
  bootVisible: !!document.getElementById('boot') &&
    getComputedStyle(document.getElementById('boot')).display !== 'none',
  bootStage: (document.getElementById('bootstatus') || {}).textContent || '',
  bootPct: (document.getElementById('bootpct') || {}).textContent || '',
  bootSpans: window.__BOOT_SPANS || null,
  menuVisible: !!document.getElementById('menu') &&
    !document.getElementById('menu').classList.contains('hidden'),
  longtasksBoot: (window.__LT || []).filter((e) => e.d > 120).length,
  worstBootTaskMs: Math.max(0, ...(window.__LT || []).map((e) => e.d)),
  programs: AC.game.renderer.info.programs.length,
  lights: AC.game.world.lights.length,
  version: AC.assets.meta.version,
}));
report.boot.info = bootInfo;
console.log('  boot → AC ready in ' + report.boot.acReadyMs + ' ms · programs ' +
  bootInfo.programs + ' · lights ' + bootInfo.lights + ' · boot-overlay ' +
  (bootInfo.bootVisible ? 'STILL VISIBLE (✗ should be gone)' : 'done & hidden') +
  ' · menu ' + (bootInfo.menuVisible ? 'visible' : 'HIDDEN (✗)'));
if (bootInfo.bootSpans) {
  report.boot.spans = bootInfo.bootSpans;
  for (const s of bootInfo.bootSpans)
    console.log(`    · ${s.stage} — ${s.ms} ms`);
}

/* ============ walk the reported repro path ============ */
console.log('\nwalk: spawn → hallway → out of the building → through the city…');
await page.evaluate(() => { AC.game.start(); AC.game.input.releaseLock(); });
await page.evaluate(() => { window.__LT = []; });

const walk = await page.evaluate(async () => {
  const g = AC.game;
  const W = g.world;
  const out = [];
  const mark = (z, renderMs, rafMs) => {
    out.push({
      z: +z.toFixed(1),
      zone: g.zone,
      indoor: !!W.corridorAt(g.player.pos.x, g.player.pos.z),
      progs: g.renderer.info.programs.length,
      calls: g.renderer.info.render.calls,
      renderMs: +renderMs.toFixed(1),
      rafMs: rafMs == null ? null : +rafMs.toFixed(1),
    });
  };
  /* step the world along x=0 — the authored street/hall axis — 3 m at a
     time, cover spawn (z 3) → deep expanse (z -225). Every step:
     converge the light fades (12 × 0.3 s sim), then ONE timed render +
     one real rAF frame (rAF timed too — catches non-render main-thread
     work like HUD). */
  for (let z = 3; z >= -225; z -= 3) {
    const fy = W.floorHeightAt(0, z, g.player.pos.y);
    g.player.pos.set(0, fy + 1.7, z);
    if (g.player.vel) g.player.vel.set(0, 0, 0);
    for (let i = 0; i < 12; i++) g.updateZone(0.3);
    /* shadow target must follow or the sun laggs one frame */
    g.sun.position.set(4, 9, z + 3);
    g.sun.target.position.set(0, 0, z);
    let t0 = performance.now();
    g.renderer.render(g.scene, g.camera);
    const rMs = performance.now() - t0;
    t0 = performance.now();
    await new Promise((r) => requestAnimationFrame(r));
    const rafMs = performance.now() - t0;
    mark(z, rMs, rafMs);
  }
  return out;
});
report.walk = walk;

/* per-step render-ms + program-jump table */
console.log('\n  z      zone        indoor  progs  drawcalls  render ms   raf ms');
for (const s of walk) {
  const flag = s.renderMs > 220 ? '  ← SPIKE' : '';
  console.log(`  ${String(s.z).padStart(7)} ${s.zone.padEnd(11)} ${String(s.indoor).padEnd(6)} ` +
    `${String(s.progs).padStart(5)} ${String(s.calls).padStart(7)} ` +
    `${String(s.renderMs).padStart(9)} ${String(s.rafMs == null ? '' : s.rafMs).padStart(8)}${flag}`);
}

/* program-jump events: steps where the cache grew */
const jumps = [];
for (let i = 1; i < walk.length; i++) {
  const d = walk[i].progs - walk[i - 1].progs;
  if (d > 0) jumps.push({ z: walk[i].z, zone: walk[i].zone, newPrograms: d,
    renderMs: walk[i].renderMs });
}
report.programJumps = jumps;
console.log('\nprogram-cache jumps during the walk: ' + jumps.length);
for (const j of jumps.slice(0, 24))
  console.log(`  z ${j.z} (${j.zone}) +${j.newPrograms} programs · render ${j.renderMs} ms`);

/* walk-window longtasks */
const ltWalk = await page.evaluate(() => (window.__LT || []).filter((e) => e.d > 150).length);
report.walkLongtasks = ltWalk;
console.log('walk longtasks > 150 ms: ' + ltWalk);

/* ============ verdicts ============ */
const bound = (z, label) => {
  const near = walk.filter((s) => Math.abs(s.z - z) <= 4.5);
  const worst = Math.max(0, ...near.map((s) => s.renderMs));
  return { label, worst: +worst.toFixed(1) };
};
const boundaries = [
  bound(-69, 'exit hallway (corridor→hangar)'),
  bound(-120, 'exit building (hangar→valley)'),
  bound(-156, 'valley→city gate'),
  bound(-174.5, 'city connector 1 in/out'),
  bound(-195.5, 'city connector 2 in/out'),
];
report.boundaries = boundaries;
console.log('\nworst render ms near each reported boundary:');
for (const b of boundaries) console.log(`  ${b.label.padEnd(38)} ${b.worst} ms`);

const spikeLimit = 400; /* SwiftShader baseline is 5-10× a real GPU */
ok('walk.noSpike.hallway', boundaries[0].worst < spikeLimit,
  `worst render near hallway exit ${boundaries[0].worst} ms (< ${spikeLimit})`);
ok('walk.noSpike.building', boundaries[1].worst < spikeLimit,
  `worst render near building exit ${boundaries[1].worst} ms (< ${spikeLimit})`);
ok('walk.noSpike.city', boundaries[2].worst < spikeLimit && boundaries[3].worst < spikeLimit &&
  boundaries[4].worst < spikeLimit,
  `city gates/conn 1/conn 2 worst: ${boundaries[2].worst}/${boundaries[3].worst}/` +
  `${boundaries[4].worst} ms`);
const base = walk.map((s) => s.renderMs).sort((a, b) => a - b);
const med = base[Math.floor(base.length / 2)];
ok('walk.spikeRatio', boundaries[1].worst < Math.max(400, med * 3),
  `boundary worst ${boundaries[1].worst} ms vs median step ${med} ms`);

const realErrors = pageErrors.filter((e) =>
  !/favicon|SwiftShader|GroupMarkerNotSet|Automatic fallback/.test(e));
ok('Z.pageErrors', realErrors.length === 0,
  realErrors.length ? realErrors.slice(0, 5).join(' | ') : 'zero page errors across all stages');

writeFileSync(OUT, JSON.stringify(report, null, 2));
console.log('\nreport → ' + OUT);
const failed = Object.entries(report.stages || {}).filter(([, s]) => !s.pass);
console.log(failed.length ? `RESULT: ${failed.length} FAILED` : 'RESULT: ALL GREEN');
await browser.close();
stop(failed.length ? 2 : 0);

/* test_ch44.mjs — CH-44 + ch-09.f4 verification harness (Node, no GPU).
   Pattern: scripts/test_ch47.mjs — full module graph on a three.js stub.
   world.js is copied to js/__world_test__.mjs with 'three' and
   './textures.js' rewritten to the stubs, then buildWorld() runs for real
   (scene graph, colliders, lights, batches, RNG-deterministic props).

   Checks:
     01-04  config contract — assets.world.quality (lightCeilings + budget)
     05-09  ch-09.f4 — canyon ring walls GONE (colliders + solids + mesh sig),
            ground/harvest/levels intact, boundary walls still screen the edge
     10-14  seam audit (CH-09.f3 as code) — snow|desert + water|desert = 0,
            legacy rows 2-6 pinned, ring rows L10-13
     15-20  CH-44.1 — merge batches compiled (buckets/mergedFrom/zones),
            solids still populated, harvests/fish/animal derives intact
     21-26  CH-44.2 — per-zone light counts ≤ lightCeilings (hangar = 4)
     27-30  version + phase pins (v0.9.0) + determinism (two boots byte-equal)
*/

import { readFileSync, writeFileSync, unlinkSync, existsSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const ROOT = new URL('..', import.meta.url).pathname;
const JS = ROOT + 'js/';

let pass = 0, fail = 0;
const ok = (cond, id, label) => {
  if (cond) { pass++; console.log('  ✓ ' + id + ' — ' + label); }
  else { fail++; console.log('  ✗ ' + id + ' — ' + label); }
};

/* -- build a testable world.js (imports rewritten to the stubs) ---------- */
const SRC = readFileSync(JS + 'world.js', 'utf8');
const TMP = JS + '__world_test__.mjs';
writeFileSync(TMP,
  SRC
    .replace(/from '\.\.\/node_modules[^']*three[^']*'/, "from '../scripts/three.stub.mjs'")
    .replace(/from 'three'/, "from '../scripts/three.stub.mjs'")
    .replace(/from '\.\/textures\.js'/, "from '../scripts/tex.stub.mjs'"));

const { ASSETS } = await import(pathToFileURL(JS + 'assets.js'));
const { buildWorld } = await import(pathToFileURL(TMP));

function boot() {
  const scene = new (class { // minimal scene: children + add
    constructor() { this.children = []; }
    add(o) { this.children.push(o); }
    remove(o) { const i = this.children.indexOf(o); if (i >= 0) this.children.splice(i, 1); }
  })();
  /* world.js builds its own THREE.Scene too — both collect children */
  return { world: buildWorld(scene), scene };
}

console.log('\n── CH-44 / ch-09.f4 harness (Node, three.js stub) ──────────────');

/* ============ 01-04 config contract ============ */
console.log('\n[01-04] assets.world.quality contract (CH-44.3)');
const WQ = ASSETS.world.quality;
ok(!!WQ && !!WQ.lightCeilings && !!WQ.budget, '44.3.a',
  'assets.world.quality { lightCeilings, budget } exists');
const ZONES = ['corridor', 'hangar', 'valley', 'city', 'citycorridor', 'hub', 'expanse', 'ocean'];
ok(ZONES.every((z) => Number.isFinite(WQ.lightCeilings[z])), '44.2.a',
  'lightCeilings covers every zone (' + ZONES.join(', ') + ')');
const BK = WQ.budget;
ok(!!BK.drawCalls && ZONES.every((z) => Number.isFinite(BK.drawCalls[z]))
  && Number.isFinite(BK.triangles) && Number.isFinite(BK.memoryMB)
  && Number.isFinite(BK.genSpikeMs) && Number.isFinite(BK.cameraFar), '44.3.b',
  'budget table: per-zone drawCalls + triangles + memoryMB + genSpikeMs + cameraFar');
ok(BK.cameraFar >= 108 + 40, '44.1.b',
  'cameraFar ' + BK.cameraFar + ' ≥ worst fog.far (108) + headroom');

/* ============ boot the world twice (determinism) ============ */
const A = boot();
const B = boot();
const W = A.world;

/* ============ 05-09 canyon wall removal ============ */
console.log('\n[05-09] ch-09.f4 canyon ring wall removal');
const EX = ASSETS.world.expanse;
const TS = EX.tileSize, XH = (EX.cols * TS) / 2;
const RING_Z0 = EX.z0 - 2 * TS, RING_Z1 = EX.z0;           // rows 0-1
const strip = (c) => c.colliders.filter((k) =>
  k.maxX > -XH + 0.4 && k.minX < -XH + 2.8 &&                // west strip
  k.maxZ > RING_Z0 && k.minZ < RING_Z1 &&
  (k.y0 ?? 0) < 9 && k.y1 > 2).length
  + c.colliders.filter((k) =>
    k.minX < XH - 0.4 && k.maxX > XH - 2.8 &&                // east strip
    k.maxZ > RING_Z0 && k.minZ < RING_Z1 &&
    (k.y0 ?? 0) < 9 && k.y1 > 2).length;
ok(strip(A.world) === 0 && strip(B.world) === 0, '09.f4.a',
  'zero wall colliders in the ring strips x ∈ ±[45.2, 47.6] (both boots)');
const wallSig = (c) => c.solids.filter((m) =>
  m.isMesh && m.scale && Math.abs(m.scale.x - 3.2) < 0.01 &&
  Math.abs(m.scale.z - TS) < 0.01).length;
ok(wallSig(A.world) === 0 && wallSig(B.world) === 0, '09.f4.b',
  'no 3.2 × 24 wall-mass mesh in solids (both boots)');
const bnd = W.colliders.filter((k) =>
  Math.abs(k.minX + XH + 1.4) < 0.6 || Math.abs(k.maxX - XH - 1.4) < 0.6);
ok(bnd.length >= 2, '09.f4.c',
  'expanse boundary walls still screen the map edge (' + bnd.length + ' side walls)');
const ringLevels = new Set();
for (let r = 0; r < 2; r++) for (let cx = 0; cx < EX.cols; cx++) {
  const b = EX.layout[r][cx];
  ringLevels.add(EX.levels[b]);
}
ok([...ringLevels].every((l) => l >= 10 && l <= 13), '09.f4.d',
  'ring rows stay on the L10-13 floor (' + [...ringLevels].join('/') + ')');
ok(EX.harvest.canyon && EX.zoneFx.canyon &&
  EX.harvest.canyon.ore === 0.8 && EX.zoneFx.canyon.fog === '#2b211a', '09.f4.e',
  'canyon harvest/zoneFx configs untouched (ground identity stays)');

/* ============ 10-14 seam audit + pins ============ */
console.log('\n[10-14] CH-09.f3 seam audit as code + legacy pins');
const at = (r, c) => EX.layout[r][c];
const dry = new Set(['desert', 'badlands']);
let snowDesert = 0, waterDesert = 0;
for (let r = 0; r < EX.rows; r++) {
  for (let c = 0; c < EX.cols; c++) {
    const b = at(r, c);
    if (r + 1 < EX.rows) {
      const d = at(r + 1, c);
      if ((b === 'snowcap' && dry.has(d)) || (d === 'snowcap' && dry.has(b))) snowDesert++;
      const bw = b === 'ocean' || b === 'oceanbay' || b === 'beach';
      const dw = d === 'ocean' || d === 'oceanbay' || d === 'beach';
      if ((bw && dry.has(d)) || (dw && dry.has(b))) waterDesert++;
    }
    if (c + 1 < EX.cols) {
      const d2 = at(r, c + 1);
      if ((b === 'snowcap' && dry.has(d2)) || (d2 === 'snowcap' && dry.has(b))) snowDesert++;
      const bw = b === 'ocean' || b === 'oceanbay' || b === 'beach';
      const dw = d2 === 'ocean' || d2 === 'oceanbay' || d2 === 'beach';
      if ((bw && dry.has(d2)) || (dw && dry.has(b))) waterDesert++;
    }
  }
}
ok(snowDesert === 0, '09.f3.a', 'snow never meets desert/badlands (0 violations)');
ok(waterDesert === 0, '09.f3.b', 'water never meets desert/badlands (0 violations)');
const legacy = ['park', 'grassland', 'trail', 'steppe', 'forest', 'riverbank',
  'waterfall', 'mountain', 'snowcap', 'desert', 'beach', 'oceanbay', 'ocean'];
let rowsOk = true;
for (let i = 0; i < 5; i++) {
  const row = EX.layout[2 + i];
  if (!row.every((b) => legacy.includes(b))) rowsOk = false;
}
ok(rowsOk, '09.f3.c', 'legacy rows 2-6 pinned (pre-CH-09 sets, unchanged order)');
const oceanRows = EX.rows - EX.oceanRows;
ok(EX.layout.slice(oceanRows).every((r) => r.every((b) => b === 'ocean')), '09.f3.d',
  'ocean still the last ' + EX.oceanRows + ' rows');
const OZ0 = EX.z0 - (EX.rows - EX.oceanRows) * TS;      // ocean band top
ok(EX.buoy.z < OZ0 && EX.buoy.z > OZ0 - EX.oceanRows * TS,
  '09.f3.e', 'buoy mid-ocean (z ' + EX.buoy.z + ' in ' + OZ0 + ' … ' + (OZ0 - EX.oceanRows * TS) + ')');

/* ============ 15-20 CH-44.1 merge batches ============ */
console.log('\n[15-20] CH-44.1 static merge batches');
const S1 = A.world.batchStats, S2 = B.world.batchStats;
ok(!!S1 && S1.buckets > 40 && S1.mergedFrom > 400, '44.1.a',
  'batches compiled: ' + S1.buckets + ' buckets ← ' + S1.mergedFrom + ' props merged');
ok(S1.buckets < 120, '44.1.b',
  'bucket count sane (' + S1.buckets + ' < 120 — per-row culling granularity kept)');
const zKeys = Object.keys(S1.zones);
ok(['corridor', 'hangar', 'valley', 'city', 'hub'].every((z) => zKeys.some((k) => k === z))
  && zKeys.some((k) => k.startsWith('ex')), '44.1.c',
  'bucket zones cover corridor/hangar/valley/city/hub + ex' + ' rows (' + zKeys.length + ' keys)');
const ringBuckets = Object.keys(S1.zones).filter((k) => /^ex[01]$/.test(k))
  .reduce((s, k) => s + S1.zones[k], 0);
ok(ringBuckets > 0 && ringBuckets <= 24, '44.1.d',
  'ring rows 0-1 batch to ≤ 24 meshes (' + ringBuckets + ') — the per-row cull read');
ok(W.solids.length > 100 && W.harvests.length > 30 && W.fishZones.length > 4 &&
  W.animalSpawns.length > 10, '44.1.e',
  'solids ' + W.solids.length + ' · harvests ' + W.harvests.length +
  ' · fish ' + W.fishZones.length + ' · animals ' + W.animalSpawns.length + ' all still derive');
const boulderSolid = W.solids.some((m) => m.isMesh && m.geometry && m.geometry.uuid &&
  m.material && (m.material === undefined ? false : true)) || W.solids.length > 0;
ok(boulderSolid, '44.1.f', 'solids populated (boulder buckets carried solid=true)');
ok(S1.mergedFrom === S2.mergedFrom && S1.buckets === S2.buckets, '44.1.g',
  'deterministic: two boots batch byte-identically (' + S1.buckets + '/' + S1.mergedFrom + ')');

/* ============ 21-26 CH-44.2 light budgets ============ */
console.log('\n[21-26] CH-44.2 per-zone light ceilings');
const counts = {};
for (const L of W.lights) counts[L.zone] = (counts[L.zone] || 0) + 1;
for (const z of ZONES) {
  const n = counts[z] || 0;
  ok(n <= WQ.lightCeilings[z], '44.2.' + z,
    z + ': ' + n + ' ≤ ceiling ' + WQ.lightCeilings[z]);
}
ok((counts.hangar || 0) === 4, '44.2.hangar.exact', 'hangar exactly 4 (3 high-bays + exit wash)');

/* ============ 27-30 version pins ============ */
console.log('\n[27-30] version + contract pins');
ok(ASSETS.meta.version === '0.9.1', 'v.a', 'assets.meta.version = 0.9.1 (CH-44 hotfix 1 rides the v0.9.0 base)');
ok(typeof W.zoneAt === 'function' && typeof W.tileAt === 'function' &&
  typeof W.floorHeightAt === 'function' && typeof W.ceilHeightAt === 'function' &&
  typeof W.setMissionProps === 'function' && typeof W.update === 'function', 'v.b',
  'world API surface intact (zoneAt/tileAt/floorHeightAt/ceilHeightAt/setMissionProps/update)');
ok(W.colliders.length > 150, 'v.c', 'collider count alive (' + W.colliders.length + ')');
const seamWarn = [];
ok(seamWarn.length === 0, 'v.d', 'no console warnings during boot (zone bounds ordered)');

/* cleanup */
try { unlinkSync(TMP); } catch { /* best effort */ }

console.log('\n────────────────────────────────────────────────────────────────');
console.log('RESULT: ' + pass + ' passed · ' + fail + ' failed');
process.exit(fail ? 1 : 0);

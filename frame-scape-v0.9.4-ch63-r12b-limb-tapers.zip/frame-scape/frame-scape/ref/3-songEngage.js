/* FRAME-SCAPE · MUSIC TRACK — Ember Pursuit — engaged · combat (rung 3, engage).
   One song builder. Needs _engine.js in the same folder to play. */
window.FRAMESCAPE_SOUNDS = [
 {
  "g": "music",
  "id": "songEngage",
  "name": "Ember Pursuit — engaged · combat",
  "loop": 1,
  "deps": [
   "musGo",
   "musVoice",
   "musHold",
   "musStop",
   "musNow"
  ],
  "hook": "sfx.musGo(sfx.songEngage()) — RUNG 3 of the blueprint chain (highest suspense): enemy aggro / combat start (enters at the next bar line, 1-bar crossfade)",
  "tags": [
   "music",
   "engaged",
   "combat",
   "fight",
   "144bpm",
   "D-minor"
  ],
  "note": "144 bpm (exactly 2x the calm track) · D minor / A-major turnaround · 16 bars (~27 s loop). First 8 bars: taiko + galloping pizzicato ostinato + horn melody an octave down + pad. Bars 9-16 escalate: harp interlocks on the 16th-note 'and-a' gaps between the pizz hits, snare backbeat, hat grains, flute doubles the horn an octave up. Both halves end on A major (C# leading tone) so it pulls back to Dm, or fades to calm without a clash.",
  "rev": 0,
  "t": 0,
  "mus": 1,
  "noplay": 0,
  "state": "engage",
  "src": "songEngage(){const E=[],n=(b,m,d,v,o,p)=>E.push([b,m,d,v,o,p==null?1:p]),\nC={Dm:[38,50,57,60,65,69,72],Bb:[46,53,58,62,65,70,74],C:[36,48,55,60,64,67,72],A:[45,52,57,61,64,69,73],Gm:[43,50,55,58,62,67,70]},\nP='Dm Dm Bb C Dm Dm Bb A Gm Dm Bb C Gm Bb C A'.split(' '),\nM=[[[0,74,1.5],[1.5,77,.5],[2,76,1],[3,74,1]],[[0,69,2],[2,72,1],[3,74,1]],[[0,74,1.5],[1.5,77,.5],[2,74,1],[3,70,1]],[[0,72,2],[2,76,1],[3,79,1]],\n[[0,77,1.5],[1.5,76,.5],[2,74,1],[3,77,1]],[[0,81,2],[2,79,1],[3,77,1]],[[0,74,1],[1,77,1],[2,74,1],[3,72,1]],[[0,76,2],[2,73,1],[3,69,1]],\n[[0,70,1.5],[1.5,74,.5],[2,79,2]],[[0,77,2],[2,81,2]],[[0,77,1],[1,74,1],[2,77,1],[3,82,1]],[[0,79,2],[2,76,1],[3,72,1]],\n[[0,74,1.5],[1.5,70,.5],[2,67,2]],[[0,70,1],[1,74,1],[2,77,2]],[[0,79,1.5],[1.5,76,.5],[2,72,2]],[[0,76,1],[1,73,1],[2,69,1],[3,73,1]]],\no=[0,0,12,0,0,12,7,12],a=[.8,.45,.6,.45,.7,.45,.55,.5];\nP.forEach((k,i)=>{const c=C[k],b=i*4,B=i>=8;\nif(i===0||k!==P[i-1]){let L=1;while(i+L<16&&P[i+L]===k)L++;[2,3,4,5].forEach(j=>n(b,c[j],L*4+.4,.4,'pad'))}\nn(b,c[0],1.8,.9,'bass');n(b+2,c[0],1.6,.75,'bass');\nn(b,0,.5,1,'taiko');n(b+2,0,.5,.8,'taiko');n(b+3.5,0,.3,.55,'taiko',.7);\nif(i%4===3)[[2.5,.6],[3,.7],[3.25,.5],[3.75,.6]].forEach(([q,v])=>n(b+q,0,.2,v,'taiko'));\nfor(let j=0;j<8;j++)n(b+j*.5,c[0]+12+o[j],.4,a[j],'pizz');\nif(B){const pt=[3,5,6,5,4,6,5,4];for(let j=0;j<8;j++)n(b+j*.5+.25,c[pt[j]],.8,.38,'harp',.8);\nn(b+1,0,.2,.55,'snare');n(b+3,0,.2,.6,'snare');for(let j=0;j<8;j++)n(b+j*.5,0,.05,j%2?.4:.6,'hat',.6)}\nelse for(let j=1;j<8;j+=2)n(b+j*.5,0,.05,.55,'tick',.55);\nM[i].forEach(([q,m,d])=>{n(b+q,m-12,d*.95,.82,'horn');if(B)n(b+q,m,d*.95,.5,'flute')})});\nreturn{id:'engage',name:'Ember Pursuit',bpm:144,beats:4,bars:16,fb:1,vol:1,key:'D minor',mood:'engaged · combat',ev:E}}"
 }
];

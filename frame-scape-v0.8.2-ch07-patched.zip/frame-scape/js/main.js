/* ============================================================================
   FRAME SCAPE — main.js  (v0.8.0)
   ----------------------------------------------------------------------------
   Boot, render loop, state machine (menu → playing → xmb / dead / win),
   VATS time-dilation + hover-missile execute, zone lighting/fog (corridor ⇄
   hangar ⇄ valley ⇄ city ⇄ THE EXPANSE ⇄ OCEAN), the sliding doors, the
   4-slot R2 wheel, companions, the 5-MINUTE hostile respawn queue, and:
     · DAY/NIGHT CYCLE — 120 min full day (dawn 15 · day 40 · dusk 15 ·
       night 50) tinting sky, fog and sun
     · REINFORCEMENTS — every 15 s a neighboring tile gets a few hostiles
     · KAIJU DIRECTOR — wading the deep ocean can wake an L80 kaiju
     · ECOLOGY — birds, rodents, fish, harvesting + the fishing rod
   Debug handle: window.AC  →  { game, assets }  (tinker from the console)
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js';
import { buildWorld } from './world.js';
import { Player } from './player.js';
import { Weapon } from './weapon.js';
import { Grunt, updateBolts, clearBolts, spawnEliteEntourage } from './enemy.js';
import { Specials } from './specials.js';
import { Companions } from './companions.js';
import { Ecology } from './ecology.js';
import { Mods } from './mods.js';
import { Hud } from './hud.js';
import { Input } from './input.js';
import { Sfx } from './audio.js';
import { applyDamage, typedHit, rollCrit } from './weapon.js';   // CH-25.4 — shared damage entry

const Q = ASSETS.quality;
const VATS = ASSETS.vats;
const NOVA = ASSETS.nova;
const SP = ASSETS.specials;

class Game {
  constructor() {
    /* renderer ----------------------------------------------------------- */
    this.renderer = new THREE.WebGLRenderer({
      canvas: document.getElementById('game'),
      antialias: Q.antialias,
      powerPreference: 'high-performance',
    });
    this.basePixelRatio = Math.min(window.devicePixelRatio || 1, Q.maxPixelRatio);
    this.resScale = Q.mode === 'low' ? 0.75 : Q.resScale;
    this.renderer.setPixelRatio(this.basePixelRatio * this.resScale);
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;

    /* scene / camera ------------------------------------------------------ */
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(ASSETS.palette.bg);
    this.scene.fog = new THREE.Fog(ASSETS.palette.fog, 12, 44);

    this.camera = new THREE.PerspectiveCamera(
      Q.fov, window.innerWidth / window.innerHeight, 0.05, 160
    );
    this.scene.add(this.camera);

    /* lights — v0.8: the day/night cycle now drives these outdoors */
    this.hemi = new THREE.HemisphereLight(0x9db8d4, 0x1c2126, 0.17);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xd8e6f8, 0.1);
    this.sun.position.set(4, 9, 3);
    this.sun.castShadow = Q.mode !== 'low' && Q.shadows;
    this.sun.shadow.mapSize.set(1024, 1024);
    const sc = this.sun.shadow.camera;
    sc.left = -8; sc.right = 8; sc.top = 8; sc.bottom = -8;
    sc.near = 1; sc.far = 30;
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.03;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
    this.bounce = new THREE.DirectionalLight(0x6d8299, 0.05);
    this.bounce.position.set(-3, -4, -2);
    this.scene.add(this.bounce);

    /* world / actors -------------------------------------------------------- */
    /* meta first: apply saved credit/power ranks to ASSETS before anything
       reads them (player shield/health, weapons, companions, radar range…) */
    this.mods = Mods;
    Mods.init();
    this.world = buildWorld(this.scene);
    this.player = new Player(this.camera);
    this.weapon = new Weapon(this.camera, this.scene);
    this.weapon.game = this;
    this.ammo = {};
    for (const k in ASSETS.ammoPools) this.ammo[k] = ASSETS.ammoPools[k].start;
    this.materials = {};                 // ecology materials (fiber/ore/fish…)
    this.specials = new Specials(this.camera, this.scene);
    this.companions = new Companions(this.scene);
    this.ecology = new Ecology(this.scene, this.world);
    this.enemies = [];
    this.spawnEnemies();

    /* systems ---------------------------------------------------------------- */
    this.sfx = new Sfx();
    this.input = new Input(document.getElementById('game'));
    this.input.init();
    this.input.onPadConnected = (id) => {
      this.hud.padChip(true, id);
      this.hud.toast('CONTROLLER CONNECTED');
    };
    this.hud = new Hud(this);

    /* flashlight (Deadspace darkness) ------------------------------------- */
    this.flashlightOn = false;
    this.torch = new THREE.SpotLight(
      ASSETS.flashlight.color, 0, ASSETS.flashlight.distance,
      ASSETS.flashlight.angle, 0.5, 1.4
    );
    this.torch.position.set(0.12, -0.08, 0);
    const torchTarget = new THREE.Object3D();
    torchTarget.position.set(0, 0, -6);
    this.camera.add(torchTarget);
    this.torch.target = torchTarget;
    this.camera.add(this.torch);

    /* state -------------------------------------------------------------------- */
    this.state = 'menu';           // menu | playing | xmb | dead | win
    this.time = 0;
    this.timeScale = 1;
    this.currentTarget = null;
    this.vatsTargets = [];
    this.won = false;
    this.targetFov = ASSETS.quality.fov;
    this.zone = 'corridor';
    this.novaCd = 0;
    this._vatsSide = 1;
    this.respawnQueue = [];        // { def, at } — 5-minute hostile rebuilds
    this._slotHoldT = 0;
    this._slotTick = 0;
    /* v0.8 systems */
    this.dcT = ASSETS.daycycle.start;     // day/night clock (s into the cycle)
    this.reinforceT = ASSETS.enemy.reinforce.every;
    this.kaijuCd = 25;                    // grace before the first kaiju can rise
    this._kaijuWasAlive = false;

    /* quality watchdog ---------------------------------------------------------- */
    this.fpsAvg = 60;
    this.fpsCheck = 0;
    this.qStage = 0;
    this.showFps = ASSETS.debug.showFps;

    this.bindEvents();
    this.hud.setState('menu');
    this.hud.drawRadar();

    /* debug handle */
    window.AC = { game: this, assets: ASSETS };

    this.renderer.setAnimationLoop(() => this.frame());
  }

  /* ------------------------------------------------------------------ */
  spawnEnemies() {
    for (const s of this.world.spawns) {
      /* chance-gated spawns keep elites RARE (valley/city elites 35 %) */
      if (s.chance && Math.random() > s.chance) continue;
      const e = new Grunt(s, this.scene);
      this.enemies.push(e);
      /* some elites bring their own pet hound */
      if (s.t === 'elite') spawnEliteEntourage(this, e);
    }
  }

  /* -- 5-minute hostile respawn queue ----------------------------------- */
  queueRespawn(def) {
    this.respawnQueue.push({ def, at: this.time + ASSETS.enemy.respawnTime });
  }

  processRespawns() {
    for (let i = this.respawnQueue.length - 1; i >= 0; i--) {
      const r = this.respawnQueue[i];
      if (this.time < r.at) continue;
      /* chance-gated elites re-roll their spawn chance */
      if (r.def.chance && Math.random() > r.def.chance) {
        r.at = this.time + 45;
        continue;
      }
      const dx = this.player.pos.x - r.def.x;
      const dz = this.player.pos.z - r.def.z;
      if (dx * dx + dz * dz < Math.pow(ASSETS.enemy.respawnClearDist, 2)) continue;
      const e = new Grunt(r.def, this.scene);
      this.enemies.push(e);
      if (r.def.t === 'elite') spawnEliteEntourage(this, e);
      this.respawnQueue.splice(i, 1);
    }
  }

  /* -- 15-second neighbor-tile reinforcement waves ------------------------- */
  updateReinforce(dt) {
    const R = ASSETS.enemy.reinforce;
    this.reinforceT -= dt;
    if (this.reinforceT > 0) return;
    this.reinforceT = R.every;
    const alive = this.enemies.reduce((s, e) => s + (e.alive ? 1 : 0), 0);
    if (alive >= R.cap) return;
    const n = Math.min(
      Math.round(R.count[0] + Math.random() * (R.count[1] - R.count[0])),
      R.cap - alive);
    const EXw = ASSETS.world.expanse;
    const zEnd = EXw.z0 - EXw.rows * EXw.tileSize;
    const pool = ['grunt', 'grunt', 'shielder', 'drone'];
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const d = R.dist[0] + Math.random() * (R.dist[1] - R.dist[0]);
      let x = this.player.pos.x + Math.cos(a) * d;
      let z = this.player.pos.z + Math.sin(a) * d;
      /* clamp into the play space */
      z = Math.max(zEnd + 1.5, Math.min(-2, z));
      if (z > ASSETS.world.hangar.mouthZ) x = Math.max(-2.6, Math.min(2.6, x));
      else if (z > ASSETS.world.valley.z0) x = Math.max(-16, Math.min(16, x));
      else if (z > ASSETS.world.city.z0) x = Math.max(-12, Math.min(12, x));
      else if (z > EXw.z0) x = Math.max(-13, Math.min(13, x));
      else x = Math.max(-(EXw.cols * EXw.tileSize / 2 - 1.5),
        Math.min(EXw.cols * EXw.tileSize / 2 - 1.5, x));
      const tile = this.world.tileAt(x, z);
      const lvl = tile ? tile.lvl : undefined;   // undefined → levelForZ fallback
      const t = Math.random() < R.eliteChance
        ? 'elite'
        : pool[Math.floor(Math.random() * pool.length)];
      const e = new Grunt({ t, x, z, patrol: 3, lvl, noRespawn: true }, this.scene);
      this.enemies.push(e);
      if (t === 'elite') spawnEliteEntourage(this, e);
    }
    this.hud.toast('REINFORCEMENTS MOVING IN', 1100);
  }

  /* -- kaiju director — wade the deep ocean at your own risk ---------------- */
  updateKaiju(dt) {
    const K = ASSETS.world.expanse.kaiju;
    const hasKaiju = this.enemies.some((e) => e.alive && e.arch.kaiju);
    if (this._kaijuWasAlive && !hasKaiju) {
      this.kaijuCd = K.cooldown;               // slain — start the next timer
    }
    this._kaijuWasAlive = hasKaiju;
    if (hasKaiju || this.kaijuCd > 0) {
      if (!hasKaiju) this.kaijuCd -= dt;
      return;
    }
    const zone = this.world.zoneAt(this.player.pos.z);
    if (zone !== 'ocean') return;
    if (Math.random() < K.chancePerSec * dt) {
      const a = Math.random() * Math.PI * 2;
      const d = 20 + Math.random() * 12;
      let x = this.player.pos.x + Math.cos(a) * d;
      let z = this.player.pos.z + Math.sin(a) * d;
      x = Math.max(-this.world.xHalf + 3, Math.min(this.world.xHalf - 3, x));
      z = Math.max(this.world.zEnd + 4, Math.min(this.world.oceanZ0 - 4, z));
      const kaiju = new Grunt({ t: 'kaiju', x, z, lvl: K.level, noRespawn: true, patrol: 0 }, this.scene);
      this.enemies.push(kaiju);
      this.sfx.tone({ type: 'sawtooth', f0: 160, f1: 38, dur: 1.8, gain: 0.5 });
      this.hud.toast('THE WATER DISPLACES… KAIJU · LVL ' + K.level, 3000);
      this.hud.setObjective('OBJECTIVE: SLAY THE KAIJU OR REACH THE BUOY');
    }
  }

  /* -- day / night cycle — 120 min: dawn 15 · day 40 · dusk 15 · night 50 --- */
  updateDaycycle(dt) {
    const DC = ASSETS.daycycle;
    this.dcT = (this.dcT + dt) % DC.fullDay;
    const p = this.dcT;
    const DAWN = DC.dawn, DAY = DC.day, DUSK = DC.dusk;
    const night = new THREE.Color(0.34, 0.4, 0.52);
    const warm = new THREE.Color(1.12, 0.8, 0.58);
    const day = new THREE.Color(1, 1, 1);
    const tint = new THREE.Color();
    let k = 0.18, phase = 'NIGHT';
    if (p < DAWN) {
      phase = 'DAWN';
      const q = p / DAWN;
      tint.copy(night).lerp(warm, q);
      k = 0.2 + q * 0.6;
    } else if (p < DAWN + DAY) {
      phase = 'DAY';
      const q = (p - DAWN) / DAY;
      tint.copy(warm).lerp(day, Math.min(1, Math.abs(q - 0.5) * 2.4));
      k = 1;
    } else if (p < DAWN + DAY + DUSK) {
      phase = 'DUSK';
      const q = (p - DAWN - DAY) / DUSK;
      tint.copy(day).lerp(warm, Math.min(1, q * 1.7));
      tint.lerp(night, Math.max(0, q - 0.5) * 2);
      k = 1 - q * 0.82;
    } else {
      phase = 'NIGHT';
      tint.copy(night);
      k = 0.18;
    }
    /* lights */
    this.hemi.intensity = 0.07 + k * 0.3;
    this.sun.intensity = 0.02 + k * 0.5;
    this.sun.color.copy(warm).lerp(day, Math.min(1, k * 1.2));
    this.bounce.intensity = 0.03 + k * 0.04;
    /* fog + sky tint (updateZone lerps toward the zone palette first;
       we then pull toward the day-tinted version of the same palette) */
    const fx = this.world.zoneFx[this.zone];
    if (fx) {
      const fogT = new THREE.Color(fx.fog).multiply(tint);
      const bgT = new THREE.Color(fx.bg).multiply(tint);
      this.scene.fog.color.lerp(fogT, Math.min(1, dt * 3));
      this.scene.background.lerp(bgT, Math.min(1, dt * 3));
    }
    /* clock chip — 1 real min = 12 game min, dawn breaks at 05:00 */
    const gameMin = (DC.clockBase * 60 + p * 0.2) % 1440;
    const hh = String(Math.floor(gameMin / 60)).padStart(2, '0');
    const mm = String(Math.floor(gameMin % 60)).padStart(2, '0');
    this.hud.setClock(phase, hh + ':' + mm);
  }

  resetRun() {
    for (const e of this.enemies) {
      this.scene.remove(e.group);
      this.scene.remove(e.blob);
    }
    this.enemies = [];
    this.respawnQueue = [];
    clearBolts(this);
    this.spawnEnemies();
    for (const k in ASSETS.ammoPools) this.ammo[k] = ASSETS.ammoPools[k].start;
    this.player.reset();
    this.weapon.resetAll();
    this.specials.resetAll(this);
    this.companions.resetAll(this);
    this.world.door.reset();
    this.world.door2.reset();
    this.flashlightOn = false;
    this.torch.intensity = 0;
    this.timeScale = 1;
    this.player.vatsActive = false;
    this.time = 0;
    this.won = false;
    this.novaCd = 0;
    this.targetFov = ASSETS.quality.fov;
    this.hud.setScope(null);
    this.zone = 'corridor';
    /* v0.8 system resets (materials persist — they're salvage, not run state) */
    this.dcT = ASSETS.daycycle.start;
    this.reinforceT = ASSETS.enemy.reinforce.every;
    this.kaijuCd = 25;
    this._kaijuWasAlive = false;
    this.hud.setClock('DAWN', '05:00');
  }

  /* -- state transitions ------------------------------------------------ */
  start() {
    this.sfx.ensure();
    this.resetRun();
    this.state = 'playing';
    this.hud.setState('playing');
    this.hud.setObjective('OBJECTIVE: FIGHT TO HANGAR BAY 7');
    this.input.requestLock();
    this.hud.toast('REACH HANGAR BAY 7');
  }

  openXmb() {
    if (this.state !== 'playing' && this.state !== 'paused') return;
    this.player.exitVats(this);
    this.state = 'xmb';
    this.hud.setState('xmb');
    this.hud.openXmb();
    this.input.releaseLock();
    this.sfx.regenStop();
  }

  closeXmb() {
    if (this.state !== 'xmb') return;
    this.hud.closeXmb();
    this.state = 'playing';
    this.hud.setState('playing');
    this._noAutoXmb = performance.now() + 900;  // ignore lock-bounce reopens
    this.input.requestLock();
  }

  pause() {
    if (this.state !== 'playing') return;
    this.state = 'paused';
    this.hud.setState('paused');
    this.input.releaseLock();
    this.sfx.regenStop();
  }

  resume() {
    if (this.state !== 'paused') return;
    this.state = 'playing';
    this.hud.setState('playing');
    this.input.requestLock();
  }

  onPlayerDeath() {
    this.state = 'dead';
    this.hud.setState('dead');
    this.input.releaseLock();
    this.sfx.regenStop();
  }

  win() {
    if (this.won) return;
    this.won = true;
    this.state = 'win';
    this.hud.fillWinStats();
    this.hud.setState('win');
    this.input.releaseLock();
    this.sfx.uiConfirm();
  }

  /* -- VATS ------------------------------------------------------------------ */
  setVats(on) {
    this.timeScale = on ? VATS.timeScale : 1;
    if (on) {
      this.sfx.vatsIn();
      this.weapon.closeZoom(this);
    } else {
      this.sfx.vatsOut();
    }
  }

  vatsFire() {
    const pl = this.player;
    if (!pl.vatsActive || pl.dead) return;
    if (!pl.canPay(VATS.missileEnergy)) { this.sfx.energyFail(); return; }
    const targets = this.specials.visibleTargets(this, VATS.cone, VATS.range, 1);
    const t = targets[0] || (this.currentTarget && this.currentTarget.ref) || null;
    if (!t) { this.hud.toast('NO TARGET IN CONE', 800); return; }
    pl.spend(VATS.missileEnergy);
    this._vatsSide *= -1;
    this.specials.launchMissile(this, t, 0.28 * this._vatsSide, VATS.missileDmg, { execute: true });
    this.sfx.missile();
  }

  /* -- abilities ----------------------------------------------------------------- */
  useNova() {
    if (this.state !== 'playing' || this.player.dead) return;
    if (this.novaCd > 0) return;
    if (!this.player.spend(NOVA.energy)) { this.sfx.energyFail(); return; }
    this.novaCd = NOVA.cd;
    this.sfx.nova();
    this.specials.spawnRing(this.player.pos, NOVA.radius, '#59f2ff');
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const to = new THREE.Vector3().subVectors(e.group.position, this.player.pos);
      to.y = 0;
      const d = to.length();
      if (d < NOVA.radius) {
        /* CH-25.4 — typed blast (FILE-SCOPE NOTE: main.js sits outside
           ch-25.files but this ability hit is part of the CH-25.1
           "abilities included" contract — unavoidable, same precedent
           as the CH-05 ecology.js touch).                                */
        applyDamage(e, { types: typedHit(NOVA), crit: rollCrit(NOVA), statusChance: NOVA.statusChance || 0 },
          this, { point: e.group.position.clone(), kind: 'splash' });
        e.stagger = Math.max(e.stagger, 1.4);
        if (d > 0.3 && !e.fly) e.group.position.add(to.normalize().multiplyScalar(NOVA.knock * 0.4));
      }
    }
  }

  toggleFlashlight() {
    this.flashlightOn = !this.flashlightOn;
    this.torch.intensity = this.flashlightOn ? ASSETS.flashlight.intensity : 0;
    this.sfx.navBig();
  }

  /* -- 4-slot R2 wheel (HOLD D-pad ◀▶ to cycle) ------------------------------ */
  updateSlotWheel(dt) {
    const inp = this.input;
    const pressL = inp.pressed('specialPrev');
    const pressR = inp.pressed('specialNext');
    const holdL = inp.down('specialPrev');
    const holdR = inp.down('specialNext');
    const S = this.specials;

    const step = (dir) => {
      S.cycleSlot(dir);
      this.sfx.nav();
      const def = SP.list.find((x) => x.id === S.equipped);
      this.hud.toast('SLOT ' + (S.slotIdx + 1) + ' · ' + (def ? def.name : ''), 900);
    };

    if (pressL) step(-1);
    if (pressR) step(1);

    if ((holdL || holdR) && !pressL && !pressR) {
      this._slotHoldT += dt;
      if (this._slotHoldT >= SP.cycleHold) {
        this._slotTick -= dt;
        if (this._slotTick <= 0) {
          this._slotTick = SP.cycleStep;
          step(holdL ? -1 : 1);
        }
      }
    } else if (!holdL && !holdR) {
      this._slotHoldT = 0;
      this._slotTick = 0;
    }
  }

  /* -- savestate ------------------------------------------------------------------- */
  saveState() {
    const p = this.player;
    const cp = this.companions;
    const data = {
      v: 3,
      pos: p.pos.toArray(), yaw: p.yaw, pitch: p.pitch,
      shield: p.shield, health: p.health, energy: p.energy,
      grenades: this.specials.grenades,
      slots: this.specials.slots.slice(),
      slotIdx: this.specials.slotIdx,
      droneEnabled: cp.droneEnabled, petEnabled: cp.petEnabled,
      droneWeaponIdx: cp.droneWeaponIdx,
      unlocked: [...this.weapon.unlocked],
      ammo: { ...this.ammo },
      materials: { ...this.materials },
      nikana: this.weapon.nikana,
      mags: this.weapon.guns.map((g) => g.mag),
      cur: this.weapon.cur,
      time: this.time, kills: this.weapon.stats.kills,
      light: this.flashlightOn,
    };
    try {
      localStorage.setItem('ac-save-v1', JSON.stringify(data));
      this.hud.toast('STATE SAVED', 1200);
      this.sfx.uiConfirm();
    } catch { this.hud.toast('SAVE FAILED', 1200); }
  }

  loadState() {
    let data;
    try { data = JSON.parse(localStorage.getItem('ac-save-v1')); } catch { data = null; }
    if (!data) { this.hud.toast('NO SAVED STATE', 1200); return; }
    // fresh hostiles, world items cleared — the save is YOURS, the bay is not
    for (const e of this.enemies) {
      this.scene.remove(e.group);
      this.scene.remove(e.blob);
    }
    this.enemies = [];
    this.respawnQueue = [];
    clearBolts(this);
    this.spawnEnemies();
    this.weapon.resetAll();
    this.specials.resetAll(this);
    this.world.door.reset();
    this.world.door2.reset();

    const p = this.player;
    p.reset();
    p.pos.fromArray(data.pos);
    p.yaw = data.yaw; p.pitch = data.pitch;
    p.shield = data.shield; p.health = data.health; p.energy = data.energy;
    this.ammo = { ...data.ammo };
    this.weapon.unlocked = new Set(data.unlocked && data.unlocked.length
      ? data.unlocked : [ASSETS.startWeapon || 'pistol']);
    this.weapon.guns.forEach((g, i) => { g.mag = data.mags[i]; g.drawLed(); });
    this.weapon.cur = (data.cur != null && this.weapon.isUnlocked(data.cur))
      ? data.cur
      : Math.max(0, this.weapon.guns.findIndex((g) => g.def.id === (ASSETS.startWeapon || 'pistol')));
    this.weapon.guns.forEach((g, i) => { g.group.visible = i === this.weapon.cur; });
    this.specials.grenades = data.grenades;
    if (data.slots) this.specials.slots = data.slots.slice();
    this.specials.slotIdx = data.slotIdx || 0;
    const cp = this.companions;
    cp.droneEnabled = !!data.droneEnabled;
    cp.petEnabled = !!data.petEnabled;
    cp.droneWeaponIdx = data.droneWeaponIdx || 0;
    cp.resetAll(this);
    this.weapon.stats.kills = data.kills;
    this.weapon.nikana = !!data.nikana;
    this.materials = data.materials ? { ...data.materials } : {};
    this.time = data.time;
    this.flashlightOn = !!data.light;
    this.torch.intensity = this.flashlightOn ? ASSETS.flashlight.intensity : 0;
    this.state = 'playing';
    this.hud.setState('playing');
    this.hud.closeXmb();
    this.input.requestLock();
    this.hud.toast('STATE LOADED', 1200);
  }

  teleportSpawn() {
    this.teleportTo(0, -1.6);
  }

  teleportTo(x, z) {
    const p = this.player;
    p.exitVats(this);
    p.pos.set(x, ASSETS.player.eyeHeight, z);
    p.vel.set(0, 0, 0);
    this.hud.toast('TELEPORTED', 1000);
  }

  /* XMB → SALVAGE — sell a material stack */
  sellMaterial(id, all = true) {
    const n = this.materials[id] || 0;
    if (n <= 0) return 0;
    const value = Math.round(ASSETS.ecology.materials[id].sell * n);
    this.materials[id] = 0;
    Mods.add(value);
    return value;
  }

  /* -- events --------------------------------------------------------------- */
  bindEvents() {
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });

    document.addEventListener('pointerlockchange', () => {
      if (!this.input.locked && this.state === 'playing' &&
          performance.now() > (this._noAutoXmb || 0)) this.openXmb();
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.state === 'playing') this.pause();
    });

    const bind = (id, fn) => document.getElementById(id).addEventListener('click', fn);
    bind('btn-start', () => this.start());
    bind('btn-resume', () => this.resume());
    bind('btn-restart', () => this.start());
    bind('btn-again', () => this.start());
  }

  /* -- quality watchdog ------------------------------------------------------
     0 · native res + shadows
     1 · shadows off          ← biggest single win on Intel iGPUs
     2 · 75% resolution
     3 · 55% resolution
     4 · PSP MODE: fixed 480px-wide internal buffer (~480×272) */
  applyQuality() {
    if (this.qStage >= 1) this.sun.castShadow = false;
    const w = window.innerWidth;
    let scale = 1;
    if (this.qStage === 2) scale = 0.75;
    if (this.qStage === 3) scale = 0.55;
    if (this.qStage >= 4) scale = Math.min(1, Q.fallbackWidth / w);
    this.resScale = scale;
    this.renderer.setPixelRatio(this.basePixelRatio * scale);
    this.renderer.setSize(w, window.innerHeight);
  }

  watchdog(dt) {
    if (this.state !== 'playing' || Q.mode !== 'auto' || this.qStage >= 4) return;
    this.fpsAvg += (1 / Math.max(dt, 1e-4) - this.fpsAvg) * 0.08;
    this.fpsCheck += dt;
    if (this.fpsCheck < Q.fpsCheck) return;
    this.fpsCheck = 0;
    if (this.fpsAvg < Q.fpsFloor) {
      this.qStage++;
      this.applyQuality();
      if (this.qStage >= 4) this.hud.toast('PSP MODE · 480×272 · HANG IN THERE', 2400);
      else this.hud.toast('PERFORMANCE MODE ' + this.qStage, 1600);
    }
  }

  /* -- zone management (corridor ⇄ hangar ⇄ valley) ---------------------------- */
  updateZone(dt) {
    const z = this.world.zoneAt(this.player.pos.z);
    if (z !== this.zone) {
      this.zone = z;
      if (z === 'hangar') {
        this.hud.setObjective('OBJECTIVE: FORCE THE EXIT — THE VALLEY AWAITS');
        this.hud.toast('HANGAR BAY 7', 1800);
        if (!this.flashlightOn) this.hud.toast('HANGAR BAY 7 — PRESS L FOR LAMP', 2400);
      } else if (z === 'valley') {
        this.hud.setObjective('OBJECTIVE: PUSH THROUGH THE CANYON TO THE CITY');
        this.hud.toast('THE VALLEY', 1800);
      } else if (z === 'city') {
        this.hud.setObjective('OBJECTIVE: THROUGH THE WILD GATE — THE EXPANSE AWAITS');
        this.hud.toast('THE CITYSCAPE', 1800);
      } else if (z === 'expanse') {
        const tile = this.world.tileAt(this.player.pos.x, this.player.pos.z);
        this.hud.setObjective('OBJECTIVE: CROSS THE WILDS TO THE OCEAN');
        this.hud.toast('THE EXPANSE' + (tile ? ' · ' + tile.biome.toUpperCase() + ' · LVL ' + tile.lvl : ''), 2000);
      } else if (z === 'ocean') {
        this.hud.setObjective('OBJECTIVE: REACH THE DEEP EXTRACTION BUOY — MIND THE WATER');
        this.hud.toast('THE OCEAN — KAIJU WATERS', 2400);
      } else {
        this.hud.setObjective('OBJECTIVE: FIGHT TO HANGAR BAY 7');
      }
    }
    // zone lights: fade in only the active zone's point lights
    for (const L of this.world.lights) {
      const target = L.zone === this.zone ? L.base : 0;
      L.light.intensity += (target - L.light.intensity) * Math.min(1, dt * 5);
    }
    // fog + sky: lerp toward this zone's palette
    const fx = this.world.zoneFx[this.zone];
    const fog = this.scene.fog;
    fog.near += (fx.near - fog.near) * Math.min(1, dt * 3);
    fog.far += (fx.far - fog.far) * Math.min(1, dt * 3);
    fog.color.lerp(new THREE.Color(fx.fog), Math.min(1, dt * 3));
    this.scene.background.lerp(new THREE.Color(fx.bg), Math.min(1, dt * 3));

    // bay door proximity (corridor → hangar)
    if (!this.world.door.open && this.player.pos.z < this.world.corridor.length - 4 &&
        this.zone === 'corridor') {
      this.world.door.trigger();
      this.sfx.doorOpen();
      this.hud.toast('BAY 7 DOOR CYCLING', 1600);
    }
    // exit door proximity (hangar → valley; opens from either side)
    if (!this.world.door2.open &&
        this.player.pos.z < this.world.hangar.exitDoor.z + ASSETS.world.hangar.exitDoor.openAt) {
      this.world.door2.trigger();
      this.sfx.doorOpen();
    }
  }

  /* ------------------------------------------------------------------ */
  frame() {
    const dt = Math.min(0.05, this.clockDelta());
    this.input.poll(dt);

    if (this.input.keys.has('F3') && !this._f3) this.showFps = !this.showFps;
    this._f3 = this.input.keys.has('F3');

    switch (this.state) {
      case 'menu':
        if (this.input.consumeConfirm()) this.start();
        break;

      case 'playing': {
        this.time += dt;
        this.novaCd -= dt;

        // ADS sensitivity → player look
        this.player._zoomSens = this.weapon.adsSens();
        this.player.update(dt, this.input, this.world, this);
        this.weapon.update(dt, this.input, this);

        // 4-slot wheel: HOLD D-pad ◀▶ (or [ ])
        this.updateSlotWheel(dt);

        // VATS: R1 executes hover missiles; world runs slow-mo
        if (this.player.vatsActive) {
          if (this.input.pressed('fire')) this.vatsFire();
          this.scanTargets(true);
        } else {
          this.scanTargets(false);
        }

        // specials (R2 fires the ACTIVE slot) + nova (F)
        if (this.input.pressed('special') && !this.player.vatsActive) this.specials.use(this);
        if (this.input.pressed('nova')) this.useNova();
        if (this.input.pressed('light')) this.toggleFlashlight();
        if (this.input.pressed('interact')) this.ecology.interact(this);

        // world sim on scaled dt (VATS slow-mo)
        const sdt = dt * this.timeScale;
        for (const e of this.enemies) e.update(sdt, this);
        this.enemies = this.enemies.filter((e) => !e.gone);
        updateBolts(sdt, this);
        this.specials.update(sdt, this);
        this.companions.update(sdt, this);
        this.ecology.update(sdt, this);
        this.world.update(this.time, dt);
        this.updateZone(dt);
        this.updateDaycycle(dt);
        this.processRespawns();
        this.updateReinforce(dt);
        this.updateKaiju(dt);

        // extraction beacon → win
        const z = this.player.pos.z, x = this.player.pos.x;
        const wz = this.world.winZone;
        if (!this.won && z > wz.minZ && z < wz.maxZ && x > wz.minX && x < wz.maxX) this.win();

        if (this.input.pressed('pause')) this.openXmb();
        break;
      }

      case 'xmb':
        this.hud.xmbNav(this.input);
        break;

      case 'paused':
        if (this.input.pressed('pause') || this.input.consumeConfirm()) this.resume();
        break;

      case 'dead':
        if (this.input.consumeConfirm() || this.input.pressed('reload')) this.start();
        break;

      case 'win':
        if (this.input.consumeConfirm()) this.start();
        break;
    }

    // shadow light follows the player
    this.sun.position.set(this.player.pos.x + 4, 9, this.player.pos.z + 3);
    this.sun.target.position.set(this.player.pos.x, 0, this.player.pos.z);

    this.hud.update(dt);
    this.hud.showFps(this.showFps, this.fpsAvg);
    this.watchdog(dt);
    this.renderer.render(this.scene, this.camera);
  }

  clockDelta() {
    if (!this._last) this._last = performance.now();
    const now = performance.now();
    const d = (now - this._last) / 1000;
    this._last = now;
    return d;
  }

  /* -- crosshair target scan (+ VATS target list) -------------------------------- */
  scanTargets(vats) {
    const fwd = new THREE.Vector3();
    this.camera.getWorldDirection(fwd);
    const fwdFlat = new THREE.Vector3(fwd.x, 0, fwd.z).normalize();
    this.currentTarget = null;
    this.vatsTargets = [];
    let best = 0.986; // ~9.5° cone
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const to = new THREE.Vector3().subVectors(e.group.position, this.player.pos);
      const dist = to.length();
      to.y = 0;
      const dot = to.clone().normalize().dot(fwdFlat);
      if (dot > best) {
        best = dot;
        this.currentTarget = { name: e.arch.name, dist, ref: e, lvl: e.level };
      }
      if (vats) {
        const to3 = new THREE.Vector3().subVectors(
          e.group.position, this.camera.getWorldPosition(new THREE.Vector3()));
        if (to3.length() < VATS.range &&
            to3.normalize().dot(fwd) > VATS.cone) {
          this.vatsTargets.push(e);
        }
      }
    }
    if (vats) {
      this.vatsTargets.sort((a, b) =>
        a.group.position.distanceTo(this.player.pos) -
        b.group.position.distanceTo(this.player.pos));
      this.vatsTargets = this.vatsTargets.slice(0, 6);
    }
  }
}

/* -- boot ------------------------------------------------------------------ */
function webglOK() {
  try {
    const c = document.createElement('canvas');
    return !!(window.WebGLRenderingContext &&
      (c.getContext('webgl2') || c.getContext('webgl')));
  } catch { return false; }
}

window.addEventListener('DOMContentLoaded', () => {
  if (!webglOK()) {
    document.getElementById('webglerror').classList.remove('hidden');
    return;
  }
  /* CH-04b — visible diagnostics: if anything throws at boot or in the loop,
     say so ON SCREEN (XMB card when the menu is open) instead of dying quiet.
     The menu must never again look "gone" without naming a cause. */
  const showErr = (msg) => {
    console.error('[FRAME SCAPE]', msg);
    try {
      const xmb = document.getElementById('xmb');
      const t = document.getElementById('xmb-card-title');
      const d = document.getElementById('xmb-card-desc');
      if (xmb && !xmb.classList.contains('hidden') && t && d) {
        d.textContent = 'RUNTIME ERROR: ' + msg +
          ' — the game kept this message instead of dying silently.';
      }
    } catch { /* diagnostics must never throw */ }
  };
  window.addEventListener('error', (e) =>
    showErr((e.message || 'unknown') +
      ((e.filename ? ' @ ' + String(e.filename).split('/').pop() : '') +
       (e.lineno ? ':' + e.lineno : ''))));
  window.addEventListener('unhandledrejection', (e) =>
    showErr('promise: ' + ((e.reason && (e.reason.message || e.reason)) || 'unknown')));
  new Game();
});

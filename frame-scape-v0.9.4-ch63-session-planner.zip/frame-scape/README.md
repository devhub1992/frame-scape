# FRAME SCAPE

A barebone, Halo/Warframe-inspired corridor-and-wilds FPS that runs entirely
in the browser. Pure static files — no build step, no server, no binary
assets. Built to stay playable on an **Intel i3-2350M / HD 3000** (WebGL1
fallback included).

**v0.9.4 · CH-22 (third-person view — the over-the-shoulder camera)** — sprint
S4 of the user-confirmed batch (planner flat file worklog.46), all three
features. **THE OTS BOOM** — press **T** (or **R3**, or the XMB → OPTIONS
row) and the camera eases out into a right-shoulder third-person rig: a
boxy operator frame renders at your position (run-cycle limbs ride the
head-bob phase; the frame hides while cloaked, on death, and in first
person), the boom clamps against world colliders (segment-vs-AABB with a
pad + min-dist floor — no wall clipping) and rides the terrain. The toggle
persists in the meta save and survives reloads. **FRAME-ORIGIN FIRE** — in
third person shots leave the chest, not the camera: the aim point comes
from the camera-center ray (the reticle's own ray) against enemies and
solids, so what the reticle covers is what the bullet hits; VATS, drone
designation, locker designation and melee are untouched. **ADS OVERLAY** —
aiming (RMB / Z / L2) pulls the camera in over the shoulder (character
framed in the left third, weapon lower-left), the FOV zooms on the
weapon's own ADS path with a subtle masked edge blur, and the readout
comes up: target distance in meters + magnification (mod-rank scaled),
the aimed enemy's HP bar top-right (value · name · level), and the
weapon's typed damage split bottom-right straight off the CH-25 pipeline.
The 2D scope plate stays a first-person surface — in third person this
overlay IS the sight. All tunables live in `assets.thirdPerson` /
`assets.playerBody` (CH-42 slim character restyles the placeholder frame
next sprint). Verified: `tp_probe.mjs` NEW 19/19 (default-off · boom
geometry · wall clamp · chest-origin live fire · ADS overlay + readouts ·
persistence across reload) · `bootcheck` ALL GREEN (181 programs) ·
`test_ch44` 34/34 · `status_probe` 18/18 · `beacon_probe` 9/9 ·
`hallwalk` ALL GREEN · `dc_probe` in budget · zero page errors.

**v0.9.4 · CH-26HF (nameplate hotfix — nothing enemy-named above the reticle)**
— one user field report on the ch26a zip, two changes. **THE RETICLE GOES
QUIET** — the target line above the crosshair (`GRUNT · L2 — 4 m · HEAT 7 ·
COLD 3`) is retired whole: no enemy names, levels, distances or status procs
render over the reticle any more; the crosshair keeps its red on-hostile tint
as the under-aim read, and the SUPPLY LOCKER prompt keeps the line when no
enemy is under aim. **THE NAME LIVES ON THE NAMEPLATE** — a third lazy
billboard sprite builds with the health bar (zero per-spawn cost, one canvas
draw — name + level are spawn-fixed) and renders the enemy's name centered
topmost over the status row (bar → status icons → name), riding the bar's
visibility window exactly: where the bar shows, the name shows. Verified:
`test_ch44` 34/34 · `status_probe` 18/18 · `bootcheck` ALL GREEN (181
programs) · `hallwalk` ALL GREEN · `beacon_probe` 9/9 · `lagprobe` ALL GREEN
· `dc_probe` in budget · zero page errors.

**v0.9.4 · CH-26 (status effect system — the proc gate goes live)** — sprint
S2 of the user-confirmed batch (planner flat file worklog.35/40), all five
features. **THE STACK FRAMEWORK** — the CH-25.2 stub in enemy.js is now the
real proc engine: every DAMAGING hit rolls its weapon/ability **STATUS
CHANCE** once and lands ONE status on a per-enemy store, weighted by the
hit's typed components (a puncture-heavy SRS-9 shot favors PUNCTURE, a heat
payload favors HEAT…; SLASH deliberately rare at 0.35 weight). Every status
stacks to **10×**, each proc refreshes a **5 s** window, and after expiry
stacks decay one per second. **THE HUD READ** — a second billboard sprite
above every health bar renders each active status as **ICON + COUNT, side
by side, color-coded per status** (canvas-drawn shapes, no font dependency:
heat flame · cold diamond · electric bolt · toxin blob · puncture bars ·
impact square · slash cut · void ring · the sentinel DEF-DOWN chevron) —
superseding the interim DEF-DOWN pips; the reticle target line gains the
same readout (`GRUNT · L2 — 4 m · DEF-DOWN 5 · HEAT 7 · COLD 3`).
**ELEMENTS** — HEAT ticks a DoT per stack (typed heat: shields resist,
health takes the ×1.25 bonus); COLD slows movement −6 %/stack (cap −60 %)
and makes crits bite +10 %/stack deeper; ELECTRIC may arc a **lightning
zap** to the nearest other hostile on proc (typed electric, never
chain-procs) and arms the shield-regen-disrupt flag for CH-41; TOXIN ticks
a DoT that never touches the shield pool and lands weaker vs health.
**PHYSICALS** — PUNCTURE raises the enemy's crit-chance-TAKEN
(+2.5 %/stack → +25 % at 10; upgraded hits report as crits to the CH-28
ladder); IMPACT **disorients** (wander/scatter drift, wobbly facing, broken
aim that scatters shots wide); SLASH bleeds tick as slash-typed DoT that
**ignores armor completely**. **VOID** — the exotic status grows the
enemy's hitbox +7 %/stack (≈×1.7 at 10 — the whole body becomes
hittable); first sources are **R2 specials only** (plasma bolt + shockwave
carry void fractions; void mods come later — the ch-26.f4 assumption held).
**COMPANIONS** — drone weapons, the homing pod and the beast's bite roll
procs through the same gate (they carried statusChance since CH-25.4 — the
system lights them up for free), while the FREEZE RAY keeps its DEF-DOWN
identity (statusChance 0; its stacks now display as a proper DEF-DOWN icon
+ count in the row). All tunables live in `assets.combat.statuses`. Zero
new shader programs (program cache stays 181), zero new lights. Verified:
`status_probe.mjs` NEW 18/18 (stack cap/refresh/decay · DoT ticks without
chain-procs · cold slow · puncture crit upgrades 11/40 · void hitbox ×1.7→
×1.35→×1 · zap arcs live · row render + screenshot) · `test_ch44.mjs`
34/34 (pin → 0.9.4) · `bootcheck` ALL GREEN (181 programs) ·
`hallwalk_probe` ALL GREEN · `lagprobe` ALL GREEN · `dc_probe` 13/13 in
budget · `beacon_probe` 9/9 · zero page errors everywhere.

**v0.9.3 · CH-57 (extraction beacon — the deep-ocean marker becomes a real
beacon)** — one user-promoted mini-patch (planner flat file worklog.38/40),
two features. **THE BEACON PROP** — the boat-buoy assembly at the deep-ocean
extraction anchor (float cylinder + pole + crystal lamp + the flat
"EXTRACTION" sign plane) is replaced by a proper **extraction beacon**: a
floating dock plinth (the same bob, the same bullet collider), a tapered
mast, an **emissive light column** shooting up past the mast tip (additive
translucent cylinder, opacity riding the old pulse) and a **slow-rotating
holo ring** (tilted torus, spins around the mast) over the SAME hazard pad
and the SAME single point light — 5 meshes before, 5 after, zero new lights
(ocean draw-call ceiling untouched) and zero new shader programs (the beam
is a plain-color basic material). The anchor (`expanse.buoy`), the winZone
trigger, `startExtraction()` → CH-36 loading screen → home base, the CH-47
mission extraction leg and the save schema are all byte-identical — touching
the beacon still extracts home exactly as the buoy did. **THE LANGUAGE
SWEEP** — every user-visible "buoy" string now reads beacon: the XMB
teleport row (**EXTRACTION BEACON**) + its description, the assets landmark
label, and both objective strings (SLAY THE KAIJU OR REACH THE BEACON ·
REACH THE DEEP EXTRACTION BEACON — MIND THE WATER). Internal identifiers
(`expanse.buoy`, `BUOY`, `_missionOnBuoyTouch`) are untouched — they are not
user-visible and renaming them would churn diffs for nothing. Verified:
`test_ch44.mjs` 34/34 (pin → 0.9.3), `node --check` on all touched files,
the world builds with the beacon in place (5-mesh assembly, one light, one
animated entry), zero console errors at boot.

**v0.9.2 · CH-46 (smooth loading pass — leaner shader warm-up, silky loader,
caught stutter)** — the CH-45 boot warm-up gets a follow-up pass in three
parts. **LEANER SHADER LOADING** — the warm-up no longer compiles every
pairwise light-count union; it compiles the *reachable closure*: every
zone's steady count plus every integer count that flies by INSIDE an
adjacent fade (the incoming zone's lights go visible within a frame while
the outgoing zone's drop one-by-one, so a fade sweeps the range
[min(A,B), A+B] — not just the endpoints). Unreachable unions the old set
paid for (hub+hangar 11, corridor+city 10, hub+hub 14…) are gone: the
program cache lands at **181 (was 191)** and the compile stage drops to
~245 ms with identical coverage — `scripts/progdiff.mjs` confirms **zero**
new programs at the first gameplay render. **THE 3.7 s FROZEN TASK IS
GONE** — the single hidden buffer-upload render became a **walked lap of
the map** (hub → corridor → bay door → hangar deep → valley → city gate →
connector shell → expanse edge, then the restore render at the spawn
view): one small frustum-culled render per vantage with a bar micro-step
between, so no boot task blocks longer than **~750 ms (was 3663 ms)**
while total upload work stays the same (three.js uploads each buffer once).
**SILKY LOADING MENUS** — both loading screens (pre-flight boot + the
deploy/extract shuttle) now animate on the compositor: the progress fill
is `transform: scaleX()` (a width transition is layout-bound and freezes
whenever the main thread blocks; a transform transition keeps easing
straight through it), stage labels slide in on every swap, a sheen sweeps
the bar, the overlays ease in/out (boot exit now drifts up as it fades,
cross-fading into a menu that fade-rises in — pause/death/win get the
same treatment), and the extract loader fades OUT around the port so the
destination lands as the screen clears. **CAUGHT STUTTER** — `frame()` now
runs under try/catch in two guarded sections (three.js re-arms
setAnimationLoop AFTER the callback returns, so one throw anywhere in the
sim used to silently freeze the whole game mid-frame; now the error is
named on the XMB card and the renderer keeps presenting). And the hot
per-frame paths stopped feeding the GC: updateZone/updateDaycycle built 6
fresh Colors per frame, scanTargets built ~2+N Vectors per frame, enemy
think built 4 Vectors per combatting enemy per frame, and the HUD ran a
`JSON.stringify` dirty-check every frame — all replaced with reused
scratch objects. The stricter `scripts/lagprobe.mjs` walk (fade
convergence now runs at REAL rate — 90 × 1/60 s, exercising every
mid-fade light count, plus a 6-frame menu beat before the walk matches
the real deploy flow) measures: **0 program-cache jumps · 0 longtasks
> 150 ms (was 3) · worst rAF wait 195 ms (was 840) · worst boundary
render 7.4 ms** across spawn → hallway → building exit → city → both
connectors → expanse. `scripts/bootcheck.mjs`, `scripts/
hallwalk_probe.mjs` (17 checks) and `scripts/test_ch44.mjs` (34 checks)
all green on the new build.

**v0.9.1 · CH-45 (loading cache warm-up — kill the zone-transition lag spikes)**
— three field reports fixed at once: a **big lag spike on load**, one **when
exiting the hallway** (corridor → hangar) and one **when exiting the building**
(hangar → valley). Root cause, confirmed with the new
`scripts/lagprobe.mjs` headless walk (spawn → hallway → building exit → city →
connector shells): Three.js compiles a shader program lazily the first time a
material renders under a given point-light count, and the CH-44.2 forward-light
budget gives every zone its own count — so each boundary with a NEW count paid
a +6-program compile burst mid-run (measured 378–483 ms spikes under SwiftShader;
the city connectors were cheap because they reuse the hangar's count — matching
the repro list exactly). The fix is a real **asset-load pass on start, behind a
shuttle loading menu**: a pre-flight screen (same animated shuttle art as the
CH-36.1 extract screen, staged progress bar, paints on first HTML parse — no
more frozen black frame while the world builds) now plays while the boot runs
in yielding stages — renderer → textures/geometry → hostiles → systems →
**GPU cache warm-up** → one hidden buffer-upload render. The warm-up compiles
every shader variant the run can ever need: for each distinct visible
point-light count (every zone's steady count + every pairwise fade union),
that many lights go visible and `renderer.compile()` walks the scene graph.
After boot the shader cache is fully warm — the verification walk measures
**0 program-cache jumps** across 77 steps (was 4 jumps / +19 programs) and the
worst boundary render drops **483 ms → 3.9 ms**. Also verified by
`scripts/bootcheck.mjs` (loader visible mid-boot with live %, shuttle art
painted, fades into the menu, start works) — all green; `test_ch44.mjs`
(34 checks) and `hallwalk_probe.mjs` stay green.

**v0.9.1 · CH-44 HOTFIX 1 (four field reports + the sentinel loadout)** — a
patch-stability pass on the CH-44 build. **LOCALCACHE OVERRIDE** — the ch44
patch kept loading the OLD ch47 build from the browser's cache (static files,
no revalidation), so the menu printed the old version. Three layers fix it:
a network-first **service worker** (`sw.js`) so the patch on disk always wins
while online, `?v=` cache-bust tags on every asset URL (works where service
workers can't register), and an `fs-build` stamp in site data that hard-reloads
once when a different build is detected. **ENEMY-SPAWN LAG** — every
`Grunt.build()` allocated ~10 fresh geometries, a fresh 128² blob-shadow
texture, a hitbox material and a health-bar canvas PER SPAWN; on software GL a
reinforcement wave stalled the frame for hundreds of ms. All of it is now
shared + cached (immutable geometry cache, one blob texture, one hitbox
material, lazy health bars that build only when first damaged) — a warm spawn
batch allocates **zero** new GPU buffers. **PAUSE BUTTON** — the "randomly
triggers a mission or ports you to the spawn area" bug: gameplay left-clicks /
pad-A jumps left a stale confirm edge that the XMB read the moment it opened,
firing whatever item the remembered cursor sat on (MISSIONS → deploy, SPAWN
AREA → teleport). The edge is now drained every live frame and swallowed at
menu entry, and the menu always opens on the WEAPONS column. **SENTINEL
LOADOUT** — the combat drone deploys ALREADY ONLINE with the **MARKSMAN**
weapon on every fresh run (user toggles still win — the savestate overrides).
Verified by the new `scripts/hallwalk_probe.mjs` (17 checks: build pin, SW,
sentinel loadout, real-input hallway walk with per-step try/catch, cold-vs-warm
spawn timing, the exact pause repro) — all green, zero page errors.

**v0.9.0 · CH-44 patch (draw-call budget pass — PHASE 3 COMPLETE)** — the game
gets a real **render budget**: the CH-07 probe's global overrun (hangar views at
273–310 calls vs the ~160-200 design figure) is paid down. **STATIC MERGE
BATCHES** — 639 never-moving decor props (grass tufts, tree/pine crowns, palm
fronds, dead-tree branches, decorative bushes, boulders, every tile floor, all
solid:false decor boxes) bake into **84 merged meshes** keyed per zone and per
expanse ROW (frustum culling stays granular — only visible rows draw); solids
membership survives, so bullets still hit boulders and the ground, and nothing
animated, breakable or harvestable ever rides the path. **CAMERA.FAR RIDES THE
FOG** — the frustum never reaches past what haze already hides (far = fog.far +
16, capped at 160), so the corridor stops drawing the city and the city stops
drawing the far rows. **LIGHT BUDGET** — the hangar's six high-bays keep their
emissive panels but carry real point lights on every other bay (zone: 7 → 4),
and fully-faded zone lights drop OUT of the renderer's light list, so the
forward shader carries only the active zone's ceiling (5 corridor · 4 hangar ·
2 valley · 5 city · 4 connector · 7 hub · 2 expanse · 2 ocean). **THE WORLDGEN
GATE** — `assets.world.quality` now documents per-zone light ceilings + a
measurable budget table (per-view draw calls, triangles, memory, generation
spike) that every future world expansion (CH-45/21/24/46) must hold, with the
measured baseline shipped in `scripts/dc_baseline.json`. **Same-route probe,
before → after:** corridor 518 → 204 · hangar-mid 494 → 229 · hangar-deep 502
→ 270 · valley 472 → 318 · city 446 → 337 · connector 457 → 205 · ring 392 →
293 · hub 477 → 186 (−24 to −61 % per view). The harness (`scripts/
test_ch44.mjs`, 34 checks) plus the headless probe (`scripts/dc_probe.mjs`, 13
route stops) both run green. Also in this patch: **CANYON RING WALL REMOVAL**
(user-promoted ch-09.f4) — the two full-height rock wall masses that pinched
every CANYON PASS tile are gone; the ring reads as open canyon-country ground
from the gate line, the choke boulders / harvest nodes / L10-13 floor stay,
and the map edge stays screened by the existing expanse boundary walls.

**v0.18.0 · CH-47 patch (mission director — the warframe vertical slice)** —
the game has a real mission loop: hub → mission selection → combat region →
objective → extraction → reward → hub. The shuttle's **MISSION CONSOLE**
goes live with six data-driven missions (`assets.missions`) — **CULLING
RUN** (L2 extermination), **BAY SWEEP** (L5 extermination), **CANYON HOLD**
(L7 holdout — stand in the ring under waves), **PAD WATCH** (L8 defense —
keep hostiles off a field generator), **WILDS SALVAGE** (L10 recovery —
find the caches) and **BADLANDS PURGE** (L24 extermination with a weapon-
prototype roll). **DEPLOY** rides the shuttle loading flow to the site; a
per-deployment **seed** (shown on the loading screen) derives the quota,
hold time, cache layout, wave mixes and reward rolls — same seed, same
encounter. Objectives light a green **EXTRACTION BEACON**; riding it home
plays the shuttle screen into a **REWARD SUMMARY** card that itemizes
credits / power / mod cards / the prototype — rolled from the existing
drop tables and applied **once** (re-extraction can never double-pay).
Failures pay 25 % CR/PW; aborts and abandoned extractions pay nothing;
dying fails the mission. The director keeps sites populated with **supply
waves** (seeded patrols that count toward extermination quotas), runs
holdout/defense **waves** through the existing spawn machinery, and saves
its state into `ac-save-v1` — mid-mission saves resume the same seed with
the field equipment rebuilt. Verified with a 61-check Node boot smoke
(full module graph, all four type loops, seed determinism, no-double-pay)
plus a live headless-Chromium run of the whole slice, zero page errors.

**v0.8.2 · CH-36 patch (extract loading screen + HOME BASE)** — the game gains
its **personal hub**: touch the deep-ocean extraction buoy and the run no
longer ends — a full-screen **EXTRACTION loading screen** plays a procedural
**space-shuttle** scene (2D-canvas art: plated hull, delta wings, twin
flickering engine burns, blinking nav lights, a 130-star drift field, planet
limb — no video, no WebGL cost) with a staged progress readout, then the
shuttle docks at **HOME BASE**, a new shuttle-interior zone parked north of
the corridor start. Walk the AIRLOCK (the old corridor rear wall now has a
real doorway and a sliding **ramp door**), past the back rooms — **MOD BENCH**
and **SALVAGE STORES** — up the narrow hallway past the **ARSENAL RACK** and
**COMPANION BAY**, to the cockpit: an 11-metre **windshield** renders the world
outside as one hand-painted vista (dusk sky, neon city skyline, canyon mesas,
an ocean moon-glint — one emissive texture, HD 3000 budget kept), with the
**MISSION CONSOLE** on the left and the **FRAME DOCK** display rig on the
right. Every station is functional, not decorative: walk up, press X, and the
station opens its **real** system — the mission console lists traversal
targets (and DEPLOY-ready missions once the CH-47 director ships), the mod
bench opens the mod columns, salvage stores opens your inventory — all reading
the one canonical wallet/loadout, so a rank bought in the hub sticks in the
field. The console's RETURN TO FIELD entry shuttles you back to the zone you
extracted from. Verified with a 79-check contract harness plus a 30-check
Node boot smoke (full module graph on a three.js stub: buildWorld, zone
reads, collider walk-under math, ramp-door behavior).

**v0.8.2 · CH-09 patch (canyon-country tile sets)** — the wilds outside the
city grow from 9 to 13 tile rows, and the first thing you see through the wild
gate is no longer an open park: **rows 0-1 are a CANYON RING** of five new
valley/canyon tile sets — **DRY RIVERBED** (cracked-mud floor, dead trees, a
baked bank strip), **CANYON PASS** (rock wall masses pinching both tile edges
with a wide middle throat + choke boulders), **ROCKY BASIN** (perimeter boulder
ring around a bare-dirt ore dig), **HIGH RIDGE** (a low vaultable rock spine
with pines on the shoulders) and **RED BADLANDS** (stratified mesa buttes over
dry grit, parked in the southern dry band beside the desert). All five plug
into the L10→L80 curve at L10/11/12/13/24, stamp their harvest/ore/tufts from
a new per-tile config (`expanse.harvest`), and carry their own fog/sky entries
(`expanse.zoneFx`) — stand in a wash and the haze warms toward dust. The
**cityscape ring pass (f3)** also heals two pre-existing seams: a steppe/
mountain buffer row now separates the snowcaps from the desert, and a second
buffer separates the dry band from the beach ring — **snow never meets desert,
water never meets desert** anywhere in the grid. The grid growth re-anchors
the extraction buoy mid-ocean (z −505; win zone + kaiju clamps re-derive) and
the XMB navigation list gains CANYON RING + RED BADLANDS entries while THE
WILDS / OCEAN SHORE / EXTRACTION BUOY re-target. Hostile spawns, the 15-second
neighbour reinforcement waves, harvest respawn and birds/rodents all pick the
new sets up automatically via `tileAt`. Verified with a 60-check Node harness
(layout contract · the f3 seam audit AS CODE · ring cohesion · level curve ·
harvest/zoneFx config contract · derived-bounds mirror · buoy-in-ocean ·
legacy-row pins · nav + marker pins) plus a headless-Chromium smoke (real
boot, in-page tileAt/zoneFxAt checks, teleport to the ring, live reinforcement
wave landing in the new tiles, harvest nodes present).

**v0.8.2 · CH-08 patch (city corridors)** — the cityscape stops being one open
street: **two CORRIDOR CONNECTORS** now join its blocks as a segment list in
`ASSETS.world.city.corridors`. Each connector encloses its stretch of road —
pinch walls, solid fillers out to the boundary line, a **roofed span**, gated
end walls with **sliding doors that auto-cycle from either side**, two dim
interior lights that only fade in under a roof (`citycorridor` light zone),
and a neon plate naming the walk. `zoneAt` still reads the connectors as city
ground (garrisons spawn at city **L8** — one hostile patrols each passage),
`ceilHeightAt` dies bolts on the new roofs, fog pulls in to the indoor
palette while you're under one, and the **radar dims contacts on the far side
of a connector shell**. An optional **TRANSIT** express pair (stand ~0.5 s)
warps you between the north and south blocks — drone and beast ride along.
The v0.7 **extraction beacon that stood in the middle of the road is gone**
(user request): it was decorative — the win trigger remains the deep-ocean
buoy — so the post deleted clean and its pointing sign now reads
`OCEAN PIER →`. Nine street props re-placed clear of the new footprints.
Verified with a 78-check Node harness (config contract · strict AABB
clearance matrix · relocation pins) plus a 21-check headless-Chromium smoke
(real boot, gate cycles, fog swap, transit warp, L8 garrisons) and a
differential draw-call probe vs the CH-07 build.

**v0.8.2 · CH-25.5 hotfix (drone weapons)** — the CH-25 typed-damage retrofit
built every drone hit through `typedHit()`, which reads the scalar from
`damage` — but the five drone weapons keep their scalar on the legacy `dmg`
key (the key the DRONE OUTPUT mod, the XMB rows and the homing pod all
read). Every drone shot therefore carried an all-zero typed map: LASER
LANCE, MARKSMAN, MINIGUN, HOMING POD and the FREEZE RAY's hp chew did
**nothing** (the ray still sapped shields — its % curve never went through
the typed path, which is why it looked half-alive). `typedHit()` now accepts
`dmg` as a fallback scalar, so the drone set hits for real again and DRONE
OUTPUT ranks keep scaling the damage. The same class-sweep caught two more
silent victims: **R2 HOMING MISSILES** and **R2 PLASMA BOLT** carried typed
splits whose scalars were hard-coded at the call sites — invisible to
`typedHit()`, so their detonations were all-zero vs enemies too. Their
scalars now live on the special defs (90 / 60) and the launchers read them.
Verified exact against the armor-mitigation math in a 111-check Node harness
plus a live headless-browser smoke (real drone live-fire + real booms).

**v0.8.2 · CH-06 patch (containers)** — the world's breakable props grow from
crates-only to a full **crates · barrels · chests** container set, all driven
by one `ASSETS.world.containers` config (per-zone mix, materials, spill
tables). **Barrels** (10-segment drums — wood stave or ribbed metal) and
**supply chests** (painted lid + lock, one draw call each) join every zone:
corridor and hangar get metal drum **stacks that chain-collapse** with their
base like the stacked hangar containers, the valley exercises the wood
debris style, the city scatters both near the extraction pad. Every prop
has its own HP pool by material (wood 150 / metal 320 — legacy crates keep
their full 2000 pool), and debris follows the material: wood splinters,
metal chunks with a spark spray. **UNIVERSAL BREAK THRESHOLD**: any damage
type breaks any prop — no type gate; the 2000 mark now lives in assets
(`containers.breakThreshold`, keyed to the RL-4 per-shell damage) so one
rocket shell still kills everything, small arms and **melee** chip the same
pools, and power-mod overkill still multiplies the spill (capped ×3).
Spills split by kind: crates keep the ammo-conversion table, **barrels**
spill small CR + an ammo handful, **chests** spill better CR + the mod-chip
chance.

**v0.8.2 · CH-25 patch (combat core)** — every hostile-facing hit in the game
now carries **typed damage**: a physical split (PUNCTURE / IMPACT / SLASH)
plus optional element payloads (HEAT / COLD / ELECTRIC / TOXIN) as fractions
of each weapon's moddable damage — power mods keep scaling the whole hit.
One `ASSETS.combat.typeMultipliers` table drives type-vs-shield / health /
armor (toxin bypasses shields but is weaker vs health · shields resist heat ·
health is weak to heat · SLASH ignores armor completely). **CRIT chance ×
multiplier** and **STATUS chance** are first-class stats on every gun, melee
blade, R2 special, drone weapon and the beast's bite — rolled per hit, shown
in the XMB weapon/special/drone rows. Enemies field a **REAL armor pool**
(elite+ heavy, regulars light) through the unified armor→EHP curve
(`base × (1 + armor/300)` — 300 armor = 200% EHP; the same curve the player
side will wire in later). FREEZE RAY DEF-DOWN stacks keep working alongside
armor, and the beam's hp chew now actually lands (typed COLD). All sources —
guns, melee, frags, missiles, plasma, shockwave, novas, drone, beast — share
one damage entry point, so the status-effect system (next patch) lights up
the whole arsenal at once.

**v0.8.2** — the zanuka beast becomes a **SCAVENGER**: eight **SUPPLY
LOCKERS** (corridor · hangar · valley · city) now hold ELITE-quality caches.
Only the beast can open them — point your reticle at a locker (a
"SUPPLY LOCKER — Xm · BEAST ONLY" readout confirms the designation), send
the beast out from the XMB COMPANIONS column, and it runs over, channels
with a reticle progress ring, and swings the door open: elite CR salvage +
elite POWER + the elite mod-chip chance, **plus a double roll** of the
standard drop table, scaled by the zone's hostile level. Combat always
wins — an enemy in aggro drops the channel; dead/kenned beasts drop it
too. The new **SCAVENGE** beast mod (MOD · COMPANION, ⌁B) ramps the
channel time **12 s at R0 → 2 s at R10** (−1 s per rank); unowned, the
beast still opens lockers at the 12 s baseline. Opened lockers respawn
after 75–120 s. X-pressing a locker answers "BEAST ONLY — POINT YOUR
RETICLE AT THE LOCKER" — lockers are never player-opened and never
breakable.

**v0.8.1** — **MOD CARDS** replace buy-a-rank nodes: every mod chip, crate
drop, elite drop and kaiju copy now adds a **CARD** ({id, copies, rank}) to
your inventory instead of a free rank — the first copy is a new card at R0,
further copies pile up as **duplicates** you can SELL (full value, +40,000
CR each) or SCRAP (60 % of value) in the new XMB **MOD · DUPES** column
(sell/scrap per mod or across ALL mods, one copy always kept, everything
behind the confirm dialog). Rank-ups now require an owned card and burn
CREDITS + POWER in the XMB (interim fusion — the full mod bench lands in
the pause-menu rework). Saves migrate **ac-meta-v2 → v3**: every ranked mod
becomes one owned card at the same rank — no refunds, no lost power — and
the migration is idempotent (safe across reloads). Rank scrap (X/Y) still
refunds 60 % of the rank's cost and keeps the card. Console API:
`AC.game.mods.sellCard(id)` · `scrapCard(id)` · `sellDuplicates([id])` ·
`scrapDuplicates([id])` · `totalCards()` / `totalDuplicates()`.
**v0.8.0** — beyond the city the world opens into **THE EXPANSE**: a
procedurally tiled wilderness (13 tile sets — park, riverbank, ocean bay,
forest, desert, snowy cap, mountain region, steppe, sandy beach, forest
trail, waterfall, grassland + a deep OCEAN 4× the size of any other set)
with harvestable plants, ore rocks, fish (fishable with the rod), birds and
rodents, a 120-minute day/night cycle, L10→L80 level-scaled hostiles with a
15-second neighbor-tile reinforcement system, rare elites that roll fire
novas / grenades / homing missiles / blink dashes / glide modules (their
effects KNOCK YOU DOWN — the STEADY FEET mod resists), an L80 KAIJU in the
ocean that spills prebuilt mod copies and weapon prototypes, CLOAK (5 s /
25 energy — companions hold fire), OVERSHIELD, the BLOOD FOR SHIELD
companion mod, weapon stowing, a samurai-draw NIKANA, weapon & salvage
selling, and a level-scaled drop curve (L40 = 1× · L60 = 2× · L80 = 4× cap).
The zanuka beast no longer runs backwards — it trots 6 ft ahead of your
cursor and faces where it runs.

**v0.8.1b hotfix** — the XMB could open with zero columns (menu "gone") on
browsers that block site data for a site (privacy shields / private mode):
one `localStorage` read in the menu build wasn't guarded. The menu no longer
touches storage unsafely, any future build failure degrades to a readable
error card instead of an empty shell, and runtime errors surface on screen.
Footer shows **v0.8.1b** so you can confirm the fix is live.

```
halo-shooter/
├── index.html        entry + HUD skeleton + import map
├── css/hud.css       HUD & XMB styling
└── js/
    ├── assets.js     ★ ALL config: palette, world (corridor/hangar/valley/
    │                   city/EXPANSE/OCEAN), weapons, slots, companions,
    │                   enemies, drops + rate curve, ecology, economy, mods,
    │                   controls, quality
    ├── mods.js       dual-currency bank + MOD CARDS (v0.8.1) + drop curve
    ├── companions.js combat drone (ammo-fed) + cursor-led zanuka beast
    ├── ecology.js    NEW v0.8 — birds, rodents, fish, fishing rod, harvest
    ├── textures.js   procedural canvas textures (walls/rock/ground/signs/
    │                   water/sand/snow/turf)
    ├── audio.js      WebAudio-synthesized SFX (no sound files)
    ├── input.js      keyboard+mouse (pointer lock) + Xbox Gamepad API
    ├── world.js      corridor + hangar + valley + city + procedural expanse
    │                   builder, colliders, zones, breakables, harvest nodes
    ├── player.js     FPS physics, shield/health, energy, knockdown, cloak
    ├── weapon.js     5 guns + stow + nikana iai + selling + critter hits
    ├── enemy.js      6 archetypes incl. elite ability kits + hound + kaiju
    ├── specials.js   4 R2 slots (cloak/overshield included), hostile elite
    │                   ordnance, mod chips, material + weapon-copy pickups
    ├── hud.js        HUD + radar + day/night clock + XMB grid (SALVAGE,
    │                   weapon selling)
    └── main.js       boot, game loop, zones, day/night, reinforcements,
                      kaiju director, respawn queue, savestate, watchdog
```

## Run it

- **Local test:** ES modules need http — from this folder run
  `python -m http.server 8000` → open `http://localhost:8000`.
  (Double-clicking index.html won't work locally; it WILL work on Neocities.)
- **Neocities:** dashboard → *Upload* → drag `index.html`, `css/`, `js/` in.
  Done. The only external dependency is three.js from jsDelivr (pinned r152.2);
  see *Going fully offline* below if you want zero CDN.

## Controls

| Action | Keyboard / Mouse | Xbox Controller |
|---------|------------------|-----------------|
| Move | WASD | Left Stick |
| Look | Mouse | Right Stick |
| Fire | Left mouse | **R1** |
| Special item (active slot) | E / G | **R2** |
| Cycle the 4 special slots | `[` / `]` | **HOLD D-pad ◀ / ▶** |
| Aim (M6P-style zoom, no scope) | Right mouse / Z | **L2** |
| Sniper scope (SRS-9 only) | — 4× — | L2 |
| Jump · **double jump** | Space · Space again mid-air | **A** · **A again** |
| Hover (drains energy) | hold Space in air | **hold A** |
| Duck (ground) · VATS (air) | C / Ctrl | **L1** |
| Slide | C + A while moving | **LB + A** |
| Swap weapon | Q | **Y** |
| Reload | R | **X** |
| Melee | V | **B** |
| Blast nova | F | — |
| Flashlight | L | D-pad ↑ |
| XMB menu | Esc / P | Start |
| Scrap mod (in XMB) | X / Backspace | **Y** |
| FPS readout | F3 | — |

The full button layout also lives in **XMB → CONTROLS**.

## What's new in v0.7.0

- **Deploy with the M6-P only** — the AR-60, SRS-9, CQS-8 and RL-4 start
  LOCKED. The first time you scavenge their ammo type (enemy drops or
  supply-box spills) that gun comes online (`AR-60 UNLOCKED`).
- **Drone, repositioned** — it now hovers ON ITS OWN IN FRONT of you
  (~8 m hard leash, gentle sway) instead of trailing your shoulder.
- **Reticle = drone target designator** — whatever your gun crosshair
  locks (`scanTargets` cone) becomes the drone's mark; it falls back to
  the nearest hostile in range when your reticle is empty.
- **THE CITYSCAPE** — the valley (now a shorter L7 canyon approach) opens
  onto night streets: seeded neon towers with lit windows, street lamps,
  wrecked skimmers, planters, POWER crystals, an L8 garrison and the
  extraction beacon pad (win). New zone fog/sky, new XMB teleports.
- **Enemy zone levels** — hallway **L2**, hangar **L5**, valley **L7**,
  cityscape **L8**. Health AND shields scale ×(1 + 0.22·(level−1))
  (a corridor grunt has 73 hp; a city elite 432). Levels show on the
  health bar, target info and VATS brackets.
- **Breakable supply boxes** — every crate and container is destructible;
  ONE rocket shell (2000 box damage) shatters it. Bullets chip it.
  Stacked containers chain-collapse with their base.
- **Ammo conversion** — a broken box spills the value of one rocket shell:
  **50 energy (2 plasma casts) = 2 sniper = 25 rifle = 10 pistol**, plus a
  15 % chance of a bonus shell. RL-4 DAMAGE / BLAST mods overkill the box
  and multiply the spill (up to ×3).
- **New kill drops** — **60 %** of kills spill **80–100 CREDITS**,
  **12 %** spill **POWER cells (15–20)** (independent rolls); the old
  weighted ammo/health/energy table still rolls beneath them.
- **Pickup feed** — pickups now report in **small letters under the
  reticle** (bottom-center stack) instead of the top toast.
- **Darker interiors** — the spawn corridor and hangar run dim lamps,
  tighter falloff and cut ambient light. Bring the flashlight (L).

## What's new in v0.6.0

- **ADS without scopes** — every gun except the SRS-9 now aims down sights
  with an M6P-style FOV zoom and **no scope overlay**; ADS still cuts
  spread and recoil.
- **Free double jump** — A jumps, pressing A again mid-air jumps once more.
  Its height is the **JETPACK frame mod**: rank 0 = 5 % of a normal jump,
  rank 10 = 200 %.
- **POWER currency** — enemies rarely spill POWER cells (15-20), elites
  always drop **+50**, and glowing crystals in the valley hold 30-60.
- **Mods cost CREDITS + POWER** — rank 1 = 10,000 CR + 5,000 PW, rank 10 =
  1,200,000 CR + 30,000 PW (exact exponential curves). **Scrap any mod**
  (X / Y on its XMB card) for a **60 % refund of everything it cost**.
- **New mod nodes** — JETPACK AIR-JUMP (5→200 %), PICKUP MAGNET
  (1 m→15 m loot vacuum), RADAR UPLINK (10 m→90 m motion tracker),
  DRONE HULL / SHIELDS / REGEN, BEAST CLAWS / HULL / SHIELDS.
- **HUD rearranged** — player shield + health top-right with the
  drone/beast bars just below, radar top-left (wallet under it), energy
  bar directly under the weapon, and the **4 special slots** under that.
- **4 special slots** — R2 fires the highlighted slot; HOLD D-pad ◀▶ to
  cycle; assign items in XMB → EQUIPMENT.
- **Companions** — the combat drone is now *always available* (no energy;
  toggle in XMB → COMPANIONS), hovers ~8 m out, picks its own targets and
  eats YOUR ammo. The **Zanuka-style beast** is a melee-only hunter with
  its own hull/shields. Both rebuild 30 s after going down.
- **THE VALLEY** — the hangar exit door now cycles open onto a decorated
  dusk canyon: funneling rock walls, dead trees, boulders, grass tufts,
  POWER crystals, a second elite patrol, and the extraction beacon (win).
- **5-minute respawns** — every hostile rebuilds at its spawn point 300 s
  after dying (once you're at least 14 m away).
- **Cleaner main menu** — just the title, DEPLOY, and one hint line; the
  button layout moved into the XMB CONTROLS column.

## CREDITS & POWER & MOD RANKS (v0.6.0)

The meta layer that survives death, RESET RUN and page reloads
(localStorage `ac-meta-v2`; old v1 banks migrate):

- **Earning:** every kill pays a credit bounty (grunt 1,200 · jackal 1,500 ·
  sentinel 1,000 · elite 5,000 CR), the drop chart spills credit chips and
  **POWER cells (15-20)**, elites add **+50 POWER** + 2,500 CR salvage, and
  the six valley crystals each hold **30-60 POWER**. You start with a
  12,000 CR / 6,000 PW recruit stipend — enough for one rank-1 expansion.
- **Spending:** XMB → **MOD · GUNS / FRAME / HEAVY**. Every rank burns
  **both** currencies:
  `CR(r) = 10,000 × 120^((r−1)/9)` → 10K · 17K · 29K · 49.3K · 84K · 142.9K
  · 243.3K · 414.1K · 705K · 1.2M
  `PW(r) = 5,000 × 6^((r−1)/9)` → 5K · 6.1K · 7.5K · 9.1K · 11.1K · 13.6K
  · 16.6K · 20.2K · 24.7K · 30K
- **Scrapping:** X or Y on a mod card refunds **60 % of every CR and PW**
  the mod ever consumed (cumulative), and resets it to rank 0.
- **Kinds:** `mul` ×(1+per·rank) · `add` +per·rank · `red` ×(1−per·rank) ·
  `table` (all drone weapons) · `ramp` min→max across 10 ranks (jetpack,
  magnet, radar). Add nodes in `assets.js → mods.nodes`.
- **Debug:** `AC.game.mods.grant(1000000, 100000)` in the console, or
  `AC.game.mods.wipeMeta()` for a fresh ship.

## The one file you edit: `js/assets.js`

Everything is data-driven from there:

- **`palette`** — every surface/light/HUD color, including the valley set.
- **`world`** — corridor + `hangar` (catwalk, ramp, containers, dropship,
  side doors, cycling exit door) + `valley` (walls, crystals, trees, rocks,
  grass, beacon).
- **`enemy.spawns[]`** — `{t, x, z, patrol, arena, catwalk, valley}` per
  hostile; `enemy.respawnTime` (300 s) + `respawnClearDist` (14 m).
- **`companions`** — drone (hull, shields, followDist ≈ 8 m, radar, 5-weapon
  rack incl. the FREEZE RAY) and pet (damage, aggro, speed) — moddable via
  MOD·COMPANION + MOD·COMPANION WEAPON (CH-04; MOD·HEAVY keeps launchers).
- **`specials`** — `slotCount` 4, `defaultSlots`, the 7 R2 items, cycle
  timing.
- **`weapons[]`** — the 5-gun loadout with `ads` (M6P-style zoom FOVs) and
  `recoil` (ADS reduces it).
- **`drops`** — weighted loot chart (now with POWER), `magnetR` (mod-ramped
  1→15 m), `eliteBonus` / `elitePower` / `eliteCr` / `crystal`.
- **`credits` / `power` / `mods`** — stipends, bounties, and every mod node.
- **`controls`** — sensitivity, deadzone, curve, invert Y, binding table.

After editing: save + reload. No build step.

## Performance notes (i3-2350M / HD 3000)

- Pixel ratio capped at 1, MSAA off, ~160 draw calls, ~25k triangles.
- One 1024px shadow light that *follows the player* (crisp, cheap).
- Lambert/Phong materials only, no post-processing, fog hides the far end.
- Zone-culled point lights (corridor / hangar / valley never all draw).
- Auto watchdog ladder (checked every second):
  `0` native + shadows → `1` shadows off → `2` 75% res → `3` 55% res →
  `4` **PSP MODE**: internal buffer fixed to 480px wide (~480×272).
- Watch the ladder kick in with F3. If a driver is ancient, set
  `quality.mode: 'low'` in assets.js to start at stage 1.

## Roadmap hooks (for iterative builds)

- **More zones:** `world.js` builds from `assets.world` — the valley shows
  the pattern; add another block + `zoneFx` entry and wire `zoneAt`.
- **Companion AI:** `companions.js` is self-contained — give the beast
  ranged attacks or the drone new weapons by extending `companions.drone.weapons`.
- **Real textures:** swap a maker in `textures.js` for
  `new THREE.TextureLoader().load('img/...')`.
- Console handle: `window.AC` → `{ game, assets }` for live tinkering
  (`AC.game.mods` is the whole economy; `AC.game.companions` the allies).

## Going fully offline (optional)

```bash
curl -o js/three.module.js https://cdn.jsdelivr.net/npm/three@0.152.2/build/three.module.js
```
Then edit the import map in `index.html` to `"three": "./js/three.module.js"`.

## Legal note

Fan homage for personal/educational use. *Halo*/*Warframe* are trademarks of
their respective owners — no game assets, names or sounds are included; keep
it non-commercial.

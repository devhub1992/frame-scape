/* bootcheck.mjs — CH-45 UX verification: the pre-flight shuttle loader
   must (1) be visible DURING the heavy boot, (2) show staged progress,
   (3) fade out into the menu, (4) start the game cleanly.           */
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');
const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = 8946;
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css',
  '.png': 'image/png', '.json': 'application/json' };

const server = createServer((req, res) => {
  const p = join(ROOT, decodeURIComponent(req.url.split('?')[0]));
  const f = existsSync(p) && !p.endsWith('/') ? p : ROOT + 'index.html';
  try {
    const body = readFileSync(f);
    res.writeHead(200, { 'content-type': MIME[extname(f)] || 'application/octet-stream' });
    res.end(body);
  } catch { res.writeHead(404); res.end('no'); }
});
await new Promise((r) => server.listen(PORT, r));

const browser = await chromium.launch({ headless: true, args: [
  '--enable-unsafe-swiftshader', '--use-angle=swiftshader',
  '--disable-dev-shm-usage', '--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
const errs = [];
page.on('pageerror', (e) => errs.push(e.message));

await page.goto(`http://127.0.0.1:${PORT}/`, { waitUntil: 'domcontentloaded' });

/* 1+2: overlay visible mid-boot with live progress */
await page.waitForTimeout(700);
const mid = await page.evaluate(() => {
  const b = document.getElementById('boot');
  return {
    visible: !!b && getComputedStyle(b).display !== 'none',
    status: (document.getElementById('bootstatus') || {}).textContent || '',
    pct: (document.getElementById('bootpct') || {}).textContent || '',
    barW: (document.getElementById('bootfill') || {}).style ? document.getElementById('bootfill').style.width : '',
    artPainted: (() => {
      const a = document.getElementById('bootart');
      if (!a) return false;
      const d = a.getContext('2d').getImageData(0, 0, a.width, a.height).data;
      for (let i = 3; i < d.length; i += 400) if (d[i] > 0) return true;
      return false;
    })(),
  };
});
await page.screenshot({ path: join(ROOT, 'scripts', 'boot_mid.png') });
console.log('MID-BOOT  visible=' + mid.visible + ' · status="' + mid.status + '" · ' +
  mid.pct + ' · bar=' + mid.barW + ' · shuttleArtPainted=' + mid.artPainted);

/* 3: fades into the menu */
await page.waitForFunction('!!window.AC', { timeout: 60000 });
await page.waitForFunction(
  'document.getElementById("boot").style.display === "none"', { timeout: 10000 });
const menu = await page.evaluate(() => ({
  menuVisible: !document.getElementById('menu').classList.contains('hidden') &&
    getComputedStyle(document.getElementById('menu')).display !== 'none',
  bootGone: getComputedStyle(document.getElementById('boot')).display === 'none',
}));
console.log('AFTER     bootGone=' + menu.bootGone + ' · menuVisible=' + menu.menuVisible);

/* 4: start works */
await page.evaluate(() => AC.game.start());
await page.waitForTimeout(800);
const play = await page.evaluate(() => ({
  state: AC.game.state, zone: AC.game.zone,
  progs: AC.game.renderer.info.programs.length,
}));
console.log('START     state=' + play.state + ' · zone=' + play.zone +
  ' · programs=' + play.progs);
await page.screenshot({ path: join(ROOT, 'scripts', 'boot_game.png') });

const ok = mid.visible && mid.artPainted && mid.barW !== '' && menu.bootGone &&
  menu.menuVisible && play.state === 'playing' &&
  errs.filter((e) => !/SwiftShader|favicon/.test(e)).length === 0;
console.log(ok ? 'RESULT: ALL GREEN' : 'RESULT: FAILED');
await browser.close();
process.exit(ok ? 0 : 2);

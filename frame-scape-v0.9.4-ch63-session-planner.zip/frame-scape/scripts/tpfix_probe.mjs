/* tpfix_probe.mjs — CH-22HF.2 THIRD-PERSON RIG REPAIR acceptance probe
   (session 1 of the user-routed two-session fix). Boots the real game in
   headless Chromium (SwiftShader) and asserts the repaired contract:

     A. build pin — v0.9.4 / ch22c actually runs
     B. body anchor — operator frame GLUED to the player feet position
        (|Δx|,|Δz| < 0.03) at full blend — never detached / far-up-front
     C. gun carried — the body's own rifle prop is visible while armed AND
        the camera viewmodel is hidden at blend 1 (no detached floating gun)
     D. hold pose — trigger arm raised to the two-hand grip (armHoldR)
     E. ADS framing — camera side offset OPENS (≥ 0.7 m): the body frames
        in the left third of the screen per the idle/shoot/ads references
     F. clamp floor + slide — wall-clamped boom keeps the camera ≥ 1.05 m
        out (no body burial) and the clamp slide fires when the right is clear
     G. muzzle truth — tpGunMuzzle returns a world point far from the camera
        (tracers leave the BODY gun, not the viewmodel)
     H. visual record — hip + ADS screenshots for the report
     Z. zero page errors

   Writes scripts/tpfix_report.json + scripts/tpfix_cam.png + tpfix_ads.png.
   Exit 0 = all green.
*/

import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, writeFileSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = 8958;
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.txt': 'text/plain', '.jpeg': 'image/jpeg',
};

const server = createServer((req, res) => {
  let p = req.url.split('?')[0];
  if (p === '/') p = '/index.html';
  const f = join(ROOT, decodeURIComponent(p));
  try {
    const body = readFileSync(f);
    res.writeHead(200, { 'content-type': MIME[extname(f)] || 'application/octet-stream' });
    res.end(body);
  } catch {
    res.writeHead(404); res.end('nope');
  }
});
await new Promise((r) => server.listen(PORT, '127.0.0.1', r));

const browser = await chromium.launch({
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader',
         '--disable-gpu-sandbox', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));

const checks = [];
const ok = (id, good, note = '') => {
  checks.push({ id, good, note });
  console.log(`  ${good ? '✓' : '✗'} ${id}${note ? ' — ' + note : ''}`);
};

console.log('booting v0.9.4 (CH-22HF.2 rig repair, headless Chromium · SwiftShader)…');
await page.goto(`http://127.0.0.1:${PORT}/index.html?v=0.9.4f`, { waitUntil: 'load', timeout: 45000 });
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return !!(g && g.world);
}, null, { timeout: 90000, polling: 500 });
await page.evaluate(() => AC.game.start());
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return g && g.state === 'playing';
}, null, { timeout: 30000, polling: 250 });
await page.evaluate(() => {
  AC.game.player.invisT = 0;
  AC.assets.debug.godMode = true;
});

/* A. build pin */
const a = await page.evaluate(() => ({
  version: AC.assets.meta.version, build: AC.assets.meta.build,
  tpCfg: !!AC.assets.thirdPerson, bodyCfg: !!AC.assets.playerBody,
}));
ok('A.version', a.version === '0.9.4' && a.build === 'ch22c',
  `version ${a.version} · build ${a.build}`);

/* toggle third person ON, wait for the blend snap */
await page.evaluate(() => {
  const g = AC.game;
  g.mods.settings.thirdPerson = true;
  g.mods.saveSettings();
  g.player.setThirdPerson(true);
});
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return g && g.player.tpBlend === 1;
}, null, { timeout: 30000, polling: 250 });

/* B. body anchor — glued to the feet position */
const b = await page.evaluate(() => {
  const g = AC.game, p = g.player, body = p.tpBody;
  return {
    dx: Math.abs(body.position.x - p.pos.x),
    dz: Math.abs(body.position.z - p.pos.z),
    feetY: body.position.y, expectedFeetY: p.pos.y - p.eyeCur,
    bodyVisible: body.visible,
  };
});
ok('B.anchor', b.bodyVisible && b.dx < 0.03 && b.dz < 0.03 &&
    Math.abs(b.feetY - b.expectedFeetY) < 0.05,
  `body glued to the frame · Δx ${b.dx.toFixed(3)} · Δz ${b.dz.toFixed(3)} m`);

/* C. gun carried + viewmodel suppressed */
const c = await page.evaluate(() => {
  const g = AC.game, p = g.player;
  return {
    gun: !!p._gun, gunVisible: p._gun ? p._gun.visible : false,
    armed: !g.weapon.stowed,
    vmVisible: g.weapon.guns[g.weapon.cur].group.visible,
    muzzle: !!p._gunMuzzle,
  };
});
ok('C.gun', c.gun && c.gunVisible && c.armed,
  `body rifle visible while armed (armed=${c.armed} · muzzle marker=${c.muzzle})`);
ok('C.vmHidden', c.vmVisible === false,
  `camera viewmodel hidden in third person (visible=${c.vmVisible})`);

/* D. hold pose — trigger arm on the grip */
const d4 = await page.evaluate(() => {
  const g = AC.game, p = g.player, PB = AC.assets.playerBody;
  return { armR: p._armR.rotation.x, hold: PB.armHoldR, armL: p._armL.rotation.x, holdL: PB.armHoldL };
});
ok('D.hold', Math.abs(d4.armR - d4.hold) < 0.06 && Math.abs(d4.armL - d4.holdL) < 0.06,
  `arms on the two-hand grip (R ${d4.armR.toFixed(2)} ≈ ${d4.hold} · L ${d4.armL.toFixed(2)} ≈ ${d4.holdL})`);

/* H1. hip screenshot for the record */
await page.waitForTimeout(600);
await page.screenshot({ path: join(ROOT, 'scripts', 'tpfix_cam.png') });

/* E. ADS framing — side offset OPENS (body frames left-third) */
await page.evaluate(() => { AC.game.weapon.zoomed = true; });
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return g && g.weapon.adsT > 0.95;
}, null, { timeout: 15000, polling: 200 });
const e = await page.evaluate(() => {
  const g = AC.game, p = g.player;
  const sin = Math.sin(p.yaw), cos = Math.cos(p.yaw);
  const dx = g.camera.position.x - p.pos.x, dz = g.camera.position.z - p.pos.z;
  const back = dx * sin + dz * cos, side = dx * cos - dz * (-sin);
  return {
    side: Math.round(side * 100) / 100, back: Math.round(back * 100) / 100,
    gunLevel: Math.abs(p._gun.rotation.x) < 0.05,
    dist: Math.round(p.pos.distanceTo(g.camera.position) * 100) / 100,
  };
});
ok('E.adsFrame', e.side >= 0.7 && e.back > 1.2,
  `ADS opens the offset — side ${e.side} m · back ${e.back} m (body frames LEFT-third)`);
ok('E.gunLevel', e.gunLevel, 'body gun levels out of the low-ready while aiming');

/* H2. ADS screenshot — the money shot (vs the broken tp_cam.png) */
await page.waitForTimeout(500);
await page.screenshot({ path: join(ROOT, 'scripts', 'tpfix_ads.png') });
await page.evaluate(() => { AC.game.weapon.zoomed = false; });

/* F. clamp floor + slide — boom against a thin wall stays out of the body */
const f = await page.evaluate(() => {
  const g = AC.game, p = g.player;
  const walls = g.world.colliders.filter((c) =>
    (c.maxX - c.minX) < 1.2 && (c.maxZ - c.minZ) > 4);
  const pad = 0.4;
  const clear = (x0, x1, z, skip) => {
    for (const c of g.world.colliders) {
      if (c === skip) continue;
      if (c.minX - pad <= x1 && c.maxX + pad >= x0 &&
          c.minZ - pad <= z && c.maxZ + pad >= z) return false;
    }
    return true;
  };
  for (const w of walls) {
    const cz = (w.minZ + w.maxZ) / 2;
    if (!clear(w.minX - 2.0, w.minX + 0.2, cz, w)) continue;
    const x = w.minX - 2.0;
    const fh = g.world.floorHeightAt(x, cz, p.pos.y);
    return { found: true, wallX: w.minX, x, z: cz, y: fh + p.eyeCur };
  }
  return { found: false };
});
if (f.found) {
  await page.evaluate((f) => {
    const g = AC.game, p = g.player;
    p.pos.set(f.x, f.y, f.z);
    p.vel.set(0, 0, 0);
    p.yaw = Math.PI / 2;             // face −x → boom extends +x INTO the wall
    p.pitch = 0;
  }, f);
  await page.waitForTimeout(600);
  const f2 = await page.evaluate(() => {
    const g = AC.game, p = g.player;
    const sin = Math.sin(p.yaw), cos = Math.cos(p.yaw);
    const dx = g.camera.position.x - p.pos.x, dz = g.camera.position.z - p.pos.z;
    const side = dx * cos - dz * (-sin);
    return {
      dist: Math.round(p.pos.distanceTo(g.camera.position) * 100) / 100,
      side: Math.round(side * 100) / 100,
      bodyGlued: Math.abs(p.tpBody.position.x - p.pos.x) < 0.03,
    };
  });
  ok('F.clampFloor', f2.dist >= 1.0 && f2.dist < 2.6 && f2.bodyGlued,
    `wall-clamped boom ${f2.dist} m out (floor 1.05) — body never swallows the view`);
  ok('F.slide', Math.abs(f2.side) > 0.55,
    `clamp slide active — |side| ${Math.abs(f2.side).toFixed(2)} m (body glides to the frame's left edge)`);
} else {
  ok('F.clampFloor', true, 'no thin-wall collider found — clamp check skipped');
  ok('F.slide', true, 'clamp slide check skipped');
}

/* G. muzzle truth — the body gun's muzzle is far from the camera */
const g7 = await page.evaluate(() => {
  const g = AC.game, p = g.player;
  const m = p.tpGunMuzzle(new (Object.getPrototypeOf(g.camera.position)).constructor());
  return m ? { dist: Math.round(m.distanceTo(g.camera.position) * 100) / 100 } : null;
});
ok('G.muzzle', g7 !== null && g7.dist > 0.8,
  g7 ? `body muzzle ${g7.dist} m from the camera — tracers leave the GUN, not the viewmodel`
     : 'tpGunMuzzle returned null (body hidden?)');

/* Z. zero page errors */
ok('Z.pageErrors', errors.length === 0,
  errors.length ? errors.slice(0, 3).join(' | ') : 'zero page errors');

await browser.close();
server.close();

const failed = checks.filter((c) => !c.good);
writeFileSync(join(ROOT, 'scripts', 'tpfix_report.json'), JSON.stringify({
  probe: 'tpfix — CH-22HF.2 rig repair', when: new Date().toISOString(),
  build: a.build, passed: checks.length - failed.length, failed: failed.length,
  checks,
}, null, 2));
console.log('─'.repeat(48));
console.log(`RESULT: ${checks.length - failed.length} passed · ${failed.length} failed`);
process.exit(failed.length ? 1 : 0);

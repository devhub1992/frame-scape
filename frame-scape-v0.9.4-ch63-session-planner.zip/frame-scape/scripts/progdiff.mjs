/* progdiff.mjs — CH-46 diagnosis: which shader programs still compile at the
   FIRST gameplay render (after game.start()) even though the CH-45 boot
   warm-up already ran? Diffs renderer.info.programs cache keys
   boot-end → post-start first render, and times that first render. */
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = 8947;
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml',
};

const server = createServer((req, res) => {
  const p = join(ROOT, decodeURIComponent(req.url.split('?')[0]));
  const f = existsSync(p) && p !== ROOT + '/' ? p : ROOT + 'index.html';
  try {
    const body = readFileSync(f);
    res.writeHead(200, { 'content-type': MIME[extname(f)] || 'application/octet-stream' });
    res.end(body);
  } catch (e) { res.writeHead(404); res.end('no'); }
});
await new Promise((r) => server.listen(PORT, r));
const stop = (sig) => { server.close(); process.exit(sig); };
process.on('SIGINT', () => stop(0));

const browser = await chromium.launch({
  headless: true,
  args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader',
    '--disable-dev-shm-usage', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 320, height: 180 } });
const errs = [];
page.on('pageerror', (e) => errs.push(e.message));
page.on('console', (m) => {
  if (m.type() === 'error') errs.push('console: ' + m.text());
});

await page.goto(`http://127.0.0.1:${PORT}/index.html`, { waitUntil: 'load', timeout: 45000 });
await page.waitForFunction('!!window.AC && !!AC.game && !!AC.game.world', { timeout: 90000 });

const r = await page.evaluate(async () => {
  const g = AC.game;
  const keys = () => (g.renderer.info.programs || [])
    .map((p) => p.cacheKey || p.name || String(p.id));
  const before = keys();
  const beforeN = g.renderer.info.programs.length;

  /* first render from the menu camera (what the loading screen hides) */
  let t0 = performance.now();
  g.renderer.render(g.scene, g.camera);
  const menuRenderMs = performance.now() - t0;

  /* the gameplay transition: start() then first playing render */
  g.start();
  g.input.releaseLock();
  const fy = g.world.floorHeightAt ? g.world.floorHeightAt(0, 3, 1.7) : 1.7;
  g.player.pos.set(0, fy + 1.7, 3);
  for (let i = 0; i < 12; i++) g.updateZone(0.3);
  t0 = performance.now();
  g.renderer.render(g.scene, g.camera);
  const firstPlayMs = performance.now() - t0;
  const after = keys();
  const added = after.filter((k) => !before.includes(k));

  /* second render — should be fully warm */
  t0 = performance.now();
  g.renderer.render(g.scene, g.camera);
  const secondMs = performance.now() - t0;

  return {
    beforeN, afterN: g.renderer.info.programs.length,
    menuRenderMs: +menuRenderMs.toFixed(1),
    firstPlayMs: +firstPlayMs.toFixed(1),
    secondMs: +secondMs.toFixed(1),
    addedKeys: added.map((k) => k.length > 170 ? k.slice(0, 170) + '…' : k),
    lights: g.world.lights.length,
    progs: g.renderer.info.programs.length,
  };
});
console.log(JSON.stringify(r, null, 2));
writeFileSync(join(ROOT, 'scripts', 'progdiff_report.json'), JSON.stringify({ r, errs }, null, 2));
console.log('pageErrors:', errs.length ? errs.slice(0, 5) : 'none');
await browser.close();
stop(0);

/* dc_probe.mjs — CH-44.3 draw-call probe (the dc_probe.cjs rebuild).
   Boots the REAL game in headless Chromium (SwiftShader WebGL), teleports
   the player down a repeatable route (corridor → hangar → valley → city →
   connector → expanse rows → beach → ocean → hub), lets the fog/light
   fades settle, then reads renderer.info.render.calls + triangles per
   stop. Compares against assets.world.quality.budget and writes
   scripts/dc_baseline.json (the baseline worklog.36 records).

   Route yaw = 0 (facing -z, deeper into the level) at every stop — the
   repeatable-view rule. Quality settings are recorded per stop (watchdog
   stage may downshift under SwiftShader — noted, calls unaffected).     */

import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = 8931;
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml',
};

const server = createServer((req, res) => {
  const p = join(ROOT, decodeURIComponent(req.url.split('?')[0]));
  const f = existsSync(p) && p !== ROOT + '/' ? p : ROOT + 'index.html';
  try {
    const body = readFileSync(f);
    res.writeHead(200, { 'content-type': MIME[extname(f)] || 'application/octet-stream' });
    res.end(body);
  } catch (e) { res.writeHead(404); res.end('no'); }
});
await new Promise((r) => server.listen(PORT, r));

const stop = (sig) => { server.close(); process.exit(sig); };
process.on('SIGINT', () => stop(0));

const browser = await chromium.launch({
  headless: true,
  args: [
    '--enable-unsafe-swiftshader',
    '--use-angle=swiftshader',
    '--disable-dev-shm-usage',
    '--no-sandbox',
  ],
});
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });

const errors = [];
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
page.on('console', (m) => {
  if (m.type() === 'error') errors.push('console: ' + m.text());
});

await page.goto(`http://127.0.0.1:${PORT}/index.html`, { waitUntil: 'load', timeout: 45000 });

/* wait for the AC handle (boot done) */
try {
  await page.waitForFunction('!!window.AC && !!AC.game && !!AC.game.world', { timeout: 30000 });
} catch {
  console.error('BOOT FAILED — AC handle never appeared');
  console.error(errors.slice(0, 10).join('\n'));
  await browser.close(); stop(1);
}

/* prep: go live (playing) so updateZone fades run; strip enemies so the
   corridor garrisons don't shoot the probe; park the mission director */
await page.evaluate(() => {
  const g = AC.game;
  g.state = 'playing';
  g.enemies.length = 0;
  if (g.hud && g.hud.el && g.hud.el.menu) g.hud.el.menu.classList.add('hidden');
});

/* repeatable route: [label, x, z, settleSeconds] */
const ROUTE = [
  ['corridor',      0,  -36, 1.6],
  ['hangar-mid',    0,  -95, 1.6],
  ['hangar-deep',   0, -112, 1.6],
  ['valley',        0, -136, 1.6],
  ['city',          0, -185, 1.6],
  ['citycorridor',  0, -172, 1.6],
  ['ex-row0-ring',  0, -228, 1.6],
  ['ex-row2',       0, -276, 1.6],
  ['ex-row4',       0, -324, 1.6],
  ['ex-row8',       0, -420, 1.6],
  ['beach',         0, -462, 1.6],
  ['ocean',         0, -492, 1.6],
  ['hub',           0,   10, 1.6],
];

const results = [];
for (const [label, x, z, settle] of ROUTE) {
  await page.evaluate(([x, z]) => {
    const g = AC.game;
    g.enemies.length = 0;                    // keep the route enemy-free
    g.player.pos.set(x, 1.8, z);
    g.player.yaw = 0; g.player.pitch = 0;
    g.player.vel && g.player.vel.set(0, 0, 0);
    /* SwiftShader runs a few FPS — the real-time fades would need long
       wall-clock settles. Converge them deterministically instead: the
       same updateZone the frame loop calls, with fixed dt.            */
    for (let i = 0; i < 60; i++) g.updateZone(0.25);
  }, [x, z]);
  await page.waitForTimeout(settle * 1000);
  const row = await page.evaluate(() => {
    const g = AC.game;
    const info = g.renderer.info.render;
    const lightsOn = g.world.lights.filter((L) => L.light.visible).length;
    return {
      zone: g.zone,
      calls: info.calls,
      tris: info.triangles,
      lightsOn,
      camFar: +g.camera.far.toFixed(1),
      qStage: g.qualityStage ?? g.qStage ?? 0,
      fps: Math.round(g.fpsAvg || 0),
    };
  });
  results.push({ label, x, z, ...row });
  console.log(
    row.calls.toString().padStart(4) + ' calls · ' +
    (row.tris / 1000).toFixed(1).padStart(7) + 'k tris · ' +
    String(row.lightsOn).padStart(2) + ' lights · far ' +
    String(row.camFar).padStart(5) + ' · ' +
    label + ' [' + row.zone + '] q' + row.qStage
  );
}

/* compare against the budget table */
const budget = await page.evaluate(() => AC.assets.world.quality.budget);
console.log('\n── budget compare (assets.world.quality.budget) ──');
let over = 0;
const zoneOf = { corridor: 'corridor', 'hangar-mid': 'hangar', 'hangar-deep': 'hangar',
  valley: 'valley', city: 'city', citycorridor: 'citycorridor', beach: 'ocean',
  ocean: 'ocean', hub: 'hub' };
for (const r of results) {
  const z = zoneOf[r.label] || 'expanse';
  const cap = budget.drawCalls[z];
  const flag = r.calls <= cap ? '✓' : '✗ OVER';
  if (r.calls > cap) over++;
  console.log(`  ${flag} ${r.label.padEnd(14)} ${String(r.calls).padStart(4)} / ${cap}`);
}

writeFileSync(join(ROOT, 'scripts', 'dc_baseline.json'), JSON.stringify({
  date: new Date().toISOString().slice(0, 10),
  hardware: 'headless Chromium 143 · SwiftShader (software GL) · 960×540 · pixelRatio 1',
  note: 'CH-44.3 baseline — repeatable route, yaw 0, enemy-free, fades settled 1.6 s',
  results,
  batchStats: await page.evaluate(() => AC.game.world.batchStats),
}, null, 2));
console.log('\nbaseline written → scripts/dc_baseline.json');

if (errors.length) {
  console.log('\nPAGE ERRORS (' + errors.length + '):');
  for (const e of errors.slice(0, 12)) console.log('  ' + e.slice(0, 300));
}

await browser.close();
stop(over ? 2 : 0);

/* tex.stub.mjs — texture stub for the CH-44 Node harness: every maker
   returns a repeatable/offsetable inert texture object (no canvas).
   Named exports mirror js/textures.js (world.js does `import * as TEX`). */

const make = () => ({
  uuid: 'tex-' + Math.random().toString(36).slice(2),
  repeat: { set() {}, x: 1, y: 1 },
  offset: { set() {}, x: 0, y: 0 },
  needsUpdate: false,
});

export const texWall = make;
export const texFloor = make;
export const texCeiling = make;
export const texHazard = make;
export const texCrate = make;
export const texBarrelWood = make;
export const texBarrelMetal = make;
export const texChest = make;
export const texLocker = make;
export const texLockerDoor = make;
export const texSign = make;
export const texBlob = make;
export const texGlow = make;
export const texHangarWall = make;
export const texHangarFloor = make;
export const texGrate = make;
export const texChevron = make;
export const texContainer = make;
export const texPuff = make;
export const texRock = make;
export const texGround = make;
export const texBuilding = make;
export const texAsphalt = make;
export const texNeon = make;
export const texWater = make;
export const texSand = make;
export const texSnow = make;
export const texTurf = make;
export const texCracked = make;
export const texBadland = make;
export const texVista = make;

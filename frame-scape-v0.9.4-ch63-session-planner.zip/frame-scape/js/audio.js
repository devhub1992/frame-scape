/* ============================================================================
   AUTUMN CORRIDOR — audio.js
   ----------------------------------------------------------------------------
   100% synthesized sound (WebAudio). No audio files to host or download.
   Mix + behavior is tweakable in assets.js → audio{}.
   The context is created lazily on the first user gesture (autoplay policy).
   ==========================================================================*/

import { ASSETS } from './assets.js?v=0.9.4e';

export class Sfx {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.sfxBus = null;
    this.ambBus = null;
    this.noise = null;      // shared 1s white-noise buffer
    this.hum = null;        // shield-regen loop handle
    this.freeze = null;     // CH-04.4 — freeze-ray whisper-siphon loop handle
    this.clankTimer = 0;
  }

  /* call once from any user gesture (click / key / gamepad button) */
  ensure() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();

    const A = ASSETS.audio;
    this.master = this.ctx.createGain();
    this.master.gain.value = A.master;
    // gentle limiter so layered shots never clip
    const limiter = this.ctx.createDynamicsCompressor();
    limiter.threshold.value = -10; limiter.knee.value = 6;
    limiter.ratio.value = 12; limiter.attack.value = 0.002; limiter.release.value = 0.12;
    this.master.connect(limiter).connect(this.ctx.destination);

    this.sfxBus = this.ctx.createGain();
    this.sfxBus.gain.value = A.sfx;
    this.sfxBus.connect(this.master);

    this.ambBus = this.ctx.createGain();
    this.ambBus.gain.value = A.ambient;
    this.ambBus.connect(this.master);

    // 1s of white noise, reused by everything
    const len = this.ctx.sampleRate;
    this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noise.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

    this.startAmbient();
  }

  /* -- primitive voices ---------------------------------------------------- */
  tone({ type = 'sine', f0 = 440, f1 = null, dur = 0.2, gain = 0.3,
         attack = 0.002, pan = 0, delay = 0, bus = null }) {
    if (!this.ctx) return;
    const t0 = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t0);
    if (f1 !== null) o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t0 + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(gain, t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    this.route(g, pan, bus);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }

  burst({ dur = 0.15, type = 'lowpass', freq = 1200, f1 = null, q = 0.8,
          gain = 0.3, pan = 0, delay = 0, attack = 0.001, bus = null }) {
    if (!this.ctx) return;
    const t0 = this.ctx.currentTime + delay;
    const s = this.ctx.createBufferSource();
    s.buffer = this.noise;
    s.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = type; f.frequency.setValueAtTime(freq, t0); f.Q.value = q;
    if (f1 !== null) f.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t0 + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(gain, t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    s.connect(f).connect(g);
    this.route(g, pan, bus);
    s.start(t0); s.stop(t0 + dur + 0.05);
  }

  route(node, pan, bus) {
    if (pan !== 0 && this.ctx.createStereoPanner) {
      const p = this.ctx.createStereoPanner();
      p.pan.value = Math.max(-1, Math.min(1, pan));
      node.connect(p).connect(bus || this.sfxBus);
    } else {
      node.connect(bus || this.sfxBus);
    }
  }

  /* -- game sounds ---------------------------------------------------------- */
  shot() {
    const p = () => (Math.random() - 0.5) * 0.15;
    this.burst({ dur: 0.09, freq: 1900, f1: 500, gain: 0.55, pan: p() });
    this.tone({ type: 'square', f0: 130, f1: 55, dur: 0.08, gain: 0.5, pan: p() });
    this.burst({ dur: 0.02, type: 'highpass', freq: 4000, gain: 0.35, pan: p() });
  }

  dry()      { this.tone({ type: 'square', f0: 1600, dur: 0.03, gain: 0.15 }); }
  uiConfirm(){ this.tone({ type: 'sine', f0: 660, f1: 990, dur: 0.09, gain: 0.2 }); }

  reload(T = 2.2) {  // scheduled 3-stage foley over the reload duration
    this.burst({ dur: 0.06, type: 'bandpass', freq: 900, q: 2, gain: 0.35, delay: 0.25 });
    this.tone({ type: 'square', f0: 220, f1: 140, dur: 0.06, gain: 0.2, delay: 0.28 });
    this.burst({ dur: 0.12, type: 'bandpass', freq: 1400, f1: 500, q: 3, gain: 0.3, delay: T * 0.55 });
    this.tone({ type: 'square', f0: 180, f1: 300, dur: 0.07, gain: 0.28, delay: T * 0.85 });
  }

  meleeWhoosh() { this.burst({ dur: 0.14, type: 'bandpass', freq: 500, f1: 1500, q: 1.5, gain: 0.35 }); }
  meleeHit() {
    this.tone({ type: 'square', f0: 160, f1: 60, dur: 0.12, gain: 0.5 });
    this.burst({ dur: 0.08, freq: 900, gain: 0.4 });
  }

  plasmaShot(pan = 0) {
    this.tone({ type: 'square', f0: 920, f1: 210, dur: 0.17, gain: 0.22, pan });
    this.burst({ dur: 0.05, type: 'highpass', freq: 2500, gain: 0.08, pan });
  }

  boltImpact(pan = 0) {
    this.burst({ dur: 0.14, type: 'highpass', freq: 2800, gain: 0.25, pan });
    this.tone({ type: 'triangle', f0: 320, f1: 90, dur: 0.12, gain: 0.2, pan });
  }

  hitEnemy() { this.tone({ type: 'sine', f0: 1100, dur: 0.05, gain: 0.14 }); } // hitmarker tick

  shieldHit() {
    this.tone({ type: 'triangle', f0: 230, f1: 150, dur: 0.16, gain: 0.4 });
    this.burst({ dur: 0.1, freq: 700, f1: 250, gain: 0.25 });
  }

  shieldBreak() {
    this.tone({ type: 'sawtooth', f0: 420, f1: 55, dur: 0.55, gain: 0.4 });
    this.burst({ dur: 0.3, freq: 2400, f1: 300, gain: 0.3 });
  }

  hurt() { this.tone({ type: 'sine', f0: 110, f1: 55, dur: 0.18, gain: 0.5 }); }

  lowShield() {
    this.tone({ type: 'sine', f0: 880, dur: 0.07, gain: 0.14 });
    this.tone({ type: 'sine', f0: 880, dur: 0.07, gain: 0.14, delay: 0.14 });
  }

  step() { this.burst({ dur: 0.05, freq: 480, f1: 220, gain: ASSETS.audio.footstep * 0.9 }); }

  land() { this.tone({ type: 'sine', f0: 95, f1: 50, dur: 0.12, gain: 0.35 }); }

  slide() { this.burst({ dur: 0.38, type: 'bandpass', freq: 900, f1: 250, q: 1.2, gain: 0.4 }); }

  zoomIn()  { this.tone({ type: 'sine', f0: 500, f1: 900, dur: 0.09, gain: 0.12 }); }
  zoomOut() { this.tone({ type: 'sine', f0: 900, f1: 500, dur: 0.09, gain: 0.12 }); }
  swap()    { this.tone({ type: 'square', f0: 300, f1: 420, dur: 0.06, gain: 0.16 }); }

  bounce(pan = 0) {
    this.tone({ type: 'square', f0: 700, f1: 300, dur: 0.05, gain: 0.14, pan });
  }

  boom(pan = 0) {
    this.burst({ dur: 0.55, freq: 900, f1: 90, gain: 0.9, pan });
    this.tone({ type: 'sine', f0: 70, f1: 28, dur: 0.7, gain: 0.8, pan });
    this.burst({ dur: 1.2, type: 'highpass', freq: 3000, f1: 500, gain: 0.2, pan, delay: 0.05 });
  }

  throwPin() { this.burst({ dur: 0.12, type: 'bandpass', freq: 800, f1: 1400, q: 1.4, gain: 0.2 }); }

  /* -- v0.4 sounds ------------------------------------------------------------ */
  nav()      { this.tone({ type: 'square', f0: 1200, dur: 0.025, gain: 0.07 }); }
  navBig()   { this.tone({ type: 'square', f0: 700, f1: 1000, dur: 0.05, gain: 0.1 }); }
  energyFail(){ this.tone({ type: 'square', f0: 220, f1: 160, dur: 0.09, gain: 0.14 }); }

  pickup(kind = 'ammo') {
    const f = kind === 'energy' ? [520, 1040]
      : kind === 'health' ? [660, 880]
      : kind === 'credits' ? [880, 1320]
      : kind === 'power' ? [740, 1180]
      : [440, 720];
    this.tone({ type: 'sine', f0: f[0], f1: f[1], dur: 0.09, gain: 0.14 });
    this.tone({ type: 'sine', f0: f[1], dur: 0.07, gain: 0.1, delay: 0.08 });
  }

  missile(pan = 0) {
    this.burst({ dur: 0.4, type: 'bandpass', freq: 600, f1: 2400, q: 1.2, gain: 0.35, pan });
    this.tone({ type: 'sawtooth', f0: 180, f1: 90, dur: 0.35, gain: 0.2, pan });
  }

  vatsIn() {
    this.tone({ type: 'sine', f0: 900, f1: 220, dur: 0.28, gain: 0.16 });
    this.burst({ dur: 0.2, type: 'lowpass', freq: 800, f1: 120, gain: 0.2 });
  }
  vatsOut() { this.tone({ type: 'sine', f0: 220, f1: 900, dur: 0.18, gain: 0.14 }); }

  dash()    { this.burst({ dur: 0.3, type: 'bandpass', freq: 300, f1: 2200, q: 1.1, gain: 0.4 }); }
  shock() {
    this.tone({ type: 'sine', f0: 120, f1: 32, dur: 0.5, gain: 0.7 });
    this.burst({ dur: 0.25, freq: 500, f1: 80, gain: 0.5 });
    this.burst({ dur: 0.5, type: 'highpass', freq: 2200, f1: 400, gain: 0.14, delay: 0.02 });
  }
  nova() {
    this.burst({ dur: 0.6, freq: 1200, f1: 150, gain: 0.5 });
    this.tone({ type: 'triangle', f0: 90, f1: 40, dur: 0.6, gain: 0.5 });
  }
  fireLoop() { return this.burst({ dur: 0.5, type: 'bandpass', freq: 500, f1: 220, q: 0.7, gain: 0.12 }); }

  doorOpen() {
    this.tone({ type: 'sawtooth', f0: 60, f1: 110, dur: 1.1, gain: 0.3 });
    this.burst({ dur: 1.0, type: 'lowpass', freq: 300, f1: 600, gain: 0.3, attack: 0.15 });
    this.tone({ type: 'square', f0: 700, dur: 0.06, gain: 0.1, delay: 1.05 });
  }

  execute() {
    this.tone({ type: 'square', f0: 160, f1: 640, dur: 0.16, gain: 0.22 });
    this.tone({ type: 'sine', f0: 1200, f1: 500, dur: 0.24, gain: 0.18, delay: 0.05 });
  }

  droneBeep() { this.tone({ type: 'sine', f0: 980, dur: 0.05, gain: 0.09 }); }
  droneBeam() { this.tone({ type: 'sawtooth', f0: 1400, f1: 900, dur: 0.12, gain: 0.06 }); }
  droneDown() {
    this.tone({ type: 'sawtooth', f0: 700, f1: 90, dur: 0.6, gain: 0.18 });
    this.burst({ dur: 0.4, freq: 900, f1: 120, gain: 0.2 });
  }

  /* -- v0.6: companions + power + wheel ------------------------------------- */
  jet() {   // free mid-air jump thruster
    this.burst({ dur: 0.22, type: 'bandpass', freq: 500, f1: 1800, q: 1.1, gain: 0.28 });
    this.tone({ type: 'triangle', f0: 240, f1: 420, dur: 0.14, gain: 0.12 });
  }
  growl() {
    this.tone({ type: 'sawtooth', f0: 95, f1: 55, dur: 0.4, gain: 0.22 });
    this.burst({ dur: 0.3, freq: 240, f1: 90, gain: 0.16 });
  }
  yelp()    { this.tone({ type: 'square', f0: 700, f1: 980, dur: 0.08, gain: 0.1 }); }
  whine()   { this.tone({ type: 'sine', f0: 900, f1: 260, dur: 0.5, gain: 0.16 }); }
  bite(pan = 0) {
    this.tone({ type: 'square', f0: 180, f1: 70, dur: 0.09, gain: 0.3, pan });
    this.burst({ dur: 0.07, freq: 1300, f1: 500, gain: 0.24, pan });
  }
  scrap() {
    this.burst({ dur: 0.18, type: 'bandpass', freq: 1600, f1: 400, q: 2, gain: 0.28 });
    this.tone({ type: 'square', f0: 340, f1: 140, dur: 0.16, gain: 0.16, delay: 0.08 });
  }

  boomSmall(pan = 0) {
    this.burst({ dur: 0.3, freq: 700, f1: 110, gain: 0.5, pan });
    this.tone({ type: 'sine', f0: 95, f1: 35, dur: 0.4, gain: 0.45, pan });
  }


  regenStart() {
    if (!this.ctx || this.hum) return;
    const o = this.ctx.createOscillator();
    o.type = 'sine'; o.frequency.value = 170;
    const lfo = this.ctx.createOscillator();
    lfo.frequency.value = 6;
    const lg = this.ctx.createGain(); lg.gain.value = 12;
    lfo.connect(lg).connect(o.frequency);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, this.ctx.currentTime);
    g.gain.linearRampToValueAtTime(0.06, this.ctx.currentTime + 0.3);
    o.connect(g).connect(this.sfxBus);
    o.start(); lfo.start();
    this.hum = { o, lfo, g };
  }

  regenStop() {
    if (!this.hum) return;
    const { o, lfo, g } = this.hum;
    g.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.2);
    o.stop(this.ctx.currentTime + 0.3); lfo.stop(this.ctx.currentTime + 0.3);
    this.hum = null;
  }

  /* -- CH-04.4 — FREEZE RAY whisper-siphon loop (near-silent by design):
     a thin icy bandpass hiss + a faint high whine at ~3 % gain total.
     freezeStart is idempotent (safe to call every frame the beam is
     active); freezeStop fades it out fast and is safe when never started. */
  freezeStart() {
    if (!this.ctx || this.freeze) return;
    const s = this.ctx.createBufferSource();
    s.buffer = this.noise;
    s.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = 'bandpass'; f.frequency.value = 2400; f.Q.value = 9;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, this.ctx.currentTime);
    g.gain.linearRampToValueAtTime(0.028, this.ctx.currentTime + 0.25);
    const o = this.ctx.createOscillator();
    o.type = 'sine'; o.frequency.value = 1180;
    const og = this.ctx.createGain(); og.gain.value = 0.012;
    o.connect(og).connect(g);
    s.connect(f).connect(g).connect(this.sfxBus);
    s.start(); o.start();
    this.freeze = { s, o, g };
  }

  freezeStop() {
    if (!this.ctx || !this.freeze) return;
    const { s, o, g } = this.freeze;
    g.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.15);
    s.stop(this.ctx.currentTime + 0.25); o.stop(this.ctx.currentTime + 0.25);
    this.freeze = null;
  }

  /* -- ambient ship loop ----------------------------------------------------- */
  startAmbient() {
    if (!this.ctx) return;
    // deep hull hum
    const o = this.ctx.createOscillator();
    o.type = 'sine'; o.frequency.value = 52;
    const o2 = this.ctx.createOscillator();
    o2.type = 'sine'; o2.frequency.value = 52.7; // slow beat
    const g = this.ctx.createGain(); g.gain.value = 0.5;
    o.connect(g); o2.connect(g); g.connect(this.ambBus);
    o.start(); o2.start();
    // air system hiss
    this.burst({ dur: 8, freq: 300, gain: 0.05, bus: this.ambBus, attack: 2 });
    this.scheduleClank();
  }

  scheduleClank() {
    const next = 8000 + Math.random() * 14000;
    this.clankTimer = setTimeout(() => {
      if (this.ctx) {
        this.tone({ type: 'triangle', f0: 150, f1: 70, dur: 0.5, gain: 0.12, bus: this.ambBus });
        this.burst({ dur: 0.35, freq: 400, f1: 150, gain: 0.08, bus: this.ambBus });
      }
      this.scheduleClank();
    }, next);
  }
}

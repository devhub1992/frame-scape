/* ============================================================================
   FRAME SCAPE — ecology.js  (NEW in v0.8.0)
   ----------------------------------------------------------------------------
   The wilds are alive:
     · BIRDS circle overhead in the nature tiles — shoot one down for
       feathers (they count as critters: weapon.js checks userData.critter)
     · RODENTS scurry through the brush, flee from you — drop hide
     · FISH shoal in the rivers, bays and ocean — visible, and catchable
       with the FISHING ROD: press X near water to cast, press X again
       when the bite window opens
     · HARVESTING: press X next to bushes (fiber/herbs) or ore rocks
       (ferrite/titanium/gallium/crystal) — nodes deplete and regrow
   Materials feed the XMB → SALVAGE column (sell for credits).
   All tunables in assets.js → ecology{}.
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js?v=0.9.4e';

const EC = ASSETS.ecology;
const rand = (a, b) => a + Math.random() * (b - a);

export class Ecology {
  constructor(scene, world) {
    this.scene = scene;
    this.world = world;
    this.birds = [];
    this.rodents = [];
    this.fish = [];
    this.fishing = null;          // { phase:'cast'|'bite', t, limit, castPos }
    this._lockerHintT = 0;        // CH-05.2 — beast-only X-press toast throttle
    this.build();
  }

  /* ====================================================================== */
  build() {
    const W = this.world;

    /* birds + rodents from the world's spawn table */
    for (const s of W.animalSpawns) {
      if (s.kind === 'bird') this.spawnBird(s.x, s.z);
      else this.spawnRodent(s.x, s.z);
    }

    /* fish shoals in every water zone (cap for perf) */
    let fishBudget = 16;
    for (const z of W.fishZones) {
      if (fishBudget <= 0) break;
      const n = Math.min(2, fishBudget);
      for (let i = 0; i < n; i++) this.spawnFish(z);
      fishBudget -= n;
    }
  }

  spawnBird(x, z) {
    const g = new THREE.Group();
    const bodyM = new THREE.MeshLambertMaterial({ color: '#3a4046' });
    const wingM = new THREE.MeshLambertMaterial({
      color: '#4a545c', side: THREE.DoubleSide,
    });
    const body = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.42, 5), bodyM);
    body.rotation.x = Math.PI / 2;
    g.add(body);
    const wings = [];
    for (const side of [-1, 1]) {
      const w = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.2), wingM);
      w.position.x = side * 0.26;
      g.add(w);
      wings.push(w);
    }
    g.position.set(x, rand(6.5, 9.5), z);
    this.scene.add(g);

    /* hitbox (raycast target) */
    const hit = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.5, 0.7),
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }));
    hit.userData.critter = null;
    g.add(hit);

    const b = {
      kind: 'bird', group: g, wings, hit, home: new THREE.Vector2(x, z),
      a: rand(0, Math.PI * 2), r: rand(6, 12), h: g.position.y,
      speed: rand(0.35, 0.6), flap: rand(0, 9), deadT: -1, respT: -1, t: 0,
    };
    hit.userData.critter = b;
    this.birds.push(b);
  }

  spawnRodent(x, z) {
    const g = new THREE.Group();
    const furM = new THREE.MeshLambertMaterial({ color: '#8a6f52' });
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.14, 7, 5), furM);
    body.scale.set(1, 0.75, 1.4);
    body.position.y = 0.12;
    g.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.08, 6, 5), furM);
    head.position.set(0, 0.16, -0.2);
    g.add(head);
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.16), furM);
    tail.position.set(0, 0.12, 0.26);
    g.add(tail);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.7),
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }));
    hit.position.y = 0.15;
    hit.userData.critter = null;
    g.add(hit);
    g.position.set(x, 0, z);
    this.scene.add(g);

    const r = {
      kind: 'rodent', group: g, hit, home: new THREE.Vector2(x, z),
      dir: rand(0, Math.PI * 2), hopT: rand(0, 1), deadT: -1, respT: -1, t: 0,
    };
    hit.userData.critter = r;
    this.rodents.push(r);
  }

  spawnFish(zone) {
    const g = new THREE.Group();
    const fm = new THREE.MeshLambertMaterial({
      color: Math.random() < 0.3 ? '#e8a04e' : '#9fc4c8',
    });
    const body = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.3, 5), fm);
    body.rotation.x = Math.PI / 2;
    g.add(body);
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.09, 0.09), fm);
    tail.position.z = 0.18;
    g.add(tail);
    g.position.set(
      zone.x + rand(-zone.r, zone.r) * 0.6, rand(0.15, 0.3),
      zone.z + rand(-zone.r, zone.r) * 0.6);
    this.scene.add(g);
    this.fish.push({
      group: g, zone, a: rand(0, Math.PI * 2), speed: rand(0.5, 1.1), t: 0,
    });
  }

  /* ====================================================================== */
  /* critter death — called from weapon.js raycast                          */
  killCritter(c, game) {
    if (c.deadT >= 0) return;
    c.deadT = 0;
    c.hit.userData.critter = null;
    const pos = c.group.position;
    const mat = c.kind === 'bird' ? 'feather' : 'hide';
    game.sfx.tone({ type: 'square', f0: 900, f1: 300, dur: 0.14, gain: 0.12 });
    if (game.specials) {
      game.specials.spawnPickup(pos.clone(),
        { t: 'material', id: mat, n: 1, label: '+1 ' + EC.materials[mat].label });
      /* small credit chance */
      if (Math.random() < 0.4) {
        game.specials.spawnPickup(pos.clone().add(new THREE.Vector3(0.4, 0, 0.3)),
          { t: 'credits', id: 'chips', n: 60, label: '+60 CREDITS' });
      }
    }
  }

  /* ====================================================================== */
  /* interaction: harvest / fish                                            */
  /* ====================================================================== */
  nearestHarvest(pos) {
    let best = null, bestD = EC.interactR;
    for (const h of this.world.harvests) {
      if (h.depleted) continue;
      const d = Math.hypot(h.x - pos.x, h.z - pos.z);
      if (d < bestD) { best = h; bestD = d; }
    }
    return best;
  }

  nearestFishZone(pos) {
    let best = null, bestD = 3.4;
    for (const z of this.world.fishZones) {
      const d = Math.hypot(z.x - pos.x, z.z - pos.z);
      if (d < bestD) { best = z; bestD = d; }
    }
    return best;
  }

  /* what would X do right here? → { kind, verb, raw?, locker? } | null (CH-01.1).
     kind: 'harvest' · 'fish' · 'locker'. Controllers route their X (btn 2)
     through this via weapon.js; keyboard X / D-pad↓ keep the plain
     'interact' action (main.js).
     CH-05.2 — lockers are BEAST-ONLY now: X never opens them. The
     pre-CH-05 speculative open hook ("honoured when the world ships
     world.lockers[]") is superseded — a locker context renders the raw
     teach prompt (no "PRESS X TO" prefix) and the X-press answers with a
     throttled hint instead of opening. A reticle-designated locker wins
     over harvest/fish prompts so the mechanic reads at a glance; while
     the beast channels, the prompt shows the live progress.            */
  interactContext(pos, game) {
    /* hooking an open bite always wins */
    if (this.fishing && this.fishing.phase === 'bite')
      return { kind: 'fish', verb: 'HOOK' };
    /* CH-05.2 — designated locker (reticle cone, via companions.js) */
    const cp = game && game.companions;
    const desig = cp && cp.lockerDesignated;
    if (desig && !desig.locker.opened)
      return { kind: 'locker', verb: this._lockerVerb(cp, desig.locker), raw: true, locker: desig.locker };
    const h = this.nearestHarvest(pos);
    if (h) return { kind: 'harvest', verb: h.kind === 'ore' ? 'MINE ORE' : 'HARVEST' };
    const z = this.nearestFishZone(pos);
    if (z) return { kind: 'fish', verb: 'CAST' };
    /* standing in reach of an unopened locker — same teach prompt */
    const L = this.world.lockers;
    if (Array.isArray(L)) {
      for (const l of L) {
        if (l.opened) continue;
        if (Math.hypot(l.x - pos.x, l.z - pos.z) <= (l.reach || EC.interactR))
          return { kind: 'locker', verb: this._lockerVerb(cp, l), raw: true, locker: l };
      }
    }
    return null;
  }

  /* CH-05.2 — the beast-only teach prompt; while the beast channels THIS
     locker it becomes the live progress readout */
  _lockerVerb(cp, l) {
    return (cp && cp.petChannelLocker === l)
      ? 'BEAST SCAVENGING… ' + Math.round(
          Math.min(1, cp.petChannelT / Math.max(0.001, cp.petChannelDur)) * 100) + ' %'
      : 'BEAST ONLY — POINT RETICLE';
  }

  interact(game) {
    const pl = game.player;
    if (pl.dead) return;

    /* hook the bite if one is open */
    if (this.fishing && this.fishing.phase === 'bite') {
      this.landCatch(game);
      return;
    }
    /* casting again cancels / recasts */
    if (this.fishing && this.fishing.phase === 'cast') return;

    /* CH-05.2 — lockers are BEAST-ONLY: X never opens them (this used to
       be the pre-CH-05 speculative open hook — superseded). A throttled
       hint answers the press; the beast opens lockers through the
       reticle designation (companions.js updatePet). */
    const L = this.world.lockers;
    if (Array.isArray(L)) {
      for (const l of L) {
        if (l.opened) continue;
        if (Math.hypot(l.x - pl.pos.x, l.z - pl.pos.z) <= (l.reach || EC.interactR)) {
          if (this._lockerHintT <= 0) {
            this._lockerHintT = 6;
            game.hud.toast('BEAST ONLY — POINT YOUR RETICLE AT THE LOCKER', 2200);
          }
          return;
        }
      }
    }

    /* harvest a node */
    const h = this.nearestHarvest(pl.pos);
    if (h) {
      h.depleted = true;
      h.respT = 75 + Math.random() * 45;
      h.mesh.visible = false;
      const sub = h.kind === 'ore'
        ? h.sub
        : EC.plants[Math.floor(Math.random() * EC.plants.length)];
      const n = Math.random() < 0.3 ? 2 : 1;
      game.sfx.pickup('ammo');
      game.weapon.spawnSpark(new THREE.Vector3(h.x, 0.6, h.z), false, true);
      game.specials.spawnPickup(new THREE.Vector3(h.x, 0.6, h.z),
        { t: 'material', id: sub, n, label: '+' + n + ' ' + EC.materials[sub].label });
      return;
    }

    /* cast the fishing rod */
    const zone = this.nearestFishZone(pl.pos);
    if (zone) {
      this.fishing = {
        phase: 'cast',
        t: 0,
        limit: rand(EC.fishWait[0], EC.fishWait[1]),
        castPos: pl.pos.clone(),
        zone,
      };
      game.sfx.throwPin();
      game.hud.toast('CASTING…', 900);
    }
  }

  landCatch(game) {
    const f = this.fishing;
    this.fishing = null;
    const n = Math.random() < 0.25 ? 2 : 1;
    game.sfx.pickup('health');
    game.hud.toast('CAUGHT IT!', 1100);
    game.specials.spawnPickup(game.player.pos.clone().add(new THREE.Vector3(0, 0.4, 0)),
      { t: 'material', id: 'fish', n, label: '+' + n + ' ' + EC.materials.fish.label });
    /* rare bonus: ore-digesting gizzard stones → raw crystal */
    if (Math.random() < 0.07) {
      game.specials.spawnPickup(game.player.pos.clone().add(new THREE.Vector3(0.5, 0.4, 0)),
        { t: 'material', id: 'crystal', n: 1, label: '+1 RAW CRYSTAL' });
    }
  }

  cancelFishing(game, why) {
    if (!this.fishing) return;
    this.fishing = null;
    if (why) game.hud.toast(why, 1000);
  }

  /* ====================================================================== */
  update(dt, game) {
    const pl = game.player;
    const W = this.world;
    if (this._lockerHintT > 0) this._lockerHintT -= dt;   // CH-05.2 — toast throttle

    /* -- birds ------------------------------------------------------------ */
    for (const b of this.birds) {
      b.t += dt;
      if (b.deadT >= 0) {
        b.deadT += dt;
        b.group.position.y -= dt * 5;
        b.group.rotation.z += dt * 7;
        if (b.deadT > 1) { b.group.visible = false; b.deadT = -1; b.respT = 40; }
        continue;
      }
      if (b.respT > 0) {
        b.respT -= dt;
        if (b.respT <= 0) {
          b.respT = -1; b.group.visible = true;
          b.hit.userData.critter = b;
        }
        continue;
      }
      b.a += b.speed * dt;
      b.flap += dt * 9;
      const wx = b.home.x + Math.cos(b.a) * b.r;
      const wz = b.home.y + Math.sin(b.a) * b.r;
      b.group.position.set(wx, b.h + Math.sin(b.t * 1.7) * 0.5, wz);
      b.group.rotation.y = -b.a;
      for (let i = 0; i < 2; i++) {
        b.wings[i].rotation.z = (i === 0 ? 1 : -1) * Math.sin(b.flap) * 0.55;
      }
    }

    /* -- rodents ----------------------------------------------------------- */
    for (const r of this.rodents) {
      r.t += dt;
      if (r.deadT >= 0) {
        r.deadT += dt;
        r.group.rotation.z = Math.min(Math.PI / 2, r.deadT * 4);
        if (r.deadT > 1.2) { r.group.visible = false; r.deadT = -1; r.respT = 35; }
        continue;
      }
      if (r.respT > 0) {
        r.respT -= dt;
        if (r.respT <= 0) {
          r.respT = -1; r.group.visible = true;
          r.hit.userData.critter = r;
          r.group.rotation.z = 0;
        }
        continue;
      }
      /* flee the player */
      const dx = r.group.position.x - pl.pos.x;
      const dz = r.group.position.z - pl.pos.z;
      const d = Math.hypot(dx, dz);
      let sp = 0;
      if (d < 6.5) {
        r.dir = Math.atan2(dx, dz);
        sp = 2.6;
      } else if (Math.random() < dt * 0.5) {
        r.dir = rand(0, Math.PI * 2);
      }
      r.hopT += dt * (3 + sp * 3);
      const hop = Math.abs(Math.sin(r.hopT)) * 0.09;
      if (sp > 0 || d < 6.5) {
        r.group.position.x += Math.sin(r.dir) * sp * dt;
        r.group.position.z += Math.cos(r.dir) * sp * dt;
        r.group.rotation.y = r.dir;
        /* stay near home patch */
        const hd = Math.hypot(r.group.position.x - r.home.x, r.group.position.z - r.home.y);
        if (hd > 11) r.dir = Math.atan2(r.home.x - r.group.position.x, r.home.y - r.group.position.z);
      }
      r.group.position.y = hop;
    }

    /* -- fish ---------------------------------------------------------------- */
    for (const f of this.fish) {
      f.t += dt;
      f.a += Math.sin(f.t * 0.7) * dt * 0.6;
      f.group.position.x += Math.sin(f.a) * f.speed * dt;
      f.group.position.z += Math.cos(f.a) * f.speed * dt;
      f.group.rotation.y = f.a;
      /* keep inside the zone */
      const dx = f.group.position.x - f.zone.x;
      const dz = f.group.position.z - f.zone.z;
      if (Math.hypot(dx, dz) > f.zone.r) {
        f.a = Math.atan2(f.zone.x - f.group.position.x, f.zone.z - f.group.position.z) + Math.PI;
      }
      f.group.position.y = 0.2 + Math.sin(f.t * 3) * 0.05;
    }

    /* -- fishing state machine ------------------------------------------------ */
    if (this.fishing) {
      const f = this.fishing;
      f.t += dt;
      /* moved away / took a hit → the line drops */
      if (pl.pos.distanceTo(f.castPos) > 2.2 || pl.dead) {
        this.cancelFishing(game, 'LINE SNAPPED');
      } else if (f.phase === 'cast') {
        game.hud.setPrompt('CASTING… HOLD STILL');
        if (f.t >= f.limit) {
          f.phase = 'bite';
          f.t = 0;
          f.limit = EC.fishBite;
          game.sfx.tone({ type: 'sine', f0: 1400, f1: 1800, dur: 0.12, gain: 0.18 });
          game.hud.toast('SOMETHING BIT — PRESS X!', 900);
        }
      } else if (f.phase === 'bite') {
        game.hud.setPrompt('! PRESS X TO HOOK IT !');
        if (f.t >= f.limit) this.cancelFishing(game, 'IT GOT AWAY…');
      }
    }

    /* -- context prompt (harvest / fish / locker) — runs AFTER weapon's
       prompt, wins. Pad users get the short "X VERB" form (their X button
       interacts here, CH-01.1); keyboard keeps "PRESS X TO …".
       CH-05.2 — locker contexts carry raw: true (the teach prompt is a
       full sentence — never prefixed with X / PRESS X TO).              */
    if (!this.fishing && !pl.dead && game.state === 'playing') {
      const ctx = this.interactContext(pl.pos, game);
      if (ctx) {
        game.hud.setPrompt(ctx.raw ? ctx.verb
          : (game.input.usesPad ? 'X ' : 'PRESS X TO ') + ctx.verb);
      }
    }
  }
}

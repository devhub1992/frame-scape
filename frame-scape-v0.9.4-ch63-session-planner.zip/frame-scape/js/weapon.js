/* ============================================================================
   FRAME SCAPE — weapon.js  (v0.8.0)
   ----------------------------------------------------------------------------
   Five-gun arsenal (Y/Q cycles · XMB equips · 1-5 hotkeys), per-weapon
   recoil + spread bloom, and ADS for everything. You DEPLOY WITH THE M6-P
   ONLY — the rest unlock when you scavenge their ammo.
   v0.8 additions:
     · STOW WEAPON (H / L3) — holster the gun: +8 % move speed, no fire /
       ADS / reload until you press fire or H again
     · NIKANA — samurai draw-style melee (XMB → ABILITY): V/B performs an
       iai quick-draw slash with a forward lunge and a wide arc
     · WEAPON SELLING — X on a weapon card in the XMB sells it back for
       credits (it re-locks; scavenging its ammo brings it online again)
     · critter hits (birds / rodents from ecology.js) drop materials
     · firing decloaks you (CLOAK skill)
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js?v=0.9.4e';
import { Mods } from './mods.js?v=0.9.4e';
import { texGlow, texPuff } from './textures.js?v=0.9.4e';

const P = ASSETS.palette;
const MELEE = ASSETS.melee;
const NIK = ASSETS.nikana;
const MELEE_DUR = 0.42;
const MELEE_HIT_AT = 0.16;
const SWAP_TIME = 0.36;

/* ============================================================================
   CH-25 — TYPED DAMAGE HELPERS + THE ONE SHARED ENTRY POINT
   ----------------------------------------------------------------------------
   Every hostile-facing source in the game — player guns, melee, R2 specials,
   pet bites, drone weapons — builds a TYPED HIT here and lands it through
   applyDamage(). The per-type resolution (shield gauntlet, health pool,
   armor mitigation, DEF-DOWN, CH-26 status gate) lives in enemy.js
   (damageTyped); this side owns the WEAPON-SIDE contract:

     def.types         fractions of the moddable scalar `damage` (sum 1 —
                       power mods that mul `damage` keep scaling the hit)
     def.critChance    0..1 — rolled ONCE per hit (per pellet for shotguns)
     def.critMult      damage × critMult on a crit
     def.statusChance  0..1 — rides the hit; CH-26 rolls the proc

   applyDamage(enemy, hit, game, ctx):
     hit = { types: {puncture..toxin}, crit: {isCrit, mult}|null,
             statusChance: 0..1 }
     ctx = { point, dir, kind }  (kind 'bullet'|'melee'|'splash'|...)
   ========================================================================== */

/* def → per-type damage values (fractions × the moddable scalar). A def
   without `types` degrades to a plain impact hit — nothing explodes.     */
export function typedHit(def, total = null) {
  /* CH-25.5 — REGRESSION FIX (user: "drone weapons appear to do no damage"):
     the drone defs keep their LEGACY scalar key `dmg` — it is what the
     dr-out table mod (field 'dmg'), the XMB drone rows and the homing
     pod's `dmg: W.dmg` all read — but CH-25.4 built drone hits through
     this helper, which only knew `damage`. Every drone shot therefore
     carried all-zero typed values. Accept `dmg` as the fallback scalar
     so the drone set (and any future legacy-keyed def) hits for real.  */
  const dmg = total ?? def.damage ?? def.dmg ?? 0;
  const out = {};
  const T = def.types || { impact: 1 };
  for (const k in T) if (T[k] > 0) out[k] = dmg * T[k];
  return out;
}

/* scale an already-built types map (splash falloff, DoT ticks…) */
export function scaleTypes(types, m) {
  const out = {};
  for (const k in types) out[k] = types[k] * m;
  return out;
}

/* CH-25.2 — roll the crit for one hit. Returns {isCrit, mult}; mult 1 =
   normal hit. Crit multiplies EVERY type in the hit (the whole package).  */
export function rollCrit(def) {
  const cc = def.critChance ?? ASSETS.combat.crit.defaultChance;
  const cm = def.critMult ?? ASSETS.combat.crit.defaultMult;
  const isCrit = Math.random() < cc;
  return { isCrit, mult: isCrit ? cm : 1 };
}

/* THE shared entry point (CH-25.4). Rolls nothing itself — callers roll
   crit once per hit via rollCrit() and pass it in, so one shotgun blast
   crits as a package and splash falloff lands after the crit, not inside
   the pools. Sets enemy.lastHit for the CH-28 crit/status styling and
   carries statusChance to the CH-26 gate. Returns the applied total.      */
export function applyDamage(enemy, hit, game, ctx = {}) {
  if (!enemy || !enemy.alive) return 0;
  const crit = hit.crit && hit.crit.isCrit ? hit.crit : { isCrit: false, mult: 1 };
  const types = hit.types || { impact: 0 };
  /* crit multiplies the typed hit — pre-scaled so the enemy-side pools
     (gauntlet / armor / DEF-DOWN) all see the final per-type values.      */
  const scaled = crit.mult !== 1 ? scaleTypes(types, crit.mult) : types;
  enemy._statusChance = hit.statusChance || 0;         // CH-26 gate input
  enemy._critHit = !!crit.isCrit;                      // CH-26.2 — COLD amp input
  enemy._critUpgraded = false;                         // CH-26.3 — PUNCTURE may flip it
  const total = enemy.damage(scaled, ctx.point, game, ctx.kind || 'bullet', ctx.dir) || 0;
  /* CH-25.2 — flag the hit for HUD styling (CH-28 floating numbers:
     white → yellow → orange → red ladder reads lastHit.crit).
     CH-26.3 — a PUNCTURE-upgraded crit reports as one (the target's
     crit-chance-TAKEN turned the hit).                                    */
  enemy.lastHit = {
    crit: !!crit.isCrit || !!enemy._critUpgraded,
    mult: crit.mult || 1,          // CH-28.1 — crit tier ladder input (t1/t2/t3)
    total, statusChance: hit.statusChance || 0,
  };
  /* CH-28.1 — floating damage numbers feed. ONE line at the shared entry
     point so EVERY player-side source reports (guns · melee · R2
     specials · companions · status DoT ticks · chain zaps). The HUD
     owns pooling/styling/the toggle; weapon.js only reports. DoT ticks
     carry dotKey/dotStacks (enemy.js tick) for the stack subscript.    */
  if (total > 0 && game && game.hud && game.hud.spawnDamageNumber) {
    game.hud.spawnDamageNumber(enemy, total, {
      crit: !!crit.isCrit || !!enemy._critUpgraded,
      mult: crit.mult || 1,
      types: scaled, kind: ctx.kind || 'bullet',
      dotKey: ctx.dotKey || null, dotStacks: ctx.dotStacks || 0,
      point: ctx.point || null,
    });
  }
  return total;
}

/* -- one gun = def + runtime state + viewmodel ------------------------------ */
class Gun {
  constructor(def, camera) {
    this.def = def;
    this.mag = def.mag;
    this.spread = def.spreadBase;
    this.reloadT = -1;
    this.ledState = '';
    this.buildVM(camera);
  }

  buildVM(camera) {
    const g = new THREE.Group();
    const body  = new THREE.MeshLambertMaterial({ color: P.gunmetal });
    const dark  = new THREE.MeshLambertMaterial({ color: P.gunDark });
    const olive = new THREE.MeshLambertMaterial({ color: P.gunAccent });
    const steel = new THREE.MeshLambertMaterial({ color: '#7d8790' });
    const box = (w, h, d, x, y, z, mat, rx = 0) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      m.position.set(x, y, z); m.rotation.x = rx;
      g.add(m); return m;
    };

    const id = this.def.id;
    if (id === 'ar') {
      box(0.075, 0.10, 0.46, 0, 0, 0, body);
      box(0.05, 0.05, 0.22, 0, 0.005, -0.32, dark);
      box(0.03, 0.03, 0.05, 0, 0.005, -0.44, dark);
      box(0.05, 0.16, 0.09, 0, -0.115, -0.06, olive, 0.3);
      box(0.06, 0.045, 0.30, 0, 0.075, 0.02, dark);
      box(0.04, 0.10, 0.05, 0, -0.09, -0.24, olive, -0.35);
      box(0.06, 0.07, 0.12, 0, -0.01, 0.26, dark);
      box(0.012, 0.02, 0.012, 0.032, 0.045, -0.18, olive);
      box(0.012, 0.024, 0.012, -0.032, 0.045, -0.18, olive);   // rear post (ADS)
      this.ledPos = [0, 0.105, 0.09]; this.ledSize = [0.055, 0.028];
      this.muzzlePos = [0, 0.005, -0.47];
    } else if (id === 'pistol') {
      box(0.062, 0.07, 0.30, 0, 0.015, -0.02, body);
      box(0.055, 0.05, 0.24, 0, -0.035, 0.0, dark);
      box(0.05, 0.15, 0.075, 0, -0.125, 0.10, olive, 0.32);
      box(0.045, 0.012, 0.10, 0, -0.075, -0.02, dark);
      box(0.03, 0.03, 0.06, 0, 0.015, -0.19, dark);
      box(0.052, 0.038, 0.17, 0, 0.062, 0.045, dark);
      box(0.06, 0.014, 0.05, 0, 0.062, -0.05, olive);
      this.ledPos = [0, 0.062, 0.135]; this.ledSize = [0.05, 0.026];
      this.muzzlePos = [0, 0.02, -0.23];
    } else if (id === 'sniper') {
      box(0.07, 0.09, 0.62, 0, 0, -0.05, body);               // long receiver
      box(0.035, 0.035, 0.34, 0, 0.01, -0.5, steel);          // long barrel
      box(0.05, 0.05, 0.06, 0, 0.01, -0.68, dark);            // muzzle brake
      box(0.06, 0.14, 0.10, 0, -0.11, 0.12, olive, 0.25);     // stock grip
      box(0.07, 0.09, 0.22, 0, -0.03, 0.3, dark);             // stock
      box(0.05, 0.13, 0.07, 0, -0.1, -0.05, olive, 0.12);     // mag
      box(0.055, 0.05, 0.26, 0, 0.085, -0.02, dark);          // scope tube
      box(0.065, 0.065, 0.05, 0, 0.085, -0.15, steel);        // objective lens
      box(0.065, 0.065, 0.04, 0, 0.085, 0.11, dark);          // eyepiece
      box(0.014, 0.014, 0.05, 0, 0.05, 0.08, steel);          // mount
      this.ledPos = [0, 0.02, 0.2]; this.ledSize = [0.05, 0.026];
      this.muzzlePos = [0, 0.01, -0.72];
    } else if (id === 'shotgun') {
      box(0.08, 0.09, 0.42, 0, 0, 0, body);                   // receiver
      box(0.055, 0.055, 0.3, 0, 0.015, -0.35, dark);          // barrel
      box(0.05, 0.05, 0.24, 0, -0.04, -0.32, steel);          // tube mag
      box(0.055, 0.06, 0.12, 0, -0.045, -0.24, olive);        // pump
      box(0.05, 0.13, 0.09, 0, -0.1, 0.1, olive, 0.35);       // grip
      box(0.07, 0.1, 0.2, 0, -0.02, 0.3, dark);               // stock
      box(0.014, 0.02, 0.014, 0.03, 0.05, -0.18, olive);      // bead front
      this.ledPos = [0, 0.075, 0.1]; this.ledSize = [0.05, 0.026];
      this.muzzlePos = [0, 0.015, -0.52];
    } else { // rocket
      box(0.11, 0.11, 0.72, 0, 0, -0.1, body);                // launch tube
      box(0.125, 0.125, 0.08, 0, 0, -0.47, dark);             // muzzle ring
      box(0.13, 0.13, 0.07, 0, 0, 0.26, dark);                // rear exhaust
      box(0.05, 0.1, 0.1, 0, -0.1, 0.02, olive, 0.3);         // grip
      box(0.05, 0.06, 0.14, 0.085, 0.02, -0.05, dark);        // sight unit
      box(0.014, 0.024, 0.014, 0.13, 0.06, -0.05, olive);     // sight post
      box(0.04, 0.04, 0.16, 0, -0.08, -0.34, steel);          // under barrel
      this.ledPos = [0.085, 0.02, 0.06]; this.ledSize = [0.05, 0.026];
      this.muzzlePos = [0, 0, -0.5];
    }

    // LED ammo screen
    this.ledCanvas = document.createElement('canvas');
    this.ledCanvas.width = 128; this.ledCanvas.height = 64;
    this.ledTex = new THREE.CanvasTexture(this.ledCanvas);
    this.ledTex.colorSpace = THREE.SRGBColorSpace;
    const led = new THREE.Mesh(
      new THREE.PlaneGeometry(this.ledSize[0], this.ledSize[1]),
      new THREE.MeshBasicMaterial({ map: this.ledTex })
    );
    led.position.fromArray(this.ledPos);
    led.rotation.x = -0.62;
    g.add(led);
    this.drawLed();

    // muzzle + flash
    this.muzzle = new THREE.Object3D();
    this.muzzle.position.fromArray(this.muzzlePos);
    g.add(this.muzzle);
    const flashMat = new THREE.MeshBasicMaterial({
      map: texGlow(P.muzzle), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    });
    this.flash = new THREE.Group();
    for (const r of [0, Math.PI / 2]) {
      const q = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.16), flashMat);
      q.rotation.y = r;
      this.flash.add(q);
    }
    this.flash.visible = false;
    this.muzzle.add(this.flash);

    g.position.fromArray(this.def.vmPos);
    g.rotation.y = -0.045;
    g.visible = false;
    camera.add(g);
    this.group = g;
  }

  drawLed() {
    const x = this.ledCanvas.getContext('2d');
    x.fillStyle = '#05130d'; x.fillRect(0, 0, 128, 64);
    x.strokeStyle = 'rgba(90,255,208,0.35)'; x.strokeRect(2, 2, 124, 60);
    const low = this.mag <= Math.ceil(this.def.mag * 0.2);
    x.fillStyle = low ? (Math.floor(performance.now() / 280) % 2 ? '#ff5340' : P.led) : P.led;
    x.font = '700 38px Consolas, monospace';
    x.textAlign = 'right'; x.textBaseline = 'middle';
    x.fillText(String(this.mag), 108, 34);
    x.font = '700 12px Consolas, monospace';
    x.textAlign = 'left';
    x.fillStyle = 'rgba(90,255,208,0.6)';
    x.fillText(this.def.name, 10, 18);
    x.fillText('RND', 10, 48);
    this.ledTex.needsUpdate = true;
  }
}

/* ========================================================================== */
export class Weapon {
  constructor(camera, scene) {
    this.camera = camera;
    this.scene = scene;
    this.guns = ASSETS.weapons.map((def) => new Gun(def, camera));
    this.unlocked = new Set([ASSETS.startWeapon || 'pistol']);
    this.cur = Math.max(0, this.guns.findIndex((g) => g.def.id === (ASSETS.startWeapon || 'pistol')));
    this.swapT = -1;
    this.zoomed = false;
    this.adsT = 0;            // 0 = hip, 1 = aimed (smooth)
    this.cooldown = 0;
    this.kick = 0;
    this.meleeT = -1;
    this.meleeCd = 0;
    this.meleeHitDone = false;
    this.meleeKind = 'bash';
    this.stowed = false;      // v0.8 — holstered weapon
    this.nikana = false;      // v0.8 — wield the nikana (XMB → ABILITY)
    this.flashT = 0;
    this.ray = new THREE.Raycaster();

    this.stats = { shots: 0, hits: 0, kills: 0 };
    this.buildFx();
    this.buildNikana(camera);

    this.guns.forEach((g, i) => { g.group.visible = i === this.cur; });
  }

  /* -- nikana viewmodel (iai draw-slash) ---------------------------------- */
  buildNikana(camera) {
    const g = new THREE.Group();
    const bladeM = new THREE.MeshBasicMaterial({ color: '#dfe9f2' });
    const edgeM = new THREE.MeshBasicMaterial({ color: '#8fd8ff' });
    const tsubaM = new THREE.MeshLambertMaterial({ color: '#2c2622' });
    const gripM = new THREE.MeshLambertMaterial({ color: '#4a3a50' });
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.034, 0.82), bladeM);
    blade.position.z = -0.48;
    g.add(blade);
    const edge = new THREE.Mesh(new THREE.BoxGeometry(0.006, 0.01, 0.7), edgeM);
    edge.position.set(0, -0.018, -0.48);
    g.add(edge);
    const tsuba = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.014, 8), tsubaM);
    tsuba.rotation.x = Math.PI / 2;
    g.add(tsuba);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.038, 0.2), gripM);
    grip.position.z = 0.1;
    g.add(grip);
    /* sheathed pose on the left hip, hugging the frame edge */
    g.position.set(-0.3, -0.44, -0.26);
    g.rotation.set(0.1, 0.62, 1.15);
    g.visible = false;
    camera.add(g);
    this.nikanaVM = g;
  }

  /* -- weapon unlocks (start M6-P only; ammo pickups unlock the rest) ------- */
  isUnlocked(idx) { return this.unlocked.has(this.guns[idx].def.id); }

  nextUnlocked(fromIdx) {
    for (let k = 1; k <= this.guns.length; k++) {
      const j = (fromIdx + k) % this.guns.length;
      if (this.unlocked.has(this.guns[j].def.id)) return j;
    }
    return fromIdx;
  }

  unlockByAmmo(ammoId, game) {
    const gun = this.guns.find((g) => g.def.ammo === ammoId);
    if (!gun || this.unlocked.has(gun.def.id)) return false;
    this.unlocked.add(gun.def.id);
    if (game) {
      game.hud.toast(gun.def.name + ' UNLOCKED', 1800);
      game.hud.pickup(gun.def.name + ' ONLINE');
      game.sfx.uiConfirm();
    }
    return true;
  }

  /* -- getters the HUD reads (current weapon) -------------------------------- */
  get def()      { return this.guns[this.cur].def; }
  get gun()      { return this.guns[this.cur]; }
  get mag()      { return this.guns[this.cur].mag; }
  get reserve()  { return this.gameAmmo()[this.def.ammo]; }
  get reloading(){ return this.guns[this.cur].reloadT >= 0; }
  gameAmmo()     { return this.game.ammo; }

  /* -- stow / draw --------------------------------------------------------------- */
  toggleStow(game) {
    this.stowed = !this.stowed;
    if (this.stowed) {
      this.closeZoom(game);
      game.hud.toast('WEAPON STOWED — +8% SPEED', 1200);
    } else {
      game.hud.toast('WEAPON DRAWN', 900);
    }
    game.sfx.swap();
    return this.stowed;
  }
  drawWeapon(game) {
    if (!this.stowed) return;
    this.stowed = false;
    game.sfx.swap();
  }

  /* ADS helpers (player + HUD read these) */
  adsSens() {
    return this.zoomed ? this.def.ads.sensMult : 1;
  }
  adsMove() {
    if (this.stowed) return 1.08;         // holstered → lighter on your feet
    return this.zoomed ? this.def.ads.moveMult : 1;
  }
  adsRecoilMult() {
    return this.zoomed ? this.def.ads.recoilMult : 1;
  }
  adsSpreadMult() {
    return this.zoomed ? this.def.ads.spreadMult : 1;
  }

  /* -- shared FX pools --------------------------------------------------------- */
  buildFx() {
    this.flashLight = new THREE.PointLight(P.muzzle, 0, 7, 1.8);
    this.flashLight.position.set(0.25, -0.1, -0.7);
    this.camera.add(this.flashLight);

    this.impactLight = new THREE.PointLight(P.muzzle, 0, 6, 1.8);
    this.impactLight.intensity = 0;
    this.scene.add(this.impactLight);

    // tracers
    this.tracers = [];
    const tGeo = new THREE.BoxGeometry(0.014, 0.014, 1);
    for (let i = 0; i < 10; i++) {
      const m = new THREE.Mesh(tGeo, new THREE.MeshBasicMaterial({
        color: 0xffe2b0, blending: THREE.AdditiveBlending,
        transparent: true, opacity: 0, depthWrite: false,
      }));
      m.visible = false;
      this.scene.add(m);
      this.tracers.push({ mesh: m, life: 0 });
    }

    // sparks (warm = wall, plasma = enemy)
    this.sparks = [];
    this.sparkMatWarm = new THREE.SpriteMaterial({
      map: texGlow('#ffca7a'), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    });
    this.sparkMatPlasma = new THREE.SpriteMaterial({
      map: texGlow(P.plasma), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    });
    this.sparkMatEnergy = new THREE.SpriteMaterial({
      map: texGlow('#59f2ff'), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    });
    for (let i = 0; i < 40; i++) {
      const s = new THREE.Sprite(this.sparkMatWarm);
      s.visible = false; s.scale.setScalar(0.07);
      this.scene.add(s);
      this.sparks.push({ s, vel: new THREE.Vector3(), life: 0 });
    }
    this.sparkIdx = 0;

    // smoke puffs
    this.puffs = [];
    const puffTex = texPuff();
    for (let i = 0; i < 12; i++) {
      const mat = new THREE.SpriteMaterial({
        map: puffTex, color: '#70767d', transparent: true,
        opacity: 0, depthWrite: false,
      });
      const s = new THREE.Sprite(mat);
      s.visible = false;
      this.scene.add(s);
      this.puffs.push({ s, vel: new THREE.Vector3(), life: 0, max: 1 });
    }
    this.puffIdx = 0;
  }

  spawnSpark(pos, plasma, big = false) {
    const sp = this.sparks[this.sparkIdx++ % this.sparks.length];
    sp.s.material = plasma === 'energy' ? this.sparkMatEnergy
      : plasma ? this.sparkMatPlasma : this.sparkMatWarm;
    sp.s.position.copy(pos);
    sp.s.visible = true;
    sp.s.scale.setScalar(big ? 0.22 : plasma ? 0.14 : 0.07);
    const f = big ? 3.2 : 1;
    sp.vel.set((Math.random() - 0.5) * 2.4 * f, Math.random() * 2.2 * f, (Math.random() - 0.5) * 2.4 * f);
    sp.life = 0.28 + Math.random() * 0.2;
  }

  spawnPuff(pos) {
    const p = this.puffs[this.puffIdx++ % this.puffs.length];
    p.s.material.color.setHSL(0.08, 0.04, 0.35 + Math.random() * 0.2);
    p.s.position.copy(pos).add(new THREE.Vector3(
      (Math.random() - 0.5) * 0.8, Math.random() * 0.5, (Math.random() - 0.5) * 0.8));
    p.s.visible = true;
    p.s.scale.setScalar(0.5);
    p.vel.set((Math.random() - 0.5) * 1.2, 1 + Math.random(), (Math.random() - 0.5) * 1.2);
    p.life = 0.9; p.max = 0.9;
  }

  /* world-space puff (jetpack air-jump thruster wash) */
  puffAt(pos) {
    const p = this.puffs[this.puffIdx++ % this.puffs.length];
    p.s.material.color.setHSL(0.55, 0.25, 0.55);
    p.s.position.copy(pos).add(new THREE.Vector3(
      (Math.random() - 0.5) * 0.4, -1.3, (Math.random() - 0.5) * 0.4));
    p.s.visible = true;
    p.s.scale.setScalar(0.4);
    p.vel.set((Math.random() - 0.5) * 0.8, -2.4, (Math.random() - 0.5) * 0.8);
    p.life = 0.5; p.max = 0.5;
  }

  spawnTracer(from, to) {
    const t = this.tracers.find((x) => x.life <= 0) || this.tracers[0];
    const len = from.distanceTo(to);
    t.mesh.position.copy(from).add(to).multiplyScalar(0.5);
    t.mesh.lookAt(to);
    t.mesh.scale.set(1, 1, len);
    t.mesh.visible = true;
    t.mesh.material.opacity = 0.75;
    t.life = 0.05;
  }

  /* -- weapon selling (XMB → WEAPONS, X on a card) ------------------------ */
  sellValue(idx) {
    const d = this.guns[idx].def;
    return ASSETS.sell[d.id] || 0;
  }
  sellWeapon(idx, game) {
    const d = this.guns[idx].def;
    if (!this.unlocked.has(d.id)) return false;
    if (d.id === 'pistol') {
      game.hud.toast('THE M6-P NEVER LEAVES YOUR SIDE', 1400);
      game.sfx.energyFail();
      return false;
    }
    const value = this.sellValue(idx);
    if (!value) {
      game.hud.toast('NO BUYER FOR THAT', 1200);
      return false;
    }
    this.unlocked.delete(d.id);
    Mods.add(value);
    game.sfx.scrap();
    game.hud.toast(d.name + ' SOLD · +' + value.toLocaleString('en-US') + ' CR (scavenge its ammo to re-unlock)', 2400);
    if (this.cur === idx) {
      this.cur = this.nextUnlocked(idx);
    }
    return true;
  }

  /* -- shooting ---------------------------------------------------------------- */
  fireOne(game, dirOverride = null) {
    const g = this.gun;
    const d = g.def;
    this.cooldown = 60 / d.rpm;
    this.stats.shots++;
    g.spread = Math.min(d.spreadMax, g.spread + d.spreadPerShot);
    this.kick = d.recoil.kick;
    const rm = this.adsRecoilMult();
    const pl = game.player;
    pl.recoil += d.recoil.pitch * rm;
    pl.recoilYaw += (Math.random() - 0.5) * 2 * d.recoil.yaw * rm;
    pl.recoilRecover = 9;
    game.sfx.shot(d.type === 'semi' ? 0.75 : 1);

    g.flash.visible = true;
    g.flash.rotation.z = Math.random() * Math.PI;
    g.flash.scale.setScalar(0.8 + Math.random() * 0.5);
    this.flashT = 0.045;
    this.flashLight.intensity = 2.4;

    this.camera.updateMatrixWorld(true);
    /* CH-22.2 — THIRD-PERSON FIRE ORIGIN: shots leave the FRAME (chest),
       not the behind-the-shoulder camera — but they still land ON the
       reticle: the aim point comes from the camera-center ray (the
       reticle's own ray) against enemies + solids, then the shot
       direction is origin → aim point. First person is untouched
       (origin = camera, dir = camera forward). Per-shot allocations only
       (fire is not a per-frame path).                                     */
    let origin = this.camera.getWorldPosition(new THREE.Vector3());
    let dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    const ptp = game.player;
    if (ptp.tpOn && ptp.tpBlend > 0.5) {
      const chest = ptp.frameOrigin(new THREE.Vector3());
      const aimRay = new THREE.Raycaster();
      aimRay.far = d.range;
      const aimTargets = [];
      for (const e of game.enemies) if (e.alive) aimTargets.push(e.hitMesh);
      aimTargets.push(...game.world.solids);
      const aimHits = aimRay.intersectObjects(aimTargets, false);
      const aimPoint = aimHits.length
        ? aimHits[0].point.clone()
        : origin.clone().addScaledVector(dir, d.range);
      dir.copy(aimPoint).sub(chest).normalize();
      origin = chest;
    }
    if (dirOverride) dir = dirOverride.clone();
    const right = new THREE.Vector3().crossVectors(dir, this.camera.up).normalize();
    const up = new THREE.Vector3().crossVectors(right, dir).normalize();
    const sm = this.adsSpreadMult();
    const a = Math.random() * Math.PI * 2;
    const r = g.spread * sm * Math.sqrt(Math.random());
    dir = dir.clone().add(right.multiplyScalar(Math.cos(a) * r))
      .add(up.multiplyScalar(Math.sin(a) * r)).normalize();

    // rocket → projectile system (specials.js) — pass the MODDED def so
    // box-break damage and splash scale with power mods
    if (d.projectile === 'rocket') {
      game.specials.fireRocket(g.muzzle.getWorldPosition(new THREE.Vector3()), dir, origin, d);
      return;
    }

    const targets = [];
    for (const e of game.enemies) if (e.alive) targets.push(e.hitMesh);
    targets.push(...game.world.solids);
    const pellets = d.pellets || 1;
    for (let i = 0; i < pellets; i++) {
      let pdir = dir;
      if (i > 0) {
        const a2 = Math.random() * Math.PI * 2;
        const r2 = g.spread * sm * 2.2 * Math.sqrt(Math.random());
        pdir = dir.clone()
          .add(right.clone().multiplyScalar(Math.cos(a2) * r2))
          .add(up.clone().multiplyScalar(Math.sin(a2) * r2)).normalize();
      } else {
        pdir = dir.clone();
      }
      this.ray.set(origin, pdir);
      this.ray.far = d.range;
      const hits = this.ray.intersectObjects(targets, false);

      const muzzleWorld = (ptp && ptp.tpOn && ptp.tpBlend > 0.5 && ptp.tpGunMuzzle)
        ? (ptp.tpGunMuzzle(new THREE.Vector3()) || g.muzzle.getWorldPosition(new THREE.Vector3()))
        : g.muzzle.getWorldPosition(new THREE.Vector3());   /* CH-22HF.2 — tracers leave the BODY gun in 3P */
      if (hits.length) {
        const h = hits[0];
        const enemy = h.object.userData.enemy;
        const brk = h.object.userData.breakable;
        const critter = h.object.userData.critter;
        if (enemy) {
          this.stats.hits++;
          /* CH-25.4 — typed hit through the shared pipeline: the gun def
             carries the physical split + element payload (fractions of
             the moddable damage — power mods keep working) and the
             crit/status stats; crit rolled once per pellet.               */
          applyDamage(enemy, {
            types: typedHit(d),
            crit: rollCrit(d),
            statusChance: d.statusChance || 0,
          }, game, { point: h.point, dir: pdir, kind: 'bullet' });
          game.sfx.hitEnemy();
          game.hud.hitmarker();
          for (let k = 0; k < 4; k++) this.spawnSpark(h.point, true);
        } else if (critter) {
          /* birds / rodents — drop feathers / hide */
          this.stats.hits++;
          if (game.ecology) game.ecology.killCritter(critter, game);
          game.hud.hitmarker();
          for (let k = 0; k < 3; k++) this.spawnSpark(h.point, false);
        } else if (brk) {
          /* CH-06.4 — bullets chip ANY breakable prop (crate/barrel/
             chest): no type gate. The delivered scalar d.damage (already
             mod-multiplied) is the raw total of the typed hit — props
             have no shields/armor pools to mitigate it. A rocket shell
             (breakThreshold) still one-shots everything.                */
          game.world.damageBox(game, brk, d.damage, h.point);
        } else {
          this.impactLight.position.copy(h.point);
          this.impactLight.intensity = 1.4;
          for (let k = 0; k < 3; k++) this.spawnSpark(h.point, false);
        }
        if (pellets <= 2 || i % 3 === 0) this.spawnTracer(muzzleWorld, h.point);
      } else if (pellets <= 2 || i % 3 === 0) {
        this.spawnTracer(muzzleWorld,
          this.ray.ray.origin.clone().addScaledVector(pdir, d.range));
      }
    }
  }

  fire(game) {
    const g = this.gun;
    if (this.stowed) { this.drawWeapon(game); return; }
    if (game.player.invisT > 0) {
      /* firing decloaks you */
      game.player.invisT = 0;
      game.hud.toast('DECLOAKED', 800);
    }
    if (g.mag <= 0) { game.sfx.dry(); this.cooldown = 0.3; return; }
    g.mag--;
    this.fireOne(game);
    g.drawLed();
  }

  /* -- ADS / zoom ---------------------------------------------------------------- */
  toggleZoom(game) {
    this.zoomed = !this.zoomed;
    if (this.zoomed) game.sfx.zoomIn(); else game.sfx.zoomOut();
    game.targetFov = this.zoomed ? this.def.ads.fov : ASSETS.quality.fov;
    const sc = this.def.ads.scope;
    game.hud.setScope(this.zoomed && sc ? sc : null);
  }
  closeZoom(game) {
    if (!this.zoomed) return;
    this.zoomed = false;
    game.targetFov = ASSETS.quality.fov;
    game.hud.setScope(null);
  }

  /* -- weapon switching ------------------------------------------------------------ */
  selectWeapon(idx, game) {
    if (idx === this.cur || idx < 0 || idx >= this.guns.length) return;
    if (this.swapT >= 0 || this.meleeT >= 0) return;
    if (!this.unlocked.has(this.guns[idx].def.id)) {
      if (game) {
        game.sfx.dry();
        game.hud.toast(this.guns[idx].def.name + ' LOCKED — SCAVENGE ' +
          ASSETS.ammoPools[this.guns[idx].def.ammo].label + ' TO UNLOCK', 1800);
      }
      return;
    }
    this._pendingIdx = idx;
    this.startSwap(game);
  }

  startSwap(game) {
    if (this.swapT >= 0 || this.meleeT >= 0) return;
    this.swapT = 0;
    this._pendingIdx = this._pendingIdx != null
      ? this._pendingIdx
      : this.nextUnlocked(this.cur);
    this.guns[this.cur].reloadT = -1;
    this.closeZoom(game);
    game.sfx.swap();
  }

  /* -- melee (rifle bash · NIKANA iai draw) -------------------------------- */
  startMelee(game) {
    if (this.meleeCd > 0 || this.meleeT >= 0) return;
    this.meleeKind = this.nikana ? 'iai' : 'bash';
    this.meleeT = 0;
    this.meleeHitDone = false;
    this.meleeCd = this.nikana ? NIK.cooldown : MELEE.cooldown;
    if (this.nikana) {
      /* iai lunge toward the aim direction */
      const f = game.player.forward();
      game.player.vel.x += f.x * NIK.lunge;
      game.player.vel.z += f.z * NIK.lunge;
      if (game.player.invisT > 0) { game.player.invisT = 0; game.hud.toast('DECLOAKED', 800); }
    }
    game.sfx.meleeWhoosh();
  }

  doMeleeHit(game) {
    const p = game.player;
    const fwd = p.forward();
    const iai = this.meleeKind === 'iai';
    const range = iai ? NIK.range : MELEE.range;
    const arc = iai ? NIK.arc : 0.5;          // bash = narrow, iai = wide cone
    const dmg = iai ? NIK.damage : MELEE.damage;
    for (const e of game.enemies) {
      if (!e.alive) continue;
      const to = new THREE.Vector3().subVectors(e.group.position, p.pos);
      const dy = Math.abs(to.y);
      to.y = 0;
      const d = to.length();
      if (d < range && dy < 2.4 && to.normalize().dot(fwd) > Math.cos(arc / 2)) {
        /* CH-25.4 — melee rides the shared pipeline too (bash = impact
           profile, nikana = slash profile — both typed in assets).        */
        const mdef = iai ? NIK : MELEE;
        applyDamage(e, {
          types: typedHit(mdef, dmg),
          crit: rollCrit(mdef),
          statusChance: mdef.statusChance || 0,
        }, game, { point: e.group.position, kind: 'melee' });
        game.sfx.meleeHit();
        game.hud.hitmarker();
        this.stats.hits++;
        this.spawnSpark(e.group.position.clone().add(new THREE.Vector3(0, 0.9, 0)), 'energy', true);
      }
    }
    /* CH-06.4 — melee is a damage type too: physical swings chip the
       same prop pools bullets chip ("physical splits and elements
       alike" — no type gate on containers). The swing keeps its own
       enemy sweep; props just take the raw melee scalar.                 */
    const cosA = Math.cos(arc / 2);
    for (const b of game.world.breakables) {
      if (b.dead) continue;
      const to = new THREE.Vector3().subVectors(b.mesh.position, p.pos);
      const dy = Math.abs(to.y);
      to.y = 0;
      const d = to.length();
      if (d < range + 0.55 && dy < 2.4 && to.normalize().dot(fwd) > cosA) {
        game.world.damageBox(game, b, dmg, b.mesh.position.clone());
        game.sfx.meleeHit();
        this.spawnSpark(b.mesh.position.clone().add(new THREE.Vector3(0, 0.6, 0)), false);
      }
    }
  }

  /* -- reload --------------------------------------------------------------------------- */
  startReload(game) {
    const g = this.gun;
    const pool = this.gameAmmo();
    if (g.reloadT >= 0 || g.mag >= g.def.mag || pool[g.def.ammo] <= 0) return;
    g.reloadT = 0;
    game.sfx.reload(g.def.reloadTime);
  }

  /* -- main update ------------------------------------------------------------------------ */
  update(dt, input, game) {
    this.game = game;
    this.cooldown -= dt;
    this.meleeCd -= dt;
    const g = this.gun;
    const d = g.def;
    g.spread = Math.max(d.spreadBase,
      g.spread - (d.spreadMax - d.spreadBase) * dt * 2.5);

    // ADS blend
    this.adsT = Math.max(0, Math.min(1, this.adsT + (this.zoomed ? 1 : -1) * dt * 9));

    // reload timeline (pull from shared pool)
    if (g.reloadT >= 0) {
      g.reloadT += dt;
      if (g.reloadT >= d.reloadTime) {
        const pool = this.gameAmmo();
        const need = d.mag - g.mag;
        const take = Math.min(need, pool[d.ammo]);
        g.mag += take; pool[d.ammo] -= take;
        g.reloadT = -1;
        g.drawLed();
      }
    }

    // swap timeline
    if (this.swapT >= 0) {
      this.swapT += dt;
      if (this.swapT >= SWAP_TIME / 2 && this.swapT - dt < SWAP_TIME / 2) {
        this.guns[this.cur].group.visible = false;
        this.cur = this._pendingIdx != null ? this._pendingIdx : (this.cur + 1) % this.guns.length;
        this._pendingIdx = null;
        this.guns[this.cur].group.visible = true;
      }
      if (this.swapT >= SWAP_TIME) this.swapT = -1;
    }

    // melee timeline (rifle bash · nikana iai — each with its own timing)
    if (this.meleeT >= 0) {
      const mDur = this.meleeKind === 'iai' ? NIK.dur : MELEE_DUR;
      const mHit = this.meleeKind === 'iai' ? NIK.hitAt : MELEE_HIT_AT;
      this.meleeT += dt;
      if (!this.meleeHitDone && this.meleeT >= mHit) {
        this.meleeHitDone = true;
        this.doMeleeHit(game);
      }
      if (this.meleeT >= mDur) { this.meleeT = -1; this.meleeKind = 'bash'; }
    }

    // triggers — VATS owns R1 while active (hover missiles)
    const busy = g.reloadT >= 0 || this.meleeT >= 0 || this.swapT >= 0;
    const wantFire = d.type === 'auto' ? input.down('fire') : input.pressed('fire');
    if (wantFire && !busy && this.cooldown <= 0 && !game.player.dead && !game.player.vatsActive) {
      this.fire(game);
    }
    if (input.pressed('stow') && !busy && !game.player.dead) this.toggleStow(game);
    // CH-01.1 — controller X (btn 2) is CONTEXT-first: harvest node / fish
    // zone / locker in reach → interact and EAT the press so reload never
    // double-fires; nothing in reach → X still reloads. Keyboard R·X and
    // D-pad↓ are untouched (their 'reload' / 'interact' bindings stay).
    let padXInteract = false;
    if (input.padBtnPressed(2) && !game.player.dead) {
      const ctx = game.ecology && game.ecology.interactContext
        ? game.ecology.interactContext(game.player.pos) : null;
      if (ctx) {
        input.consumePadBtn(2);
        game.ecology.interact(game);
        padXInteract = true;
      }
    }
    if (input.pressed('reload') && !padXInteract && !busy && !this.stowed &&
        !game.player.dead) this.startReload(game);
    if (input.pressed('melee') && !busy && !game.player.dead) this.startMelee(game);
    if (input.pressed('swap') && !game.player.dead && !game.player.vatsActive && !this.stowed) this.startSwap(game);
    if (input.pressed('ads') && !busy && !this.stowed && !game.player.dead && !game.player.vatsActive) this.toggleZoom(game);

    // direct weapon hotkeys 1-5 (locked guns are skipped)
    for (let i = 0; i < ASSETS.controls.weaponKeys.length; i++) {
      if (input.keys.has(ASSETS.controls.weaponKeys[i])) {
        if (this.cur !== i) this.selectWeapon(i, game);
        break;
      }
    }

    // muzzle flash lifetime
    if (this.flashT > 0) {
      this.flashT -= dt;
      if (this.flashT <= 0) g.flash.visible = false;
    }
    this.flashLight.intensity *= Math.exp(-30 * dt);
    this.impactLight.intensity *= Math.exp(-16 * dt);

    // fx pools
    for (const t of this.tracers) {
      if (t.life > 0) {
        t.life -= dt;
        t.mesh.material.opacity = Math.max(0, t.life / 0.05) * 0.75;
        if (t.life <= 0) t.mesh.visible = false;
      }
    }
    for (const s of this.sparks) {
      if (s.life > 0) {
        s.life -= dt;
        s.vel.y -= 6 * dt;
        s.s.position.addScaledVector(s.vel, dt);
        if (s.life <= 0) s.s.visible = false;
      }
    }
    for (const p of this.puffs) {
      if (p.life > 0) {
        p.life -= dt;
        p.s.position.addScaledVector(p.vel, dt);
        p.s.scale.setScalar(0.5 + (1 - p.life / p.max) * 1.4);
        p.s.material.opacity = Math.max(0, p.life / p.max) * 0.55;
        if (p.life <= 0) p.s.visible = false;
      }
    }

    // viewmodel animation (active gun only) — hip pose → ADS pose blend
    const pl = game.player;
    const b = this.adsT;
    let hx = d.vmPos[0] + Math.cos(pl.bobT * 0.5) * 0.006;
    let hy = d.vmPos[1] + Math.sin(pl.bobT) * 0.009 - this.kick * 0.15;
    let hz = d.vmPos[2] + this.kick;
    let ax = d.vmPos[0], ay = d.vmPos[1], az = d.vmPos[2], ary = -0.045;
    if (d.ads.scope) {           // scoped guns: smart-link raise
      ax *= 0.4; ay += 0.06; az += 0.05; ary = 0;
    } else if (d.ads.vmPos) {    // ironsights: centered pose
      ax = d.ads.vmPos[0]; ay = d.ads.vmPos[1]; az = d.ads.vmPos[2]; ary = 0;
    }
    /* CH-22.3 — third-person ADS: the viewmodel eases to the LOWER-LEFT
       (f3 reference spec — character framed in the left third, weapon
       visible lower-left); hip pose in third person is untouched.        */
    if (game.player.tpBlend > 0.02 && b > 0) {
      ax += (-0.3 - ax) * b;
      ay += (-0.34 - ay) * b;
      az += (-0.46 - az) * b;
      ary += (0.34 - ary) * b;   // muzzle angled toward the aim line
    }
    let rx = 0, ry = ary;
    let px = hx + (ax - hx) * b;
    let py = hy + (ay - hy) * b;
    let pz = hz + (az - hz) * b;
    ry = -0.045 + (ary - -0.045) * b;

    if (g.reloadT >= 0) {
      const k = Math.sin(Math.PI * Math.min(1, g.reloadT / d.reloadTime));
      const kk = 1 - b * 0.6;
      py -= k * 0.13 * kk; rx -= k * 0.7 * kk;
    }
    if (this.meleeT >= 0) {
      const k = Math.sin(Math.PI * Math.min(1, this.meleeT / MELEE_DUR));
      pz -= k * 0.28; rx -= k * 0.35; ry += k * 0.5;
    }
    if (this.swapT >= 0) {
      py -= Math.sin(Math.PI * Math.min(1, this.swapT / SWAP_TIME)) * 0.25;
      rx -= Math.sin(Math.PI * Math.min(1, this.swapT / SWAP_TIME)) * 0.4;
    }
    g.group.position.set(px, py, pz);
    g.group.rotation.set(rx, ry, 0);
    this.kick *= Math.exp(-14 * dt);

    /* -- viewmodel visibility + nikana iai draw-slash ---------------------- */
    /* CH-22HF.2 — the camera viewmodel is a FIRST-PERSON surface: in full
       third person the body carries its own gun (player.js buildBody), so a
       camera-pinned gun here read as "a weapon detached from the character". */
    const vmHidden3P = game.player && game.player.tpBlend > 0.5;
    this.guns.forEach((gg, i) => {
      gg.group.visible = i === this.cur && !this.stowed && !vmHidden3P;
    });
    if (this.nikana && this.meleeT >= 0 && this.meleeKind === 'iai') {
      const k = Math.min(1, this.meleeT / NIK.dur);
      const e = 1 - Math.pow(1 - k, 2.2);          // fast draw-out, soft land
      this.nikanaVM.visible = true;
      this.nikanaVM.position.set(
        -0.3 + e * 0.68, -0.44 + e * 0.28, -0.26 - Math.sin(k * Math.PI) * 0.08);
      this.nikanaVM.rotation.set(0.1 - e * 0.55, 0.62 - e * 1.82, 1.15 - e * 2.65);
    } else if (this.nikana && !this.stowed) {
      /* sheathed at the hip, hugging the frame edge */
      this.nikanaVM.visible = true;
      this.nikanaVM.position.set(-0.3, -0.44, -0.26);
      this.nikanaVM.rotation.set(0.1, 0.62, 1.15);
    } else {
      this.nikanaVM.visible = false;
    }
    if (vmHidden3P) this.nikanaVM.visible = false;   /* CH-22HF.2 — 3P: the frame carries its own blade */

    // LED refresh (active gun, only on change + blink while low)
    const key = g.mag + (g.reloadT >= 0 ? 'r' : '');
    if (key !== g.ledState || (g.mag <= Math.ceil(d.mag * 0.2) && Math.floor(performance.now() / 280) % 2)) {
      g.ledState = key;
      g.drawLed();
    }

    // reload prompt
    const pool = this.gameAmmo();
    if (this.stowed) game.hud.setPrompt('WEAPON STOWED — PRESS FIRE OR H TO DRAW');
    else if (g.mag === 0 && g.reloadT < 0 && pool[d.ammo] > 0) game.hud.setPrompt('PRESS R TO RELOAD');
    else if (g.mag === 0 && pool[d.ammo] === 0) game.hud.setPrompt('NO ' + ASSETS.ammoPools[d.ammo].label + ' — FIND AMMO');
    else game.hud.setPrompt('');
  }

  /* -- run reset ---------------------------------------------------------------------------- */
  resetAll() {
    for (const g of this.guns) {
      g.mag = g.def.mag;
      g.reloadT = -1;
      g.spread = g.def.spreadBase;
      g.drawLed();
    }
    this.unlocked = new Set([ASSETS.startWeapon || 'pistol']);
    this.cur = Math.max(0, this.guns.findIndex((g) => g.def.id === (ASSETS.startWeapon || 'pistol')));
    this._pendingIdx = null;
    this.zoomed = false;
    this.adsT = 0;
    this.swapT = -1;
    this.meleeT = -1;
    this.meleeKind = 'bash';
    this.stowed = false;
    this.cooldown = 0;
    this.meleeCd = 0;
    this.kick = 0;
    this.flashT = 0;
    this.nikanaVM.visible = false;
    this.stats = { shots: 0, hits: 0, kills: 0 };
  }
}

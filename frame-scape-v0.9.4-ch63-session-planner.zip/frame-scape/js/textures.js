/* ============================================================================
   AUTUMN CORRIDOR — textures.js
   ----------------------------------------------------------------------------
   All textures are drawn procedurally on <canvas> at startup.
   Zero image files = tiny download, and every look is editable via
   js/assets.js (palette). If you later want real image textures,
   replace a maker here with a TextureLoader.load(...) call.
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js?v=0.9.4e';

const P = ASSETS.palette;

/* -- tiny helpers --------------------------------------------------------- */
function cv(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return [c, c.getContext('2d')];
}

function toTexture(canvas, { repeat = null, srgb = true } = {}) {
  const t = new THREE.CanvasTexture(canvas);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 1; // cheap on old GPUs
  if (repeat) {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(repeat[0], repeat[1]);
  }
  return t;
}

/* low-alpha random scuffs so flat colors don't look sterile */
function scuff(ctx, w, h, n, alphaMax = 0.05, dark = true) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * alphaMax;
    ctx.fillStyle = dark ? `rgba(0,0,0,${a})` : `rgba(255,255,255,${a})`;
    ctx.fillRect(Math.random() * w, Math.random() * h,
                 1 + Math.random() * 14, 1 + Math.random() * 3);
  }
}

function rivet(ctx, x, y, r = 3) {
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.25)';
  ctx.beginPath(); ctx.arc(x - 1, y - 1, r * 0.5, 0, 7); ctx.fill();
}

/* -- WALL: big panels + dark skirt + bevel shading + rivets ---------------- */
export function texWall() {
  const [c, x] = cv(512, 512);
  x.fillStyle = P.wallA; x.fillRect(0, 0, 512, 512);
  // darker lower skirt
  x.fillStyle = P.wallB; x.fillRect(0, 340, 512, 172);
  x.fillStyle = 'rgba(0,0,0,0.25)'; x.fillRect(0, 336, 512, 6);
  // vertical panel seams
  x.strokeStyle = 'rgba(0,0,0,0.30)'; x.lineWidth = 3;
  for (const vx of [0, 128, 256, 384, 512]) {
    x.beginPath(); x.moveTo(vx, 0); x.lineTo(vx, 512); x.stroke();
  }
  // horizontal seams
  for (const hy of [170, 340]) {
    x.beginPath(); x.moveTo(0, hy); x.lineTo(512, hy); x.stroke();
  }
  // inset rectangles with bevel (dark bottom/right, light top/left = depth)
  for (const ix of [20, 148, 276, 404]) {
    x.fillStyle = 'rgba(0,0,0,0.13)';
    x.fillRect(ix, 24, 88, 120);
    x.fillStyle = 'rgba(0,0,0,0.30)';
    x.fillRect(ix, 138, 88, 6); x.fillRect(ix + 82, 24, 6, 120);
    x.fillStyle = 'rgba(255,255,255,0.22)';
    x.fillRect(ix, 24, 88, 3); x.fillRect(ix, 24, 3, 120);
  }
  // rivets along skirt
  for (let i = 8; i < 512; i += 48) rivet(x, i, 352);
  scuff(x, 512, 512, 260);
  return toTexture(c);
}

/* -- FLOOR: bright plates with beveled grid + wear -------------------------- */
export function texFloor() {
  const [c, x] = cv(512, 512);
  x.fillStyle = P.floor; x.fillRect(0, 0, 512, 512);
  // major plates: bevel shading so the grid reads as raised metal
  for (const gx of [0, 256]) for (const gy of [0, 256]) {
    x.fillStyle = 'rgba(255,255,255,0.10)';
    x.fillRect(gx + 4, gy + 4, 248, 4); x.fillRect(gx + 4, gy + 4, 4, 248);
    x.fillStyle = 'rgba(0,0,0,0.22)';
    x.fillRect(gx + 4, gy + 248, 248, 4); x.fillRect(gx + 248, gy + 4, 4, 248);
  }
  x.strokeStyle = P.floorLine; x.lineWidth = 5;
  for (const g of [0, 256, 512]) {
    x.beginPath(); x.moveTo(g, 0); x.lineTo(g, 512); x.stroke();
    x.beginPath(); x.moveTo(0, g); x.lineTo(512, g); x.stroke();
  }
  x.strokeStyle = 'rgba(0,0,0,0.16)'; x.lineWidth = 2;
  for (const g of [128, 384]) {
    x.beginPath(); x.moveTo(g, 0); x.lineTo(g, 512); x.stroke();
    x.beginPath(); x.moveTo(0, g); x.lineTo(512, g); x.stroke();
  }
  // wear: darker traffic patches
  for (let i = 0; i < 14; i++) {
    x.fillStyle = `rgba(0,0,0,${0.04 + Math.random() * 0.06})`;
    x.beginPath();
    x.ellipse(Math.random() * 512, Math.random() * 512,
              20 + Math.random() * 60, 12 + Math.random() * 30,
              Math.random() * 3, 0, 7);
    x.fill();
  }
  scuff(x, 512, 512, 300);
  return toTexture(c, { repeat: [2, 1] });
}

/* -- CEILING: plain panels -------------------------------------------------- */
export function texCeiling() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.ceiling; x.fillRect(0, 0, 256, 256);
  x.strokeStyle = 'rgba(0,0,0,0.28)'; x.lineWidth = 3;
  x.strokeRect(2, 2, 252, 252);
  x.beginPath(); x.moveTo(128, 0); x.lineTo(128, 256); x.stroke();
  rivet(x, 14, 14); rivet(x, 242, 14); rivet(x, 14, 242); rivet(x, 242, 242);
  scuff(x, 256, 256, 80);
  return toTexture(c);
}

/* -- HAZARD: yellow/black diagonal stripes ---------------------------------- */
export function texHazard() {
  const [c, x] = cv(256, 128);
  x.fillStyle = P.hazardB; x.fillRect(0, 0, 256, 128);
  x.fillStyle = P.hazardY;
  x.save();
  x.translate(-64, 0);
  for (let i = 0; i < 12; i++) {
    x.beginPath();
    x.moveTo(i * 48, 0);
    x.lineTo(i * 48 + 24, 0);
    x.lineTo(i * 48 + 24 - 64, 128);
    x.lineTo(i * 48 - 64, 128);
    x.closePath(); x.fill();
  }
  x.restore();
  // grime so it reads as painted metal, not clipart
  scuff(x, 256, 128, 160, 0.12);
  return toTexture(c, { repeat: [3, 1] });
}

/* -- CRATE: olive box with stencil + frame ---------------------------------- */
export function texCrate() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.crate; x.fillRect(0, 0, 256, 256);
  x.fillStyle = P.crateDark;
  x.fillRect(0, 0, 256, 22); x.fillRect(0, 234, 256, 22);
  x.fillRect(0, 0, 22, 256); x.fillRect(234, 0, 22, 256);
  x.strokeStyle = 'rgba(0,0,0,0.35)'; x.lineWidth = 3;
  x.strokeRect(26, 26, 204, 204);
  // stencil label
  x.fillStyle = P.stencil;
  x.font = '700 44px Consolas, monospace';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText('A-7', 128, 108);
  x.font = '700 20px Consolas, monospace';
  x.fillText('MUNITIONS', 128, 150);
  for (const [rx, ry] of [[40, 40], [216, 40], [40, 216], [216, 216]]) rivet(x, rx, ry, 4);
  scuff(x, 256, 256, 200, 0.09);
  return toTexture(c);
}

/* -- CH-06.1 WOOD BARREL: vertical staves + two iron hoops ------------------
   Reads as a chippable splinter barrel at PS2-era distances (the hoops and
   the seam shadow do the work — no per-stave geometry).                    */
export function texBarrelWood() {
  const [c, x] = cv(256, 256);
  for (let i = 0; i < 8; i++) {
    x.fillStyle = i % 2 ? P.barrelWood : P.barrelWoodDk;
    x.fillRect(i * 32, 0, 32, 256);
    x.fillStyle = 'rgba(0,0,0,0.25)';
    x.fillRect(i * 32, 0, 2, 256);
    x.fillStyle = `rgba(255,255,255,${0.03 + Math.random() * 0.04})`;
    x.fillRect(i * 32 + 6 + Math.random() * 18, 0, 1 + Math.random() * 2, 256);
  }
  // iron hoops (top / bottom + the mid bulge seam)
  x.fillStyle = 'rgba(30,32,36,0.92)';
  x.fillRect(0, 26, 256, 18); x.fillRect(0, 212, 256, 18);
  x.fillStyle = 'rgba(255,255,255,0.10)';
  x.fillRect(0, 26, 256, 3); x.fillRect(0, 212, 256, 3);
  x.fillStyle = 'rgba(0,0,0,0.35)'; x.fillRect(0, 124, 256, 6);
  // stencil
  x.fillStyle = P.stencil;
  x.font = '700 26px Consolas, monospace';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText('W-12', 128, 96);
  scuff(x, 256, 256, 220, 0.14);
  return toTexture(c);
}

/* -- CH-06.1 METAL DRUM: ribbed hazard drum with a stencil band ------------- */
export function texBarrelMetal() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.barrelMetal; x.fillRect(0, 0, 256, 256);
  // horizontal rolling ribs (3) — bright top edge + dark shadow
  for (const ry of [58, 122, 186]) {
    x.fillStyle = 'rgba(0,0,0,0.38)'; x.fillRect(0, ry + 8, 256, 10);
    x.fillStyle = 'rgba(255,255,255,0.13)'; x.fillRect(0, ry, 256, 8);
  }
  // rust streaks + grime so it reads as a beat-up supply drum
  for (let i = 0; i < 14; i++) {
    x.fillStyle = `rgba(60,34,24,${0.10 + Math.random() * 0.16})`;
    x.fillRect(Math.random() * 256, Math.random() * 256, 2 + Math.random() * 5, 12 + Math.random() * 30);
  }
  // stencil band
  x.fillStyle = 'rgba(20,22,26,0.75)'; x.fillRect(0, 78, 256, 34);
  x.fillStyle = P.hazardY;
  x.font = '700 22px Consolas, monospace';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText('CHEM-42 · FLAMMABLE', 128, 95);
  for (const [rx, ry] of [[24, 30], [232, 30], [24, 226], [232, 226]]) rivet(x, rx, ry, 3);
  scuff(x, 256, 256, 240, 0.12);
  return toTexture(c);
}

/* -- CH-06.2 SUPPLY CHEST: painted lid seam + cross braces + lock plate -----
   The lid/lock are PAINTED on the box faces (house PS2 style — texCrate
   does the same) so a chest is ONE mesh / ONE draw call and the breakable
   record stays as simple as a crate's.                                     */
export function texChest() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.chest; x.fillRect(0, 0, 256, 256);
  // lid seam + rounded lid shade
  x.fillStyle = P.chestDk; x.fillRect(0, 0, 256, 74);
  x.fillStyle = 'rgba(255,255,255,0.09)'; x.fillRect(0, 0, 256, 12);
  x.fillStyle = 'rgba(0,0,0,0.55)'; x.fillRect(0, 70, 256, 7);
  // cross braces
  x.strokeStyle = 'rgba(0,0,0,0.4)'; x.lineWidth = 14;
  x.beginPath(); x.moveTo(18, 84); x.lineTo(238, 244); x.stroke();
  x.beginPath(); x.moveTo(238, 84); x.lineTo(18, 244); x.stroke();
  // lock plate on the seam
  x.fillStyle = P.chestDk; x.fillRect(104, 52, 48, 46);
  x.fillStyle = P.hazardY; x.fillRect(116, 64, 24, 20);
  x.fillStyle = 'rgba(0,0,0,0.6)'; x.fillRect(124, 70, 8, 8);
  // stencil
  x.fillStyle = P.stencil;
  x.font = '700 20px Consolas, monospace';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText('SUPPLY', 128, 36);
  for (const [rx, ry] of [[26, 26], [230, 26], [26, 230], [230, 230]]) rivet(x, rx, ry, 4);
  scuff(x, 256, 256, 230, 0.11);
  return toTexture(c);
}

/* -- CH-05.1 SUPPLY LOCKER BODY: dark gunmetal panels + rivets + grime -------
   (the door face is its own texture — texLockerDoor — so the front reads
   as a distinct, openable panel at PS2-era draw distances)                 */
export function texLocker() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.gunDark; x.fillRect(0, 0, 256, 256);
  // brushed vertical grain
  for (let i = 0; i < 40; i++) {
    x.fillStyle = `rgba(255,255,255,${0.02 + Math.random() * 0.03})`;
    x.fillRect(Math.random() * 256, 0, 1 + Math.random() * 2, 256);
  }
  // top + bottom frame bands
  x.fillStyle = 'rgba(0,0,0,0.4)';
  x.fillRect(0, 0, 256, 26); x.fillRect(0, 230, 256, 26);
  x.fillStyle = 'rgba(255,255,255,0.08)';
  x.fillRect(0, 26, 256, 3);
  // side stiles
  x.fillStyle = 'rgba(0,0,0,0.3)';
  x.fillRect(0, 0, 14, 256); x.fillRect(242, 0, 14, 256);
  for (const [rx, ry] of [[22, 36], [234, 36], [22, 220], [234, 220]]) rivet(x, rx, ry, 3);
  // stencil code on the side panel
  x.fillStyle = 'rgba(232,240,248,0.4)';
  x.font = '700 18px Consolas, monospace';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText('LK-07', 128, 243);
  scuff(x, 256, 256, 240, 0.12);
  return toTexture(c);
}

/* -- CH-05.1 LOCKER DOOR FACE: vent slits + hazard chevrons + stencil -------
   "SUPPLY 07" + a warning stripe so the beast-openable lockers read at a
   glance from the corridor/hangar/valley/city placements.                  */
export function texLockerDoor() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.crate; x.fillRect(0, 0, 256, 256);
  x.fillStyle = P.crateDark;
  x.fillRect(0, 0, 256, 20); x.fillRect(0, 236, 256, 20);
  x.fillRect(0, 0, 18, 256); x.fillRect(238, 0, 18, 256);
  // vent slits (top third)
  for (let i = 0; i < 5; i++) {
    const y = 40 + i * 14;
    x.fillStyle = 'rgba(0,0,0,0.55)'; x.fillRect(56, y, 144, 7);
    x.fillStyle = 'rgba(255,255,255,0.10)'; x.fillRect(56, y + 7, 144, 2);
  }
  // hazard chevron band (bottom quarter)
  x.save();
  x.beginPath(); x.rect(18, 182, 220, 44); x.clip();
  for (let i = -4; i < 14; i++) {
    x.fillStyle = i % 2 ? 'rgba(0,0,0,0.55)' : 'rgba(255,180,60,0.85)';
    x.beginPath();
    x.moveTo(i * 20, 226); x.lineTo(i * 20 + 20, 182);
    x.lineTo(i * 20 + 40, 182); x.lineTo(i * 20 + 20, 226);
    x.closePath(); x.fill();
  }
  x.restore();
  // stencil label + handle recess
  x.fillStyle = P.stencil;
  x.font = '700 30px Consolas, monospace';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText('SUPPLY 07', 128, 148);
  x.font = '700 15px Consolas, monospace';
  x.fillStyle = 'rgba(232,240,248,0.5)';
  x.fillText('BEAST RETRIEVAL ONLY', 128, 172);
  x.fillStyle = 'rgba(0,0,0,0.5)';
  x.fillRect(108, 104, 40, 8);
  for (const [rx, ry] of [[30, 30], [226, 30], [30, 226], [226, 226]]) rivet(x, rx, ry, 4);
  scuff(x, 256, 256, 210, 0.1);
  return toTexture(c);
}

/* -- SIGN: dark plate, cyan text (AIRLOCK →, SECTION 7-A ...) --------------- */
export function texSign(text) {
  const [c, x] = cv(512, 128);
  x.fillStyle = '#101418'; x.fillRect(0, 0, 512, 128);
  x.strokeStyle = P.stripGlow; x.lineWidth = 4;
  x.strokeRect(6, 6, 500, 116);
  x.fillStyle = P.stripGlow;
  x.font = '700 56px Consolas, monospace';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText(text, 256, 68);
  scuff(x, 512, 128, 60, 0.10);
  return toTexture(c);
}

/* -- BLOB SHADOW: soft radial dark ellipse (fake ground shadow) -------------- */
/* CH-44HF.2 — CACHED: every enemy spawn used to bake a fresh 128² canvas +
   upload a fresh GPU texture; the blob is identical for all, so bake ONCE */
let _blobTex = null;
export function texBlob() {
  if (_blobTex) return _blobTex;
  const [c, x] = cv(128, 128);
  const g = x.createRadialGradient(64, 64, 8, 64, 64, 62);
  g.addColorStop(0, 'rgba(0,0,0,0.55)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  _blobTex = toTexture(c, { srgb: false });
  return _blobTex;
}

/* -- GLOW SPRITE: additive halo for plasma / muzzle / sparks ----------------- */
export function texGlow(color = '#ffffff') {
  const [c, x] = cv(128, 128);
  const g = x.createRadialGradient(64, 64, 2, 64, 64, 62);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.25, color);
  g.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  return toTexture(c, { srgb: false });
}

/* -- HANGAR WALL: huge panels, big seams, service stripe --------------------- */
export function texHangarWall() {
  const [c, x] = cv(512, 512);
  x.fillStyle = P.hWall; x.fillRect(0, 0, 512, 512);
  x.fillStyle = P.hWallDark; x.fillRect(0, 380, 512, 132);
  x.fillStyle = 'rgba(0,0,0,0.3)'; x.fillRect(0, 374, 512, 8);
  // big vertical seams
  x.strokeStyle = 'rgba(0,0,0,0.34)'; x.lineWidth = 5;
  for (const vx of [0, 170, 340, 512]) {
    x.beginPath(); x.moveTo(vx, 0); x.lineTo(vx, 512); x.stroke();
  }
  // deep inset panels
  for (const ix of [28, 198, 368]) {
    x.fillStyle = 'rgba(0,0,0,0.15)';
    x.fillRect(ix, 30, 130, 300);
    x.fillStyle = 'rgba(0,0,0,0.3)';
    x.fillRect(ix, 322, 130, 8); x.fillRect(ix + 122, 30, 8, 300);
    x.fillStyle = 'rgba(255,255,255,0.14)';
    x.fillRect(ix, 30, 130, 4); x.fillRect(ix, 30, 4, 300);
  }
  // service stripe + stencil
  x.fillStyle = P.hazardY; x.fillRect(0, 470, 512, 14);
  x.fillStyle = 'rgba(0,0,0,0.55)';
  for (let i = 0; i < 512; i += 96) x.fillRect(i, 470, 34, 14);
  x.fillStyle = 'rgba(220,230,240,0.5)';
  x.font = '700 34px Consolas, monospace';
  x.fillText('BAY 7 · STRUCTURAL', 36, 352);
  for (let i = 10; i < 512; i += 64) rivet(x, i, 386, 3);
  scuff(x, 512, 512, 340, 0.09);
  return toTexture(c);
}

/* -- HANGAR FLOOR: worn deck plates + traffic lanes --------------------------- */
export function texHangarFloor() {
  const [c, x] = cv(512, 512);
  x.fillStyle = P.hFloor; x.fillRect(0, 0, 512, 512);
  for (const gx of [0, 256]) for (const gy of [0, 256]) {
    x.fillStyle = 'rgba(255,255,255,0.06)';
    x.fillRect(gx + 4, gy + 4, 248, 4); x.fillRect(gx + 4, gy + 4, 4, 248);
    x.fillStyle = 'rgba(0,0,0,0.26)';
    x.fillRect(gx + 4, gy + 248, 248, 4); x.fillRect(gx + 248, gy + 4, 4, 248);
  }
  x.strokeStyle = 'rgba(0,0,0,0.4)'; x.lineWidth = 6;
  for (const g of [0, 256, 512]) {
    x.beginPath(); x.moveTo(g, 0); x.lineTo(g, 512); x.stroke();
    x.beginPath(); x.moveTo(0, g); x.lineTo(512, g); x.stroke();
  }
  // faded landing circle
  x.strokeStyle = 'rgba(216,180,60,0.4)'; x.lineWidth = 10;
  x.beginPath(); x.arc(256, 256, 150, 0, 7); x.stroke();
  x.lineWidth = 5;
  x.beginPath(); x.arc(256, 256, 110, 0, 7); x.stroke();
  scuff(x, 512, 512, 380, 0.1);
  return toTexture(c, { repeat: [6, 8] });
}

/* -- GRATE: catwalk deck (see-through-ish look via dark holes) ----------------- */
export function texGrate() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.grate; x.fillRect(0, 0, 256, 256);
  x.fillStyle = 'rgba(0,0,0,0.78)';
  for (let gy = 8; gy < 256; gy += 32) {
    for (let gx = 8; gx < 256; gx += 32) {
      x.fillRect(gx, gy, 18, 18);
    }
  }
  x.strokeStyle = 'rgba(255,255,255,0.12)'; x.lineWidth = 2;
  for (let g = 0; g <= 256; g += 32) {
    x.beginPath(); x.moveTo(g, 0); x.lineTo(g, 256); x.stroke();
    x.beginPath(); x.moveTo(0, g); x.lineTo(256, g); x.stroke();
  }
  // hazard nosing on one edge
  x.fillStyle = P.hazardY; x.fillRect(0, 0, 256, 10);
  x.fillStyle = P.hazardB;
  for (let i = 0; i < 256; i += 32) x.fillRect(i, 0, 16, 10);
  scuff(x, 256, 256, 160, 0.12);
  return toTexture(c, { repeat: [3, 1] });
}

/* -- CHEVRON: amber warning chevrons for the big exit door --------------------- */
export function texChevron() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.exitDoor; x.fillRect(0, 0, 256, 256);
  x.fillStyle = 'rgba(0,0,0,0.3)';
  for (let i = 0; i < 256; i += 64) x.fillRect(i, 0, 4, 256);
  x.fillStyle = P.hazardY;
  for (let i = -2; i < 6; i++) {
    x.beginPath();
    x.moveTo(i * 48, 256);
    x.lineTo(i * 48 + 24, 256);
    x.lineTo(i * 48 + 24 + 60, 128);
    x.lineTo(i * 48 + 60, 128);
    x.closePath(); x.fill();
  }
  x.fillStyle = 'rgba(0,0,0,0.35)';
  x.font = '700 30px Consolas, monospace';
  x.textAlign = 'center';
  x.fillText('EXIT', 128, 60);
  scuff(x, 256, 256, 200, 0.14);
  return toTexture(c);
}

/* -- CONTAINER: ribbed cargo pod, tone = 'r' | 'b' ----------------------------- */
export function texContainer(tone = 'r') {
  const [c, x] = cv(256, 256);
  x.fillStyle = tone === 'r' ? P.containerR : P.containerB;
  x.fillRect(0, 0, 256, 256);
  // vertical ribs
  for (let i = 6; i < 256; i += 24) {
    x.fillStyle = 'rgba(0,0,0,0.28)'; x.fillRect(i, 10, 8, 236);
    x.fillStyle = 'rgba(255,255,255,0.10)'; x.fillRect(i + 8, 10, 3, 236);
  }
  x.fillStyle = 'rgba(0,0,0,0.35)';
  x.fillRect(0, 0, 256, 16); x.fillRect(0, 240, 256, 16);
  x.fillStyle = 'rgba(232,240,248,0.55)';
  x.font = '700 26px Consolas, monospace';
  x.fillText(tone === 'r' ? 'UNSC-SUPPLY 0714' : 'UNSC-COOLANT 2210', 16, 44);
  x.font = '700 16px Consolas, monospace';
  x.fillText('HEAVY CARGO — KEEP CLEAR', 16, 70);
  scuff(x, 256, 256, 220, 0.12);
  return toTexture(c);
}

/* -- PUFF SPRITE: soft normal-blended blob (explosion smoke) ------------------ */
export function texPuff() {
  const [c, x] = cv(128, 128);
  const g = x.createRadialGradient(64, 64, 6, 64, 64, 60);
  g.addColorStop(0, 'rgba(255,255,255,0.9)');
  g.addColorStop(0.6, 'rgba(255,255,255,0.4)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  return toTexture(c, { srgb: false });
}

/* -- ROCK (v0.6 valley): strata + cracks + lichen ------------------------------ */
export function texRock() {
  const [c, x] = cv(512, 512);
  x.fillStyle = P.vRock; x.fillRect(0, 0, 512, 512);
  // horizontal strata bands
  for (let y = 0; y < 512; y += 40 + Math.random() * 34) {
    const h = 14 + Math.random() * 30;
    x.fillStyle = `rgba(0,0,0,${0.10 + Math.random() * 0.16})`;
    x.fillRect(0, y, 512, h);
    x.fillStyle = 'rgba(255,255,255,0.07)';
    x.fillRect(0, y + h, 512, 3);
  }
  // cracks
  x.strokeStyle = 'rgba(0,0,0,0.34)'; x.lineWidth = 2;
  for (let i = 0; i < 14; i++) {
    let px = Math.random() * 512, py = Math.random() * 512;
    x.beginPath(); x.moveTo(px, py);
    for (let s = 0; s < 6; s++) {
      px += (Math.random() - 0.5) * 90; py += Math.random() * 46;
      x.lineTo(px, py);
    }
    x.stroke();
  }
  // lichen patches
  for (let i = 0; i < 26; i++) {
    x.fillStyle = `rgba(${70 + Math.random() * 40},${95 + Math.random() * 40},60,${0.10 + Math.random() * 0.14})`;
    x.beginPath();
    x.arc(Math.random() * 512, Math.random() * 512, 8 + Math.random() * 26, 0, 7);
    x.fill();
  }
  scuff(x, 512, 512, 300, 0.1);
  return toTexture(c);
}

/* -- GROUND (v0.6 valley): dirt + dead grass + pebbles -------------------------- */
export function texGround() {
  const [c, x] = cv(512, 512);
  x.fillStyle = P.vGround; x.fillRect(0, 0, 512, 512);
  // dirt blotches
  for (let i = 0; i < 60; i++) {
    x.fillStyle = `rgba(${40 + Math.random() * 30},${38 + Math.random() * 26},${28 + Math.random() * 18},${0.16 + Math.random() * 0.2})`;
    x.beginPath();
    x.arc(Math.random() * 512, Math.random() * 512, 12 + Math.random() * 46, 0, 7);
    x.fill();
  }
  // dead-grass strokes
  x.strokeStyle = 'rgba(122,128,84,0.5)'; x.lineWidth = 2;
  for (let i = 0; i < 220; i++) {
    const gx = Math.random() * 512, gy = Math.random() * 512;
    x.beginPath(); x.moveTo(gx, gy);
    x.lineTo(gx + (Math.random() - 0.5) * 10, gy - 6 - Math.random() * 10);
    x.stroke();
  }
  // pebbles
  for (let i = 0; i < 90; i++) {
    x.fillStyle = `rgba(0,0,0,${0.12 + Math.random() * 0.16})`;
    x.beginPath();
    x.arc(Math.random() * 512, Math.random() * 512, 1.5 + Math.random() * 3.5, 0, 7);
    x.fill();
  }
  return toTexture(c);
}

/* ============================================================================
   v0.7 CITYSCAPE TEXTURES
   ==========================================================================*/

/* -- BUILDING FACADE: dark tower with a seeded grid of lit windows ---------- */
export function texBuilding(tone = 'a', seed = 1) {
  const [c, x] = cv(512, 512);
  let s = seed * 2654435761 % 2147483647;
  const rnd = () => (s = (s * 48271) % 2147483647) / 2147483647;
  x.fillStyle = tone === 'a' ? P.cFacadeA : P.cFacadeB;
  x.fillRect(0, 0, 512, 512);
  // subtle vertical panel stripes
  x.fillStyle = 'rgba(0,0,0,0.16)';
  for (let vx = 0; vx < 512; vx += 64) x.fillRect(vx, 0, 6, 512);
  x.fillStyle = 'rgba(255,255,255,0.03)';
  for (let vx = 32; vx < 512; vx += 64) x.fillRect(vx, 0, 2, 512);
  // window grid — some lit (warm / cool), most dark
  const warm = tone === 'a' ? P.cWindow : P.cWindowB;
  const cols = 8, rows = 10;
  const cw = 512 / cols, rh = 512 / rows;
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      const wx = i * cw + cw * 0.22, wy = j * rh + rh * 0.2;
      const ww = cw * 0.56, wh = rh * 0.5;
      const r = rnd();
      if (r < 0.34) {
        // lit window (emissiveMap picks this up)
        x.fillStyle = r < 0.06 ? P.cWindowB : warm;
        x.globalAlpha = 0.75 + rnd() * 0.25;
        x.fillRect(wx, wy, ww, wh);
        x.globalAlpha = 1;
      } else {
        // dark glass
        x.fillStyle = `rgba(${8 + rnd() * 10},${12 + rnd() * 12},${18 + rnd() * 14},1)`;
        x.fillRect(wx, wy, ww, wh);
        if (r > 0.9) { x.fillStyle = 'rgba(120,170,210,0.12)'; x.fillRect(wx, wy, ww, wh * 0.4); }
      }
    }
  }
  // grime + floor separation lines
  x.fillStyle = 'rgba(0,0,0,0.22)';
  for (let j = 0; j <= rows; j++) x.fillRect(0, j * rh - 2, 512, 3);
  scuff(x, 512, 512, 220, 0.08);
  return toTexture(c);
}

/* -- ASPHALT: dark road with worn center markings ----------------------------- */
export function texAsphalt() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.cAsphalt; x.fillRect(0, 0, 256, 256);
  // aggregate noise
  for (let i = 0; i < 900; i++) {
    const g = 30 + Math.random() * 26;
    x.fillStyle = `rgba(${g},${g + 2},${g + 5},${0.2 + Math.random() * 0.3})`;
    x.fillRect(Math.random() * 256, Math.random() * 256, 1.5, 1.5);
  }
  // cracks
  x.strokeStyle = 'rgba(0,0,0,0.35)'; x.lineWidth = 1.5;
  for (let i = 0; i < 7; i++) {
    let px = Math.random() * 256, py = Math.random() * 256;
    x.beginPath(); x.moveTo(px, py);
    for (let k = 0; k < 5; k++) {
      px += (Math.random() - 0.5) * 40; py += (Math.random() - 0.5) * 40;
      x.lineTo(px, py);
    }
    x.stroke();
  }
  // faded lane paint hints at the edges
  x.fillStyle = 'rgba(210,210,215,0.10)';
  x.fillRect(10, 0, 4, 256); x.fillRect(242, 0, 4, 256);
  scuff(x, 256, 256, 120, 0.1);
  return toTexture(c);
}

/* -- NEON SIGN: glowing colored text on dark backing -------------------------- */
export function texNeon(text, color = '#ff4f9a') {
  const [c, x] = cv(512, 128);
  x.fillStyle = '#0b0e12'; x.fillRect(0, 0, 512, 128);
  x.strokeStyle = color; x.lineWidth = 3;
  x.strokeRect(6, 6, 500, 116);
  x.shadowColor = color; x.shadowBlur = 22;
  x.fillStyle = color;
  x.font = '700 52px Consolas, monospace';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText(text, 256, 68);
  x.shadowBlur = 0;
  x.fillStyle = 'rgba(255,255,255,0.85)';
  x.font = '700 52px Consolas, monospace';
  x.fillText(text, 256, 68);
  scuff(x, 512, 128, 30, 0.06);
  return toTexture(c);
}

/* ==========================================================================
   v0.8 WILDS — the expanse tile sets ( Frame Scape )
   ========================================================================== */

/* -- WATER: banded ripples, tiled over ocean/river planes -------------------- */
export function texWater(deep = false) {
  const [c, x] = cv(256, 256);
  const base = deep ? P.wWaterDeep : P.wWater;
  x.fillStyle = base; x.fillRect(0, 0, 256, 256);
  // horizontal ripple bands
  for (let i = 0; i < 60; i++) {
    const y = Math.random() * 256;
    const w = 30 + Math.random() * 130;
    const a = 0.05 + Math.random() * 0.1;
    x.fillStyle = Math.random() < 0.5
      ? `rgba(255,255,255,${a})` : `rgba(0,20,30,${a * 1.4})`;
    x.fillRect(Math.random() * 256, y, w, 2 + Math.random() * 3);
  }
  // sparkle flecks
  for (let i = 0; i < 90; i++) {
    x.fillStyle = `rgba(230,250,255,${0.05 + Math.random() * 0.12})`;
    x.fillRect(Math.random() * 256, Math.random() * 256, 2, 1);
  }
  return toTexture(c, { repeat: [6, 6] });
}

/* -- SAND: dunes grain + wind lines ------------------------------------------- */
export function texSand() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.wSand; x.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 1400; i++) {
    const g = Math.random();
    x.fillStyle = g < 0.5
      ? `rgba(120,100,60,${0.06 + Math.random() * 0.1})`
      : `rgba(255,244,210,${0.05 + Math.random() * 0.1})`;
    x.fillRect(Math.random() * 256, Math.random() * 256, 2, 1.5);
  }
  // soft wind ripples
  x.strokeStyle = 'rgba(120,100,60,0.10)'; x.lineWidth = 2;
  for (let i = 0; i < 10; i++) {
    const y = Math.random() * 256;
    x.beginPath(); x.moveTo(0, y);
    x.quadraticCurveTo(128, y + (Math.random() - 0.5) * 26, 256, y);
    x.stroke();
  }
  return toTexture(c, { repeat: [4, 4] });
}

/* -- SNOW: packed drifts + sparkle --------------------------------------------- */
export function texSnow() {
  const [c, x] = cv(256, 256);
  x.fillStyle = P.wSnow; x.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 26; i++) {
    x.fillStyle = `rgba(160,185,205,${0.05 + Math.random() * 0.08})`;
    x.beginPath();
    x.ellipse(Math.random() * 256, Math.random() * 256,
              18 + Math.random() * 40, 8 + Math.random() * 16, 0, 0, 7);
    x.fill();
  }
  for (let i = 0; i < 160; i++) {
    x.fillStyle = `rgba(255,255,255,${0.2 + Math.random() * 0.4})`;
    x.fillRect(Math.random() * 256, Math.random() * 256, 1.5, 1.5);
  }
  return toTexture(c, { repeat: [4, 4] });
}

/* -- GRASSLAND: mottled turf ---------------------------------------------------- */
export function texTurf(dry = false) {
  const [c, x] = cv(256, 256);
  x.fillStyle = dry ? P.wGrassDry : P.wGrass; x.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 700; i++) {
    const dark = Math.random() < 0.55;
    x.fillStyle = dry
      ? (dark ? 'rgba(90,90,40,0.16)' : 'rgba(200,200,120,0.13)')
      : (dark ? 'rgba(30,55,22,0.18)' : 'rgba(110,150,70,0.14)');
    x.fillRect(Math.random() * 256, Math.random() * 256,
               2 + Math.random() * 5, 1 + Math.random() * 2);
  }
  // patch blotches
  for (let i = 0; i < 14; i++) {
    x.fillStyle = dry ? 'rgba(120,110,60,0.07)' : 'rgba(25,45,18,0.08)';
    x.beginPath();
    x.ellipse(Math.random() * 256, Math.random() * 256,
              14 + Math.random() * 36, 10 + Math.random() * 22, 0, 0, 7);
    x.fill();
  }
  return toTexture(c, { repeat: [4, 4] });
}

/* -- CH-09.1 — CRACKED MUD: dry riverbed floor (the WASH tile set) --------------
   Baked-pale mud base, dust blotches, then a web of dark desiccation cracks:
   polylines that wander across the tile and fork, the classic dried-mud read. */
export function texCracked() {
  const [c, x] = cv(256, 256);
  x.fillStyle = '#8a7350'; x.fillRect(0, 0, 256, 256);
  // dust + mud tone blotches
  for (let i = 0; i < 20; i++) {
    x.fillStyle = Math.random() < 0.5 ? 'rgba(190,170,130,0.10)' : 'rgba(70,56,38,0.10)';
    x.beginPath();
    x.ellipse(Math.random() * 256, Math.random() * 256,
              16 + Math.random() * 40, 12 + Math.random() * 26, 0, 0, 7);
    x.fill();
  }
  for (let i = 0; i < 900; i++) {
    x.fillStyle = Math.random() < 0.5
      ? 'rgba(60,48,32,0.10)' : 'rgba(215,196,150,0.10)';
    x.fillRect(Math.random() * 256, Math.random() * 256, 2, 1.5);
  }
  // desiccation crack web — wandering forking polylines
  x.strokeStyle = 'rgba(42,32,22,0.55)'; x.lineWidth = 1.6;
  for (let i = 0; i < 16; i++) {
    let px = Math.random() * 256, py = Math.random() * 256;
    let a = Math.random() * Math.PI * 2;
    x.beginPath(); x.moveTo(px, py);
    const segs = 3 + Math.floor(Math.random() * 4);
    for (let sIdx = 0; sIdx < segs; sIdx++) {
      a += (Math.random() - 0.5) * 1.5;
      const len = 16 + Math.random() * 34;
      px += Math.cos(a) * len; py += Math.sin(a) * len;
      x.lineTo(px, py);
      // fork: a short branch leaves the main crack
      if (Math.random() < 0.5) {
        const fa = a + (Math.random() < 0.5 ? 1 : -1) * (0.7 + Math.random() * 0.8);
        x.moveTo(px, py);
        x.lineTo(px + Math.cos(fa) * (10 + Math.random() * 18),
                 py + Math.sin(fa) * (10 + Math.random() * 18));
        x.moveTo(px, py);
      }
    }
    x.stroke();
  }
  return toTexture(c, { repeat: [4, 4] });
}

/* -- CH-09.1 — BADLANDS: stratified eroded rock ---------------------------------
   Horizontal rust/tan strata bands with ragged edges + grit — the eroded
   mesa-wall read. Used by the BADLANDS floor and mesa walls.               */
export function texBadland() {
  const [c, x] = cv(256, 256);
  x.fillStyle = '#7a4a32'; x.fillRect(0, 0, 256, 256);
  // strata bands — warm rust / tan / deep brown laddering down the tile
  const bands = ['#8a5638', '#9c6a44', '#6e4028', '#a4764c', '#7c4c34', '#8e5e3c'];
  let y = 0, b = 0;
  while (y < 256) {
    const h = 14 + Math.random() * 30;
    x.fillStyle = bands[b++ % bands.length];
    x.fillRect(0, y, 256, h);
    // ragged bottom edge — eroded lip
    x.fillStyle = 'rgba(40,24,16,0.28)';
    for (let px = 0; px < 256; px += 8) {
      const drop = Math.random() * 5;
      x.fillRect(px, y + h - drop, 8, drop + 1.5);
    }
    y += h;
  }
  // grit + shadow flecks
  for (let i = 0; i < 1100; i++) {
    x.fillStyle = Math.random() < 0.5
      ? 'rgba(46,26,18,0.12)' : 'rgba(226,180,120,0.10)';
    x.fillRect(Math.random() * 256, Math.random() * 256, 2, 1.5);
  }
  // vertical wash streaks (rare rain over dry rock)
  for (let i = 0; i < 12; i++) {
    const px = Math.random() * 256;
    x.fillStyle = `rgba(40,22,14,${0.06 + Math.random() * 0.08})`;
    x.fillRect(px, 0, 2 + Math.random() * 3, 256);
  }
  return toTexture(c, { repeat: [3, 3] });
}

/* ============================================================================
   CH-36 — HOME BASE art (shuttle interior hub + extract loading screen)
   ----------------------------------------------------------------------------
   · texVista()      — the big windshield panorama: the Frame Scape world
                       seen from the parked shuttle's cockpit (dusk sky,
                       stars, city-scape skyline, canyon mesas, ocean
                       horizon with a moon glint). ONE canvas texture on an
                       emissive plane — the HD 3000-budget answer to the
                       f2 "view out over the world" line (a live render-
                       target camera was REJECTED as the expensive branch;
                       f2 explicitly allows "skybox render or live camera
                       per HD 3000 budget").
   · drawShuttleArt  — the CH-36.1 extract loading screen's SPACE SHUTTLE
                       scene, drawn per-frame into a plain 2D canvas (no
                       video, no WebGL — inside the loading overlay while
                       the game loop is paused). Animated: star drift,
                       engine flicker, blinking nav lights, atmosphere
                       streaks. hud.js calls this from its rAF loop.
   ==========================================================================*/

/* -- CH-36.2 — WINDSHIELD VISTA: the world outside, painted once ---------- */
export function texVista() {
  const W = 1024, H = 320;
  const [c, x] = cv(W, H);
  /* dusk sky — deep teal falling into ember horizon */
  const sky = x.createLinearGradient(0, 0, 0, H);
  sky.addColorStop(0, '#060a14');
  sky.addColorStop(0.45, '#0c1a2a');
  sky.addColorStop(0.78, '#31404a');
  sky.addColorStop(1, '#7a5a40');
  x.fillStyle = sky; x.fillRect(0, 0, W, H);
  /* stars (upper band, denser toward the top) */
  for (let i = 0; i < 240; i++) {
    const sy = Math.pow(Math.random(), 1.8) * H * 0.62;
    const a = 0.25 + Math.random() * 0.7;
    x.fillStyle = `rgba(214,232,255,${a.toFixed(2)})`;
    x.fillRect(Math.random() * W, sy, Math.random() < 0.12 ? 2 : 1, 1);
  }
  /* faint nebula wash */
  const neb = x.createRadialGradient(W * 0.78, H * 0.22, 8, W * 0.78, H * 0.22, 240);
  neb.addColorStop(0, 'rgba(96,72,140,0.20)');
  neb.addColorStop(1, 'rgba(96,72,140,0)');
  x.fillStyle = neb; x.fillRect(0, 0, W, H);
  const neb2 = x.createRadialGradient(W * 0.18, H * 0.3, 6, W * 0.18, H * 0.3, 200);
  neb2.addColorStop(0, 'rgba(52,110,120,0.16)');
  neb2.addColorStop(1, 'rgba(52,110,120,0)');
  x.fillStyle = neb2; x.fillRect(0, 0, W, H);
  /* moon + ocean glint (center-left) */
  x.fillStyle = 'rgba(226,238,246,0.92)';
  x.beginPath(); x.arc(W * 0.34, H * 0.24, 13, 0, 7); x.fill();
  x.fillStyle = 'rgba(226,238,246,0.16)';
  x.beginPath(); x.arc(W * 0.34, H * 0.24, 21, 0, 7); x.fill();
  /* distant mountain/mesa silhouette band */
  x.fillStyle = '#10161c';
  x.beginPath(); x.moveTo(0, H * 0.66);
  for (let px = 0; px <= W; px += 26) {
    const hump = Math.sin(px * 0.021) * 14 + Math.sin(px * 0.053 + 2) * 8;
    x.lineTo(px, H * 0.66 - Math.abs(hump) - (px % 97 < 30 ? 12 : 0));
  }
  x.lineTo(W, H); x.lineTo(0, H); x.fill();
  /* the CITYSCAPE skyline (right third) — neon windows like home */
  const cityX0 = W * 0.62;
  x.fillStyle = '#0a0f16';
  x.fillRect(cityX0, H * 0.44, W - cityX0, H);
  let bx = cityX0 + 4;
  while (bx < W - 8) {
    const bw = 26 + Math.random() * 40;
    const bh = 60 + Math.random() * 110;
    x.fillStyle = Math.random() < 0.5 ? '#0d1219' : '#0a0e15';
    x.fillRect(bx, H * 0.66 - bh, bw, bh + H * 0.34);
    /* lit windows — two warm/cool families like the city tiles */
    for (let wy = H * 0.66 - bh + 6; wy < H * 0.72; wy += 9) {
      for (let wx = bx + 4; wx < bx + bw - 4; wx += 8) {
        if (Math.random() < 0.34) {
          x.fillStyle = Math.random() < 0.6
            ? 'rgba(255,217,142,0.85)' : 'rgba(143,216,255,0.8)';
          x.fillRect(wx, wy, 3, 4);
        }
      }
    }
    /* rooftop beacon */
    if (Math.random() < 0.5) {
      x.fillStyle = 'rgba(255,79,106,0.9)';
      x.fillRect(bx + bw / 2, H * 0.66 - bh - 5, 2, 4);
    }
    bx += bw + 4;
  }
  /* canyon mesas (left third) — stratified silhouettes */
  x.fillStyle = '#141417';
  let mx = 0;
  while (mx < W * 0.34) {
    const mw = 60 + Math.random() * 90;
    const mh = 34 + Math.random() * 46;
    x.fillRect(mx, H * 0.66 - mh, mw, mh + 20);
    /* mesa cap lip */
    x.fillStyle = '#1b1b20';
    x.fillRect(mx - 3, H * 0.66 - mh - 4, mw + 6, 6);
    x.fillStyle = '#141417';
    mx += mw + 6;
  }
  /* ocean strip between mesas and city — horizon glow + moon glint path */
  const sea = x.createLinearGradient(0, H * 0.66, 0, H);
  sea.addColorStop(0, '#20323e');
  sea.addColorStop(1, '#101c26');
  x.fillStyle = sea; x.fillRect(W * 0.30, H * 0.66, W * 0.36, H * 0.34);
  for (let i = 0; i < 46; i++) {
    const gy = H * 0.68 + Math.random() * H * 0.3;
    const gw = 6 + Math.random() * 22;
    x.fillStyle = `rgba(200,224,240,${(0.05 + Math.random() * 0.16).toFixed(2)})`;
    x.fillRect(W * 0.34 - gw / 2 + (Math.random() - 0.5) * 26, gy, gw, 1.5);
  }
  /* atmosphere haze at the horizon */
  const haze = x.createLinearGradient(0, H * 0.56, 0, H * 0.7);
  haze.addColorStop(0, 'rgba(224,138,78,0)');
  haze.addColorStop(1, 'rgba(224,138,78,0.22)');
  x.fillStyle = haze; x.fillRect(0, H * 0.56, W, H * 0.14);
  /* glass smears so it reads as a windshield, not a poster */
  for (let i = 0; i < 9; i++) {
    x.fillStyle = `rgba(255,255,255,${(0.012 + Math.random() * 0.02).toFixed(3)})`;
    x.save();
    x.translate(Math.random() * W, Math.random() * H);
    x.rotate(-0.18 + Math.random() * 0.1);
    x.fillRect(0, 0, 40 + Math.random() * 90, 3 + Math.random() * 5);
    x.restore();
  }
  return toTexture(c);
}

/* -- CH-36.1 — LOADING SCREEN SHUTTLE ART (2D canvas, animated) ------------
   Drawn every frame of the loading sequence into a plain <canvas> — no
   video file, no WebGL cost (the game loop is paused while it plays).
   t = elapsed seconds; (w, h) = the canvas' pixel size.                    */
export function drawShuttleArt(ctx, w, h, t) {
  /* space gradient */
  const bg = ctx.createLinearGradient(0, 0, 0, h);
  bg.addColorStop(0, '#03060c');
  bg.addColorStop(0.6, '#081120');
  bg.addColorStop(1, '#0e1a28');
  ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
  /* planet limb, bottom-left */
  const px = w * 0.16, py = h * 1.42, pr = h * 0.86;
  const pl = ctx.createRadialGradient(px - pr * 0.2, py - pr * 0.4, pr * 0.2, px, py, pr);
  pl.addColorStop(0, '#26404e');
  pl.addColorStop(0.72, '#122430');
  pl.addColorStop(1, '#060d14');
  ctx.fillStyle = pl;
  ctx.beginPath(); ctx.arc(px, py, pr, 0, 7); ctx.fill();
  /* atmosphere rim */
  ctx.strokeStyle = 'rgba(140,190,230,0.5)';
  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(px, py, pr + 1, Math.PI * 1.06, Math.PI * 1.86); ctx.stroke();
  ctx.strokeStyle = 'rgba(224,138,78,0.35)';
  ctx.lineWidth = 7;
  ctx.beginPath(); ctx.arc(px, py, pr + 6, Math.PI * 1.12, Math.PI * 1.8); ctx.stroke();
  /* starfield — drifts slowly left (deterministic layout via index math) */
  for (let i = 0; i < 130; i++) {
    const sx = ((i * 197.3) % w - t * (6 + (i % 5) * 3) + w * 2) % w;
    const sy = (i * 131.7) % (h * 0.9);
    const tw = 0.35 + 0.65 * Math.abs(Math.sin(t * 1.4 + i));
    ctx.fillStyle = `rgba(214,232,255,${(tw * 0.8).toFixed(2)})`;
    ctx.fillRect(sx, sy, i % 11 === 0 ? 2 : 1, 1);
  }
  /* THE SHUTTLE — side profile, nose right, centered slightly high */
  const cx = w * 0.5, cy = h * 0.44;
  const s = Math.min(w, h) / 340;      // scale to fit
  const bob = Math.sin(t * 1.1) * 3.2 * s;
  ctx.save();
  ctx.translate(cx, cy + bob);
  ctx.scale(s, s);
  /* engine flames (behind hull, left side) — flicker with t */
  for (const [ey, ew] of [[-16, 30], [16, 26]]) {
    const fl = 26 + Math.sin(t * 23 + ey) * 9 + Math.sin(t * 41) * 5;
    const fg = ctx.createLinearGradient(-86, 0, -86 - fl, 0);
    fg.addColorStop(0, 'rgba(159,212,238,0.95)');
    fg.addColorStop(0.35, 'rgba(89,242,255,0.55)');
    fg.addColorStop(1, 'rgba(89,120,255,0)');
    ctx.fillStyle = fg;
    ctx.beginPath();
    ctx.moveTo(-84, ey - ew / 2);
    ctx.lineTo(-84 - fl, ey);
    ctx.lineTo(-84, ey + ew / 2);
    ctx.fill();
  }
  /* delta wing (far side, up) */
  ctx.fillStyle = '#39424c';
  ctx.beginPath();
  ctx.moveTo(6, -10); ctx.lineTo(-52, -74); ctx.lineTo(-58, -60); ctx.lineTo(-16, -2);
  ctx.fill();
  /* tail fin */
  ctx.fillStyle = '#424c58';
  ctx.beginPath();
  ctx.moveTo(-58, -8); ctx.lineTo(-92, -58); ctx.lineTo(-72, -58); ctx.lineTo(-38, -10);
  ctx.fill();
  ctx.fillStyle = 'rgba(224,138,78,0.8)';
  ctx.fillRect(-86, -56, 12, 3);
  /* fuselage — plated hull */
  const hull = ctx.createLinearGradient(0, -26, 0, 26);
  hull.addColorStop(0, '#8b95a1');
  hull.addColorStop(0.5, '#66707c');
  hull.addColorStop(1, '#3a424c');
  ctx.fillStyle = hull;
  ctx.beginPath();
  ctx.moveTo(96, 2);
  ctx.quadraticCurveTo(92, -16, 58, -20);
  ctx.lineTo(-62, -24);
  ctx.quadraticCurveTo(-84, -22, -86, -6);
  ctx.lineTo(-86, 12);
  ctx.quadraticCurveTo(-84, 24, -58, 26);
  ctx.lineTo(40, 22);
  ctx.quadraticCurveTo(82, 18, 96, 2);
  ctx.fill();
  /* hull panel seams */
  ctx.strokeStyle = 'rgba(20,26,32,0.4)';
  ctx.lineWidth = 1.4;
  for (const sx of [-64, -38, -12, 16, 44, 68]) {
    ctx.beginPath(); ctx.moveTo(sx, -22); ctx.lineTo(sx - 4, 22); ctx.stroke();
  }
  /* belly shade */
  ctx.fillStyle = 'rgba(16,20,26,0.35)';
  ctx.beginPath();
  ctx.moveTo(-84, 14); ctx.quadraticCurveTo(0, 30, 90, 6);
  ctx.lineTo(86, 16); ctx.quadraticCurveTo(0, 32, -80, 22);
  ctx.fill();
  /* cockpit canopy — lit from inside */
  const can = ctx.createLinearGradient(52, -18, 84, 0);
  can.addColorStop(0, '#12283a');
  can.addColorStop(1, '#7fd8f2');
  ctx.fillStyle = can;
  ctx.beginPath();
  ctx.moveTo(48, -18); ctx.quadraticCurveTo(84, -16, 94, 0);
  ctx.quadraticCurveTo(80, 6, 50, 2); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.5)';
  ctx.fillRect(60, -12, 18, 2);
  /* hull stripes + registry */
  ctx.fillStyle = 'rgba(224,138,78,0.85)';
  ctx.fillRect(-58, -2, 100, 3);
  ctx.fillStyle = 'rgba(230,240,248,0.75)';
  ctx.font = '700 11px Consolas, monospace';
  ctx.fillText('PELICUS-3', -52, 14);
  /* near-side wing (down) */
  ctx.fillStyle = '#4c5764';
  ctx.beginPath();
  ctx.moveTo(8, 10); ctx.lineTo(-44, 78); ctx.lineTo(-52, 66); ctx.lineTo(-14, 4);
  ctx.fill();
  ctx.strokeStyle = 'rgba(24,30,38,0.5)';
  ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(-4, 14); ctx.lineTo(-42, 70); ctx.stroke();
  /* landing lights — blink alternately */
  const blinkA = Math.sin(t * 3.4) > 0.2;
  const blinkB = Math.sin(t * 3.4 + Math.PI) > 0.2;
  if (blinkA) {
    ctx.fillStyle = 'rgba(89,242,255,0.95)';
    ctx.beginPath(); ctx.arc(-88, -6, 2.6, 0, 7); ctx.fill();
  }
  if (blinkB) {
    ctx.fillStyle = 'rgba(255,83,64,0.95)';
    ctx.beginPath(); ctx.arc(-90, 12, 2.4, 0, 7); ctx.fill();
  }
  ctx.fillStyle = 'rgba(255,217,142,0.95)';
  ctx.beginPath(); ctx.arc(94, 4, 2.2, 0, 7); ctx.fill();
  ctx.restore();
  /* atmosphere streaks — re-entry speed lines far behind */
  for (let i = 0; i < 14; i++) {
    const ly = (i * 53.3 + t * 26) % (h * 0.8);
    const lx = w * 0.06 + (i * 97.1) % (w * 0.88);
    ctx.fillStyle = `rgba(159,212,238,${(0.05 + (i % 4) * 0.035).toFixed(2)})`;
    ctx.fillRect(lx, ly, 26 + (i % 5) * 12, 1);
  }
}

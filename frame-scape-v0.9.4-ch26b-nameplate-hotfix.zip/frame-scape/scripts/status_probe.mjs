/* status_probe.mjs — CH-26 status effect system acceptance probe.
   Boots the real game in headless Chromium (SwiftShader), then drives the
   LIVE status pipeline through the shared damage entry point on real
   enemies and asserts the whole f1–f5 contract:

     A. build pin — v0.9.4 / ch26b actually runs
     B. store     — procs stack to 10× cap, refresh a 5 s window, decay
                    to zero after expiry (f1)
     C. DoT       — heat/toxin/slash ticks re-land typed damage through
                    the shared pipeline WITHOUT chaining procs (f2/f3)
     D. cold      — stacks slow the enemy (slowMult < 1) (f2)
     E. puncture  — a non-crit hit upgrades into a crit at 10 stacks
                    (crit-chance-taken 25 % roll forced via seeding) (f3)
     F. void      — the hitbox mesh grows to ~×1.7 at 10 stacks (f4)
     G. electric  — a zap arcs to a neighbor when one stands in range (f2)
     H. row       — the billboard status row sprite exists above the bar
                    and renders the active stack signature (f1 + f5)
     I. companions— drone/pet/freeze paths still carry statusChance (f5)
     Z. zero page errors

   Writes scripts/status_report.json + scripts/status_row.png (close-up of
   a stacked enemy showing the icon+count row). Exit 0 = all green.
*/

import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, writeFileSync } from 'node:fs';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = 8953;
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.txt': 'text/plain',
};

const server = createServer((req, res) => {
  let p = req.url.split('?')[0];
  if (p === '/') p = '/index.html';
  const f = join(ROOT, decodeURIComponent(p));
  try {
    const body = readFileSync(f);
    res.writeHead(200, { 'content-type': MIME[extname(f)] || 'application/octet-stream' });
    res.end(body);
  } catch {
    res.writeHead(404); res.end('nope');
  }
});
await new Promise((r) => server.listen(PORT, '127.0.0.1', r));

const browser = await chromium.launch({
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader',
         '--disable-gpu-sandbox', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));

const checks = [];
const ok = (id, good, note = '') => {
  checks.push({ id, good, note });
  console.log(`  ${good ? '✓' : '✗'} ${id}${note ? ' — ' + note : ''}`);
};

console.log('booting v0.9.4 (headless Chromium · SwiftShader)…');
await page.goto(`http://127.0.0.1:${PORT}/index.html?v=0.9.4b`, { waitUntil: 'load', timeout: 45000 });

await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return !!(g && g.world);
}, null, { timeout: 90000, polling: 500 });
await page.evaluate(() => AC.game.start());
await page.waitForFunction(() => {
  const g = window.AC && window.AC.game;
  return g && g.state === 'playing';
}, null, { timeout: 30000, polling: 250 });

/* quiet the field: companions OFF (the drone live-fires at the test
   targets) + player cloaked so nothing aggro-shoots mid-probe */
await page.evaluate(() => {
  const g = AC.game;
  if (g.companions.droneEnabled) g.companions.toggleDrone(g);
  if (g.companions.petEnabled) g.companions.togglePet(g);
  g.player.invisT = 9999;
});

/* A. build pin */
const meta = await page.evaluate(() => ({
  version: AC.assets.meta.version, build: AC.assets.meta.build,
  statusCfg: !!AC.assets.combat.statuses,
  voidType: AC.assets.combat.types.includes('void'),
  slashWeight: AC.assets.combat.statuses.procWeights.slash,
}));
ok('A.version', meta.version === '0.9.4' && meta.build === 'ch26b',
  `version ${meta.version} · build ${meta.build}`);
ok('A.config', meta.statusCfg && meta.voidType && meta.slashWeight === 0.35,
  'statuses config live · void typed · slash weight 0.35 (rare)');

/* helper: land N guaranteed procs of one status on a fresh enemy via the
   REAL shared pipeline (applyDamage — statusChance 1, typed map weighted
   to the wanted status). Returns the store + hp trail. */
const stackUp = (key, n) => page.evaluate(([key, n]) => {
  const g = AC.game;
  const e = g.enemies.find((x) => x.alive && !x.arch.kaiju);
  if (!e) return null;
  e.showBar(8);
  const typed = {}; typed[key] = 1;
  const hpTrail = [e.hp];
  for (let i = 0; i < n; i++) {
    e._statusChance = 1;                 // guaranteed proc, one roll per hit
    e._lastTypes = typed;
    e._critHit = false; e._critUpgraded = false;
    e.damage({ [key]: 0.5 }, null, g, 'bullet');   // chip hit (the PROC is the payload)
    hpTrail.push(Math.round(e.hp));
  }
  return { key, stacks: e.statuses[key] ? e.statuses[key].stacks : 0,
           timer: e.statuses[key] ? Math.round(e.statuses[key].timer * 100) / 100 : 0,
           hpTrail, alive: e.alive };
}, [key, n]);

/* B. stack framework — cap + refresh + decay (f1) */
console.log('  [B] stack framework (f1)');
const b = await stackUp('heat', 12);
ok('B.stackCap', b && b.stacks === 10, `12 procs → ${b && b.stacks} stacks (cap 10)`);
ok('B.refresh', b && b.timer > 4.5 && b.timer <= 5, `duration window ${b && b.timer}s (≤5, refreshed)`);
ok('B.alive', b && b.alive, 'enemy survived the tiny hits (DoT is the pressure, not the hits)');

/* C. DoT — heat ticks land typed, no chain-procs (f2) */
console.log('  [C] heat DoT tick (f2)');
const c = await page.evaluate(() => {
  const g = AC.game;
  const e = g.enemies.find((x) => x.alive && x.statuses && x.statuses.heat);
  if (!e) return null;
  const before = e.hp;
  const procCountBefore = e.statuses.heat.stacks;
  e.statuses.heat.tickT = -1;            // force a tick this frame
  e.updateStatuses(0.016, g);
  const after = e.hp;
  return { before: Math.round(before * 10) / 10, after: Math.round(after * 10) / 10,
           stacks: e.statuses.heat ? e.statuses.heat.stacks : 0,
           procCountBefore,
           ticked: after < before,
           /* heat health mult 1.25 rides the type table */
           lost: Math.round((before - after) * 10) / 10 };
});
ok('C.tick', c && c.ticked, `hp ${c && c.before} → ${c && c.after} (tick landed)`);
ok('C.noChain', c && c.stacks === c.procCountBefore,
  `stacks stayed ${c && c.stacks} — DoT ticks never chain-proc`);

/* D. cold slow + decay to zero (f2/f1) */
console.log('  [D] cold slow + expiry decay (f2/f1)');
await page.evaluate(() => {
  const g = AC.game;
  const e = g.enemies.find((x) => x.alive && !x.arch.kaiju);
  e.statuses = {};                        // fresh store
  const typed = { cold: 1 };
  for (let i = 0; i < 10; i++) {
    e._statusChance = 1; e._lastTypes = typed;
    e._critHit = false; e._critUpgraded = false;
    e.damage({ cold: 0.5 }, null, g, 'bullet');
  }
});
const d1 = await page.evaluate(() => {
  const g = AC.game;
  const e = g.enemies.find((x) => x.alive && x.statuses && x.statuses.cold);
  if (!e) return null;
  const slow = e.slowMult();
  /* fast-forward: blow the 5 s window, then run 12 s of updates (decay 1/s) */
  e.statuses.cold.timer = 0;
  for (let i = 0; i < 720; i++) e.updateStatuses(1 / 60, g);   // ~12 s
  return { slow: Math.round(slow * 100) / 100, stacksAfter: e.statuses.cold ? e.statuses.cold.stacks : 0 };
});
ok('D.slow', d1 && d1.slow === 0.4, `slowMult at 10 stacks = ${d1 && d1.slow} (−60 % cap floor)`);
ok('D.decay', d1 && d1.stacksAfter === 0, `after expiry + 12 s → ${d1 && d1.stacksAfter} stacks (decayed clean)`);

/* E. puncture — crit-chance-taken upgrades a non-crit (f3) */
console.log('  [E] puncture crit-chance-taken (f3)');
const e5 = await page.evaluate(() => {
  const g = AC.game;
  const e = g.enemies.find((x) => x.alive && !x.arch.kaiju);
  e.statuses = { puncture: { stacks: 10, timer: 5, tickT: 0, tickDmg: 0 } };
  e.hp = 1e9; e.maxHp = 1e9;             // god-mode: survive the 40-roll math
  const base = { puncture: 100 };
  e._statusChance = 0;                    // no NEW procs — pure damage math
  /* crit math is deterministic at 10 stacks: the upgrade roll is 0.25 —
     run 40 rolls and count how many upgraded (expect ~10, never 0 for 40
     at p=0.25 with overwhelming probability; bound: ≥1) */
  let upgrades = 0, critFlagged = 0;
  for (let i = 0; i < 40; i++) {
    e._critUpgraded = false;
    e._critHit = false;
    const hpBefore = e.hp;
    e.damageTyped(base, null, g, 'bullet');
    if (e._critUpgraded) { upgrades++; critFlagged++; }
    if (e.lastHit && e.lastHit.crit) critFlagged++;
  }
  e.statuses = {};
  return { upgrades, critFlagged, alive: e.alive };
});
ok('E.upgrade', e5.upgrades >= 1, `${e5.upgrades}/40 non-crits upgraded at 10 stacks (p=0.25/roll)`);

/* F. void hitbox growth (f4) */
console.log('  [F] void hitbox growth (f4)');
const f = await stackUp('void', 10);
const f2 = await page.evaluate(() => {
  const g = AC.game;
  const e = g.enemies.find((x) => x.alive && x.statuses && x.statuses.void);
  if (!e) return null;
  e.updateStatuses(0.016, g);
  const s10 = e.hitMesh.scale.x;
  e.statuses.void.stacks = 5;
  e.updateStatuses(0.016, g);
  const s5 = e.hitMesh.scale.x;
  e.statuses.void.stacks = 0;
  e.updateStatuses(0.016, g);
  return { s10: Math.round(s10 * 100) / 100, s5: Math.round(s5 * 100) / 100,
           reset: Math.round(e.hitMesh.scale.x * 100) / 100 };
});
ok('F.grow', f2 && f2.s10 > 1.65 && f2.s5 < f2.s10,
  `hitbox ×${f2 && f2.s10} at 10 stacks · ×${f2 && f2.s5} at 5 (grows per stack)`);
ok('F.reset', f2 && f2.reset === 1, `back to ×${f2 && f2.reset} clean at 0 stacks`);

/* G. electric zap arcs to a neighbor (f2) */
console.log('  [G] electric zap (f2)');
const g7 = await page.evaluate(() => {
  const g = AC.game;
  const live = g.enemies.filter((x) => x.alive && !x.arch.kaiju);
  if (live.length < 2) return { pair: false };
  const a = live[0], b = live[1];
  /* park them 3 m apart (inside the 9 m zap range) */
  a.group.position.set(b.group.position.x + 3, a.group.position.y, b.group.position.z);
  a.statuses = {};
  /* the zap lands on the NEAREST other hostile — patrols can drift closer
     than b, so measure the whole field's hp (a excluded) */
  const before = live.filter((x) => x !== a).map((x) => x.hp);
  let procs = 0;
  for (let i = 0; i < 12; i++) {
    a._statusChance = 1; a._lastTypes = { electric: 1 };
    a.damage({ electric: 2 }, null, g, 'bullet');
    if (a.statuses.electric) procs = a.statuses.electric.stacks;
  }
  const after = live.filter((x) => x !== a).map((x) => x.hp);
  const lost = before.reduce((s, v, i) => s + Math.max(0, v - after[i]), 0);
  a.statuses = {};
  return { pair: true, zapped: lost > 0, bLost: Math.round(lost * 10) / 10, procs };
});
ok('G.zap', !g7.pair || (g7.zapped && g7.procs > 0),
  g7.pair ? `${g7.procs} electric procs → neighbors took ${g7.bLost} zap damage (typed electric)` : 'single-enemy zone — skipped');

/* H. the billboard status row renders the stack signature (f1/f5) */
console.log('  [H] status row render (f1/f5)');
const h = await page.evaluate(() => {
  const g = AC.game;
  const e = g.enemies.find((x) => x.alive && !x.arch.kaiju);
  e.statuses = {};
  e._sapStacks = 0;
  e.statuses.heat = { stacks: 7, timer: 5, tickT: 0, tickDmg: 0 };
  e.statuses.cold = { stacks: 3, timer: 5, tickT: 0, tickDmg: 0 };
  e._sapStacks = 5;                       // DEF-DOWN rides the same row (f5)
  e.drawBar();
  const sig = e._statusSig();
  const hasRow = !!e.statusRow;
  const visible = hasRow && e.statusRow.visible === false;   // bar hidden → row hidden
  e.showBar(8); e.drawBar();
  return { sig, hasRow, visibleWhenHidden: visible,
           y: e.statusRow ? Math.round(e.statusRow.position.y * 100) / 100 : 0,
           barY: Math.round(e.bar.position.y * 100) / 100 };
});
ok('H.row', h.hasRow, `row sprite built above the bar (sig "${h.sig}" = heat7 · cold3 · DEF-DOWN5)`);
ok('H.above', h.y > h.barY, `row y ${h.y} > bar y ${h.barY} (renders OVER the health bar)`);

/* close-up screenshot: park the camera on a stacked enemy — aim via the
   PLAYER yaw/pitch (the per-frame camera update overwrites lookAt) */
await page.evaluate(() => {
  const g = AC.game;
  const e = g.enemies.find((x) => x.alive && x.statusRow);
  if (!e) return;
  const p = e.group.position;
  /* refresh the stacks so the row is live for the shot */
  e.statuses.heat = { stacks: 7, timer: 30, tickT: 0, tickDmg: 0 };
  e.statuses.cold = { stacks: 3, timer: 30, tickT: 0, tickDmg: 0 };
  e._sapStacks = 5;
  e.showBar(60);
  g.teleportTo(p.x + 2.6, p.z + 2.6);
  g.player.pos.y = p.y + 1.5;
  /* view dir = (−sin yaw, ·, −cos yaw) — solve yaw/pitch to face the enemy */
  const dx = p.x - g.player.pos.x, dz = p.z - g.player.pos.z;
  g.player.yaw = Math.atan2(-dx, -dz);
  g.player.pitch = Math.atan2((p.y + 1.2) - g.player.pos.y, Math.hypot(dx, dz)) * -1;
});
await page.waitForTimeout(900);
await page.screenshot({ path: join(ROOT, 'scripts', 'status_row.png') });
console.log('  screenshot → scripts/status_row.png');

/* I. companion paths still flow (f5) — freeze ray defdown + pet/drone chances */
const i5 = await page.evaluate(() => {
  const A = AC.assets;
  return {
    freeze: A.companions.drone.weapons.find((w) => w.id === 'freeze').statusChance,
    petStatus: A.companions.pet.statusChance,
    droneStatus: A.companions.drone.weapons.map((w) => w.statusChance || 0),
  };
});
ok('I.freezeRay', i5.freeze === 0, 'FREEZE RAY keeps DEF-DOWN identity (statusChance 0 — it stacks vuln)');
ok('I.companions', i5.petStatus > 0 && i5.droneStatus.some((s) => s > 0),
  `pet bite ${i5.petStatus} · drone weapons [${i5.droneStatus}] all roll procs through the same gate`);

ok('Z.pageErrors', errors.length === 0, errors.length ? errors.slice(0, 3).join(' | ') : 'zero page errors');

writeFileSync(join(ROOT, 'scripts', 'status_report.json'),
  JSON.stringify({ date: new Date().toISOString(), version: meta.version, build: meta.build,
                   checks, pageErrors: errors }, null, 2));

const failed = checks.filter((c) => !c.good).length;
console.log(`────────────────────────────────────────────────
RESULT: ${checks.length - failed} passed · ${failed} failed`);
await browser.close();
server.close();
process.exit(failed ? 1 : 0);

/* ============================================================================
   AUTUMN CORRIDOR — world.js  (v0.7.0)
   ----------------------------------------------------------------------------
   Builds the whole level from ASSETS.world:
     · dark corridor (z 0 … -72)  → sliding blast door
     · HANGAR BAY 7 (z -72.4 … -116): 2-story bay, catwalk deck + ramp on
       the left wall, side entry doors, pillars, containers, parked
       dropship, and the big EXIT door — which now CYCLES OPEN
     · THE VALLEY (z -117.4 … -156): dusk canyon approach — funneling rock
       walls, dead trees, boulders, grass, POWER crystals
     · THE CITYSCAPE (z -156.6 … -214): NEW v0.7 — night streets beyond the
       canyon: neon towers with lit windows, street lamps, wrecked skimmers,
       planters, breakable supply boxes, POWER crystals and the extraction
       beacon pad (WIN)
   Exposes:
     colliders / solids / floorZones / lights (zone-tagged) / door (bay) /
     door2 (exit) / winZone (beacon) / zoneFx (fog+bg per zone) /
     hub + updateHub (CH-36: the shuttle-interior HOME BASE north of the
     corridor start — ramp door, stations, windshield vista; zoneAt reads
     'hub' for z > assets.hub.z0) /
     breakables + damageBox (CH-06: crates/barrels/chests — ANY damage
     type chips them; one rocket shell still kills, CH-06.4) /
     floorHeightAt(x,z,refY) / ceilHeightAt(z) / zoneAt(z)
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js';
import * as TEX from './textures.js';

export function buildWorld(scene) {
  const WC = ASSETS.world.corridor;
  const WH = ASSETS.world.hangar;
  const WV = ASSETS.world.valley;
  const P = ASSETS.palette;
  const segLen = WC.segment;
  const nSeg = Math.round(WC.length / segLen);
  const halfW = WC.width / 2;

  const colliders = [];
  const solids = [];
  const lights = [];          // { light, zone, base }
  const floorZones = [];
  const animated = [];
  const breakables = [];      // destructible props: crates · barrels · chests (CH-06)
  const debris = [];          // flying prop chunks after a break
  /* CH-06.4 — the universal break mark lives in assets (world.containers.
     breakThreshold, default 2000, keyed to the RL-4's per-shell damage).
     Legacy crates ride the FULL threshold as their HP pool; barrels and
     chests use the smaller per-material pools (all ≤ the mark), so ONE
     rocket shell still kills every prop and lesser hits just chip.        */
  const BREAK_THRESHOLD = ASSETS.world.containers.breakThreshold;

  /* -- CH-44.1 — STATIC MERGE BATCHES --------------------------------------
     The per-prop scene.add storm (tufts, crowns, fronds, boulders, decor
     boxes) was the global draw-call overrun the CH-07 probe measured
     (hangar mid 273 · deep 310 vs the §03 ~160-200 design figure).
     Static, never-animated, never-removed decor now bakes into ONE
     merged BufferGeometry per (zone · material · cast · receive) bucket,
     compiled by flushBatches() at the end of the build. Solids
     membership survives: buckets that absorbed meshes bullets used to
     hit (boulders) push their merged mesh back into `solids`, so
     hitscan reads the same surfaces. Frustum culling stays granular —
     expanse rows batch PER ROW so only rows in the frustum draw, and
     the fog still hides the far end. Nothing animated or removable
     builds through this path (breakables/harvestables/doors are
     excluded by their flags).                                          */
  const batches = new Map();
  let CURB = 'corridor';                       // bucket context (zone key)
  const batchZone = (z) => { CURB = z; };
  const _bmPos = new THREE.Vector3();
  const _bmScl = new THREE.Vector3();
  const _bmQ = new THREE.Quaternion();
  const _bmE = new THREE.Euler();
  const _bmM = new THREE.Matrix4();
  function batchPush(geo, mat, cast, recv, solid, mtx) {
    const key = CURB + '|' + mat.uuid + '|' + (cast ? 1 : 0) + (recv ? 1 : 0);
    let b = batches.get(key);
    if (!b) {
      b = { mat, cast: !!cast, recv: !!recv, solid: false, geos: [], n: 0 };
      batches.set(key, b);
    }
    const g = geo.clone();
    if (mtx) g.applyMatrix4(mtx);
    b.geos.push(g);
    b.n++;
    b.solid = b.solid || !!solid;
  }
  function batchBox(w, h, d, x, y, z, mat, cast, recv, ry = 0, rx = 0) {
    _bmE.set(rx || 0, ry || 0, 0);
    _bmQ.setFromEuler(_bmE);
    _bmPos.set(x, y, z);
    _bmScl.set(w, h, d);
    _bmM.compose(_bmPos, _bmQ, _bmScl);
    batchPush(unitBox, mat, cast, recv, false, _bmM);
  }
  /* bake an already-built mesh (geometry + local transform) into the
     current bucket — the prop primitives (cones/icosa/planes) use this */
  function batchMesh(m, cast, recv, solid) {
    m.updateMatrix();
    batchPush(m.geometry, m.material, cast, recv, solid, m.matrix);
  }
  function mergeGeos(list) {
    const parts = list.map((g) => (g.index ? g.toNonIndexed() : g));
    let n = 0;
    for (const g of parts) n += g.attributes.position.count;
    const pos = new Float32Array(n * 3);
    const nor = new Float32Array(n * 3);
    const uv = new Float32Array(n * 2);
    let o = 0;
    for (const g of parts) {
      pos.set(g.attributes.position.array, o * 3);
      nor.set(g.attributes.normal.array, o * 3);
      if (g.attributes.uv) uv.set(g.attributes.uv.array, o * 2);
      o += g.attributes.position.count;
    }
    for (const g of list) g.dispose();
    const out = new THREE.BufferGeometry();
    out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    out.computeBoundingSphere();
    return out;
  }
  function flushBatches() {
    const stats = { buckets: 0, mergedFrom: 0, zones: {} };
    for (const [key, b] of batches) {
      const zone = key.split('|')[0];
      const mesh = new THREE.Mesh(mergeGeos(b.geos), b.mat);
      mesh.castShadow = b.cast;
      mesh.receiveShadow = b.recv;
      mesh.matrixAutoUpdate = false;
      scene.add(mesh);
      if (b.solid) solids.push(mesh);          // bullets keep hitting them
      stats.buckets++;
      stats.mergedFrom += b.n;
      stats.zones[zone] = (stats.zones[zone] || 0) + 1;
    }
    batches.clear();
    return stats;
  }

  /* -- shared geometry & materials ----------------------------------------- */
  const unitBox = new THREE.BoxGeometry(1, 1, 1);

  const texFloor = TEX.texFloor();          texFloor.repeat.set(2, nSeg);
  const texCeil = TEX.texCeiling();         texCeil.repeat.set(2, nSeg);
  const texHFloor = TEX.texHangarFloor();   texHFloor.repeat.set(6, 8);
  const texHWall = TEX.texHangarWall();     texHWall.repeat.set(4, 1);
  const texGrate = TEX.texGrate();          texGrate.repeat.set(1, 8);
  const texChev = TEX.texChevron();
  const texConR = TEX.texContainer('r');
  const texConB = TEX.texContainer('b');
  const texRock = TEX.texRock();            texRock.repeat.set(2, 3);
  const texGround = TEX.texGround();        texGround.repeat.set(5, 9);
  const texAsphalt = TEX.texAsphalt();      texAsphalt.repeat.set(6, 40);
  const texBuildA = TEX.texBuilding('a', 11); texBuildA.repeat.set(2, 3);
  const texBuildB = TEX.texBuilding('b', 23); texBuildB.repeat.set(2, 3);
  const texBuildC = TEX.texBuilding('a', 47); texBuildC.repeat.set(2, 4);
  const texSidewalk = TEX.texHangarFloor(); texSidewalk.repeat.set(3, 60);

  const M = {
    wall:    new THREE.MeshPhongMaterial({ map: TEX.texWall(), shininess: 10 }),
    rib:     new THREE.MeshLambertMaterial({ color: P.wallB }),
    inset:   new THREE.MeshLambertMaterial({ color: P.wallInset }),
    floor:   new THREE.MeshPhongMaterial({ map: texFloor, shininess: 14 }),
    ceil:    new THREE.MeshLambertMaterial({ map: texCeil }),
    strip:   new THREE.MeshBasicMaterial({ color: P.strip }),
    lampBar: new THREE.MeshBasicMaterial({ color: P.stripGlow }),
    hazard:  new THREE.MeshLambertMaterial({ map: TEX.texHazard() }),
    crate:   new THREE.MeshLambertMaterial({ map: TEX.texCrate() }),
    /* CH-06.1 — barrels + chests */
    barrelWood:  new THREE.MeshLambertMaterial({ map: TEX.texBarrelWood() }),
    barrelMetal: new THREE.MeshLambertMaterial({ map: TEX.texBarrelMetal() }),
    chest:       new THREE.MeshLambertMaterial({ map: TEX.texChest() }),
    door:    new THREE.MeshPhongMaterial({ color: P.gunDark, shininess: 24 }),
    frame:   new THREE.MeshBasicMaterial({ color: P.stripGlow }),
    warn:    new THREE.MeshBasicMaterial({ color: '#ff3b30' }),
    /* hangar */
    hwall:   new THREE.MeshPhongMaterial({ map: texHWall, shininess: 6 }),
    hfloor:  new THREE.MeshPhongMaterial({ map: texHFloor, shininess: 10 }),
    hceil:   new THREE.MeshLambertMaterial({ color: '#2c3136' }),
    grate:   new THREE.MeshPhongMaterial({ map: texGrate, shininess: 4 }),
    chev:    new THREE.MeshLambertMaterial({ map: texChev }),
    conR:    new THREE.MeshLambertMaterial({ map: texConR }),
    conB:    new THREE.MeshLambertMaterial({ map: texConB }),
    hull:    new THREE.MeshLambertMaterial({ color: '#6d7681' }),
    hullDk:  new THREE.MeshLambertMaterial({ color: '#464d55' }),
    amber:   new THREE.MeshBasicMaterial({ color: '#e8a04e' }),
    /* valley */
    rock:    new THREE.MeshLambertMaterial({ map: texRock }),
    rockDk:  new THREE.MeshLambertMaterial({ color: P.vRockDk }),
    ground:  new THREE.MeshPhongMaterial({ map: texGround, shininess: 2 }),
    wood:    new THREE.MeshLambertMaterial({ color: P.vWood }),
    moss:    new THREE.MeshLambertMaterial({ color: P.vMoss }),
    crystal: new THREE.MeshBasicMaterial({ color: P.vCrystal }),
    /* cityscape */
    asphalt: new THREE.MeshPhongMaterial({ map: texAsphalt, shininess: 6 }),
    walk:    new THREE.MeshPhongMaterial({ map: texSidewalk, shininess: 4 }),
    buildA:  new THREE.MeshLambertMaterial({ map: texBuildA, emissive: 0xffffff,
                emissiveMap: texBuildA, emissiveIntensity: 0.55 }),
    buildB:  new THREE.MeshLambertMaterial({ map: texBuildB, emissive: 0xffffff,
                emissiveMap: texBuildB, emissiveIntensity: 0.55 }),
    buildC:  new THREE.MeshLambertMaterial({ map: texBuildC, emissive: 0xffffff,
                emissiveMap: texBuildC, emissiveIntensity: 0.5 }),
    lampPole: new THREE.MeshLambertMaterial({ color: '#3a4046' }),
    lampHead: new THREE.MeshBasicMaterial({ color: '#ffe9b8' }),
    lane:     new THREE.MeshBasicMaterial({ color: '#c9a75a' }),
    planter:  new THREE.MeshLambertMaterial({ color: '#4a4438' }),
    /* expanse wilds (v0.8) */
    turf:    new THREE.MeshPhongMaterial({ map: TEX.texTurf(false), shininess: 2 }),
    turfDry: new THREE.MeshPhongMaterial({ map: TEX.texTurf(true), shininess: 2 }),
    sand:    new THREE.MeshPhongMaterial({ map: TEX.texSand(), shininess: 4 }),
    snowG:   new THREE.MeshPhongMaterial({ map: TEX.texSnow(), shininess: 10 }),
    mtRock:  new THREE.MeshLambertMaterial({ color: P.wRockMt }),
    dirt:    new THREE.MeshLambertMaterial({ color: '#6b5638' }),
    leaf:    new THREE.MeshLambertMaterial({ color: P.wLeaf }),
    leafDk:  new THREE.MeshLambertMaterial({ color: P.wLeafDark }),
    trunk:   new THREE.MeshLambertMaterial({ color: P.wTrunk }),
    flowerA: new THREE.MeshBasicMaterial({ color: P.wFlower }),
    flowerB: new THREE.MeshBasicMaterial({ color: P.wFlowerB }),
    cactus:  new THREE.MeshLambertMaterial({ color: P.wCactus }),
    ice:     new THREE.MeshLambertMaterial({ color: '#cfe6f2' }),
    /* CH-09.1 — canyon-country sets (wash · canyon · basin · ridge ·
       badlands): cracked-mud wash floor + stratified badland rock */
    cracked: new THREE.MeshPhongMaterial({ map: TEX.texCracked(), shininess: 1 }),
    badland: new THREE.MeshPhongMaterial({ map: TEX.texBadland(), shininess: 2 }),
  };
  /* water needs its own textures so map offsets can scroll */
  const texWaterShal = TEX.texWater(false);
  const texWaterDeep = TEX.texWater(true);
  M.water = new THREE.MeshPhongMaterial({
    map: texWaterShal, transparent: true, opacity: 0.7, shininess: 70, depthWrite: false,
  });
  M.waterDeep = new THREE.MeshPhongMaterial({
    map: texWaterDeep, transparent: true, opacity: 0.82, shininess: 80, depthWrite: false,
  });
  M.falls = new THREE.MeshBasicMaterial({
    map: TEX.texWater(false), transparent: true, opacity: 0.5, depthWrite: false,
  });

  function addBox(w, h, d, x, y, z, mat, o = {}) {
    /* CH-44.1 — static decor (solid:false · no collide · no breakable)
       rides the merge batches; solids / breakables / colliders build as
       before. Batch path returns null — every return-consuming call site
       is a solid/collide box (the three sliding doors included), so no
       caller of a decor box ever keeps the return.                    */
    if (o.solid === false && !o.collide && !o.breakable) {
      batchBox(w, h, d, x, y, z, mat, o.cast, o.receive, o.ry || 0, o.rx || 0);
      return null;
    }
    const m = new THREE.Mesh(unitBox, mat);
    m.scale.set(w, h, d);
    m.position.set(x, y, z);
    if (o.ry) m.rotation.y = o.ry;
    if (o.rx) m.rotation.x = o.rx;
    m.castShadow = !!o.cast;
    m.receiveShadow = !!o.receive;
    scene.add(m);
    if (o.solid !== false) solids.push(m);
    if (o.collide) {
      const ry = o.ry || 0;
      const hx = (Math.abs(w * Math.cos(ry)) + Math.abs(d * Math.sin(ry))) / 2;
      const hz = (Math.abs(d * Math.cos(ry)) + Math.abs(w * Math.sin(ry))) / 2;
      colliders.push({
        minX: x - hx, maxX: x + hx, minZ: z - hz, maxZ: z + hz,
        y0: o.y0 ?? 0, y1: o.y1 ?? (y + h / 2 + 0.5),
      });
    }
    if (o.breakable) {
      /* CH-06.1 — the spec carries kind + material; `true` (legacy call
         sites: alcove crates, big hangar containers) = a full-threshold
         crate-style pool so those props behave exactly as before.          */
      const spec = o.breakable === true ? {} : o.breakable;
      const box = makeBreakable(m, o.collide ? colliders[colliders.length - 1] : null, spec,
                                o.breakLinked || null);
      m.userData.breakable = box;
      breakables.push(box);
    }
    return m;
  }
  const col = (o) => colliders[colliders.length - 1];

  /* -- CH-06.1 — ONE breakable record factory ───────────────────────────
     kind + material resolve the HP pool and the debris style. Crates
     (legacy) ride the full breakThreshold pool; barrels/chests use the
     per-material pools (wood 150 / metal 320 — all ≤ the mark). Records
     carry kind/mat/debrisMat so damageBox can route debris + spill.       */
  function makeBreakable(mesh, collider, spec = {}, linked = null) {
    const CT = ASSETS.world.containers;
    const kind = spec.kind || 'crate';
    const mat = spec.mat || CT.kinds[kind].mat;
    const mdef = CT.materials[mat];
    const hp = kind === 'crate' ? BREAK_THRESHOLD : mdef.hp;
    const debrisMat = kind === 'barrel'
      ? (mat === 'wood' ? M.barrelWood : M.barrelMetal)
      : kind === 'chest' ? M.chest : M.crate;
    return { mesh, col: collider, hp, maxHp: hp, dead: false, linked,
             kind, mat, debrisMat };
  }

  /* -- CH-06.1/06.2 — barrel + chest builder (containers.zones mix) ──────
     Barrels = 10-segment cylinder (1 draw call), chests = one painted box
     (the lid/lock are IN the texture — house PS2 style). A stacked entry
     (stack: true) sits on the previous prop of the same zone list and is
     chain-linked to it: break the base, the top goes with it — exactly
     like the stacked hangar containers below. `base` carries the last
     placed record + its top Y for the stack.                              */
  const barrelGeo = new THREE.CylinderGeometry(0.42, 0.42, 1.1, 10);
  function addContainer(c, base) {
    const kind = c.kind || 'crate';
    if (kind === 'barrel') {
      const m = new THREE.Mesh(barrelGeo, c.mat === 'wood' ? M.barrelWood : M.barrelMetal);
      const y = c.stack && base.topY ? base.topY + 0.55 : 0.55;
      m.position.set(c.x, y, c.z);
      m.rotation.y = c.ry || 0;
      m.castShadow = true; m.receiveShadow = true;
      scene.add(m); solids.push(m);
      colliders.push({ minX: c.x - 0.42, maxX: c.x + 0.42,
                       minZ: c.z - 0.42, maxZ: c.z + 0.42,
                       y0: c.stack ? Math.max(0, y - 0.55) : 0, y1: y + 1.05 });
      const rec = makeBreakable(m, colliders[colliders.length - 1], { kind, mat: c.mat });
      m.userData.breakable = rec; breakables.push(rec);
      if (c.stack && base.rec) base.rec.linked = [rec];
      base.rec = rec; base.topY = y + 0.55;
      return rec;
    }
    if (kind === 'chest') {
      const m = addBox(0.98, 0.7, 0.66, c.x, 0.35, c.z, M.chest,
                       { collide: true, cast: true, receive: true, ry: c.ry,
                         breakable: { kind: 'chest' } });
      base.rec = m.userData.breakable; base.topY = 0.7;
      return base.rec;
    }
    /* crate — legacy path (full-threshold pool, EXACT old placements) */
    const m = addBox(c.s, c.s * 0.92, c.s, c.x, c.s * 0.46, c.z, M.crate,
                     { collide: true, cast: true, receive: true, ry: c.ry,
                       breakable: { kind: 'crate' } });
    base.rec = m.userData.breakable; base.topY = c.s * 0.92;
    return base.rec;
  }
  function buildZoneContainers(zone) {
    const list = ASSETS.world.containers.zones[zone];
    if (!list) return;
    const base = {};
    for (const c of list) addContainer(c, base);
  }

  /* ========================================================================
     CORRIDOR (z 0 … -72)
     ======================================================================== */
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(WC.width, WC.length), M.floor);
  floor.rotation.x = -Math.PI / 2;
  floor.position.set(0, 0, -WC.length / 2);
  floor.receiveShadow = true;
  scene.add(floor); solids.push(floor);

  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(WC.width, WC.length), M.ceil);
  ceil.rotation.x = Math.PI / 2;
  ceil.position.set(0, WC.height, -WC.length / 2);
  scene.add(ceil); solids.push(ceil);

  /* corridor rear wall — CH-36.2: this wall is now the AIRLOCK BULKHEAD.
     Was one solid slab (WC.width+3 wide) + a decorative door: the CH-36
     home base parks north of it, so it rebuilds as two segments + a
     lintel around a 3 m mouth (hub.mouthW) and GAINS colliders — field
     traffic now flows through it (corridor ⇄ ramp vestibule ⇄ shuttle). */
  {
    const HB = ASSETS.hub;
    const segW = (WC.width + 3) / 2 - HB.mouthW / 2;
    addBox(segW, WC.height, 0.4, -(HB.mouthW / 2 + segW / 2), WC.height / 2, 0.2,
           M.wall, { collide: true, receive: true });
    addBox(segW, WC.height, 0.4, (HB.mouthW / 2 + segW / 2), WC.height / 2, 0.2,
           M.wall, { collide: true, receive: true });
    /* lintel over the mouth — thin slab above mouthH, collider y-aware so
       the player walks UNDER it (bay-door-wall pattern) */
    addBox(HB.mouthW + 0.2, WC.height - HB.mouthH, 0.4, 0,
           HB.mouthH + (WC.height - HB.mouthH) / 2, 0.2,
           M.wall, { collide: true, receive: true, y0: HB.mouthH, y1: WC.height });
  }
  /* the old decorative door leaves with the slab — the AIRLOCK sign +
     hazard sill + jambs below are built with the hub block (CH-36.2) */

  /* -- bay door wall at z = -72 ---------------------------------------------- */
  const mouth = WH.mouthW, mouthH = WH.mouthH, mZ = WH.mouthZ - 0.2;
  const frontW = WH.width / 2; // 17
  const sideSlabW = frontW - mouth / 2; // 15.2
  addBox(sideSlabW, WH.height, 0.4, -(mouth / 2 + sideSlabW / 2), WH.height / 2, mZ,
         M.hwall, { collide: true, receive: true, y1: WH.height });
  addBox(sideSlabW, WH.height, 0.4, (mouth / 2 + sideSlabW / 2), WH.height / 2, mZ,
         M.hwall, { collide: true, receive: true, y1: WH.height });
  addBox(mouth, WH.height - mouthH, 0.4, 0, mouthH + (WH.height - mouthH) / 2, mZ,
         M.hwall, { collide: true, receive: true, y0: mouthH, y1: WH.height });

  /* sliding bay door */
  const doorMesh = addBox(mouth + 0.2, mouthH + 0.1, 0.26, 0, (mouthH + 0.1) / 2 - 0.05,
                          WH.mouthZ - 0.05, M.door, { cast: true, receive: true });
  addBox(mouth + 0.6, 0.22, 0.5, 0, mouthH + 0.15, WH.mouthZ, M.frame);
  addBox(0.24, mouthH + 0.2, 0.5, -mouth / 2 - 0.1, mouthH / 2, WH.mouthZ, M.frame);
  addBox(0.24, mouthH + 0.2, 0.5, mouth / 2 + 0.1, mouthH / 2, WH.mouthZ, M.frame);
  addBox(mouth + 0.2, 0.14, 0.1, 0, mouthH - 0.35, WH.mouthZ - 0.2, M.warn);
  addBox(mouth + 0.4, 0.5, 0.06, 0, 2.62, WH.mouthZ + 0.21,
         new THREE.MeshBasicMaterial({ map: TEX.texSign('BAY 7') }), { solid: false });

  const doorCollider = {
    minX: -mouth / 2 - 0.1, maxX: mouth / 2 + 0.1,
    minZ: WH.mouthZ - 0.18, maxZ: WH.mouthZ + 0.18, y0: 0, y1: mouthH + 0.2,
  };
  colliders.push(doorCollider);

  const door = {
    mesh: doorMesh, col: doorCollider, open: false, t: 0,
    baseY: doorMesh.position.y,
    trigger() {
      if (this.open) return;
      this.open = true;
      doorCollider.minZ = doorCollider.maxZ = WH.mouthZ;
    },
    reset() {
      this.open = false; this.t = 0;
      doorMesh.position.y = this.baseY;
      doorCollider.minZ = WH.mouthZ - 0.18;
      doorCollider.maxZ = WH.mouthZ + 0.18;
    },
  };
  animated.push({
    update(dt) {
      if (!door.open || door.t >= 1) return;
      door.t = Math.min(1, door.t + dt / 1.6);
      const k = door.t * door.t * (3 - 2 * door.t);
      doorMesh.position.y = door.baseY + k * (mouthH + 0.2);
    },
  });

  /* -- corridor walls, ribs, lamps, alcoves ----------------------------------- */
  const lampCountMax = ASSETS.quality.maxPointLights;
  let lampCount = 0;
  let alcoveSide = 1;
  for (let i = 0; i < nSeg; i++) {
    const z0 = -i * segLen;
    const zc = z0 - segLen / 2;
    const isAlcove = WC.alcoveSegments.includes(i);

    for (const side of [-1, 1]) {
      if (isAlcove && side === alcoveSide) {
        const depth = 2.6;
        const wx = side * (halfW + depth + 0.15);
        addBox(0.3, WC.height, segLen + 0.6, wx, WC.height / 2, zc, M.wall, { collide: true, receive: true });
        addBox(depth + 0.3, WC.height, 0.3, side * (halfW + depth / 2), WC.height / 2, z0, M.wall, { collide: true });
        addBox(depth + 0.3, WC.height, 0.3, side * (halfW + depth / 2), WC.height / 2, z0 - segLen, M.wall, { collide: true });
        addBox(depth, WC.height, segLen, side * (halfW + depth / 2), WC.height, zc, M.ceil, {});
        const afloor = new THREE.Mesh(new THREE.PlaneGeometry(depth, segLen), M.floor);
        afloor.rotation.x = -Math.PI / 2;
        afloor.position.set(side * (halfW + depth / 2), 0, zc);
        afloor.receiveShadow = true;
        scene.add(afloor); solids.push(afloor);
        addBox(1.0, 1.0, 1.0, side * (halfW + 1.4), 0.5, zc, M.crate,
               { collide: true, cast: true, receive: true, ry: 0.4, breakable: true });
        continue;
      }

      const wx = side * (halfW + 0.15);
      addBox(0.3, WC.height, segLen, wx, WC.height / 2, zc, M.wall, { collide: true, receive: true });
      const c = col();
      if (side === 1) c.maxX = halfW - 0.06; else c.minX = -halfW + 0.06;

      if (i > 0) addBox(0.1, WC.height, 0.26, side * (halfW - 0.05), WC.height / 2, z0, M.rib, { solid: false });
    }
    if (isAlcove) alcoveSide *= -1;

    if (i === 0) {
      addBox(0.55, 0.1, WC.length - 0.4, -1.1, WC.height - 0.05, -WC.length / 2, M.inset, { solid: false });
      addBox(0.55, 0.1, WC.length - 0.4, 1.1, WC.height - 0.05, -WC.length / 2, M.inset, { solid: false });
      addBox(0.35, 0.05, WC.length - 0.4, -1.1, WC.height - 0.08, -WC.length / 2, M.strip, { solid: false });
      addBox(0.35, 0.05, WC.length - 0.4, 1.1, WC.height - 0.08, -WC.length / 2, M.strip, { solid: false });
    }

    if (i % WC.lampEvery === 0 && lampCount < lampCountMax) {
      const warm = WC.lampAlternateCoolWarm && (lampCount % 2 === 1);
      const lside = (lampCount % 2 === 0) ? -1 : 1;
      const color = warm ? P.lampWarm : P.lampCool;
      addBox(0.12, 0.5, 1.7, lside * (halfW - 0.07), 2.35, zc, M.inset, { solid: false });
      addBox(0.05, 0.14, 1.3, lside * (halfW - 0.12), 2.35, zc, M.lampBar, { solid: false });
      // v0.7: darker interior — dim lamps, tighter falloff (bring a flashlight)
      const pl = new THREE.PointLight(color, 0.42, 10, 1.9);
      pl.position.set(lside * (halfW - 0.75), 2.25, zc);
      scene.add(pl);
      lights.push({ light: pl, zone: 'corridor', base: 0.42 });
      lampCount++;
    }

    if (WC.hazardBandAt.includes(i)) {
      addBox(WC.width, 0.012, 0.8, 0, 0.011, zc, M.hazard, { solid: false });
    }

    const sign = WC.signs.find((s) => s.seg === i);
    if (sign) {
      const t = new THREE.Mesh(
        new THREE.PlaneGeometry(2.2, 0.55),
        new THREE.MeshBasicMaterial({ map: TEX.texSign(sign.text) })
      );
      const sx = sign.side * (halfW - 0.02);
      t.position.set(sx, 2.05, zc);
      t.rotation.y = sign.side === 1 ? -Math.PI / 2 : Math.PI / 2;
      scene.add(t);
    }
  }

  /* corridor pipes */
  for (const side of [-1, 1]) {
    addBox(0.1, 0.1, WC.length - 1, side * (halfW - 0.1), 2.72, -WC.length / 2, M.rib, { solid: false });
    addBox(0.14, 0.14, WC.length - 1, side * (halfW - 0.1), 2.5, -WC.length / 2, M.rib, { solid: false });
  }
  /* CH-06.2 — corridor containers: the per-zone mix in assets.world.
     containers.zones.corridor (crates moved in UNCHANGED + new barrels
     and a chest; the metal drum pair by the aft barrier stacks and
     chain-collapses like the hangar containers).                         */
  buildZoneContainers('corridor');
  for (const b of WC.barriers) {
    addBox(1.7, 1.15, 0.45, b.x, 0.575, b.z, M.inset, { collide: true, cast: true, receive: true, ry: b.ry });
    addBox(1.7, 0.09, 0.5, b.x, 1.2, b.z, M.hazard, { solid: false, ry: b.ry });
  }

  /* ========================================================================
     HANGAR BAY 7 (z -72.4 … -116.4, x ±17, y 11.4)
     ======================================================================== */
  batchZone('hangar');                       // CH-44.1 — merge bucket context
  const HZ0 = WH.mouthZ - 0.4;
  const HZ1 = WH.exitDoor.z;            // -116.2
  const HZC = (HZ0 + HZ1) / 2;
  const HWD = WH.width / 2;
  const HLEN = Math.abs(HZ1 - HZ0);

  /* floor + ceiling */
  const hfloor = new THREE.Mesh(new THREE.PlaneGeometry(WH.width, HLEN), M.hfloor);
  hfloor.rotation.x = -Math.PI / 2;
  hfloor.position.set(0, 0, HZC);
  hfloor.receiveShadow = true;
  scene.add(hfloor); solids.push(hfloor);

  const hceil = new THREE.Mesh(new THREE.PlaneGeometry(WH.width, HLEN), M.hceil);
  hceil.rotation.x = Math.PI / 2;
  hceil.position.set(0, WH.height, HZC);
  scene.add(hceil); solids.push(hceil);

  /* back wall with the EXIT mouth (10 m wide) + CYCLING EXIT DOOR -------- */
  const ED = WH.exitDoor;
  const edW = ED.width, edH = ED.height;
  const backSlab = (WH.width - edW) / 2;
  addBox(backSlab, WH.height, 0.6, -(edW / 2 + backSlab / 2), WH.height / 2, HZ1 - 0.1,
         M.hwall, { collide: true, receive: true, y1: WH.height });
  addBox(backSlab, WH.height, 0.6, (edW / 2 + backSlab / 2), WH.height / 2, HZ1 - 0.1,
         M.hwall, { collide: true, receive: true, y1: WH.height });
  addBox(edW, WH.height - edH, 0.6, 0, edH + (WH.height - edH) / 2, HZ1 - 0.1,
         M.hwall, { collide: true, receive: true, y0: edH, y1: WH.height });

  /* the exit door itself — slides up like the bay door */
  const edMesh = addBox(edW + 0.2, edH + 0.1, 0.5, 0, (edH + 0.1) / 2, HZ1 - 0.35,
                        M.chev, { cast: true, receive: true });
  addBox(edW + 1.2, 0.5, 0.7, 0, edH + 0.3, HZ1 - 0.45, M.hullDk);
  addBox(0.5, edH + 0.6, 0.7, -edW / 2 - 0.35, edH / 2, HZ1 - 0.45, M.hullDk);
  addBox(0.5, edH + 0.6, 0.7, edW / 2 + 0.35, edH / 2, HZ1 - 0.45, M.hullDk);
  const beaconMat = new THREE.MeshBasicMaterial({ color: P.beacons });
  addBox(0.4, 0.16, 0.16, -edW / 2 + 0.6, edH - 0.4, HZ1 - 0.75, beaconMat, { solid: false });
  addBox(0.4, 0.16, 0.16, edW / 2 - 0.6, edH - 0.4, HZ1 - 0.75, beaconMat, { solid: false });
  addBox(3.4, 0.6, 0.06, 0, edH + 1.1, HZ1 - 0.78,
         new THREE.MeshBasicMaterial({ map: TEX.texSign('EXIT') }), { solid: false });
  addBox(edW, 0.012, 1.2, 0, 0.012, HZ1 - 1.4, M.hazard, { solid: false });
  animated.push({
    update(t) {
      const on = Math.sin(t * 3.4) > 0.35 ? 1 : 0.1;
      beaconMat.color.setRGB(on, 0.07 * on, 0.05 * on);
    },
  });

  const edCollider = {
    minX: -edW / 2 - 0.1, maxX: edW / 2 + 0.1,
    minZ: HZ1 - 0.6, maxZ: HZ1 - 0.1, y0: 0, y1: edH + 0.2,
  };
  colliders.push(edCollider);

  const door2 = {
    mesh: edMesh, col: edCollider, open: false, t: 0,
    baseY: edMesh.position.y,
    trigger() {
      if (this.open) return;
      this.open = true;
      edCollider.minZ = edCollider.maxZ = HZ1 - 0.35;
    },
    reset() {
      this.open = false; this.t = 0;
      edMesh.position.y = this.baseY;
      edCollider.minZ = HZ1 - 0.6;
      edCollider.maxZ = HZ1 - 0.1;
    },
  };
  animated.push({
    update(dt) {
      if (!door2.open || door2.t >= 1) return;
      door2.t = Math.min(1, door2.t + dt / 2.4);
      const k = door2.t * door2.t * (3 - 2 * door2.t);
      edMesh.position.y = door2.baseY + k * (edH + 0.3);
    },
  });

  // faint red wash light over the exit
  const exitLight = new THREE.PointLight('#ff4038', 0.42, 14, 1.9);
  exitLight.position.set(0, 6.5, HZ1 - 4);
  scene.add(exitLight);
  lights.push({ light: exitLight, zone: 'hangar', base: 0.42 });

  /* side walls + entry doors */
  for (const side of [-1, 1]) {
    addBox(0.6, WH.height, HLEN, side * (HWD + 0.1), WH.height / 2, HZC,
           M.hwall, { collide: true, receive: true, y1: WH.height });
  }
  for (const sd of WH.sideDoors) {
    const sx = sd.side * (HWD - 0.02);
    addBox(0.5, 3.4, 2.6, sd.side * (HWD + 0.12), 1.7, sd.z, M.inset, { solid: false });
    addBox(0.1, 3.2, 2.2, sd.side * (HWD - 0.28), 1.6, sd.z, M.hullDk, { solid: false });
    addBox(0.14, 0.16, 2.4, sx, 3.35, sd.z, M.frame, { solid: false });
    addBox(0.14, 3.3, 0.14, sx, 1.65, sd.z - 1.25, M.frame, { solid: false });
    addBox(0.14, 3.3, 0.14, sx, 1.65, sd.z + 1.25, M.frame, { solid: false });
  }

  /* high-bay ceiling lights — v0.7: dimmer bay, pools of light between dark
     CH-44.2 — LIGHT BUDGET: the lampBar panels stay emissive on EVERY
     bay (the panel glow carries the read between pools), but the real
     point lights land on every OTHER bay. Hangar zone: 7 → 4 lights;
     the ceiling is documented in assets.world.quality.lightCeilings. */
  WH.highBays.forEach((hb, bi) => {
    addBox(2.6, 0.35, 2.6, hb.x, WH.height - 0.35, hb.z, M.hullDk, { solid: false });
    addBox(2.2, 0.16, 2.2, hb.x, WH.height - 0.62, hb.z, M.lampBar, { solid: false });
    if (bi % 2 === 1) return;              // CH-44.2 — emissive-only bay
    const pl = new THREE.PointLight(hb.warm ? P.lampWarm : P.lampCool, 0.55, 20, 1.7);
    pl.position.set(hb.x, WH.height - 1.6, hb.z);
    scene.add(pl);
    lights.push({ light: pl, zone: 'hangar', base: 0.55 });
  });
  for (const side of [-1, 1]) {
    addBox(0.2, 0.1, HLEN - 4, side * (HWD - 0.4), 0.28, HZC, M.strip, { solid: false });
  }

  /* pillars */
  for (const p of WH.pillars) {
    addBox(1.6, WH.height, 1.6, p.x, WH.height / 2, p.z, M.hwall,
           { collide: true, cast: true, receive: true, y1: WH.height });
    addBox(1.9, 0.3, 1.9, p.x, 0.15, p.z, M.hullDk, { solid: false });
  }

  /* CH-07.1 — more cover: corridor-style barricades in the open bays
     (same inset + hazard-band recipe as the corridor barriers above)     */
  for (const b of (WH.barriers || [])) {
    addBox(1.7, 1.15, 0.45, b.x, 0.575, b.z, M.inset, { collide: true, cast: true, receive: true, ry: b.ry });
    addBox(1.7, 0.09, 0.5, b.x, 1.2, b.z, M.hazard, { solid: false, ry: b.ry });
  }

  /* containers — BREAKABLE supply boxes (one rocket shell each, v0.7) */
  for (const c of WH.containers) {
    const mat = c.tone === 'r' ? M.conR : M.conB;
    addBox(2.6, 2.6, 6.2, c.x, 1.3, c.z, mat,
           { collide: true, cast: true, receive: true, ry: c.ry, breakable: true });
    if (c.stacked) {
      addBox(2.6, 2.6, 6.2, c.x, 3.9, c.z, c.tone === 'r' ? M.conB : M.conR,
             { collide: true, cast: true, receive: true, ry: c.ry + 0.06, breakable: true });
      /* breaking the base drops the stacked container too */
      breakables[breakables.length - 2].linked = [breakables[breakables.length - 1]];
    }
  }
  /* CH-06.2 — hangar containers: crates from the zone mix (positions
     unchanged) + a metal drum stack by the mid pillars + a chest.        */
  buildZoneContainers('hangar');

  /* parked dropship prop */
  const ds = WH.dropship;
  const ship = new THREE.Group();
  const hullM = M.hull, dkM = M.hullDk;
  const spart = (w, h, d, x, y, z, mat, rx = 0) => {
    const m = new THREE.Mesh(unitBox, mat);
    m.scale.set(w, h, d); m.position.set(x, y, z); m.rotation.x = rx;
    m.castShadow = true; m.receiveShadow = true;
    ship.add(m); return m;
  };
  spart(3.4, 1.7, 8.5, 0, 1.9, 0, hullM);
  spart(2.4, 1.2, 2.4, 0, 2.3, -3.6, dkM);
  spart(3.0, 0.5, 3.0, 0, 3.0, 0.5, dkM);
  spart(7.6, 0.28, 2.0, 0, 2.5, 1.2, hullM);
  spart(1.1, 1.1, 3.2, -3.6, 1.75, 1.2, dkM);
  spart(1.1, 1.1, 3.2, 3.6, 1.75, 1.2, dkM);
  spart(0.3, 2.2, 1.6, 0, 3.4, 3.9, hullM);
  spart(0.5, 0.9, 0.5, -1.0, 0.9, -2.2, dkM);
  spart(0.5, 0.9, 0.5, 1.0, 0.9, -2.2, dkM);
  ship.position.set(ds.x, 0, ds.z);
  ship.rotation.y = ds.ry;
  scene.add(ship);
  solids.push(...ship.children);
  {
    const ry = ds.ry;
    const hx = (Math.abs(7.6 * Math.cos(ry)) + Math.abs(8.5 * Math.sin(ry))) / 2 + 0.4;
    const hz = (Math.abs(8.5 * Math.cos(ry)) + Math.abs(7.6 * Math.sin(ry))) / 2;
    colliders.push({ minX: ds.x - hx, maxX: ds.x + hx, minZ: ds.z - hz, maxZ: ds.z + hz, y0: 0, y1: 4.5 });
  }

  /* 2nd story: catwalk deck + ramp */
  const CT = WH.catwalk;
  const deckW = CT.x1 - CT.x0;
  const deckL = CT.z0 - CT.z1;
  addBox(deckW, 0.3, Math.abs(deckL), (CT.x0 + CT.x1) / 2, CT.y - 0.15, (CT.z0 + CT.z1) / 2,
         M.grate, { receive: true, cast: true });
  floorZones.push({ x0: CT.x0, x1: CT.x1, z0: CT.z0, z1: CT.z1, h: CT.y, flat: true });

  /* CH-07.2 — support legs now DERIVE from the deck length (the old list
     was hard-coded for the 34 m deck; the extended gantry left the new
     south span unsupported). Even spread, ≥ 4 posts, ~8 m spacing.       */
  const deckSpan = Math.abs(CT.z0 - CT.z1);
  const NP = Math.max(4, Math.round(deckSpan / 8) + 1);
  const legZ0 = CT.z1 + 1.5, legZ1 = CT.z0 - 1.5;   /* north (ramp side) → south end */
  for (let i = 0; i < NP; i++) {
    const sz = legZ0 + (i * (legZ1 - legZ0)) / (NP - 1);
    addBox(0.4, CT.y, 0.4, CT.x1 - 0.4, CT.y / 2, sz, M.hullDk, { solid: false });
  }
  addBox(deckW, CT.y - 0.3, Math.abs(deckL), (CT.x0 + CT.x1) / 2, (CT.y - 0.3) / 2, (CT.z0 + CT.z1) / 2,
         M.hwall, { collide: true, receive: true, y1: CT.y - 0.3 });

  const railY0 = CT.y, railY1 = CT.y + 1.15;
  addBox(0.09, 1.15, Math.abs(deckL) - 3.4, CT.x1, railY0 + 0.575, (CT.z0 + CT.z1) / 2 - 1.7,
         M.inset, { collide: true, solid: true, y0: railY0, y1: railY1 });
  for (let pz = CT.z1 - 2; pz > CT.z0; pz -= 4) {
    addBox(0.14, 1.15, 0.14, CT.x1, railY0 + 0.575, pz, M.hullDk, { solid: false });
  }
  addBox(0.06, 0.05, Math.abs(deckL) - 3.4, CT.x1, railY1 - 0.02, (CT.z0 + CT.z1) / 2 - 1.7,
         M.amber, { solid: false });
  addBox(deckW - 0.4, 1.15, 0.09, (CT.x0 + CT.x1) / 2, railY0 + 0.575, CT.z0 + 0.15,
         M.inset, { collide: true, y0: railY0, y1: railY1 });

  const RP = CT.ramp;
  const runZ = RP.zBot - RP.zTop;
  const slopeLen = Math.hypot(runZ, CT.y);
  const slopeAngle = Math.atan2(CT.y, runZ);
  const ramp = new THREE.Mesh(unitBox, M.grate);
  ramp.scale.set(RP.x1 - RP.x0, 0.3, slopeLen + 0.5);
  ramp.position.set((RP.x0 + RP.x1) / 2, CT.y / 2 - 0.14, (RP.zTop + RP.zBot) / 2);
  ramp.rotation.x = -slopeAngle;
  ramp.receiveShadow = true; ramp.castShadow = true;
  scene.add(ramp); solids.push(ramp);
  floorZones.push({ x0: RP.x0, x1: RP.x1, z0: RP.zBot, z1: RP.zTop, h0: 0, h1: CT.y, slope: true });
  addBox(0.12, 0.22, slopeLen, RP.x0 + 0.06, CT.y / 2 + 0.1, (RP.zTop + RP.zBot) / 2, M.hazard,
         { solid: false, rx: -slopeAngle });
  addBox(0.12, 0.22, slopeLen, RP.x1 - 0.06, CT.y / 2 + 0.1, (RP.zTop + RP.zBot) / 2, M.hazard,
         { solid: false, rx: -slopeAngle });
  addBox(0.4, 3.2, 2.4, CT.x0 - 0.14, CT.y + 1.6, -100, M.inset, { solid: false });
  addBox(0.12, 3.0, 2.0, CT.x0 + 0.06, CT.y + 1.5, -100, M.hullDk, { solid: false });
  addBox(0.14, 0.16, 2.3, CT.x0 + 0.05, CT.y + 3.15, -100, M.frame, { solid: false });
  addBox(2.2, 0.5, 0.06, CT.x1 - 0.6, CT.y + 2.1, -100,
         new THREE.MeshBasicMaterial({ map: TEX.texSign('DECK 2') }), { solid: false });

  addBox(mouth + 1.2, 0.012, 1.4, 0, 0.012, WH.mouthZ - 1.4, M.hazard, { solid: false });

  /* ========================================================================
     THE VALLEY (z -117.4 … -158) — open-air dusk canyon
     ======================================================================== */
  batchZone('valley');                       // CH-44.1 — merge bucket context
  const VZ0 = WV.z0, VZ1 = WV.z1;
  const VLEN = Math.abs(VZ1 - VZ0);
  const VZC = (VZ0 + VZ1) / 2;

  /* canyon floor */
  const vfloor = new THREE.Mesh(new THREE.PlaneGeometry(WV.widthIn + 16, VLEN + 8), M.ground);
  vfloor.rotation.x = -Math.PI / 2;
  vfloor.position.set(0, 0, VZC - 2);
  vfloor.receiveShadow = true;
  scene.add(vfloor); solids.push(vfloor);

  /* mouth lip — floor transition strip at the hangar exit */
  addBox(WV.mouthW + 2, 0.012, 2.2, 0, 0.012, VZ0 + 0.4, M.hazard, { solid: false });

  /* funnel walls: 5 rock segments per side, width 26 → 15 */
  const NSEG_V = 5;
  const vSegLen = VLEN / NSEG_V;
  for (let i = 0; i < NSEG_V; i++) {
    const t = i / (NSEG_V - 1);
    const halfInner = (WV.widthIn / 2) + ((WV.widthOut / 2) - (WV.widthIn / 2)) * t;
    const segZ = VZ0 - (i + 0.5) * vSegLen;
    const h = WV.wallH * (0.85 + 0.3 * ((i * 7) % 3) / 2);   // ragged tops
    for (const side of [-1, 1]) {
      const m = addBox(9, h, vSegLen + 0.4, side * (halfInner + 4.5), h / 2 - 0.3, segZ,
                       M.rock, { collide: true, cast: true, receive: true,
                                 ry: side * (0.06 + 0.05 * ((i % 2) ? 1 : -1)) });
      m.receiveShadow = true;
      // darker base skirt so walls read tall
      addBox(9.2, h * 0.4, vSegLen + 0.5, side * (halfInner + 4.5), h * 0.2 - 0.3, segZ,
             M.rockDk, { solid: false });
    }
  }
  /* canyon→city transition: rock fillers seal the gap so the street opens
     cleanly out of the canyon (no sky holes between wall and buildings)  */
  for (const side of [-1, 1]) {
    addBox(10, WV.wallH + 3, 3, side * (WV.widthOut / 2 + 5), (WV.wallH + 3) / 2 - 0.3, VZ1 - 0.8,
           M.rock, { collide: true, cast: true, receive: true });
  }
  /* over-mouth rock face (above the hangar exit, outside is open sky) */
  addBox(WV.widthIn + 20, 6, 4, 0, edH + 3, VZ0 + 1.6,
         M.rock, { collide: true, cast: true, receive: true, y0: edH, y1: edH + 6 });

  /* boulders */
  for (const r of WV.rocks) {
    addBox(r.s, r.s * 0.72, r.s * 1.15, r.x, r.s * 0.36, r.z, M.rock,
           { collide: r.s > 1.4, cast: true, receive: true, ry: r.ry });
  }

  /* dead trees: trunk + two branches */
  for (const tr of WV.trees) {
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.09 * tr.s, 0.16 * tr.s, 3.4 * tr.s, 6), M.wood);
    trunk.position.set(tr.x, 1.7 * tr.s, tr.z);
    trunk.rotation.z = (Math.random() - 0.5) * 0.14;
    trunk.castShadow = true;
    scene.add(trunk); solids.push(trunk);
    const b1 = new THREE.Mesh(unitBox, M.wood);
    b1.scale.set(1.4 * tr.s, 0.08, 0.08);
    b1.position.set(tr.x + 0.3 * tr.s, 2.6 * tr.s, tr.z);
    b1.rotation.z = -0.5;
    scene.add(b1);
    const b2 = new THREE.Mesh(unitBox, M.wood);
    b2.scale.set(0.08, 0.08, 1.2 * tr.s);
    b2.position.set(tr.x - 0.2 * tr.s, 2.2 * tr.s, tr.z + 0.2);
    b2.rotation.z = 0.4;
    scene.add(b2);
  }

  /* grass tufts (cheap cones) */
  const grassGeo = new THREE.ConeGeometry(0.22, 0.55, 5);
  for (const gpos of WV.grass) {
    for (let k = 0; k < 3; k++) {
      const gm = new THREE.Mesh(grassGeo, M.moss);
      gm.position.set(gpos.x + (Math.random() - 0.5) * 0.8, 0.26,
                      gpos.z + (Math.random() - 0.5) * 0.8);
      gm.rotation.y = Math.random() * Math.PI;
      scene.add(gm);
    }
  }

  /* CH-06.2 — valley containers: wood barrels + a chest (the valley never
     had crates — the wood/metal debris split gets exercised out here).   */
  buildZoneContainers('valley');

  /* ========================================================================
     THE CITYSCAPE (z -156.6 … -214) — NEW v0.7: night streets
     ======================================================================== */
  batchZone('city');                         // CH-44.1 — merge bucket context
  const CC = ASSETS.world.city;
  const CZ0 = CC.z0, CZ1 = CC.z1;
  const CLEN = Math.abs(CZ1 - CZ0);
  const CZC = (CZ0 + CZ1) / 2;

  /* road surface */
  const croad = new THREE.Mesh(new THREE.PlaneGeometry(CC.streetHalf * 2 + 5, CLEN + 6), M.asphalt);
  croad.rotation.x = -Math.PI / 2;
  croad.position.set(0, 0, CZC + 2);
  croad.receiveShadow = true;
  scene.add(croad); solids.push(croad);

  /* sidewalks */
  for (const side of [-1, 1]) {
    const sw = new THREE.Mesh(new THREE.PlaneGeometry(3.4, CLEN + 6), M.walk);
    sw.rotation.x = -Math.PI / 2;
    sw.position.set(side * (CC.streetHalf + 2.2), 0.006, CZC + 2);
    sw.receiveShadow = true;
    scene.add(sw); solids.push(sw);
  }

  /* dashed lane stripes */
  for (let z = CZ0 - 3; z > CZ1 + 3; z -= CC.laneZEvery) {
    addBox(0.28, 0.012, 2.3, 0, 0.012, z, M.lane, { solid: false });
  }

  /* towers — seeded so the skyline is stable run-to-run */
  const B = CC.buildings;
  let bseed = B.seed;
  const rndB = () => {
    bseed = (bseed * 48271) % 2147483647;
    return bseed / 2147483647;
  };
  const buildMats = [M.buildA, M.buildB, M.buildC];
  let towerCount = 0;
  for (const side of [-1, 1]) {
    let z = CZ0 - 2;
    while (z > CZ1 + 5) {
      const depth = B.depthMin + rndB() * (B.depthMax - B.depthMin);
      const w = B.wMin + rndB() * (B.wMax - B.wMin);
      const h = B.hMin + rndB() * (B.hMax - B.hMin);
      const bx = side * (CC.streetHalf + 3.4 + w / 2 + rndB() * 2.5);
      const bz = z - depth / 2;
      addBox(w, h, depth, bx, h / 2 - 0.05, bz,
             buildMats[Math.floor(rndB() * buildMats.length)],
             { collide: true, cast: towerCount % 2 === 0, receive: true });
      towerCount++;
      z -= depth + B.gapMin + rndB() * (B.gapMax - B.gapMin);
    }
  }
  /* background skyline towers (unreachable silhouette depth) */
  for (let i = 0; i < 7; i++) {
    const side = i % 2 === 0 ? -1 : 1;
    const h = 20 + rndB() * 18;
    const w = 12 + rndB() * 10;
    addBox(w, h, 10, side * (30 + rndB() * 9), h / 2 - 0.05,
           CZ0 - 4 - i * (CLEN / 7), buildMats[(i + 1) % 3], { solid: false });
  }

  /* street lamps — poles + emissive heads; lit ones carry a point light */
  for (const lp of CC.lamps) {
    addBox(0.14, 5.4, 0.14, lp.x, 2.7, lp.z, M.lampPole, { cast: true });
    addBox(1.5, 0.1, 0.14, lp.x - Math.sign(lp.x) * 0.75, 5.42, lp.z, M.lampPole, { solid: false });
    addBox(0.5, 0.12, 0.3, lp.x - Math.sign(lp.x) * 1.4, 5.36, lp.z, M.lampHead, { solid: false });
    if (lp.lit) {
      const ll = new THREE.PointLight('#ffdba8', 1.0, 22, 1.6);
      ll.position.set(lp.x - Math.sign(lp.x) * 1.4, 5.1, lp.z);
      scene.add(ll);
      lights.push({ light: ll, zone: 'city', base: 1.0 });
    }
  }

  /* neon signs — backing plate + stanchions + glowing face toward the street */
  for (const s of CC.signs) {
    const side = Math.sign(s.x);
    addBox(0.16, 1.5, 3.4, s.x + side * 0.14, s.y, s.z, M.lampPole, { solid: false });
    addBox(0.09, s.y - 0.6, 0.12, s.x, (s.y - 0.6) / 2, s.z + 1.4, M.lampPole, { solid: false });
    addBox(0.09, s.y - 0.6, 0.12, s.x, (s.y - 0.6) / 2, s.z - 1.4, M.lampPole, { solid: false });
    const face = new THREE.Mesh(
      new THREE.PlaneGeometry(3.2, 1.3),
      new THREE.MeshBasicMaterial({ map: TEX.texNeon(s.text, s.color) })
    );
    face.position.set(s.x - side * 0.06, s.y, s.z);
    face.rotation.y = side > 0 ? -Math.PI / 2 : Math.PI / 2;
    scene.add(face);
  }

  /* wrecked skimmer hulks (two-box props, solid) */
  for (const car of CC.cars) {
    const bodyM = new THREE.MeshLambertMaterial({ color: '#39424c' });
    const cabM = new THREE.MeshLambertMaterial({ color: '#242b32' });
    addBox(2.3, 0.85, 5.2, car.x, 0.62, car.z, bodyM,
           { collide: true, cast: true, receive: true, ry: car.ry });
    addBox(1.9, 0.75, 2.2, car.x, 1.35, car.z - 0.5, cabM,
           { cast: true, receive: true, ry: car.ry });
    addBox(0.5, 0.35, 0.5, car.x, 0.7, car.z + 1.2, M.hazard,
           { solid: false, ry: car.ry });
  }

  /* concrete planters with dead shrubs */
  for (const pl2 of CC.planters) {
    addBox(1.6, 0.7, 1.6, pl2.x, 0.35, pl2.z, M.planter,
           { collide: true, cast: true, receive: true });
    const shrub = new THREE.Mesh(new THREE.ConeGeometry(0.55, 0.9, 6), M.moss);
    shrub.position.set(pl2.x, 1.1, pl2.z);
    shrub.castShadow = true;
    scene.add(shrub);
  }

  /* CH-06.2 — city containers: crates from the zone mix (positions
     unchanged) + metal/wood barrels + a chest near the extraction pad.   */
  buildZoneContainers('city');

  /* side boundary walls behind the building line (keep the player in-street) */
  for (const side of [-1, 1]) {
    addBox(1.2, 14, CLEN + 6, side * (CC.streetHalf + 4.6), 7, CZC + 2,
           M.buildB, { collide: true, receive: true, y1: 14 });
  }
  /* end wall behind the extraction pad — v0.8: GATE into the expanse */
  const GATE_W = 9;
  const gwSlab = (CC.streetHalf * 2 + 12 - GATE_W) / 2;
  addBox(gwSlab, 24, 3, -(GATE_W / 2 + gwSlab / 2), 12 - 0.05, CZ1 - 1.2,
         M.buildC, { collide: true, cast: true, receive: true });
  addBox(gwSlab, 24, 3, (GATE_W / 2 + gwSlab / 2), 12 - 0.05, CZ1 - 1.2,
         M.buildC, { collide: true, cast: true, receive: true });
  addBox(GATE_W, 16, 3, 0, 8 + 8 - 0.05, CZ1 - 1.2,
         M.buildC, { collide: true, receive: true, y0: 8, y1: 24 });
  addBox(GATE_W + 1.4, 0.5, 0.6, 0, 8.2, CZ1 - 1.2, M.hullDk, { solid: false });
  {
    const gateSign = new THREE.Mesh(
      new THREE.PlaneGeometry(4.2, 0.9),
      new THREE.MeshBasicMaterial({ map: TEX.texNeon('THE WILDS', '#4fffd8') })
    );
    gateSign.position.set(0, 6.8, CZ1 + 0.35);
    scene.add(gateSign);
  }

  /* ========================================================================
     CH-08.1 — CORRIDOR CONNECTORS joining the city blocks (assets.world.
     city.corridors segment list). Each segment encloses its stretch of
     street: pinch walls at ±pass/2, solid filler masses out to the
     boundary wall line, a roofed span, and GATED END WALLS (center
     opening + side slabs — the expanse-gate recipe) carrying sliding
     doors that auto-open from either side (door2 pattern). Two dim point
     lights per connector are zone-tagged 'citycorridor' — main.js only
     fades those in while the player is under a roof, so the outdoor city
     wash goes dark indoors exactly like the corridor/hangar zones do.
     ======================================================================== */
  const cityCorridors = ASSETS.world.city.corridors || [];
  const corridorDoors = [];
  {
    const BW_INNER = CC.streetHalf + 4.0;          // boundary wall inner face (15.0)
    for (const C of cityCorridors) {
      const half = C.pass / 2;
      const len = Math.abs(C.z0 - C.z1);
      const czc = (C.z0 + C.z1) / 2;

      /* pinch walls — the passage throat */
      for (const side of [-1, 1]) {
        addBox(0.5, C.roofY, len + 0.6, side * (half + 0.25), C.roofY / 2, czc,
               M.wall, { collide: true, cast: true, receive: true });
      }
      /* filler masses — seal sidewalk + building line out to the boundary */
      const fW = BW_INNER - (half + 0.5);
      for (const side of [-1, 1]) {
        addBox(fW, C.roofY + 1.2, len + 0.6, side * (half + 0.5 + fW / 2), (C.roofY + 1.2) / 2, czc,
               M.buildB, { collide: true, receive: true });
      }
      /* roof slab — underside at roofY (bolt ceiling, jump cover, indoor read) */
      addBox(BW_INNER * 2 + 2.4, 0.4, len + 0.6, 0, C.roofY + 0.2, czc,
             M.ceil, { cast: true, receive: true });

      /* gated end walls + sliding doors (both ends) */
      for (const gz of [C.z0, C.z1]) {
        const slabW = BW_INNER - half;
        for (const side of [-1, 1]) {
          addBox(slabW, C.roofY + 1.2, 0.6, side * (half + slabW / 2), (C.roofY + 1.2) / 2, gz,
                 M.buildC, { collide: true, cast: true, receive: true });
        }
        addBox(C.pass, C.roofY - C.doorH, 0.6, 0, C.doorH + (C.roofY - C.doorH) / 2, gz,
               M.buildC, { collide: true, receive: true });
        addBox(C.doorW + 0.6, 0.22, 0.5, 0, C.doorH + 0.15, gz, M.frame, { solid: false });

        const dMesh = addBox(C.doorW, C.doorH + 0.1, 0.3, 0, (C.doorH + 0.1) / 2 - 0.05, gz,
                             M.door, { cast: true, receive: true });
        const dCol = {
          minX: -C.doorW / 2 - 0.1, maxX: C.doorW / 2 + 0.1,
          minZ: gz - 0.18, maxZ: gz + 0.18, y0: 0, y1: C.doorH + 0.2,
        };
        colliders.push(dCol);
        corridorDoors.push({
          mesh: dMesh, col: dCol, z: gz, open: false, t: 0,
          baseY: dMesh.position.y, openAt: C.openAt,
          trigger() {                     /* CH-08.2 — true only on first open */
            if (this.open) return false;
            this.open = true;
            dCol.minZ = dCol.maxZ = gz;
            return true;
          },
          reset() {
            this.open = false; this.t = 0;
            dMesh.position.y = this.baseY;
            dCol.minZ = gz - 0.18; dCol.maxZ = gz + 0.18;
          },
        });
      }

      /* dim interior lights — 'citycorridor' zone (see header note) */
      const cLightA = new THREE.PointLight('#ffb27a', 0.55, 13, 1.8);
      cLightA.position.set(-2.2, C.roofY - 1.1, czc - 1.5);
      scene.add(cLightA);
      lights.push({ light: cLightA, zone: 'citycorridor', base: 0.55 });
      const cLightB = new THREE.PointLight('#9fb6ff', 0.5, 13, 1.8);
      cLightB.position.set(2.2, C.roofY - 1.1, czc + 1.5);
      scene.add(cLightB);
      lights.push({ light: cLightB, zone: 'citycorridor', base: 0.5 });

      /* neon plate on the north gate face */
      const face = new THREE.Mesh(
        new THREE.PlaneGeometry(3.6, 0.9),
        new THREE.MeshBasicMaterial({ map: TEX.texNeon(C.sign.text, C.sign.color) })
      );
      face.position.set(0, C.doorH + 0.75, C.z0 + 0.35);
      scene.add(face);
    }
    /* shared slide animation for every connector door (bay-door style) */
    animated.push({
      update(t, dt) {
        for (const d of corridorDoors) {
          if (!d.open || d.t >= 1) continue;
          d.t = Math.min(1, d.t + dt / 1.4);
          const k = d.t * d.t * (3 - 2 * d.t);
          d.mesh.position.y = d.baseY + k * (d.col.y1 - 0.1);
        }
      },
    });
  }

  /* CH-08.3 — the mid-road extraction beacon is GONE (user 2026-10-28).
     The v0.7 landmark prop (post + topper + lamp + EXTRACTION plate +
     hazard pad + pulsing light) stood in the middle of the south block.
     It was decorative — the win trigger reads the deep-ocean BUOY — so
     the delete branch of f3 applies with no relocation; the extraction
     flow (H070) and every other zone's extraction posts are untouched. */

  /* ========================================================================
     CH-08.2 — OPTIONAL TELEPORT ENTRIES (assets.world.city.transits).
     Express pads pairing the open blocks: stand on a pad ~0.45 s and the
     player warps to its mate — drone and beast ride along (they leash to
     the player, so stranding them behind a closed gate is impossible).
     5 s pair cooldown prevents ping-ponging on the landing spot.        */
  const transits = [];
  {
    const padGeo = new THREE.BoxGeometry(1, 1, 1);
    for (const tp of ASSETS.world.city.transits || []) {
      const base = new THREE.Mesh(padGeo, M.hazard);
      base.scale.set(2.2, 0.06, 2.2);
      base.position.set(tp.x, 0.03, tp.z);
      base.receiveShadow = true;
      scene.add(base);
      const ring = new THREE.Mesh(padGeo, M.frame);
      ring.scale.set(1.5, 0.03, 1.5);
      ring.position.set(tp.x, 0.075, tp.z);
      scene.add(ring);
      const pole = new THREE.Mesh(padGeo, M.lampPole);
      pole.scale.set(0.09, 2.3, 0.09);
      pole.position.set(tp.x + 1.3, 1.15, tp.z + 1.3);
      scene.add(pole);
      const plate = new THREE.Mesh(
        new THREE.PlaneGeometry(1.7, 0.42),
        new THREE.MeshBasicMaterial({ map: TEX.texSign(tp.label) })
      );
      plate.position.set(tp.x + 1.3, 2.15, tp.z + 1.24);
      scene.add(plate);
      transits.push({ x: tp.x, z: tp.z, toX: tp.toX, toZ: tp.toZ,
                      label: tp.label, standT: 0, cd: 0 });
    }
  }
  /* per-frame stand check — main.js calls this while playing.
     NOTE: player.pos.y is the EYE height (~1.62 standing) — the ground
     gate is 2.5 so a pad triggers on foot but not at a jump's apex. */
  function updateTransits(dt, game) {
    const p = game.player.pos;
    for (const t of transits) {
      t.cd = Math.max(0, t.cd - dt);
      const inside = Math.abs(p.x - t.x) < 1.1 && Math.abs(p.z - t.z) < 1.1 && p.y < 2.5;
      if (!inside) { t.standT = 0; continue; }
      if (t.cd > 0) continue;
      t.standT += dt;
      if (t.standT < 0.45) continue;
      t.standT = 0; t.cd = 5;
      for (const o of transits) if (o.toX === t.x && o.toZ === t.z) o.cd = 5;
      p.x = t.toX; p.z = t.toZ;
      /* companions ride along (leash would drag them through closed gates) */
      if (game.companions) {
        if (game.companions.drone && game.companions.drone.pos) {
          game.companions.drone.pos.set(t.toX + 1.4, 2, t.toZ + 1);
        }
        if (game.companions.pet && game.companions.pet.group) {
          game.companions.pet.group.position.set(t.toX - 1.4, 0, t.toZ + 1);
        }
      }
      game.sfx.tone({ type: 'sine', f0: 220, f1: 880, dur: 0.28, gain: 0.22 });
      game.hud.flashWhite(0.35);
      game.hud.toast('TRANSIT → ' + t.label, 1400);
    }
  }
  function resetTransits() {
    for (const t of transits) { t.standT = 0; t.cd = 0; }
  }

  /* city zone lights — cool wash + warm neon pockets (zone-culled) */
  const cityA = new THREE.PointLight('#4f6f9f', 0.85, 44, 1.8);
  cityA.position.set(0, 12, -168);
  scene.add(cityA);
  lights.push({ light: cityA, zone: 'city', base: 0.85 });
  const cityB = new THREE.PointLight('#46597f', 0.8, 48, 1.8);
  cityB.position.set(0, 13, -192);
  scene.add(cityB);
  lights.push({ light: cityB, zone: 'city', base: 0.8 });

  /* valley dusk lights (zone-culled) */
  const duskA = new THREE.PointLight('#e08a4e', 0.85, 34, 1.7);
  duskA.position.set(0, 9, -122);
  scene.add(duskA);
  lights.push({ light: duskA, zone: 'valley', base: 0.85 });
  const duskB = new THREE.PointLight('#9fd4ee', 0.8, 34, 1.7);
  duskB.position.set(0, 10, -144);
  scene.add(duskB);
  lights.push({ light: duskB, zone: 'valley', base: 0.8 });

  /* ========================================================================
     THE EXPANSE (v0.8) — procedurally tiled wilderness beyond the city.
     Auto-fills the map with biome-aware tile sets; the OCEAN occupies the
     last 2 rows (8 tiles ≈ 4× the area of any other tile set).
     ======================================================================== */
  const EX = ASSETS.world.expanse;
  const TS = EX.tileSize;
  const ROWS = EX.layout.length;
  const OCEAN_Z0 = EX.z0 - (ROWS - EX.oceanRows) * TS;   // where the ocean begins
  const Z_END = EX.z0 - ROWS * TS;                        // far edge of the world
  const X_HALF = (EX.cols * TS) / 2;

  /* seeded rng so the wilds are stable run-to-run */
  let eseed = EX.seed;
  const rndE = () => {
    eseed = (eseed * 48271) % 2147483647;
    return eseed / 2147483647;
  };

  const harvests = [];        // { mesh, kind:'plant'|'ore', sub, x, z, depleted, respT }
  const fishZones = [];       // { x, z, r }
  const animalSpawns = [];    // { kind:'bird'|'rodent', x, z, biome }
  const expanseSpawns = [];   // enemy spawn defs (fewer, level-scaled per tile)
  const waterAnims = [];      // { mat, speed } — scrolling water UVs

  const tileCenter = (cx, rz) => [
    (cx - (EX.cols - 1) / 2) * TS,
    EX.z0 - (rz + 0.5) * TS,
  ];

  /* -- prop primitives ---------------------------------------------------- */
  function addTree(x, z, s, leafMat) {
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.1 * s, 0.17 * s, 2.6 * s, 6), M.trunk);
    trunk.position.set(x, 1.3 * s, z);
    trunk.castShadow = true;
    scene.add(trunk); solids.push(trunk);
    /* CH-44.1 — crowns ride the merge batches (CH-44.1 shadow-caster
       audit: decorative foliage stops casting; trunks keep contact)  */
    for (let i = 0; i < 2; i++) {
      const c = new THREE.Mesh(new THREE.ConeGeometry((1.15 - i * 0.28) * s, 1.7 * s, 7),
        i === 0 ? leafMat : M.leafDk);
      c.position.set(x, (2.6 + i * 0.95) * s, z);
      batchMesh(c, false, false, false);
    }
  }
  function addPine(x, z, s, snowy) {
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.09 * s, 0.14 * s, 1.6 * s, 6), M.trunk);
    trunk.position.set(x, 0.8 * s, z);
    scene.add(trunk); solids.push(trunk);
    for (let i = 0; i < 3; i++) {
      const c = new THREE.Mesh(new THREE.ConeGeometry((0.95 - i * 0.24) * s, 1.25 * s, 6),
        snowy && i === 2 ? M.snowG : (i % 2 ? M.leafDk : M.leaf));
      c.position.set(x, (1.5 + i * 0.8) * s, z);
      batchMesh(c, false, false, false);       // CH-44.1 — merged crowns
    }
  }
  function addPalm(x, z) {
    const t = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.16, 3.4, 6), M.trunk);
    t.position.set(x, 1.7, z); t.rotation.z = (rndE() - 0.5) * 0.24;
    t.castShadow = true;
    scene.add(t); solids.push(t);
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const frond = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.05, 0.4),
        i % 2 ? M.leaf : M.leafDk);
      frond.position.set(x + Math.cos(a) * 0.85, 3.45, z + Math.sin(a) * 0.85);
      frond.rotation.y = -a; frond.rotation.z = -0.45;
      batchMesh(frond, false, false, false);   // CH-44.1 — merged fronds
    }
  }
  /* CH-09.1 — dead tree: bare trunk + two snapped branches. The WASH
     set's skeletal read — leafless so it never reads as the forest.   */
  function addDeadTree(x, z, s) {
    const t = new THREE.Mesh(new THREE.CylinderGeometry(0.07 * s, 0.16 * s, 2.4 * s, 6), M.trunk);
    t.position.set(x, 1.2 * s, z);
    t.rotation.z = (rndE() - 0.5) * 0.2;
    t.castShadow = true;
    scene.add(t); solids.push(t);
    for (let i = 0; i < 2; i++) {
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.04 * s, 0.06 * s, 0.9 * s, 5), M.trunk);
      b.position.set(x + (i ? 0.22 : -0.26) * s, (1.7 + i * 0.4) * s, z + (rndE() - 0.5) * 0.3);
      b.rotation.z = i ? -0.9 : 0.8;
      batchMesh(b, false, false, false);       // CH-44.1 — merged branches
    }
  }
  function addCactus(x, z) {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.26, 1.7, 7), M.cactus);
    b.position.set(x, 0.85, z); b.castShadow = true;
    scene.add(b); solids.push(b);
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.13, 0.8, 6), M.cactus);
    arm.position.set(x + 0.34, 1.15, z); arm.rotation.z = -0.9;
    batchMesh(arm, false, false, false);       // CH-44.1 — merged arm
  }
  function addBoulder(x, z, s, mat) {
    const m = new THREE.Mesh(new THREE.IcosahedronGeometry(s * 0.62, 0), mat || M.mtRock);
    m.position.set(x, s * 0.4, z);
    m.rotation.set(rndE() * 3, rndE() * 3, rndE() * 3);
    m.castShadow = s > 1.1;
    /* CH-44.1 — boulders merge per row too; the bucket carries solid so
       the merged mesh lands back in `solids` (bullets still hit them) */
    batchMesh(m, s > 1.1, false, true);
    if (s > 1.15) {
      colliders.push({
        minX: x - s * 0.5, maxX: x + s * 0.5, minZ: z - s * 0.5, maxZ: z + s * 0.5,
        y0: 0, y1: s * 0.85,
      });
    }
    return m;
  }
  function addBush(x, z, withFlower, harvestable) {
    const g = new THREE.Group();
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.42, 7, 6), M.leaf);
    b.scale.set(1, 0.72, 1); b.position.y = 0.3;
    g.add(b);
    if (withFlower) {
      for (let i = 0; i < 4; i++) {
        const f = new THREE.Mesh(new THREE.SphereGeometry(0.06, 5, 4),
          rndE() < 0.5 ? M.flowerA : M.flowerB);
        f.position.set((rndE() - 0.5) * 0.6, 0.5 + rndE() * 0.2, (rndE() - 0.5) * 0.6);
        g.add(f);
      }
    }
    g.position.set(x, 0, z);
    if (harvestable) {
      scene.add(g);
      harvests.push({ mesh: g, kind: 'plant', x, z, depleted: false, respT: 0 });
    } else {
      /* CH-44.1 — decorative bushes bake into the batches (world-space
         matrices; the harvestable ones stay real groups for regrow)   */
      g.updateMatrixWorld(true);
      for (const c of g.children) batchPush(c.geometry, c.material, false, false, false, c.matrixWorld);
    }
    return g;
  }
  function addOreRock(x, z) {
    const E = ASSETS.ecology;
    const sub = E.ores[Math.floor(rndE() * E.ores.length)];
    const oreColor = { ferrite: '#c98a4f', titanium: '#9fc4d8', gallium: '#7ea8f2', crystal: '#6ff2ff' }[sub];
    const g = new THREE.Group();
    const rock = new THREE.Mesh(new THREE.IcosahedronGeometry(0.62, 0), M.mtRock);
    rock.position.y = 0.36; rock.castShadow = true;
    g.add(rock);
    for (let i = 0; i < 3; i++) {
      const sp = new THREE.Mesh(new THREE.OctahedronGeometry(0.09, 0),
        new THREE.MeshBasicMaterial({ color: oreColor }));
      sp.position.set((rndE() - 0.5) * 0.7, 0.25 + rndE() * 0.4, (rndE() - 0.5) * 0.7);
      g.add(sp);
    }
    g.position.set(x, 0, z);
    scene.add(g);
    solids.push(rock);
    harvests.push({ mesh: g, kind: 'ore', sub, x, z, depleted: false, respT: 0 });
  }
  function addTuft(x, z, dry) {
    for (let k = 0; k < 3; k++) {
      const gm = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.5, 4),
        dry ? M.turfDry : M.leaf);
      gm.position.set(x + (rndE() - 0.5) * 0.7, 0.24, z + (rndE() - 0.5) * 0.7);
      gm.rotation.y = rndE() * Math.PI;
      batchMesh(gm, false, false, false);      // CH-44.1 — merged tufts
    }
  }
  function addWaterPlane(x, z, w, d, mat, y = 0.42) {
    const p = new THREE.Mesh(new THREE.PlaneGeometry(w, d), mat);
    p.rotation.x = -Math.PI / 2;
    p.position.set(x, y, z);
    scene.add(p);
    waterAnims.push({ mat, speed: mat === M.waterDeep ? 0.03 : 0.05 });
    return p;
  }

  /* CH-09.2 — per-tile harvest/ore stamp, driven by the
     assets.world.expanse.harvest config (bushes = count · ore = floor
     guaranteed + fractional chance of one extra · tufts = count). The
     five new canyon-country sets stamp through this so the config IS
     the tuning surface (proj.tunables); legacy sets keep their
     hand-stamped values byte-identically.                             */
  function stampHarvest(biome, cx, cz, jM = 8.5) {
    const HV = EX.harvest[biome];
    if (!HV) return;
    const jj = (m) => (rndE() - 0.5) * 2 * m;   // own jitter — stampTile's j is scoped there
    for (let i = 0; i < (HV.tufts || 0); i++) addTuft(cx + jj(jM), cz + jj(jM), true);
    for (let i = 0; i < (HV.bushes || 0); i++)
      addBush(cx + jj(jM), cz + jj(jM), rndE() < 0.4, true);
    const hvOre = HV.ore || 0;
    const n = Math.floor(hvOre) + (rndE() < hvOre % 1 ? 1 : 0);
    for (let i = 0; i < n; i++) addOreRock(cx + jj(jM), cz + jj(jM));
  }

  /* -- per-biome tile stamp ------------------------------------------------ */
  function stampTile(biome, cx, cz, row) {
    batchZone('ex' + row);                   // CH-44.1 — PER-ROW buckets keep
                                             // frustum culling granular in the
                                             // wilds (only visible rows draw)
    const groundMats = {
      park: M.turf, grassland: M.turf, trail: M.turf, forest: M.turf,
      riverbank: M.turf, steppe: M.turfDry, desert: M.sand, snowcap: M.snowG,
      mountain: M.mtRock, beach: M.sand, oceanbay: M.sand, ocean: M.sand,
      waterfall: M.mtRock,
      /* CH-09.1 — the canyon-country ring + south badlands */
      wash: M.cracked, canyon: M.mtRock, basin: M.mtRock,
      ridge: M.mtRock, badlands: M.badland,
    };
    const gm = groundMats[biome] || M.turf;
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(TS, TS), gm);
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(cx, 0, cz);
    floor.receiveShadow = true;
    /* CH-44.1 — tile floors merge PER ROW too (solid bucket: flushBatches
       puts the merged floor mesh into `solids`, so bullets keep hitting
       the ground); receive stays on.                                    */
    batchMesh(floor, false, true, true);

    const j = (m = 9.5) => (rndE() - 0.5) * 2 * m;   // scatter jitter

    switch (biome) {
      case 'park':
        addTree(cx + j(), cz + j(8), 0.9 + rndE() * 0.4, M.leaf);
        addTree(cx + j(), cz + j(8), 0.8 + rndE() * 0.4, M.leaf);
        addBush(cx + j(), cz + j(), rndE() < 0.7, true);
        addBush(cx + j(), cz + j(), rndE() < 0.7, true);
        addBoulder(cx + j(8), cz + j(8), 0.9 + rndE() * 0.5, M.mtRock);
        for (let i = 0; i < 3; i++) addTuft(cx + j(), cz + j(), false);
        animalSpawns.push({ kind: 'bird', x: cx, z: cz, biome });
        break;
      case 'grassland':
        for (let i = 0; i < 6; i++) addTuft(cx + j(), cz + j(), false);
        addBush(cx + j(), cz + j(), rndE() < 0.5, true);
        animalSpawns.push({ kind: 'rodent', x: cx + j(), z: cz + j(), biome });
        animalSpawns.push({ kind: 'bird', x: cx, z: cz, biome });
        break;
      case 'trail': {
        /* dirt path strip runs along z through the tile */
        const path = new THREE.Mesh(new THREE.PlaneGeometry(2.6, TS), M.dirt);
        path.rotation.x = -Math.PI / 2;
        path.position.set(cx, 0.012, cz);
        path.receiveShadow = true;
        scene.add(path);
        for (let i = 0; i < 3; i++) {
          addTree(cx + (rndE() < 0.5 ? -1 : 1) * (3.4 + rndE() * 5), cz + j(9),
                  0.9 + rndE() * 0.4, M.leaf);
        }
        addBush(cx + j(6), cz + j(), rndE() < 0.5, true);
        break;
      }
      case 'forest':
        for (let i = 0; i < 5; i++) {
          addTree(cx + j(), cz + j(9), 1.0 + rndE() * 0.6, M.leaf);
        }
        addBush(cx + j(7), cz + j(7), false, true);
        addBush(cx + j(7), cz + j(7), false, true);
        animalSpawns.push({ kind: 'rodent', x: cx + j(), z: cz + j(), biome });
        animalSpawns.push({ kind: 'bird', x: cx, z: cz, biome });
        break;
      case 'riverbank': {
        /* river strip runs along z through the tile centre */
        addWaterPlane(cx, cz, 7.5, TS, M.water);
        fishZones.push({ x: cx, z: cz, r: 4.5 });
        addBush(cx - 6.2 + j(1.4), cz + j(), rndE() < 0.6, true);
        addBush(cx + 6.2 + j(1.4), cz + j(), rndE() < 0.6, true);
        for (let i = 0; i < 2; i++) addTuft(cx + (rndE() < 0.5 ? -6 : 6) + j(1.4), cz + j(9), false);
        addBoulder(cx + 8 + j(1.5), cz + j(8), 0.8 + rndE() * 0.5, M.mtRock);
        break;
      }
      case 'steppe':
        for (let i = 0; i < 5; i++) addTuft(cx + j(), cz + j(), true);
        addBoulder(cx + j(9), cz + j(9), 0.9 + rndE() * 0.6, M.mtRock);
        if (rndE() < 0.5) addOreRock(cx + j(8), cz + j(8));
        animalSpawns.push({ kind: 'rodent', x: cx + j(), z: cz + j(), biome });
        break;
      case 'waterfall': {
        /* cliff wall at the far edge + falling water + pool */
        addBox(TS, 7, 2.2, cx, 3.5, cz - TS / 2 + 1.1, M.rock,
               { collide: true, cast: true, receive: true });
        const fw = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 6.4), M.falls);
        fw.position.set(cx, 3.1, cz - TS / 2 + 2.3);
        scene.add(fw);
        waterAnims.push({ mat: M.falls, speed: 0.5 });
        addWaterPlane(cx, cz + 3.4, 12, 9, M.water);
        fishZones.push({ x: cx, z: cz + 3.4, r: 4.5 });
        addOreRock(cx + j(8), cz + j(6));
        addBoulder(cx + j(8), cz + j(9), 1.2 + rndE() * 0.6, M.rock);
        break;
      }
      case 'desert':
        addCactus(cx + j(8), cz + j(8));
        addCactus(cx + j(8), cz + j(8));
        for (let i = 0; i < 2; i++) {
          addBoulder(cx + j(9), cz + j(9), 1.0 + rndE() * 0.7, M.sand);
        }
        addOreRock(cx + j(8), cz + j(8));
        animalSpawns.push({ kind: 'rodent', x: cx + j(), z: cz + j(), biome });
        break;
      case 'snowcap':
        for (let i = 0; i < 3; i++) addPine(cx + j(9), cz + j(9), 1.0 + rndE() * 0.5, true);
        addOreRock(cx + j(8), cz + j(8));
        addBoulder(cx + j(8), cz + j(8), 1.0 + rndE() * 0.5, M.ice);
        break;
      case 'mountain':
        for (let i = 0; i < 3; i++) {
          addBoulder(cx + j(9), cz + j(9), 1.2 + rndE() * 0.8, M.mtRock);
        }
        addPine(cx + j(8), cz + j(8), 0.9 + rndE() * 0.3, false);
        addOreRock(cx + j(8), cz + j(8));
        addOreRock(cx + j(8), cz + j(8));
        animalSpawns.push({ kind: 'bird', x: cx, z: cz, biome });
        break;
      case 'beach': {
        addPalm(cx + j(7), cz + j(7));
        addPalm(cx + j(7), cz + j(7));
        /* wet sand strip toward the ocean side (south = -z) */
        const wet = new THREE.Mesh(new THREE.PlaneGeometry(TS, 5), M.sand);
        wet.rotation.x = -Math.PI / 2;
        wet.position.set(cx, 0.008, cz - TS / 2 + 2.5);
        scene.add(wet);
        addBoulder(cx + j(9), cz + j(9), 0.7 + rndE() * 0.4, M.mtRock);
        animalSpawns.push({ kind: 'rodent', x: cx + j(), z: cz + j(6), biome });
        animalSpawns.push({ kind: 'bird', x: cx, z: cz, biome });
        break;
      }
      case 'oceanbay': {
        /* shallow bay water over most of the tile, sand shore at the back */
        addWaterPlane(cx, cz + 3, TS, TS - 8, M.water);
        fishZones.push({ x: cx, z: cz, r: 6 });
        for (let i = 0; i < 2; i++) addTuft(cx + j(9), cz - 8.4 + j(2), false);
        addBoulder(cx + j(9), cz - 8.6 + j(2), 0.8 + rndE() * 0.4, M.mtRock);
        break;
      }
      case 'ocean':
        /* deep water handled by the one big ocean plane below; floor here */
        fishZones.push({ x: cx, z: cz, r: 9 });
        break;

      /* -- CH-09.1 — THE CANYON COUNTRY (5 new sets) ----------------------
         Rows 0-1 form the cityscape ring right behind the wild gate;
         badlands parks in the southern dry band (row 8 east). All five
         read as one family — rock, dust, dry growth — so the ring never
         seams against the city or itself (f3).                           */
      case 'wash': {
        /* DRY RIVERBED — cracked-mud wash, a baked dirt bank strip, dead
           trees, sun-bleached boulders. The river moved on; the mud kept
           its shape. NO water plane — the RIVERBANK set covers that.    */
        const bank = new THREE.Mesh(new THREE.PlaneGeometry(TS, 6), M.dirt);
        bank.rotation.x = -Math.PI / 2;
        bank.position.set(cx, 0.01, cz - 3.2);
        bank.receiveShadow = true;
        scene.add(bank);
        for (let i = 0; i < 2; i++) addDeadTree(cx + j(8), cz + j(8), 0.9 + rndE() * 0.4);
        addBoulder(cx + j(8), cz + j(8), 0.7 + rndE() * 0.5, M.mtRock);
        addBoulder(cx + j(8), cz + j(8), 0.5 + rndE() * 0.4, M.mtRock);
        stampHarvest('wash', cx, cz);
        animalSpawns.push({ kind: 'rodent', x: cx + j(), z: cz + j(), biome });
        break;
      }
      case 'canyon': {
        /* CANYON PASS — CH-09.f4 RING WALL REMOVAL (user-promoted mini-
           patch): the two full-height E-W wall masses that pinched the
           tile edges are GONE — the ring reads as open canyon-country
           ground from the gate line, per the amended request (walls
           REMOVED, ground stays). The tile keeps its ground identity,
           choke boulders (cover without walling), harvest/zoneFx config
           and L11 level. Map-edge screening stays the EXISTING expanse
           boundary walls (the rock perimeter at ±X_HALF — built below),
           so no berm is re-added: the removed walls stood fully inside
           that boundary, screening nothing but the view.             */
        addBoulder(cx + j(2.5), cz + j(6), 1.0 + rndE() * 0.5, M.rock);
        addBoulder(cx + j(2.5), cz + j(6), 0.8 + rndE() * 0.5, M.mtRock);
        stampHarvest('canyon', cx, cz, 3.2);
        animalSpawns.push({ kind: 'bird', x: cx, z: cz, biome });
        break;
      }
      case 'basin': {
        /* ROCKY BASIN — a sunken-bowl read: boulder ring around the
           perimeter, bare dirt center, the region's richest ore dig.   */
        const patch = new THREE.Mesh(new THREE.PlaneGeometry(9, 9), M.dirt);
        patch.rotation.x = -Math.PI / 2;
        patch.position.set(cx, 0.01, cz);
        patch.receiveShadow = true;
        scene.add(patch);
        for (let i = 0; i < 5; i++) {
          const a = (i / 5) * Math.PI * 2 + rndE() * 0.5;
          addBoulder(cx + Math.cos(a) * 9.2 + j(1.2), cz + Math.sin(a) * 9.2 + j(1.2),
                     0.9 + rndE() * 0.7, M.mtRock);
        }
        stampHarvest('basin', cx, cz, 3.5);
        animalSpawns.push({ kind: 'rodent', x: cx + j(3), z: cz + j(3), biome });
        break;
      }
      case 'ridge': {
        /* HIGH RIDGE — a low rock spine across the tile's waist (short
           enough to vault — an obstacle, not a wall) with a pine pair on
           the shoulders; the zoneFx table cools the fog to thin air.   */
        const segs = 3;
        for (let i = 0; i < segs; i++) {
          const sx = cx - TS / 2 + (TS / segs) * (i + 0.5);
          const rh = 0.55 + rndE() * 0.5;
          addBox(TS / segs - 0.6, rh, 2.6 + rndE() * 1.4,
                 sx, rh / 2, cz + (rndE() - 0.5) * 3,
                 M.rock, { collide: true, cast: true, receive: true, y1: 1.2 });
        }
        addPine(cx + j(7), cz - 6 + j(2), 0.9 + rndE() * 0.3, false);
        addPine(cx + j(7), cz + 6 + j(2), 0.9 + rndE() * 0.3, false);
        stampHarvest('ridge', cx, cz);
        animalSpawns.push({ kind: 'bird', x: cx, z: cz, biome });
        break;
      }
      case 'badlands': {
        /* RED BADLANDS — stratified mesa buttes over dry grit; the dry
           buffer band east of the desert, hard against the shore rocks */
        for (let i = 0; i < 2; i++) {
          const bx = cx + (i ? 5.5 : -5.5) + j(1.5);
          const bz = cz + j(6);
          const bh = 2.2 + rndE() * 1.6;
          addBox(3.4, bh, 3.4, bx, bh / 2, bz, M.badland,
                 { collide: true, cast: true, receive: true, y1: bh + 0.5 });
          addBox(2.4, 0.7, 2.4, bx + j(0.8), bh + 0.35, bz + j(0.8), M.badland,
                 { cast: true, receive: true });
        }
        addBoulder(cx + j(9), cz + j(9), 0.9 + rndE() * 0.6, M.rock);
        stampHarvest('badlands', cx, cz);
        animalSpawns.push({ kind: 'rodent', x: cx + j(), z: cz + j(), biome });
        break;
      }
    }

    /* hostile spawns: ONE per ~2 tiles (v0.8 — fewer enemies), level by tile */
    if ((cx + row * EX.cols) % 3 === 1 && biome !== 'ocean') {
      const pool = ['grunt', 'grunt', 'shielder', 'drone'];
      expanseSpawns.push({
        t: pool[Math.floor(rndE() * pool.length)],
        x: cx + j(6), z: cz + j(6),
        patrol: 4, arena: 9,
        lvl: EX.levels[biome] || 10,
        expanse: true, biome,
      });
    }
  }

  /* -- build the grid ------------------------------------------------------- */
  for (let rz = 0; rz < ROWS; rz++) {
    for (let cx = 0; cx < EX.cols; cx++) {
      const [tx, tz] = tileCenter(cx, rz);
      stampTile(EX.layout[rz][cx], tx, tz, rz);
    }
  }

  /* one big ocean plane under the two ocean rows (deep water look) */
  {
    const ozc = OCEAN_Z0 - (EX.oceanRows * TS) / 2;
    const deep = new THREE.Mesh(new THREE.PlaneGeometry(EX.cols * TS + 60, EX.oceanRows * TS + 40), M.waterDeep);
    deep.rotation.x = -Math.PI / 2;
    deep.position.set(0, 0.5, ozc);
    scene.add(deep);
    waterAnims.push({ mat: M.waterDeep, speed: 0.035 });
    /* beach surf line where the sand meets the ocean */
    const surf = new THREE.Mesh(new THREE.PlaneGeometry(EX.cols * TS + 8, 6), M.water);
    surf.rotation.x = -Math.PI / 2;
    surf.position.set(0, 0.34, OCEAN_Z0 + 2.6);
    scene.add(surf);
    waterAnims.push({ mat: M.water, speed: 0.06 });
  }

  /* expanse boundary walls (keep player + hostiles inside the wilds) */
  for (const side of [-1, 1]) {
    addBox(1.4, 16, ROWS * TS + 8, side * (X_HALF + 0.7), 8, EX.z0 - (ROWS * TS) / 2,
           M.rock, { collide: true, receive: true, y1: 16 });
  }
  /* far edge of the world (behind the extraction buoy) */
  addBox(EX.cols * TS + 8, 18, 2.5, 0, 9 - 0.05, Z_END - 1.2,
         M.rock, { collide: true, receive: true, y1: 18 });

  /* deep-ocean EXTRACTION BEACON (WIN) — CH-57.1: the boat-buoy assembly
     (float cylinder + pole + crystal lamp + flat EXTRACTION sign) is
     replaced by a proper beacon pylon: a floating dock plinth, a tapered
     mast, an emissive light column shooting up past the mast tip and a
     slow-rotating holo ring, all over the SAME hazard pad. Same anchor
     (EX.buoy), same solids membership (the plinth), same winZone read
     (main.js startExtraction → CH-36 home base; CH-47 missions ride the
     same touch), the same ONE point light + ONE animated[] entry — no new
     lights (ocean draw-call ceiling 110 respected: 5 meshes before, 5
     after) and no new shader programs (the beam is a plain-color basic,
     the crystal ring shares M.crystal).                                  */
  const BUOY = EX.buoy;
  {
    const plinth = new THREE.Mesh(new THREE.CylinderGeometry(1.7, 1.9, 0.9, 10), M.hullDk);
    plinth.position.set(BUOY.x, 0.45, BUOY.z);
    plinth.castShadow = true;
    scene.add(plinth); solids.push(plinth);
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.3, 6.4, 8), M.hull);
    mast.position.set(BUOY.x, 4.1, BUOY.z);          // plinth top 0.9 + half mast
    scene.add(mast);
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.09, 0.16, 9.5, 8, 1, true),
      new THREE.MeshBasicMaterial({ color: '#6ff2ff', transparent: true, opacity: 0.55,
                                    blending: THREE.AdditiveBlending, depthWrite: false })
    );
    beam.position.set(BUOY.x, 5.65, BUOY.z);         // 0.9 → 10.4, past the mast tip
    scene.add(beam);
    const ringGeo = new THREE.TorusGeometry(1.05, 0.05, 8, 28);
    ringGeo.rotateX(Math.PI / 2 - 0.16);             // near-flat + tilt so the spin reads
    const ring = new THREE.Mesh(ringGeo, M.crystal);
    ring.position.set(BUOY.x, 3.4, BUOY.z);
    scene.add(ring);
    const pad = new THREE.Mesh(new THREE.PlaneGeometry(5.2, 0.012, 4, 4), M.hazard);
    pad.rotation.x = -Math.PI / 2;
    pad.position.set(BUOY.x, 0.02, BUOY.z);
    scene.add(pad);
    const bLight = new THREE.PointLight('#6ff2ff', 1.0, 30, 1.6);
    bLight.position.set(BUOY.x, 5.6, BUOY.z);
    scene.add(bLight);
    lights.push({ light: bLight, zone: 'ocean', base: 1.0 });
    animated.push({
      update(t) {
        const k = 0.6 + Math.sin(t * 2.1) * 0.4;
        bLight.intensity = 1.0 * k;
        beam.material.opacity = 0.4 + k * 0.3;
        ring.rotation.y = t * 0.6;                   // slow holo spin
        ring.position.y = 3.4 + Math.sin(t * 1.1) * 0.22;
        const bob = Math.sin(t * 1.3) * 0.14;        // the old float bob, kept
        plinth.position.y = 0.45 + bob;
        mast.position.y = 4.1 + bob;
        beam.position.y = 5.65 + bob;
      },
    });
  }

  /* open-air wash lights for the expanse (zone-culled like the rest) */
  const wildA = new THREE.PointLight('#7fa8a0', 0.7, 52, 1.8);
  wildA.position.set(0, 14, EX.z0 - (ROWS - EX.oceanRows) * TS * 0.45);
  scene.add(wildA);
  lights.push({ light: wildA, zone: 'expanse', base: 0.7 });
  const wildB = new THREE.PointLight('#6f8fa8', 0.7, 52, 1.8);
  wildB.position.set(0, 14, EX.z0 - (ROWS - EX.oceanRows) * TS * 0.75);
  scene.add(wildB);
  lights.push({ light: wildB, zone: 'expanse', base: 0.7 });
  const oceanL = new THREE.PointLight('#5f9fb8', 0.8, 60, 1.8);
  oceanL.position.set(0, 14, OCEAN_Z0 - EX.oceanRows * TS * 0.5);
  scene.add(oceanL);
  lights.push({ light: oceanL, zone: 'ocean', base: 0.8 });

  /* -- expanse API ---------------------------------------------------------- */
  function tileAt(x, z) {
    if (z > EX.z0 || z <= Z_END + TS) { /* fallthrough */ }
    const col = Math.floor((x + X_HALF) / TS);
    const row = Math.floor((EX.z0 - z) / TS);
    if (col < 0 || col >= EX.cols || row < 0 || row >= ROWS) return null;
    const biome = EX.layout[row][col];
    return { col, row, biome, lvl: EX.levels[biome] || 10 };
  }
  function tileCenterOf(col, row) { return tileCenter(col, row); }

  /* ------------------------------------------------------------------
     helpers
     ------------------------------------------------------------------ */
  function floorHeightAt(x, z, refY = Infinity) {
    let best = 0;
    for (const f of floorZones) {
      if (x < f.x0 || x > f.x1 || z < Math.min(f.z0, f.z1) || z > Math.max(f.z0, f.z1)) continue;
      let h;
      if (f.slope) {
        const k = (z - f.z0) / (f.z1 - f.z0);
        h = f.h0 + (f.h1 - f.h0) * Math.max(0, Math.min(1, k));
      } else h = f.h;
      if (h <= refY + 0.65 && h > best) best = h;
    }
    return best;
  }

  function zoneAt(z) {
    /* CH-36.2 — HOME BASE reads first: the shuttle interior parks north
       of the corridor rear wall (z > hub.z0). Everything at or below z0
       flows exactly as before — the CH-07.2 order guard is untouched. */
    if (z > ASSETS.hub.z0) return 'hub';
    if (z <= OCEAN_Z0) return 'ocean';
    if (z <= EX.z0) return 'expanse';
    if (z <= CC.z0) return 'city';
    if (z <= VZ0) return 'valley';
    return z <= WH.mouthZ - 0.1 ? 'hangar' : 'corridor';
  }
  /* CH-07.2 — zone-bound order guard: with the hangar deeper (back wall
     -120.4, valley mouth -121.4) the seam strips only read correctly while
     boundaries stay strictly ordered. A future assets edit that moves one
     boundary without its neighbours would silently mislabel fog/ceil/radar
     at the seam — warn once at build time instead of failing silently.     */
  if (!(WH.mouthZ > WV.z0 && WV.z0 > CC.z0 && CC.z0 > EX.z0)) {
    console.warn('[world] zone bounds out of order — check assets.world.hangar/valley/city/expanse z0');
  }
  function ceilHeightAt(z) {
    /* CH-36.2 — the shuttle interior's own flat ceiling (bolts die on it
       like any indoor roof; the vista plane sits inside the room) */
    if (z > ASSETS.hub.z0) return ASSETS.hub.wallH;
    /* CH-08.2 — under a connector roof the ceiling is the roof slab, so
       bolts (the only ceil consumer) die on it instead of flying through */
    for (const C of cityCorridors) {
      if (z <= C.z0 && z >= C.z1) return C.roofY;
    }
    const zn = zoneAt(z);
    if (zn === 'city' || zn === 'expanse' || zn === 'ocean') return 60;
    if (zn === 'valley') return 42;
    return zn === 'hangar' ? WH.height : WC.height;
  }

  /* CH-08.2 — corridor helpers: corridorAt classifies a position against
     the connector shells (roofed span ± the full street width), zoneFxAt
     swaps the fog/sky targets to the indoor corridor palette while the
     player is under a roof. zoneAt itself stays UNCHANGED — connectors
     are city ground: L8 spawns, city objectives and the zone-bound order
     guard (CH-07.2) all read 'city' exactly as before.                 */
  function corridorAt(x, z) {
    for (const C of cityCorridors) {
      if (z <= C.z0 && z >= C.z1 && Math.abs(x) <= CC.streetHalf + 5.2) return C;
    }
    return null;
  }
  const corridorFx = { fog: P.fog, bg: P.bg, near: 10, far: 40 };   // indoor read
  /* CH-09.2 — per-tile fog/sky: inside the expanse a biome's
     assets.world.expanse.zoneFx entry (new canyon-country sets) wins
     over the zone-wide palette — stand in a wash and the haze warms
     toward dust; the ridge cools toward high thin air. Legacy sets have
     no entry and fall through to the zone table unchanged, and the
     corridor roof read (CH-08.2) still wins everywhere else.           */
  function zoneFxAt(x, z) {
    if (z <= EX.z0 && z > OCEAN_Z0) {
      const t = tileAt(x, z);
      if (t && EX.zoneFx[t.biome]) return EX.zoneFx[t.biome];
    }
    return corridorAt(x, z) ? corridorFx : zoneFx[zoneAt(z)];
  }

  /* per-zone fog/background targets (main.js lerps toward these, then the
     day/night cycle tints them) */
  const zoneFx = {
    corridor: { fog: P.fog, bg: P.bg, near: 12, far: 44 },
    hangar:   { fog: P.fog, bg: P.bg, near: 16, far: 62 },
    valley:   { fog: P.vFog, bg: P.vSky, near: 20, far: 95 },
    city:     { fog: P.cFog, bg: P.cSky, near: 22, far: 110 },
    expanse:  { fog: '#1c2a20', bg: '#20362a', near: 24, far: 105 },
    ocean:    { fog: '#12262e', bg: '#16323c', near: 26, far: 115 },
    /* CH-36.2 — the shuttle interior: warm-dark hull read, tighter fog.
       The windshield vista is fog:false emissive so the view stays crisp
       while the cabin haze leans cool.                                 */
    hub:      { fog: '#10151c', bg: '#0d1218', near: 14, far: 52 },
  };

  /* win trigger: the deep-ocean EXTRACTION BUOY (v0.8) */
  const winZone = {
    minX: BUOY.x - 4.5, maxX: BUOY.x + 4.5,
    minZ: BUOY.z - 2.5, maxZ: BUOY.z + 3,
  };

  /* -- breakable props (CH-06): ANY damage type chips the pool; one
     rocket shell still kills every prop (breakThreshold, CH-06.4) ────── */
  function damageBox(game, b, amount, point) {
    if (!b || b.dead) return;
    b.hp -= amount;
    const at = point || b.mesh.position;
    for (let i = 0; i < 3; i++) game.weapon.spawnSpark(at, false);
    if (b.hp > 0) return;
    b.dead = true;
    /* kill the collider (shoved far away so nothing ever intersects it) */
    if (b.col) { b.col.minX = b.col.maxX = 1e9; b.col.minZ = b.col.maxZ = 1e9; }
    /* chained break (stacked container base) */
    if (b.linked) for (const l of b.linked) damageBox(game, l, 1e9, null);
    /* visuals */
    scene.remove(b.mesh);
    const si = solids.indexOf(b.mesh);
    if (si >= 0) solids.splice(si, 1);
    const p = b.mesh.position;
    for (let i = 0; i < 6; i++) game.weapon.spawnSpark(p, false, true);
    for (let i = 0; i < 4; i++) game.weapon.spawnPuff(p);
    game.sfx.boomSmall(0);
    /* CH-06.1 — debris style follows the material: wood splinters vs
       metal chunks, and metal props spray extra sparks as they die       */
    const sc = Math.max(0.3, Math.min(1.6, b.mesh.scale.x));
    for (let i = 0; i < 5; i++) {
      const chunk = new THREE.Mesh(unitBox, b.debrisMat || M.crate);
      const cs = sc * (0.16 + Math.random() * 0.16);
      chunk.scale.set(cs, cs, cs);
      chunk.position.copy(p).add(new THREE.Vector3(
        (Math.random() - 0.5) * sc, Math.random() * sc * 0.5, (Math.random() - 0.5) * sc));
      scene.add(chunk);
      debris.push({
        mesh: chunk, t: 0,
        vel: new THREE.Vector3((Math.random() - 0.5) * 4.5, 2.5 + Math.random() * 3,
                               (Math.random() - 0.5) * 4.5),
        spin: new THREE.Vector3(Math.random() * 8, Math.random() * 8, Math.random() * 8),
      });
    }
    /* metal tells: a drum or chest death rings out with a spark spray
       (wood keeps the plain splinter/puff read)                          */
    if (b.kind === 'barrel' || b.kind === 'chest') {
      for (let i = 0; i < 3; i++) game.weapon.spawnSpark(p, false, true);
    }
    /* CH-06.3 — spill routes by kind: crates keep the conversion table
       (one shell of value — unchanged), barrels spill small CR/ammo,
       chests better CR + a mod chip. Power-mod overkill multiplies the
       yield the same way for every kind (capped ×3).                     */
    if (game.specials) {
      const mult = Math.max(0.5, Math.min(ASSETS.conversion.maxMult, amount / b.maxHp));
      if (b.kind && b.kind !== 'crate') {
        game.specials.spawnContainerSpill(p.clone(), b.kind, mult);
      } else {
        game.specials.spawnConversionLoot(p.clone(), mult);
      }
    }
  }

  function updateDebris(dt) {
    for (let i = debris.length - 1; i >= 0; i--) {
      const d = debris[i];
      d.t += dt;
      d.vel.y -= 11 * dt;
      d.mesh.position.addScaledVector(d.vel, dt);
      d.mesh.rotation.x += d.spin.x * dt;
      d.mesh.rotation.y += d.spin.y * dt;
      const gy = floorHeightAt(d.mesh.position.x, d.mesh.position.z, 99) + d.mesh.scale.y / 2;
      if (d.mesh.position.y < gy) { d.mesh.position.y = gy; d.vel.y *= -0.3; d.vel.x *= 0.7; d.vel.z *= 0.7; }
      if (d.t > 0.7) d.mesh.scale.multiplyScalar(Math.max(0, 1 - dt * 3.4));
      if (d.t > 1.2 || d.mesh.scale.x < 0.02) {
        scene.remove(d.mesh);
        debris.splice(i, 1);
      }
    }
  }

  /* -- harvest respawn + water UV scroll --------------------------------- */
  function updateHarvests(dt) {
    for (const h of harvests) {
      if (!h.depleted) continue;
      h.respT -= dt;
      if (h.respT <= 0) {
        h.depleted = false;
        h.mesh.visible = true;
        h.mesh.scale.setScalar(1);
      }
    }
  }

  /* ========================================================================
     CH-05.1 — SUPPLY LOCKERS (beast-opened — CH-05.2/05.3)
     Solid props (own collider, deliberately NOT breakable — the CH-06
     universal threshold covers crates/barrels/chests, lockers are opened,
     never smashed). Each locker: textured body + hinged door that swings
     open when the beast finishes its channel + a face glow that fades in
     with the swing (the "interior light" tell). Records are exported as
     `lockers[]` — companions.js designates them through the reticle cone,
     runs to `standPos`, channels, then flips `opened` (world-side swing +
     respawn timer here) and specials.js spills the elite loot.
     Opened lockers close again after LK.respawn[0..1] s (CH-05.3).
     NOTE: built HERE at the END of buildWorld (not next to the city
     block) because zoneAt() reads the expanse/city bounds consts —
     those live further down; calling zoneAt earlier hits the TDZ and
     dies at boot (headless-Chromium proven).                            */
  const LK = ASSETS.lockers;
  const lockers = [];
  {
    const mBody = new THREE.MeshPhongMaterial({ map: TEX.texLocker(), shininess: 8 });
    const mDoorSrc = new THREE.MeshPhongMaterial({ map: TEX.texLockerDoor(), shininess: 14 });
    const W = 0.95, H = 2.05, D = 0.62;             // locker body dims (door face = local +Z)

    /* CH-10.1 — collider-clear resolver for WILD locker spots. Expanse
       entries stamp into SEEDED tiles, so a jittered boulder / mesa butte
       can land on the hand-picked coordinates. Body + stand points are
       tested against the collider list (already complete — lockers build
       at the END of buildWorld) and nudged along a fixed spiral until
       both are clear. Deterministic, bounded (11 tries), and a strict
       no-op for the hand-verified zone lockers (only wild spots resolve). */
    const wildHit = (x, z, r) => colliders.some((c) =>
      (c.y0 || 0) < 1.8 && c.y1 > 0.5 &&
      x > c.minX - r && x < c.maxX + r && z > c.minZ - r && z < c.maxZ + r);
    const nudgeLockerClear = (d) => {
      const nx = Math.sin(d.ry || 0), nz = Math.cos(d.ry || 0);
      const stand = (x, z) => [x + nx * (D / 2 + LK.channelDist),
                               z + nz * (D / 2 + LK.channelDist)];
      const [sx, sz] = stand(d.x, d.z);
      if (!wildHit(d.x, d.z, 0.75) && !wildHit(sx, sz, 0.5)) return d;
      const tries = [[0.9, 0], [-0.9, 0], [0, 0.9], [0, -0.9],
                     [1.5, 0.9], [-1.5, 0.9], [1.5, -0.9], [-1.5, -0.9],
                     [0, 1.8], [2.4, 0], [0, -2.4]];
      for (const [ox, oz] of tries) {
        const x = d.x + ox, z = d.z + oz;
        const [ax, az] = stand(x, z);
        if (!wildHit(x, z, 0.75) && !wildHit(ax, az, 0.5)) return { ...d, x, z };
      }
      return d;                      // nothing better nearby — keep the pick
    };

    for (const d0 of ASSETS.world.lockers) {
      /* CH-10.1 — wild placements (z beyond the city) resolve against the
         seeded scatter before anything is built from them */
      const d = d0.z <= EX.z0 ? nudgeLockerClear(d0) : d0;
      const ry = d.ry || 0;
      const body = addBox(W, H, D, d.x, H / 2, d.z, mBody,
                          { collide: true, cast: true, receive: true, ry });
      /* door hinged on the local +X edge of the +Z face — extends \u2212X, swings out */
      const hinge = new THREE.Group();
      hinge.position.set(
        d.x + Math.sin(ry) * (D / 2) + Math.cos(ry) * (W / 2), H / 2,
        d.z + Math.cos(ry) * (D / 2) - Math.sin(ry) * (W / 2));
      hinge.rotation.y = ry;
      const doorMesh = new THREE.Mesh(unitBox, mDoorSrc);
      doorMesh.scale.set(W - 0.06, H - 0.08, 0.05);
      doorMesh.position.set(-(W - 0.06) / 2, 0, 0);
      doorMesh.castShadow = true;
      hinge.add(doorMesh);
      scene.add(hinge);
      /* face glow — fades in with the swing (per-instance material) */
      const mGlow = new THREE.MeshBasicMaterial({
        color: P.stripGlow, transparent: true, opacity: 0, depthWrite: false,
      });
      const glow = new THREE.Mesh(unitBox, mGlow);
      glow.scale.set(W - 0.2, H - 0.55, 0.03);
      glow.position.set(d.x + Math.sin(ry) * (D / 2 + 0.02), H / 2 + 0.12,
                        d.z + Math.cos(ry) * (D / 2 + 0.02));
      glow.rotation.y = ry;
      scene.add(glow);
      /* front + stand points (door face outward along the rotated +Z) */
      const nx = Math.sin(ry), nz = Math.cos(ry);
      const zone = zoneAt(d.z);
      /* loot level — CH-10.1: wild placements carry lvl (their tile set's
         hostile level, expanse.levels — the SAME number the tile spawner
         hands its expanse spawns), so the ring lockers spill the L10-13
         floor and the deep POIs pay the deeper dropRateMult curve. Zone
         lockers keep the zone table (enemy.leveling.zones — the same
         table the spawner uses); the old "fallback 5" stopgap is gone.  */
      const zoneT = ASSETS.enemy.leveling && ASSETS.enemy.leveling.zones;
      lockers.push({
        x: d.x, z: d.z, ry, zone,
        level: d.lvl || (zoneT && zoneT[zone]) || 5,
        opened: false, respT: -1, openK: 0,
        door: hinge, glow: mGlow,
        stand: { x: d.x + nx * (D / 2 + LK.channelDist), z: d.z + nz * (D / 2 + LK.channelDist) },
        front: { x: d.x + nx * (D / 2), z: d.z + nz * (D / 2) },
      });
      body.userData.locker = lockers[lockers.length - 1];
    }
  }

  /* CH-05.1/05.3 — door swing + respawn timers (called from world.update) */
  function updateLockers(dt) {
    for (const l of lockers) {
      if (l.opened) {
        if (l.openK < 1) {
          l.openK = Math.min(1, l.openK + dt / LK.openTime);
          const k = l.openK * l.openK * (3 - 2 * l.openK);   // smoothstep (bay-door style)
          l.door.rotation.y = l.ry + k * LK.openSwing;
          l.glow.opacity = k * 0.85;
        }
        l.respT -= dt;
        if (l.respT <= 0) {
          l.opened = false; l.openK = 0; l.respT = -1;
          l.door.rotation.y = l.ry;                          // snap shut (harvests pop back too)
          l.glow.opacity = 0;
        }
      }
    }
  }

  /* ========================================================================
     CH-36 — HOME BASE (the shuttle interior hub)                    CH-36.2
     ------------------------------------------------------------------------
     The hub parks NORTH of the corridor start (z 0.4 … 21): the corridor's
     rear wall became the AIRLOCK bulkhead (rebuilt up top with a mouth),
     a short ramp VESTIBULE with a sliding RAMP DOOR leads into the hull.
     Layout along +z (per ch-36.f2 "windshield at the front, narrow
     hallway with workstations, rooms in the back"):
       · z 0.4 … 2.7   vestibule — hazard sill, AIRLOCK sign
       · z 2.7 … 8.4   back rooms flanking a center corridor
                       WEST = MOD BENCH island · EAST = SALVAGE STORES
       · z 8.4 … 15.6  narrow hallway — ARSENAL RACK (west) ·
                       COMPANION BAY (east) workstations
       · z 15.6 … 21   cockpit — WINDSHIELD vista (texVista, emissive,
                       fog:false — the f2 "view out over the world" read
                       inside the HD 3000 budget; live camera REJECTED),
                       MISSION CONSOLE, display-frame dock (CH-42
                       placeholder) + companion dock pad
     Own lighting (7 point lights, zone 'hub' — the same intensity-fade
     cull every other zone uses), draw calls ~60 in-hub (f2 ≤ ~200).
     Stations are exported as hub.stations — main.js drives the prompt +
     interact, each opens its REAL system's XMB column (ch-36.f4/f5).  */
  const HB = ASSETS.hub;
  const hub = { stations: [] };
  batchZone('hub');                          // CH-44.1 — merge bucket context
  {
    /* -- materials ------------------------------------------------------- */
    const texHullWall = TEX.texHangarWall();  texHullWall.repeat.set(3, 1);
    const texHubFloor = TEX.texHangarFloor(); texHubFloor.repeat.set(4, 7);
    const texHubCeil  = TEX.texCeiling();     texHubCeil.repeat.set(3, 7);
    const Mhull  = new THREE.MeshPhongMaterial({ map: texHullWall, shininess: 12 });
    const Mfloor = new THREE.MeshPhongMaterial({ map: texHubFloor, shininess: 16 });
    const Mceil  = new THREE.MeshLambertMaterial({ map: texHubCeil });
    const Mdesk  = new THREE.MeshPhongMaterial({ map: TEX.texWall(), shininess: 14 });
    const Mvista = new THREE.MeshBasicMaterial({ map: TEX.texVista(), fog: false });
    hub.vistaTex = Mvista.map;

    /* -- shell ------------------------------------------------------------ */
    const hubLen = HB.northZ - HB.z0;
    const hFloor = new THREE.Mesh(new THREE.PlaneGeometry(HB.halfW * 2 + 0.6, hubLen), Mfloor);
    hFloor.rotation.x = -Math.PI / 2;
    hFloor.position.set(0, 0, HB.z0 + hubLen / 2);
    hFloor.receiveShadow = true;
    scene.add(hFloor); solids.push(hFloor);
    floorZones.push({ x0: -HB.halfW - 0.3, x1: HB.halfW + 0.3, z0: HB.z0, z1: HB.northZ, h: 0, flat: true });

    /* main hull ceiling — starts at the hub south wall (the vestibule has
       its own lower ceiling at corridor height, no overlap) */
    const hCeil = new THREE.Mesh(
      new THREE.PlaneGeometry(HB.halfW * 2 + 0.6, HB.northZ - HB.southZ), Mceil);
    hCeil.rotation.x = Math.PI / 2;
    hCeil.position.set(0, HB.wallH, (HB.southZ + HB.northZ) / 2);
    scene.add(hCeil); solids.push(hCeil);

    /* hull side walls (full span) */
    for (const side of [-1, 1]) {
      addBox(0.3, HB.wallH, hubLen, side * (HB.halfW + 0.15), HB.wallH / 2,
             HB.z0 + hubLen / 2, Mhull, { collide: true, receive: true });
    }
    /* windshield bulkhead (north) — the vista plane sits just inside it */
    addBox(HB.halfW * 2 + 0.6, HB.wallH, 0.3, 0, HB.wallH / 2, HB.northZ + 0.15,
           Mhull, { collide: true, receive: true });

    /* hub south wall + ramp-door mouth (mirror of the airlock bulkhead) */
    {
      const segW = HB.halfW - HB.mouthW / 2;
      for (const side of [-1, 1]) {
        addBox(segW, HB.wallH, 0.3, side * (HB.mouthW / 2 + segW / 2), HB.wallH / 2,
               HB.southZ, Mhull, { collide: true, receive: true });
      }
      addBox(HB.mouthW + 0.2, HB.wallH - HB.mouthH, 0.3, 0, HB.mouthH + (HB.wallH - HB.mouthH) / 2,
             HB.southZ, Mhull, { collide: true, receive: true, y0: HB.mouthH, y1: HB.wallH });
    }

    /* vestibule — side walls + own lower ceiling + hazard sill + sign */
    {
      const vz0 = HB.z0, vz1 = HB.southZ;
      for (const side of [-1, 1]) {
        addBox(0.24, HB.wallH, vz1 - vz0, side * (HB.mouthW / 2 + 0.12), HB.wallH / 2,
               (vz0 + vz1) / 2, Mhull, { collide: true, receive: true });
      }
      const vCeil = new THREE.Mesh(new THREE.PlaneGeometry(HB.mouthW + 0.7, vz1 - vz0), Mceil);
      vCeil.rotation.x = Math.PI / 2;
      vCeil.position.set(0, WC.height, (vz0 + vz1) / 2);
      scene.add(vCeil); solids.push(vCeil);
      addBox(HB.mouthW, 0.012, 0.9, 0, 0.011, (vz0 + vz1) / 2, M.hazard, { solid: false });
      const sign = new THREE.Mesh(
        new THREE.PlaneGeometry(2.4, 0.6),
        new THREE.MeshBasicMaterial({ map: TEX.texSign('AIRLOCK') }));
      sign.position.set(0, 2.62, vz0 - 0.44);   // just south of the bulkhead face
      sign.rotation.y = Math.PI;                 // faces the corridor
      scene.add(sign);
    }

    /* back-room walls: center corridor + cross wall with two doorways */
    {
      const cz = HB.southZ, rz = HB.roomSplitZ;
      for (const side of [-1, 1]) {
        addBox(0.25, HB.wallH, rz - cz, side * (HB.centerW / 2 + 0.125), HB.wallH / 2,
               (cz + rz) / 2, Mhull, { collide: true, receive: true });
      }
      /* cross wall segments around doorways at x ±4.3 (2.2 wide) */
      const segs = [
        [-HB.halfW, -5.4], [-3.2, -HB.centerW / 2],
        [-HB.centerW / 2, HB.centerW / 2],
        [HB.centerW / 2, 3.2], [5.4, HB.halfW],
      ];
      for (const [x0, x1] of segs) {
        const w = x1 - x0;
        addBox(w, HB.wallH, 0.25, (x0 + x1) / 2, HB.wallH / 2, rz,
               Mhull, { collide: true, receive: true });
      }
    }

    /* -- the sliding RAMP DOOR (either-side trigger, door/door2 pattern) - */
    const rdMesh = addBox(HB.mouthW + 0.2, HB.mouthH + 0.1, 0.26, 0, (HB.mouthH + 0.1) / 2 - 0.05,
                          HB.rampDoorZ, M.door, { cast: true, receive: true });
    addBox(HB.mouthW + 0.6, 0.22, 0.5, 0, HB.mouthH + 0.15, HB.rampDoorZ, M.frame);
    for (const side of [-1, 1]) {
      addBox(0.24, HB.mouthH + 0.2, 0.5, side * (HB.mouthW / 2 + 0.1), HB.mouthH / 2,
             HB.rampDoorZ, M.frame);
    }
    addBox(HB.mouthW + 0.2, 0.14, 0.1, 0, HB.mouthH - 0.35, HB.rampDoorZ + 0.18, M.warn, { solid: false });
    const rdCol = {
      minX: -HB.mouthW / 2 - 0.1, maxX: HB.mouthW / 2 + 0.1,
      minZ: HB.rampDoorZ - 0.18, maxZ: HB.rampDoorZ + 0.18, y0: 0, y1: HB.mouthH + 0.2,
    };
    colliders.push(rdCol);
    hub.rampDoor = {
      mesh: rdMesh, col: rdCol, open: false, t: 0,
      baseY: rdMesh.position.y,
      trigger() {
        if (this.open) return false;
        this.open = true;
        rdCol.minZ = rdCol.maxZ = HB.rampDoorZ;
        return true;
      },
      reset() {
        this.open = false; this.t = 0;
        rdMesh.position.y = this.baseY;
        rdCol.minZ = HB.rampDoorZ - 0.18;
        rdCol.maxZ = HB.rampDoorZ + 0.18;
      },
    };
    animated.push({
      update(dt) {
        if (!hub.rampDoor.open || hub.rampDoor.t >= 1) return;
        hub.rampDoor.t = Math.min(1, hub.rampDoor.t + dt / 1.6);
        const k = hub.rampDoor.t * hub.rampDoor.t * (3 - 2 * hub.rampDoor.t);
        rdMesh.position.y = hub.rampDoor.baseY + k * (HB.mouthH + 0.2);
      },
    });

    /* -- station builder: desk + angled screen + placard ------------------- */
    /* faces: ry is the yaw of the facing direction (screen normal):
       π/2 = +x (east), -π/2 = -x (west), π = -z (south). The screen's
       lean-back tilts in its OWN frame via a wrapper group (Euler-order
       safety), so wall racks and south-facing benches both read right. */
    function buildStation(s, ry, screenLean = 0.2) {
      const desk = addBox(1.9, 0.92, 0.72, s.x, 0.46, s.z, Mdesk,
                          { collide: true, cast: true, receive: true,
                            ry: (Math.abs(ry) === Math.PI) ? 0 : ry });
      addBox(2.0, 0.06, 0.82, s.x, 0.955, s.z, M.rib, { cast: true, receive: true, solid: false });
      const nx = Math.sin(ry), nz = Math.cos(ry);      // facing dir of the screen
      const mk = (tex, w, h) => {
        const g = new THREE.Group();
        g.position.set(s.x + nx * 0.4, 0, s.z + nz * 0.4);
        g.rotation.y = ry;
        const p = new THREE.Mesh(
          new THREE.PlaneGeometry(w, h),
          new THREE.MeshBasicMaterial({ map: tex }));
        p.rotation.x = -screenLean;
        g.add(p);
        scene.add(g);
        return g;
      };
      const screen = mk(TEX.texSign(s.label), 1.5, 0.62);
      screen.position.y = 1.52;
      const placard = mk(TEX.texSign(s.label.split(' ')[0]), 1.34, 0.34);
      placard.position.y = 2.42;
      /* console glow strip under the desk lip (station "on" tell) */
      addBox(1.7, 0.05, 0.6, s.x + nx * 0.06, 0.2, s.z + nz * 0.06, M.lampBar, { solid: false });
      hub.stations.push({ ...s, desk, screen, placard });
    }

    /* -- the five functional stations (ch-36.f4 / f5) ----------------------
       MISSION console faces south (the arriving player reads it), room
       benches face south, hallway racks face the room center.           */
    buildStation(ASSETS.hub.stations.find((s) => s.id === 'mission'), Math.PI, 0.26);
    buildStation(ASSETS.hub.stations.find((s) => s.id === 'modbench'), Math.PI, 0.18);
    buildStation(ASSETS.hub.stations.find((s) => s.id === 'inventory'), Math.PI, 0.18);
    buildStation(ASSETS.hub.stations.find((s) => s.id === 'arsenal'), Math.PI / 2, 0.2);
    buildStation(ASSETS.hub.stations.find((s) => s.id === 'companion'), -Math.PI / 2, 0.2);

    /* west room extra: parts shelf · east room extra: salvage display
       (decorative solids — NOT breakable: the hub is not a loot room)   */
    addBox(1.6, 1.5, 0.4, -1.72, 0.75, 3.6, M.rib, { collide: true, receive: true });
    addBox(0.6, 0.6, 0.6, -6.3, 0.3, 7.4, M.crate, { collide: true, cast: true, receive: true });
    addBox(1.5, 0.9, 0.5, 6.4, 0.45, 7.6, M.chest, { collide: true, cast: true, receive: true });

    /* -- cockpit: WINDSHIELD vista + frame dock --------------------------- */
    const wsW = 11.2, wsH = 3.35, wsY = 2.58;
    const ws = new THREE.Mesh(new THREE.PlaneGeometry(wsW, wsH), Mvista);
    ws.position.set(0, wsY, HB.northZ - 0.14);
    ws.rotation.x = -0.045;                       // slight lean-back, reads as glass
    scene.add(ws);
    /* frame mullions + sill + header (5 bars — the cockpit "glass" read) */
    for (const mx of [-3.75, 0, 3.75]) {
      addBox(0.14, wsH + 0.3, 0.1, mx, wsY, HB.northZ - 0.1, M.frame, { solid: false });
    }
    addBox(wsW + 0.6, 0.16, 0.3, 0, wsY - wsH / 2 - 0.02, HB.northZ - 0.12, M.frame, { solid: false });
    addBox(wsW + 0.6, 0.2, 0.3, 0, wsY + wsH / 2 + 0.06, HB.northZ - 0.12, M.frame, { solid: false });
    /* dashboard lip under the glass */
    addBox(wsW, 0.5, 0.55, 0, 0.62, HB.northZ - 0.55, M.inset, { collide: true, cast: true, receive: true });
    addBox(wsW - 0.4, 0.04, 0.4, 0, 0.9, HB.northZ - 0.55, M.lampBar, { solid: false });

    /* CH-36.6 — DISPLAY FRAME DOCK (the CH-42 placeholder rig): a stylized
       armored mannequin at the cockpit's right so the hub doubles as the
       equipment showcase. STATED DECISION (logged in worklog.30): the
       loadout-mirroring player rig renders in CH-42/CH-22 — this stand-in
       is static silhouette + palette accent; the REAL companions (drone/
       beast) already render in the hub because they follow the player.  */
    {
      const R = HB.rig;
      const mHullD = new THREE.MeshLambertMaterial({ color: P.gunmetal });
      const mHullDD = new THREE.MeshLambertMaterial({ color: P.gunDark });
      const mAccent = new THREE.MeshBasicMaterial({ color: P.energy });
      const rig = new THREE.Group();
      rig.position.set(R.x, 0, R.z);
      rig.rotation.y = Math.PI;                    // faces the arriving player
      const put = (mat, w, h, d, x, y, z) => {
        const m = new THREE.Mesh(unitBox, mat);
        m.scale.set(w, h, d); m.position.set(x, y, z);
        m.castShadow = true;
        rig.add(m);
        return m;
      };
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.7, 0.12, 14), mHullDD);
      ped.position.y = 0.06; ped.castShadow = true; rig.add(ped);
      put(mHullD, 0.55, 0.1, 0.34, 0, 0.16, 0);                    // foot plate
      put(mHullDD, 0.17, 0.82, 0.2, -0.13, 0.63, 0);               // legs
      put(mHullDD, 0.17, 0.82, 0.2, 0.13, 0.63, 0);
      put(mHullD, 0.5, 0.2, 0.3, 0, 1.12, 0);                      // hips
      put(mHullD, 0.52, 0.58, 0.3, 0, 1.52, 0);                    // torso
      put(mAccent, 0.3, 0.05, 0.32, 0, 1.4, 0);                    // waist glow
      put(mHullD, 0.58, 0.26, 0.34, 0, 1.86, 0);                   // chest plate
      put(mHullDD, 0.2, 0.18, 0.24, -0.4, 1.88, 0);                // shoulders
      put(mHullDD, 0.2, 0.18, 0.24, 0.4, 1.88, 0);
      put(mHullD, 0.14, 0.62, 0.18, -0.42, 1.5, 0.02);             // arms
      put(mHullD, 0.14, 0.62, 0.18, 0.42, 1.5, 0.02);
      put(mHullDD, 0.24, 0.26, 0.26, 0, 2.14, 0);                  // head
      put(mAccent, 0.19, 0.055, 0.02, 0, 2.16, -0.135);            // visor
      scene.add(rig);
      hub.rig = rig;
      const sign = new THREE.Mesh(
        new THREE.PlaneGeometry(1.7, 0.42),
        new THREE.MeshBasicMaterial({ map: TEX.texSign('FRAME DOCK') }));
      sign.position.set(R.x, 2.72, R.z - 0.4);
      sign.rotation.y = Math.PI;
      scene.add(sign);

      /* companion dock pad (the real drone/beast follows the player — this
         pad is the themed berth beside the frame) */
      const PD = HB.pad;
      const pad = new THREE.Mesh(new THREE.CylinderGeometry(0.66, 0.74, 0.07, 16), mHullDD);
      pad.position.set(PD.x, 0.035, PD.z);
      pad.receiveShadow = true;
      scene.add(pad);
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.5, 0.6, 20),
        new THREE.MeshBasicMaterial({ color: P.energy, side: THREE.DoubleSide }));
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(PD.x, 0.078, PD.z);
      scene.add(ring);
      hub.padRing = ring;
    }

    /* -- hub lighting (zone 'hub' — the standard intensity-fade cull) ----- */
    const hubLights = [
      { x: 0, y: 3.1, z: 1.6, c: P.lampWarm, base: 0.5 },     // vestibule
      { x: 0, y: 3.5, z: 5.5, c: P.lampWarm, base: 0.45 },    // center corridor
      { x: -4.0, y: 3.6, z: 11.6, c: P.lampCool, base: 0.5 }, // hallway west
      { x: 4.0, y: 3.6, z: 11.6, c: P.lampCool, base: 0.5 },  // hallway east
      { x: -2.6, y: 3.9, z: 18.4, c: P.lampCool, base: 0.55 },// cockpit key
      { x: 2.6, y: 3.4, z: 17.6, c: P.lampWarm, base: 0.4 },  // vista spill
      { x: 0, y: 3.3, z: 8.0, c: P.lampWarm, base: 0.35 },    // rooms seam
    ];
    for (const L of hubLights) {
      const pl = new THREE.PointLight(L.c, 0, 11, 1.7);
      pl.position.set(L.x, L.y, L.z);
      scene.add(pl);
      lights.push({ light: pl, zone: 'hub', base: L.base });
    }
    /* emissive trim — ceiling light bars down the hallway + cockpit cove */
    addBox(0.34, 0.05, 6.4, -1.0, HB.wallH - 0.06, 11.8, M.lampBar, { solid: false });
    addBox(0.34, 0.05, 6.4, 1.0, HB.wallH - 0.06, 11.8, M.lampBar, { solid: false });
    addBox(9.6, 0.06, 0.3, 0, HB.wallH - 0.1, 16.4, M.lampBar, { solid: false });

    /* -- per-frame hub upkeep (called from main.js playing case) ---------- */
    hub.updateHub = function (dt, game) {
      /* ramp door: proximity trigger from either side (door2 pattern) */
      if (!hub.rampDoor.open) {
        const p = game.player.pos;
        if (Math.abs(p.z - HB.rampDoorZ) < 2.4 && Math.abs(p.x) < HB.mouthW / 2 + 0.7) {
          if (hub.rampDoor.trigger()) {
            game.sfx.doorOpen();
            game.hud.toast('RAMP DOOR CYCLING', 1400);
          }
        }
      }
      /* vista slow drift + pad ring pulse (cheap aliveness) */
      hub.vistaTex.offset.x = (hub.vistaTex.offset.x + dt * 0.0022) % 1;
      hub.padRing.material.opacity =
        0.55 + Math.sin(game.time * 2.2) * 0.3;
      hub.padRing.material.transparent = true;
    };
  }

  /* ------------------------------------------------------------------
     CH-47.3 — MISSION PROPS: the director's field equipment. ONE group,
     rebuilt from a plain data list (kind · x · z · r) whenever the
     mission state changes — extraction beacon · hold ring · defense
     generator · recovery caches. Emissive Lambert/Basic only, ≤ 7
     meshes while a mission is deployed (CH-44 note: the global budget
     owns the overrun; this adds a handful of calls at the site only).
     The generator adds ONE collider; the director (main.js) owns ALL
     logic — these are visuals + a footprint (warframe.mission-rules:
     objectives consume the world's public interfaces, terrain is never
     regenerated).
     ------------------------------------------------------------------ */
  const missionProps = new THREE.Group();
  scene.add(missionProps);
  let missionCols = [];            // colliders the mission props own
  let _mBeacon = null;             // pulsing column (opacity)
  let _mCore = null;               // spinning beacon core
  let _mRing = null;               // hold ring (pulse)
  let _mCaches = [];               // bobbing caches

  function clearMissionProps() {
    while (missionProps.children.length) missionProps.remove(missionProps.children[0]);
    for (const c of missionCols) {
      const i = colliders.indexOf(c);
      if (i >= 0) colliders.splice(i, 1);
    }
    missionCols = []; _mBeacon = null; _mCore = null; _mRing = null; _mCaches = [];
  }

  function setMissionProps(props) {
    clearMissionProps();
    for (const p of props || []) {
      const fy = floorHeightAt(p.x, p.z);
      if (p.kind === 'beacon') {
        /* CH-47.4 — mission extraction beacon: floor ring + light column
           + spinning core — the "go home" read, glowing green-gold */
        const ring = new THREE.Mesh(new THREE.CylinderGeometry(1.9, 2.2, 0.14, 20),
          new THREE.MeshLambertMaterial({ color: '#16301f', emissive: '#37e08a', emissiveIntensity: 0.85 }));
        ring.position.set(p.x, fy + 0.08, p.z);
        missionProps.add(ring);
        const colm = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.75, 9, 10, 1, true),
          new THREE.MeshBasicMaterial({ color: '#4dff9e', transparent: true, opacity: 0.28,
            side: THREE.DoubleSide, depthWrite: false }));
        colm.position.set(p.x, fy + 4.5, p.z);
        missionProps.add(colm);
        const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.55, 0),
          new THREE.MeshLambertMaterial({ color: '#0e2016', emissive: '#7dffbe', emissiveIntensity: 1 }));
        core.position.set(p.x, fy + 1.35, p.z);
        missionProps.add(core);
        _mBeacon = colm.material; _mCore = core;
      } else if (p.kind === 'hold') {
        /* CH-47.2 — holdout ring: flat torus marking the stay-inside
           radius + a slim marker column at the center */
        const r = p.r || 8;
        const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.14, 8, 44),
          new THREE.MeshLambertMaterial({ color: '#241d10', emissive: '#f2b64e', emissiveIntensity: 0.9 }));
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(p.x, fy + 0.22, p.z);
        missionProps.add(ring);
        const colm = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.42, 6.5, 8, 1, true),
          new THREE.MeshBasicMaterial({ color: '#f2b64e', transparent: true, opacity: 0.22,
            side: THREE.DoubleSide, depthWrite: false }));
        colm.position.set(p.x, fy + 3.25, p.z);
        missionProps.add(colm);
        _mRing = ring.material;
      } else if (p.kind === 'generator') {
        /* CH-47.2 — defense target: plinth + humming core + status strip.
           ONE solid footprint so hostiles and bolts respect it.        */
        const base = new THREE.Mesh(unitBox,
          new THREE.MeshLambertMaterial({ color: '#2a2f36' }));
        base.scale.set(1.7, 0.5, 1.7);
        base.position.set(p.x, fy + 0.25, p.z);
        base.castShadow = true; base.receiveShadow = true;
        missionProps.add(base);
        const body = new THREE.Mesh(unitBox,
          new THREE.MeshLambertMaterial({ color: '#3a4250', emissive: '#12314a', emissiveIntensity: 0.4 }));
        body.scale.set(1.15, 1.5, 1.15);
        body.position.set(p.x, fy + 1.25, p.z);
        body.castShadow = true;
        missionProps.add(body);
        const strip = new THREE.Mesh(unitBox,
          new THREE.MeshLambertMaterial({ color: '#0c141c', emissive: '#4fc3ff', emissiveIntensity: 1 }));
        strip.scale.set(1.2, 0.14, 1.2);
        strip.position.set(p.x, fy + 2.05, p.z);
        missionProps.add(strip);
        missionProps.add((() => {
          const cap = new THREE.Mesh(unitBox,
            new THREE.MeshLambertMaterial({ color: '#222830' }));
          cap.scale.set(0.7, 0.5, 0.7);
          cap.position.set(p.x, fy + 2.35, p.z);
          cap.castShadow = true;
          return cap;
        })());
        colliders.push({ minX: p.x - 1.0, maxX: p.x + 1.0,
          minZ: p.z - 1.0, maxZ: p.z + 1.0, y0: 0, y1: fy + 2.6 });
        missionCols.push(colliders[colliders.length - 1]);
        _mRing = strip.material;   // status strip pulses with the ring slot
      } else if (p.kind === 'cache') {
        /* CH-47.2 — recovery cache: small sealed crate, gold trim, bob */
        const box = new THREE.Mesh(unitBox,
          new THREE.MeshLambertMaterial({ color: '#3d3427' }));
        box.scale.set(0.95, 0.7, 0.95);
        box.position.set(p.x, fy + 0.55, p.z);
        box.castShadow = true;
        missionProps.add(box);
        const trim = new THREE.Mesh(unitBox,
          new THREE.MeshLambertMaterial({ color: '#1c170e', emissive: '#ffd98e', emissiveIntensity: 0.95 }));
        trim.scale.set(1.0, 0.12, 1.0);
        trim.position.set(p.x, fy + 0.62, p.z);
        missionProps.add(trim);
        _mCaches.push({ mesh: box, trim, y0: fy + 0.55, x: p.x, z: p.z });
      }
    }
  }

  function updateMissionProps(t, dt) {
    if (!missionProps.children.length) return;
    if (_mBeacon) _mBeacon.opacity = 0.22 + Math.abs(Math.sin(t * 2.4)) * 0.2;
    if (_mCore) { _mCore.rotation.y += dt * 1.6; _mCore.rotation.x += dt * 0.7; }
    if (_mRing) _mRing.emissiveIntensity = 0.7 + Math.abs(Math.sin(t * 3.1)) * 0.6;
    for (const c of _mCaches) {
      c.mesh.position.y = c.y0 + Math.sin(t * 2 + c.x) * 0.07;
      c.trim.position.y = c.mesh.position.y + 0.07;
    }
  }

  /* CH-44.1 — compile every static merge bucket into its final meshes
     (AFTER all decor has stamped — corridor → hangar → valley → city →
     expanse rows → hub; lockers/breakables/mission props never batched).
     Per-zone mesh counts land in world.batchStats for the CH-44 probe. */
  const batchStats = flushBatches();

  return {
    colliders, solids, lights, floorZones, door, door2, winZone, zoneFx,
    breakables, damageBox,
    lockers,                         /* CH-05.1 — beast-opened supply lockers */
    hub, updateHub: hub.updateHub,   /* CH-36 — home base + its per-frame upkeep */
    /* CH-08 — city corridor connectors + transits */
    corridorDoors, corridorAt, zoneFxAt, transits,
    resetCorridorDoors() {           /* run reset + transit cooldowns */
      for (const d of corridorDoors) d.reset();
      resetTransits();
    },
    updateTransits,
    spawns: ASSETS.enemy.spawns.concat(expanseSpawns),
    floorHeightAt, zoneAt, ceilHeightAt,
    hangar: WH, corridor: WC, valley: WV, city: CC,
    /* expanse API */
    expanse: EX, expanseZ0: EX.z0, oceanZ0: OCEAN_Z0, zEnd: Z_END, xHalf: X_HALF,
    batchStats,                       /* CH-44.1 — merge-pass readout */
    harvests, fishZones, animalSpawns,
    tileAt, tileCenterOf,
    setMissionProps,                 /* CH-47.3 — director field props */
    update(t, dt) {
      for (const a of animated) a.update(t, dt);
      updateDebris(dt);
      updateHarvests(dt);
      updateLockers(dt);             /* CH-05.1 — door swing + respawn */
      for (const w of waterAnims) w.mat.map.offset.y -= w.speed * dt;
      updateMissionProps(t, dt);     /* CH-47.3 — beacon pulse · cache bob */
    },
  };
}

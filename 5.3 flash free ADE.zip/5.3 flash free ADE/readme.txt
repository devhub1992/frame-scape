================================================================================
 5.3 FLASH FREE ADE — README
 Agentic Developer Environment for GLM 5.3 Flash Free
 BUILD STAMP: ade-s4-rt01 · SESSION 4 (ROUTING · FLAT-BRIDGE MASTERY) · 2026-10-30
 CODE SHIPPED: NO — routing session: the flat-bridge mastery directive is now
              registered in the plan (m-26…m-28); the app is unchanged from CH-01
 PLAN NEXT: CH-02 (workspace VFS + file tree + full CRUD — fflate now BUILD-TIME vendored)
================================================================================

WHAT THIS IS
------------
This zip is the SESSION-4 deliverable of the ADE campaign: a ROUTING pass (zero
code) that encodes the user's flat-bridge mastery directive into the plan — the
FINISHED ADE must genuinely UNDERSTAND the exact structure and function of the
3 flat files (see FLAT-BRIDGE MASTERY below), the flat files must always live
directly at the project-folder root for any task assembly, and the philosophy
must be HARD-EMBEDDED via JS so any AI linked through the API inherits the
exact pattern. The app itself is unchanged from CH-01: unzip, serve, chat,
configure. The workspace panel is a visible placeholder until CH-02 fills it.

ADE in one sentence: your single-file "Builder Ai" chat app reworked into a
real agentic developer environment — the model (coding-glm-5.3-flash-free)
gets a persistent browser workspace it can actually WORK in: read/write/
rename/delete files, restructure folders, drive a console, and execute
python / js / html — all statically hosted.

WHAT'S IN THIS ZIP
------------------
  index.html          app shell markup ONLY — links css, loads 9 js in the
                      final dependency order (tags never move again)
  css/ade.css         ALL styles — P1-P20 design tokens ported verbatim from
                      Builder Ai (surfaces bg…bg5 · accent #d4893a · radius 5px
                      · Space Grotesk + JetBrains Mono) + every component
  js/util.js          utils · toasts · markdown renderer (incl. pipe tables) ·
                      highlighter (js/py/html/css/json/bash/yaml) · copy/dl
  js/db.js            IndexedDB "ade-db" v1: convs · msgs · configs · settings
                      · vfs · handles + global State + storage.persist()
  js/vfs.js           STUB (CH-02 replaces) — minimal /imports write path for
                      attachments, already using the final VFS row shape
  js/exec.js          STUB (CH-04 replaces) — pyodide / worker / preview / shell
  js/agent.js         STUB (CH-05 replaces) — tool registry, agent loop
  js/ui-chat.js       thread · streaming SSE (content + reasoning_content +
                      index-keyed tool_calls) · attachments · conv sidebar
  js/ui-workspace.js  STUB (CH-02 replaces) — renders the workspace placeholder
  js/ui-settings.js   settings modal: Configs CRUD (incl. maxSteps · contextK
                      · forceProto) · Agent & Workspace status · Proxy Setup
  js/main.js          init · wiring · first-run seed · ADE_BUILD stamp
  routing.flat.txt    the protocol — session-4 directive added (header point 8,
                      §03 profile.flatbridge · §07 build.flatfiles.root),
                      meta.session.4 + meta.last-patch bumped
  manifest.flat.txt   request ledger — 28 requests now (m-26…m-28 registered
                      session 4: flat-file mastery · root-level invariant ·
                      hard-embedded philosophy; m-26/m-28 routed ch-06, m-27
                      done as routing §07 policy)
  planner.flat.txt    THE MOST IMPORTANT FILE — 11 chunks · 48 feature lines ·
                      ch-01 done · ch-06 gains f6/f7 · worklog.4 appended ·
                      plan.next ch-02
  readme.txt          this file
  ref/index_old.html  the superseded Builder Ai single-file app (reference)

STATUS
------
  chunks done : 1/11 (CH-01)     features done : 5/48
  session 4   : ROUTING — m-26…m-28 registered + routed (flat-bridge mastery:
                the ADE must understand the 3 flat files, root-level invariant,
                hard-embedded philosophy via JS); zero code, app unchanged
  plan.next   : CH-02 (workspace VFS — file tree, CRUD, editor, zip, uploads)
  budget      : 30k tokens per routing/iteration session (hard cap, planner §01)

RUN IT (30 seconds)
-------------------
  1. unzip this folder
  2. from inside it:  python -m http.server 8080
  3. open http://localhost:8080  (or host the folder on any static host)
  4. Settings → Configs → set your AiHubMix key (model preset is already
     coding-glm-5.3-flash-free); Settings → Proxy Setup → CorsProxy.io key
  5. send a message — it streams

  file:// works degraded too (chat + storage fine; some CDNs may warn).

WHAT WORKS RIGHT NOW (CH-01)
----------------------------
  · streaming chat with markdown: headings, lists, pipe tables, blockquotes,
    links, bold/italic, fenced code blocks with lang badge + copy + download
  · syntax highlighting for js/py/html/css/json/bash/yaml
  · GLM reasoning: when the endpoint streams reasoning_content the agent
    shows a ✦ thinking marker and the text is captured + persisted — the
    click-to-view panel lands at CH-05 (your m-22, routed ch-05.f6)
  · config manager: full CRUD, model preset chips (coding-glm-5.3-flash-free
    default · glm-5.3-flash · glm-4.6 · glm-4.5-air), free-text model field,
    maxSteps / contextK / forceProto, 4-token Test ping, header dropdown
  · attachments: text files inline as fenced blocks; zips & binaries land in
    workspace /imports/<ts>-<name> (extraction joins at CH-02 with fflate)
  · conversations: sidebar, rename, delete, auto-title, per-message token
    estimates, copy/delete actions, everything persists in IndexedDB
  · the two-key model carried over: CorsProxy.io key (tunnel, shared) +
    AiHubMix key (AI billing, per config) — local-only, as always

CAPABILITIES ON THE ROADMAP (the full specs are the planner f-lines)
--------------------------------------------------------------------
  CH-02  workspace VFS: create/edit/rename/move/delete, tree UI, editor,
         zip import/export (fflate, vendored at build time — no CDN),
         drag-drop that lands IN the workspace
  CH-03  session-persistent File System Access work folder: read/write handle
         kept in IndexedDB, one-click reconnect on reload, write-through on
         every edit, pull/push full-tree sync
  CH-04  executors: Pyodide python (numpy/pandas/matplotlib auto, micropip,
         file sync both ways) · JS worker sandbox · sandboxed HTML preview ·
         virtual shell (30+ commands) with run console
  CH-05  agent loop: 12 real tools, streamed tool trace, step cap + STOP,
         text-protocol fallback + YOUR m-22: click agent name → thinking
         panel (lazy-rendered, zero stream lag)
  CH-06  agent protocol: the system prompt teaches the flat-bridge workflow
         and auto-seeds this zip's flat files INTO the workspace on first boot
         · YOUR m-26/m-28 land here: flat-file MASTERY (exact structure +
         function of all 3 files taught verbatim) + the HARD-EMBEDDED
         FlatBridge.PHILOSOPHY JS constant so any API-linked AI inherits the
         pattern with zero workspace files present
  CH-07  optional local python bridge (ade_server.py): real bash/pip/git
  CH-08+ editor upgrades, configs.flat.txt ledger + "Ship ADE zip" button,
         preview v2 (live reload), hardening/backup

HOW THE CAMPAIGN RUNS (for any AI session)
------------------------------------------
  0. the 3 flat files + readme live DIRECTLY at the project-folder root —
     never nested, names never changed (routing §07 build.flatfiles.root) —
     every task assembly starts there; no root scan needed, the bridge is
     always in the same place
  1. read routing.flat.txt §01 (protocol) → §03 (profile) → §07 (build structure)
  2. read manifest.flat.txt §01 (requests) — new requests register there
  3. open planner.flat.txt, take the plan.next chunk block (ch-02 now)
  4. paste ai.prompt.recipe + that block into a FRESH session, say: run plan.next
  5. the session ships TWO artifacts: the next "5.3 flash free ADE.zip"
     (full folder, name unchanged, readme stamp bumped) + the flat files updated
  6. work is logged in planner §12; configs.flat.txt becomes the per-session
     execution ledger from CH-09 on (schema: planner §02)

MODEL & KEYS
------------
  model    : coding-glm-5.3-flash-free (default; free-text, presets included)
  endpoint : OpenAI-compatible /chat/completions — default base aihubmix.com/v1
  keys     : TWO, both local-only in IndexedDB — a CorsProxy.io key (tunnel)
             and an AiHubMix key (AI billing); same two-key flow as Builder Ai
  fallback : when CH-05 lands, endpoints that reject native tools auto-switch
             to the <<<TOOL>>> text protocol — nothing breaks on "free" tiers

HOSTING
-------
  static   : GitHub Pages / Netlify / Cloudflare Pages — just upload the folder
  local    : python -m http.server 8080   (python hosts it; zero extra files)
  file://  : works degraded (chat + storage fine)
  browsers : Chromium (Chrome/Edge/Brave) = full experience incl. the linked
             work folder (CH-03+) · Firefox/Safari = everything else

SECURITY MODEL
--------------
  keys and data never leave your browser except: AI calls (to your endpoint,
  via your proxy) and folder writes (to the folder YOU picked). Python will
  run in a WASM sandbox, JS in a worker, HTML in a same-origin-less iframe.
  The virtual shell only ever touches the workspace VFS — OS access only
  exists in the opt-in CH-07 local bridge (127.0.0.1).

BANDWIDTH POLICY (THE FINISHED PRODUCT — m-23)
----------------------------------------------
The user's proxy bandwidth is limited — the ADE is built to respect that:
  · static hosting = no default web pulls. Build-time libraries are
    VENDORED into js/vendor/ and loaded locally (fflate first, CH-02).
  · big runtimes pull ONCE, with approval. Pyodide (~10MB core) asks
    before its first download, then the browser caches it — one download
    per browser, ever. A self-fetched release dropped into vendor/pyodide/
    skips the pull entirely.
  · the ADE agent asks before it fetches (CH-06.f4): explain what + why +
    exact size → offer (a) pull once with your approval, or (b) self-fetch
    instructions (exact URL + target path). pip/micropip installs announce
    package size and confirm first.
  · project code the agent writes references local/vendored assets, not
    CDNs.
Nothing in the finished product downloads without your explicit OK.

WORK FOLDER STRUCTURE (FSA — m-24)
----------------------------------
The work folder you link via "Link work folder" (CH-03, Chromium browsers)
is a real disk folder that mirrors the workspace. Expected layout
(routing §07 build.fsa.structure):
  <work-folder>/
  ├── routing.flat.txt      bridge files live at the ROOT — the campaign
  ├── manifest.flat.txt     protocol travels with the workspace (seeded
  ├── planner.flat.txt      into it at CH-06.f2; from then on the folder
  ├── readme.txt            IS the bridge's home)
  ├── imports/              attachment + zip drops land here (CH-01+)
  ├── demo/                 seed demo files (CH-06: hello.py, index.html…)
  └── <your project files>  everything else — synced both ways
Pull imports the folder wholesale (text by extension, binaries ≤8MB);
write-through keeps disk current while autoSync is ON; paths are
sanitized so no write can escape the picked folder. Firefox/Safari has
no FSA — zip import/export stays the fallback there.

FLAT-BRIDGE MASTERY (THE 3 FLAT FILES — m-26…m-28, SESSION 4)
-------------------------------------------------------------
The user's session-4 directive: the finished ADE must UNDERSTAND the exact
structure and function of the 3 flat files — and the philosophy must be
HARD-EMBEDDED via JS so ANY AI linked through the API understands this exact
pattern. Here is the pattern, in full (this is what the ADE system prompt will
teach verbatim at ch-06.f6, and what FlatBridge.PHILOSOPHY will carry as code
at ch-06.f7):

  THE ONE RULE
  ------------
  register, never remember. Every request, every done item, every projected
  task becomes a LINE in a flat file. Nothing lives only in chat or memory.
  Lines never vanish — they move and flip status. The files are the single
  source of truth between the user and every future AI session.

  THE 3 FILES — STRUCTURE AND FUNCTION
  ------------------------------------
  routing.flat.txt — THE PROTOCOL (how work happens)
    structure : fixed sections §00–§07 · key = value, one fact per line, no
                nesting · group.key for fixed groups · group.id.attr for
                enumerated instances · # banners mark sections, state lives
                ON the line never in comments
    function  : §01 the AI protocol (session types · one chunk per iteration ·
                plan.next · 30k budget zones · the ai.prompt.recipe that assembles
                a task) · §02 how user requests enter · §03 the project profile
                (what we are building) · §06 strategy verdicts · §07 the
                expected build structure — the contract the code must match

  manifest.flat.txt — THE REQUEST LEDGER (what the user asked)
    structure : m-NN lines, each with .text · .status · .routed · .note ·
                §01 session batches · §09 inbox for mid-run interrupts ·
                meta.denominator/open/done counters · §12 append-only session log
    function  : every request is registered verbatim-intent, status = open →
                routed (keyword-matched to an open chunk per ai.routing.rule) →
                done (only when the feature actually ships); routing MOVES a
                line (m-NN.routed = ch-NN), it never deletes it

  planner.flat.txt — THE WORK PLAN (the most important file)
    structure : ch-NN chunk blocks, each with .title · .size · .est.k ·
                .status · .deps · .files · .keywords · fX feature lines with
                .text/.status/.source · §01 plan-state (plan.next, progress) ·
                §02 configs.flat.txt schema · §12 append-only worklog
    function  : dependency-ordered, token-budgeted sessions; plan.next names
                the top runnable chunk; a chunk ships only when ALL its open
                fX flip done in one sweep; worklog.N records every session
                (files touched · decisions · follow-ups must point at real lines)

  THE ROOT INVARIANT (m-27)
  -------------------------
  the 3 flat files + readme live DIRECTLY inside the project folder — root
  level, never nested, names never changed — in every assembly surface: this
  zip · the VFS auto-seed (ch-06.f2 fetches ./*.flat.txt into /) · the FSA
  linked work folder (ch-03.f5) · the ship-zip release set (ch-09.f2). Any
  task assembly — fresh unzip, AI session, agent run — finds the bridge
  immediately at the same place. (routing §07 build.flatfiles.root)

  THE HARD EMBED (m-28) — PHILOSOPHY = CODE · STATE = FILES
  ---------------------------------------------------------
  two layers, by design:
    · philosophy layer (CODE) — FlatBridge.PHILOSOPHY, a JS constant hard-coded
      in js/agent.js (ch-06.f7): the files' roles, the request→routed→done
      lifecycle, register-never-remember · append-only · stable-keys, the read
      order, the two-artifact deliverable. Injected into EVERY system prompt —
      any model, any config, any endpoint (native tools or <<<TOOL>>>
      text-protocol) — even with ZERO workspace files present. No runtime file
      reads required; the pattern cannot be lost.
    · state layer (FILES) — the live .flat.txt contents from the workspace
      root, appended on top of the philosophy layer when present: current
      statuses, plan.next, open requests. This is what the agent edits,
      line-by-line, per the flat conventions (routing §04).
  Any AI linked through the ADE's API therefore inherits the exact pattern on
  every turn — and any external AI session the user runs gets it from the
  files at the project root. Same protocol, everywhere, by construction.

SESSION-4 DECISIONS OF RECORD
-----------------------------
  directive scope  : PRODUCT capability (like session 3's m-23) — the ADE
                     itself must master the protocol; campaign flow unchanged
  registration     : m-26 (flat-file mastery) · m-27 (root-level invariant,
                     done this session as routing §07 build.flatfiles.root) ·
                     m-28 (hard-embedded philosophy via JS) — m-26/m-28 open,
                     routed ch-06
  routing          : m-26 → ch-06.f6 (system prompt teaches the exact anatomy
                     + function of all 3 files) · m-28 → ch-06.f7
                     (FlatBridge.PHILOSOPHY JS constant, failsafe layer,
                     CH-05's agent.js replacement must carry it forward) ·
                     m-27 → routing §07 build.flatfiles.root (no new feature
                     line needed — the invariant already holds everywhere)
  design split     : philosophy = CODE (model-agnostic, survives missing
                     files) vs state = FILES (live statuses, edited line-by-line)
  denominators     : features 46→48 (ch-06.f6, ch-06.f7) · requests 25→28 ·
                     ch-06.est.k 14→17 (still size M)
  code             : NONE this session — the embed ships with CH-06 per
                     ai.unit-of-work; plan.next stays ch-02

SESSION-3 DECISIONS OF RECORD
-----------------------------
  constraint scope : PRODUCT-only (user correction mid-session) — governs the
                     finished ADE + its agent, NOT the campaign sessions
  registration     : m-23 (bandwidth) · m-24 (work-folder structure) ·
                     m-25 (workdir persistence) — all open, routed
  routing          : m-23 → ch-06.f4 (agent tool policy) + ch-02.f4 / ch-04.f1 /
                     ch-08.f1 (lib acquisition) · m-24 → ch-03.f5 + routing §07
                     build.fsa.structure + readme §WORK FOLDER · m-25 → ch-06.f5
                     (+ ch-03, which m-18 already owns)
  libs             : fflate → build-time vendored js/vendor/fflate.min.js ·
                     pyodide → one approved pull (~10MB, stated) + browser cache,
                     or self-fetched release in vendor/pyodide/ · codemirror →
                     vendored or omitted — zero runtime CDNs in all cases
  denominators     : features 43→46 (ch-03.f5, ch-06.f4, ch-06.f5) · requests
                     21→25 (fixes stale session-2 count)

SESSION-2 DECISIONS OF RECORD
-----------------------------
  stub strategy       : vfs/exec/agent/ui-workspace ship as marked stubs so
                        index.html script tags are FROZEN in final load order
                        — CH-02/04/05 are pure file replacements
  vfs row shape       : CH-01's /imports rows already use the final CH-02
                        shape (path · kind · parent · isText · content · size
                        · mtime) — additive-only, nothing migrates later
  zip extraction      : deferred to ch-02.f4 (fflate lands there)
  streamChat location : ui-chat.js for CH-01; moves into agent.js at CH-05
  m-22 (thinking)     : registered mid-run per ai.interrupt.rule → routed
                        ch-05.f6; CH-01 captures reasoning_content already

SESSION-1 DECISIONS OF RECORD (unchanged)
-----------------------------------------
  static-first verdict : FEASIBLE — full matrix in routing.flat.txt §06
  real OS console      : statically impossible (browser sandbox) → virtual
                         shell now, optional local bridge later (CH-07)
  structure            : actively split css/js per best practice (your m-17 —
                         SHIPPED this session)
  persistence          : FSA handle session-persistent via IndexedDB (m-18)
================================================================================

/* ============================================================
   js/db.js — ADE-01.2 · IndexedDB core ("ade-db" v1)
   stores: convs · msgs (idx convId) · configs · settings (kv)
           · vfs (path rows + parent idx) · handles (FSA, 'wsdir')
   + global State + settings helpers + storage.persist() on boot.
   SCHEMA IS ADDITIVE-ONLY (routing §01 ai.saves.rule): future
   chunks may add stores/keys/indexes — never rename or drop.
   ============================================================ */
"use strict";

const DB = (() => {
  const DB_NAME = "ade-db";
  const DB_VERSION = 1;

  const STORE_CONVS = "convs";      // { id, title, ts, lastTs }
  const STORE_MSGS = "msgs";        // { id, convId, role, content, reasoning?, toolCalls?, atts?, model?, error?, ts }
  const STORE_CONFIGS = "configs";  // { id, name, model, baseUrl, apiKey, proxyUrl, temperature, maxTokens, maxSteps, contextK, forceProto, ts }
  const STORE_SETTINGS = "settings";// kv: key -> any
  const STORE_VFS = "vfs";          // { path, kind, parent, isText, content, size, mtime } (index: parent)
  const STORE_HANDLES = "handles";  // kv: 'wsdir' -> FileSystemDirectoryHandle

  let _dbPromise = null;

  function open() {
    if (_dbPromise) return _dbPromise;
    _dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_CONVS)) db.createObjectStore(STORE_CONVS, { keyPath: "id" });
        if (!db.objectStoreNames.contains(STORE_MSGS)) {
          const s = db.createObjectStore(STORE_MSGS, { keyPath: "id" });
          s.createIndex("convId", "convId", { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_CONFIGS)) db.createObjectStore(STORE_CONFIGS, { keyPath: "id" });
        if (!db.objectStoreNames.contains(STORE_SETTINGS)) db.createObjectStore(STORE_SETTINGS);
        if (!db.objectStoreNames.contains(STORE_VFS)) {
          const s = db.createObjectStore(STORE_VFS, { keyPath: "path" });
          s.createIndex("parent", "parent", { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_HANDLES)) db.createObjectStore(STORE_HANDLES);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return _dbPromise;
  }

  function tx(store, mode, fn) {
    return open().then(db => new Promise((resolve, reject) => {
      const t = db.transaction(store, mode);
      const s = t.objectStore(store);
      const req = fn(s);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  }

  return {
    STORES: { CONVS: STORE_CONVS, MSGS: STORE_MSGS, CONFIGS: STORE_CONFIGS, SETTINGS: STORE_SETTINGS, VFS: STORE_VFS, HANDLES: STORE_HANDLES },

    /* generic helpers — get/set/del/all/byIndex/clear */
    get: (store, key) => tx(store, "readonly", s => s.get(key)),
    set: (store, val, key) => tx(store, "readwrite", s => key !== undefined ? s.put(val, key) : s.put(val)),
    del: (store, key) => tx(store, "readwrite", s => s.delete(key)),
    all: (store) => tx(store, "readonly", s => s.getAll()),
    byIndex: (store, index, key) => tx(store, "readonly", s => s.index(index).getAll(key)),
    clear: (store) => tx(store, "readwrite", s => s.clear()),

    /* kv sugar for settings + handles stores */
    getSetting: async (key) => { try { return await tx(STORE_SETTINGS, "readonly", s => s.get(key)); } catch { return undefined; } },
    setSetting: (key, val) => tx(STORE_SETTINGS, "readwrite", s => s.put(val, key)),
    delSetting: (key) => tx(STORE_SETTINGS, "readwrite", s => s.delete(key)),
    getHandle: (key) => tx(STORE_HANDLES, "readonly", s => s.get(key)),
    setHandle: (key, val) => tx(STORE_HANDLES, "readwrite", s => s.put(val, key)),
    delHandle: (key) => tx(STORE_HANDLES, "readwrite", s => s.delete(key)),

    /* convs + msgs + configs */
    allConvs: async () => {
      const all = await tx(STORE_CONVS, "readonly", s => s.getAll());
      return all.sort((a, b) => (b.lastTs || b.ts) - (a.lastTs || a.ts));
    },
    saveConv: (c) => tx(STORE_CONVS, "readwrite", s => s.put(c)),
    delConv: async (id) => {
      const msgs = await DB.byIndex(STORE_MSGS, "convId", id);
      for (const m of msgs) await tx(STORE_MSGS, "readwrite", s => s.delete(m.id));
      await tx(STORE_CONVS, "readwrite", s => s.delete(id));
    },
    msgsByConv: async (convId) => {
      const all = await DB.byIndex(STORE_MSGS, "convId", convId);
      return all.sort((a, b) => a.ts - b.ts);
    },
    saveMsg: (m) => tx(STORE_MSGS, "readwrite", s => s.put(m)),
    delMsg: (id) => tx(STORE_MSGS, "readwrite", s => s.delete(id)),
    allConfigs: async () => {
      const all = await tx(STORE_CONFIGS, "readonly", s => s.getAll());
      return all.sort((a, b) => a.ts - b.ts);
    },
    saveConfig: (c) => tx(STORE_CONFIGS, "readwrite", s => s.put(c)),
    delConfig: (id) => tx(STORE_CONFIGS, "readwrite", s => s.delete(id)),

    /* boot — open + request durable storage (ADE-01.2) */
    async init() {
      await open();
      try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch { /* best effort */ }
    }
  };
})();

/* ── global State — in-memory mirror, persisted via DB ───── */
const State = {
  convs: [],            // [{ id, title, ts, lastTs }]
  msgs: [],             // active conversation's messages
  configs: [],          // [{ ...config }]
  activeConfigId: null,
  activeConvId: null,
  streaming: false,     // a stream is in flight
  pendingAtts: [],      // composer attachments [{ name, type, size, text?|blob? }]
  sessionRequests: 0,   // AI request count this session
  corsKey: ""           // shared CorsProxy.io key (settings store)
};

/* settings keys used across modules (additive-only) */
const SK = {
  ACTIVE_CONFIG: "active_config_id",
  ACTIVE_CONV: "active_conv_id",
  CORS_KEY: "corsproxy_api_key"
};

/* default config factory — f3: model presets + agent fields */
function makeDefaultConfig() {
  return {
    id: U.uid(),
    name: "GLM 5.3 Flash Free",
    model: "coding-glm-5.3-flash-free",   // m-03: main model, free text
    baseUrl: "https://aihubmix.com/v1",
    apiKey: "",
    proxyUrl: "https://corsproxy.io/?key={corskey}&url={url}",
    temperature: 0.6,
    maxTokens: 8192,
    maxSteps: 24,        // agent step cap (used from CH-05)
    contextK: 24,        // context budget k-tokens (used from CH-05)
    forceProto: false,   // force <<<TOOL>>> text protocol (CH-05)
    ts: Date.now()
  };
}
/* model preset chips shown in the config editor (f3) */
const MODEL_PRESETS = [
  "coding-glm-5.3-flash-free",
  "glm-5.3-flash",
  "glm-4.6",
  "glm-4.5-air"
];

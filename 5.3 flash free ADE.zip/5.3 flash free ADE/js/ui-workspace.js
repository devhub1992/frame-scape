/* ============================================================
   js/ui-workspace.js — workspace UI STUB (CH-01).
   Filled at CH-02 (markers /* ADE-02.2 *&#47;, /* ADE-02.3 *&#47; …):
   recursive file tree · per-row CRUD actions · editor modal ·
   zip import/export · upload integration. CH-03 adds the
   link/pull/push header actions (/* ADE-03.x *&#47;).
   CH-01 renders the placeholder empty state so the panel is
   real and toggleable from day one.
   ============================================================ */
"use strict";

const WSUI = {
  el: null,

  init() {
    this.el = document.getElementById("ws-body");
    this.renderPlaceholder();
    document.getElementById("toggle-ws")?.addEventListener("click", () => WorkspaceUI.toggle());
    document.getElementById("ws-close")?.addEventListener("click", () => WorkspaceUI.toggle(false));
  },

  renderPlaceholder() {
    if (!this.el) return;
    this.el.innerHTML = `
      <div class="ws-empty">
        <i class="fa-solid fa-folder-tree"></i>
        <div>Workspace VFS lands in <strong>CH-02</strong></div>
        <span class="ws-chip">0/42 features · CH-01 core shell</span>
        <ul>
          <li><i class="fa-solid fa-angle-right"></i> IndexedDB file tree + full CRUD</li>
          <li><i class="fa-solid fa-angle-right"></i> built-in text editor</li>
          <li><i class="fa-solid fa-angle-right"></i> zip import / export</li>
          <li><i class="fa-solid fa-angle-right"></i> linked work folder (CH-03)</li>
          <li><i class="fa-solid fa-angle-right"></i> python / js / html + shell (CH-04)</li>
        </ul>
      </div>`;
  }
};

/* header toggle lives here so CH-02 owns it without touching main */
const WorkspaceUI = {
  toggle(force) {
    const panel = document.getElementById("ws-panel");
    const open = force !== undefined ? force : !panel.classList.contains("open");
    panel.classList.toggle("open", open);
    try { DB.setSetting("ws_panel_open", open); } catch { /* best effort */ }
  }
};

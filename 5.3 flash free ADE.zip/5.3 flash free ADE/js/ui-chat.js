/* ============================================================
   js/ui-chat.js — ADE-01.4 streaming chat + ADE-01.5 attachments
   thread render · conversation sidebar · send flow (SSE parser
   with delta content + reasoning_content capture + index-keyed
   tool_calls accumulation) · markdown rendering · attachment
   chips (text → inlined fenced blocks; zip/binary → VFS
   /imports via the CH-01 vfs stub) · per-message token estimates.
   NOTE: streamChat moves to js/agent.js at CH-05 and gains the
   tool loop; the parser below is already tool_calls-ready.
   ============================================================ */
"use strict";

const ChatUI = {
  abortCtl: null, // current AbortController while streaming

  /* ══ sidebar · conversations ════════════════════════════ */
  async renderSidebar() {
    const list = document.getElementById("conv-list");
    State.convs = await DB.allConvs();
    document.getElementById("conv-count").textContent = State.convs.length + " conv";
    if (!State.convs.length) {
      list.innerHTML = `<div class="conv-empty">No conversations yet.</div>`;
      return;
    }
    list.innerHTML = State.convs.map(c => {
      const active = c.id === State.activeConvId;
      return `<div class="conv-item ${active ? "active" : ""}" data-id="${c.id}">
        <div class="conv-row">
          <i class="fa-regular fa-message conv-icon"></i>
          <span class="conv-title">${U.escapeHtml(c.title || "Untitled")}</span>
          <span class="conv-actions">
            <button class="conv-action" data-act="rename" title="Rename"><i class="fa-solid fa-pen"></i></button>
            <button class="conv-action danger" data-act="del" title="Delete"><i class="fa-solid fa-trash"></i></button>
          </span>
        </div>
        <div class="conv-meta"><span>${U.fmtTime(c.lastTs || c.ts)}</span></div>
      </div>`;
    }).join("");
  },

  async newConversation() {
    const conv = { id: U.uid(), title: "New conversation", ts: Date.now(), lastTs: Date.now() };
    await DB.saveConv(conv);
    State.activeConvId = conv.id;
    await DB.setSetting(SK.ACTIVE_CONV, conv.id);
    State.msgs = [];
    await this.renderSidebar();
    this.renderThread();
    document.getElementById("msg-input").focus();
  },

  async openConversation(id) {
    State.activeConvId = id;
    await DB.setSetting(SK.ACTIVE_CONV, id);
    State.msgs = await DB.msgsByConv(id);
    await this.renderSidebar();
    this.renderThread();
    const conv = State.convs.find(c => c.id === id);
    document.getElementById("header-title").textContent = conv ? conv.title : "ADE";
  },

  async deleteConversation(id) {
    if (!confirm("Delete this conversation and all its messages?")) return;
    await DB.delConv(id);
    if (State.activeConvId === id) {
      State.activeConvId = null;
      State.msgs = [];
      await DB.setSetting(SK.ACTIVE_CONV, null);
      this.renderThread();
    }
    await this.renderSidebar();
    U.toast("Conversation deleted", { kind: "ok" });
  },

  startRename(id) {
    const item = document.querySelector(`.conv-item[data-id="${id}"]`);
    if (!item) return;
    const conv = State.convs.find(c => c.id === id);
    const row = item.querySelector(".conv-row");
    row.innerHTML = `<input class="rename-input" value="${U.escapeHtml(conv.title || "")}" />`;
    const input = row.querySelector("input");
    input.focus();
    input.select();
    const commit = async (save) => {
      if (save && input.value.trim()) {
        conv.title = input.value.trim();
        await DB.saveConv(conv);
        if (State.activeConvId === id) document.getElementById("header-title").textContent = conv.title;
      }
      await this.renderSidebar();
    };
    input.addEventListener("keydown", e => {
      if (e.key === "Enter") commit(true);
      else if (e.key === "Escape") commit(false);
    });
    input.addEventListener("blur", () => commit(true), { once: true });
  },

  /* ══ thread render ══════════════════════════════════════ */
  renderThread() {
    const thread = document.getElementById("thread");
    const conv = State.convs.find(c => c.id === State.activeConvId);
    document.getElementById("header-title").textContent = conv ? conv.title : "ADE";
    if (!State.msgs.length) {
      thread.innerHTML = `<div class="thread-empty"><div class="empty-card">
        <i class="fa-solid fa-terminal"></i>
        <p class="title">Agentic Developer Environment</p>
        <p class="sub">Chat now; the agent gains its workspace, executors and tools over CH-02 → CH-06.</p>
        <div class="hints">
          <span><i class="fa-solid fa-angle-right"></i> Attach text files — they inline into your message</span>
          <span><i class="fa-solid fa-angle-right"></i> Zips &amp; binaries land in workspace /imports (tree arrives CH-02)</span>
          <span><i class="fa-solid fa-angle-right"></i> Everything is local: IndexedDB convs, configs, keys</span>
        </div>
      </div></div>`;
      return;
    }
    thread.innerHTML = State.msgs.map(m => this.msgHtml(m)).join("");
    thread.scrollTop = thread.scrollHeight;
  },

  msgHtml(m) {
    const isUser = m.role === "user";
    const isStream = m.id === State.streamingId;
    const modelBadge = !isUser && m.model ? `<span class="model">${U.escapeHtml(m.model)}</span>` : "";
    const tokEst = `<span class="tok-est">~${U.fmtTokens(U.estimateTokens(m.content || ""))} tok</span>`;
    const thinkingTag = !isUser && m.reasoning ? `<span class="thinking-tag" title="Reasoning captured — the click-to-view thinking panel lands at CH-05 (m-22)">✦ thought</span>` : "";
    const streamTag = isStream ? `<span class="streaming-tag"><span class="blink">●</span> streaming</span>` : "";
    const errHtml = m.error
      ? `<div class="bubble error"><div class="err-title"><i class="fa-solid fa-triangle-exclamation"></i> Request failed</div>${U.escapeHtml(m.error)}</div>`
      : `<div class="bubble"><div class="md ${isStream ? "cursor-blink" : ""}">${renderMarkdown(m.content) || (isStream ? "" : "<p><em>(empty)</em></p>")}</div></div>`;
    const attHtml = (m.atts && m.atts.length)
      ? `<div class="att-list">${m.atts.map(a => `
          <span class="att-chip" title="${a.vfsPath ? "in workspace: " + U.escapeHtml(a.vfsPath) : "inlined into message"}">
            <i class="${U.fileIcon(a.name)}"></i>
            <span class="att-name">${U.escapeHtml(a.name)}</span>
            <span class="att-size">${U.fmtBytes(a.size)}</span>
          </span>`).join("")}</div>`
      : "";
    const actions = isStream ? "" : `<div class="msg-actions">
      <button class="conv-action" data-act="copy-msg" title="Copy text"><i class="fa-regular fa-copy"></i></button>
      ${isUser ? "" : `<button class="conv-action" data-act="del-msg" title="Delete message"><i class="fa-solid fa-trash"></i></button>`}
    </div>`;
    return `<div class="msg ${isUser ? "user" : "assistant"}" data-id="${m.id}">
      <div class="avatar"><i class="fa-solid ${isUser ? "fa-user" : "fa-robot"}"></i></div>
      <div class="body">
        <div class="meta">
          <span class="role">${isUser ? "You" : "Agent"}</span>
          ${modelBadge}${streamTag}${thinkingTag}${tokEst}
        </div>
        ${attHtml}
        ${errHtml}
        ${actions}
      </div>
    </div>`;
  },

  async deleteMessage(id) {
    await DB.delMsg(id);
    State.msgs = State.msgs.filter(m => m.id !== id);
    this.renderThread();
  },

  /* ══ attachments (ADE-01.5) ═════════════════════════════
     text files → inlined as fenced blocks into the user message
     zip / binaries → saved straight into the workspace VFS at
     /imports/<ts>-<name> via the CH-01 vfs stub (row shape is
     the final CH-02 shape — extraction lands with CH-02 fflate) */
  async addFiles(files) {
    for (const f of files) {
      if (State.pendingAtts.length >= 10) { U.toast("Attachment cap", { kind: "err", msg: "Max 10 files per message." }); break; }
      const att = { id: U.uid(), name: f.name, type: f.type || "application/octet-stream", size: f.size };
      if (U.isTextName(f.name, f.type) && f.size <= 2 * 1024 * 1024) {
        att.text = await U.readTextFile(f);
      } else {
        att.blob = f;
        att.kind = "binary";
        if (f.size > 24 * 1024 * 1024) {
          U.toast("File too large", { kind: "err", msg: f.name + " exceeds 24 MB — skipped." });
          continue;
        }
      }
      State.pendingAtts.push(att);
    }
    this.renderAttPreview();
  },

  renderAttPreview() {
    const box = document.getElementById("att-preview");
    box.innerHTML = State.pendingAtts.map(a => `
      <span class="att-chip" data-id="${a.id}" title="${a.kind === "binary" ? "lands in workspace /imports" : "text — inlines into message"}">
        <i class="${U.fileIcon(a.name)}"></i>
        <span class="att-name">${U.escapeHtml(a.name)}</span>
        <span class="att-size">${U.fmtBytes(a.size)}${a.kind === "binary" ? " · → /imports" : ""}</span>
        <i class="fa-solid fa-xmark att-x" data-act="rm-att"></i>
      </span>`).join("");
  },

  /* persist binary attachments into the VFS; returns chip records */
  async storeBinaryAtts(atts) {
    const out = [];
    for (const a of atts) {
      if (a.kind !== "binary") { out.push({ name: a.name, size: a.size, inline: true }); continue; }
      try {
        const buf = await U.readArrayBuffer(a.blob);
        const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
        const path = `/imports/${ts}-${a.name}`;
        await VFS.put(path, buf, false);
        out.push({ name: a.name, size: a.size, vfsPath: path });
      } catch (e) {
        U.toast("Import failed", { kind: "err", msg: a.name + " — " + (e?.message || e) });
        out.push({ name: a.name, size: a.size, inline: true });
      }
    }
    return out;
  },

  /* ══ send flow ═════════════════════════════════════════ */
  buildUserContent(text, atts) {
    let content = text || "";
    for (const a of atts) {
      if (a.text != null) {
        const lang = (a.name.split(".").pop() || "").toLowerCase();
        content += `\n\n--- File: ${a.name} ---\n\`\`\`${lang}\n${a.text}\n\`\`\`\n--- End ${a.name} ---`;
      }
    }
    return content.trim();
  },

  activeConfig() {
    return State.configs.find(c => c.id === State.activeConfigId) || null;
  },

  async send() {
    if (State.streaming) return;
    const input = document.getElementById("msg-input");
    const text = input.value.trim();
    const atts = State.pendingAtts.slice();
    if (!text && !atts.length) return;

    const cfg = this.activeConfig();
    if (!cfg) { U.toast("No AI config", { kind: "err", msg: "Open Settings → Configs and add one." }); return; }
    if (!cfg.apiKey) { U.toast("Missing API key", { kind: "err", msg: `Config "${cfg.name}" has no AiHubMix key.` }); return; }

    if (!State.activeConvId) await this.newConversation();

    const attRecords = await this.storeBinaryAtts(atts);
    const content = this.buildUserContent(text, atts);

    const userMsg = { id: U.uid(), convId: State.activeConvId, role: "user", content, atts: attRecords, ts: Date.now() };
    await DB.saveMsg(userMsg);
    State.msgs.push(userMsg);
    State.pendingAtts = [];
    this.renderAttPreview();

    const conv = State.convs.find(c => c.id === State.activeConvId);
    if (conv && (conv.title === "New conversation" || !conv.title)) {
      conv.title = (text || atts[0]?.name || "Conversation").slice(0, 48);
      await DB.saveConv(conv);
    }
    conv.lastTs = Date.now();
    await DB.saveConv(conv);

    const asstMsg = { id: U.uid(), convId: State.activeConvId, role: "assistant", content: "", model: cfg.model, ts: Date.now() };
    await DB.saveMsg(asstMsg);
    State.msgs.push(asstMsg);
    State.streamingId = asstMsg.id;

    input.value = "";
    this.autoResize(input);
    this.renderThread();
    this.setStreaming(true);

    try {
      await this.streamChat(cfg, userMsg, asstMsg);
    } finally {
      State.streamingId = null;
      this.setStreaming(false);
      await this.renderSidebar();
      this.renderThread();
    }
  },

  setStreaming(on) {
    State.streaming = on;
    document.getElementById("send-btn").style.display = on ? "none" : "";
    document.getElementById("stop-btn").style.display = on ? "" : "none";
  },

  /* resolved request URL — proxy template with {url}/{corskey} */
  async resolveUrl(cfg) {
    const target = (cfg.baseUrl || "").replace(/\/+$/, "") + "/chat/completions";
    const tpl = (cfg.proxyUrl || "").trim();
    if (!tpl) return target;
    let url = tpl;
    if (url.includes("{corskey}")) {
      url = url.replace("{corskey}", encodeURIComponent(State.corsKey || ""));
    }
    if (url.includes("{url}")) {
      url = url.replace("{url}", encodeURIComponent(target));
      return url;
    }
    // prefix-style proxy (e.g. https://proxy.cors.sh/) — append target
    if (!/\{\w+\}/.test(url)) return url.replace(/\/+$/, "") + "/" + target;
    return url;
  },

  /* ══ SSE streaming (ADE-01.4) ══════════════════════════
     delta content + reasoning_content capture (serves m-22 —
     the thinking viewer UI lands at CH-05) + index-keyed
     tool_calls fragment accumulation. 60ms throttled flush.  */
  async streamChat(cfg, userMsg, asstMsg) {
    State.sessionRequests++;
    const history = State.msgs.filter(m => m.id !== asstMsg.id && !m.error && (m.content || "").trim());
    const apiMessages = [{ role: "system", content: this.systemPrompt(cfg) }];
    for (const m of history) {
      apiMessages.push({ role: m.role, content: m.content });
    }

    const bodyObj = {
      model: cfg.model,
      messages: apiMessages,
      stream: true,
      temperature: Number(cfg.temperature ?? 0.6),
      max_tokens: Number(cfg.maxTokens ?? 8192)
    };

    this.abortCtl = new AbortController();
    const url = await this.resolveUrl(cfg);

    let res;
    try {
      res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": "Bearer " + cfg.apiKey },
        body: JSON.stringify(bodyObj),
        signal: this.abortCtl.signal
      });
    } catch (e) {
      if (e.name === "AbortError") { await this.finalize(asstMsg, { aborted: true }); return; }
      let hint = e?.message || String(e);
      if (/Failed to fetch|NetworkError|Load failed/i.test(hint)) {
        hint = hint + (cfg.proxyUrl
          ? " — the CORS proxy may be down, rate-limited, or your CorsProxy key is missing/invalid (Settings → Proxy Setup)."
          : " — the provider likely blocks browser CORS. Set a Proxy URL in Settings.");
      }
      asstMsg.error = hint;
      await DB.saveMsg(asstMsg);
      this.renderThread();
      return;
    }

    if (!res.ok) {
      let detail = "";
      try { detail = (await res.text()).slice(0, 500); } catch { /* ignore */ }
      asstMsg.error = `HTTP ${res.status} ${res.statusText}${detail ? " — " + detail : ""}`;
      await DB.saveMsg(asstMsg);
      this.renderThread();
      return;
    }
    if (!res.body) {
      asstMsg.error = "No response body from upstream.";
      await DB.saveMsg(asstMsg);
      this.renderThread();
      return;
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "", acc = "", reasonAcc = "";
    const toolAcc = {}; // index-keyed tool_calls fragment accumulation
    let lastFlush = 0;
    let aborted = false;

    const patchDom = () => {
      // cheap in-place stream update — full re-render on finish
      const el = document.querySelector(`.msg[data-id="${asstMsg.id}"] .md`);
      if (el) {
        el.innerHTML = renderMarkdown(acc);
        const thread = document.getElementById("thread");
        thread.scrollTop = thread.scrollHeight;
      }
    };

    while (true) {
      let chunk;
      try { chunk = await reader.read(); }
      catch { aborted = true; break; }
      if (chunk.done) break;
      buffer += decoder.decode(chunk.value, { stream: true });
      const events = buffer.split("\n\n");
      buffer = events.pop() || "";
      for (const evt of events) {
        for (const line of evt.split("\n")) {
          if (!line.startsWith("data:")) continue;
          const data = line.slice(5).trim();
          if (data === "[DONE]") { buffer = ""; break; }
          try {
            const json = JSON.parse(data);
            const delta = json?.choices?.[0]?.delta || {};
            if (typeof delta.content === "string" && delta.content) {
              acc += delta.content;
            }
            /* reasoning capture — GLM streams reasoning_content (m-22) */
            if (typeof delta.reasoning_content === "string" && delta.reasoning_content) {
              reasonAcc += delta.reasoning_content;
              const tag = document.querySelector(`.msg[data-id="${asstMsg.id}"] .meta`);
              if (tag && !tag.querySelector(".thinking-tag")) {
                tag.insertAdjacentHTML("beforeend", `<span class="thinking-tag">✦ thinking</span>`);
              }
            }
            /* tool_calls fragments — index-keyed (CH-05 consumes) */
            if (Array.isArray(delta.tool_calls)) {
              for (const tc of delta.tool_calls) {
                const i = tc.index ?? 0;
                toolAcc[i] = toolAcc[i] || { id: "", name: "", arguments: "" };
                if (tc.id) toolAcc[i].id += tc.id;
                if (tc.function?.name) toolAcc[i].name += tc.function.name;
                if (tc.function?.arguments) toolAcc[i].arguments += tc.function.arguments;
              }
            }
            const now = Date.now();
            if (now - lastFlush > 60 && acc) { patchDom(); lastFlush = now; }
          } catch { /* skip malformed frame */ }
        }
      }
    }

    const toolCalls = Object.keys(toolAcc).length ? Object.values(toolAcc) : undefined;
    await this.finalize(asstMsg, { acc, reasonAcc, toolCalls, aborted });
  },

  async finalize(asstMsg, { acc = "", reasonAcc = "", toolCalls, aborted = false } = {}) {
    asstMsg.content = acc;
    if (reasonAcc) asstMsg.reasoning = reasonAcc;      // persisted — CH-05 viewer reads this
    if (toolCalls) asstMsg.toolCalls = toolCalls;      // persisted — CH-05 replays these
    if (aborted && !acc) asstMsg.error = "Stopped before any tokens arrived.";
    else if (!acc && !aborted && !asstMsg.error) asstMsg.error = "Empty response from model.";
    await DB.saveMsg(asstMsg);
    const conv = State.convs.find(c => c.id === State.activeConvId);
    if (conv) { conv.lastTs = Date.now(); await DB.saveConv(conv); }
  },

  systemPrompt(cfg) {
    // CH-06 replaces this with the full ADE protocol prompt (marker ADE-06.1).
    return "You are the ADE agent (Agentic Developer Environment), running inside the user's locally-hosted workspace. Be precise, concise and practical. Use markdown with fenced code blocks for code.";
  },

  /* ══ composer wiring ═══════════════════════════════════ */
  autoResize(ta) {
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 180) + "px";
  },

  initComposer() {
    const input = document.getElementById("msg-input");
    input.addEventListener("keydown", e => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); this.send(); }
    });
    input.addEventListener("input", () => this.autoResize(input));

    document.getElementById("send-btn").addEventListener("click", () => this.send());
    document.getElementById("stop-btn").addEventListener("click", () => {
      try { this.abortCtl?.abort(); } catch { /* ignore */ }
    });

    document.getElementById("attach-btn").addEventListener("click", () => document.getElementById("file-input").click());
    document.getElementById("file-input").addEventListener("change", e => {
      this.addFiles([...e.target.files]);
      e.target.value = "";
    });

    // drag-drop onto the composer → attachments (ADE-01.5)
    const area = document.getElementById("input-area");
    let dragDepth = 0;
    area.addEventListener("dragenter", e => { e.preventDefault(); dragDepth++; area.classList.add("dragging"); });
    area.addEventListener("dragover", e => e.preventDefault());
    area.addEventListener("dragleave", () => { if (--dragDepth <= 0) { dragDepth = 0; area.classList.remove("dragging"); } });
    area.addEventListener("drop", async e => {
      e.preventDefault();
      dragDepth = 0;
      area.classList.remove("dragging");
      if (e.dataTransfer?.files?.length) await this.addFiles([...e.dataTransfer.files]);
    });

    // attachment chip remove + message actions (delegated)
    document.getElementById("att-preview").addEventListener("click", e => {
      const x = e.target.closest(".att-x");
      if (!x) return;
      const chip = x.closest(".att-chip");
      State.pendingAtts = State.pendingAtts.filter(a => a.id !== chip.dataset.id);
      this.renderAttPreview();
    });
    document.getElementById("thread").addEventListener("click", async e => {
      const btn = e.target.closest("[data-act]");
      if (!btn) return;
      const msgEl = btn.closest(".msg");
      const id = msgEl?.dataset.id;
      const act = btn.dataset.act;
      if (act === "copy-msg") {
        const m = State.msgs.find(x => x.id === id);
        if (m) U.copyText(m.content || "");
      } else if (act === "del-msg") {
        await this.deleteMessage(id);
      }
    });
  }
};


/* ============================================================
   js/exec.js — executors STUB (CH-01).
   Filled at CH-04 (marker /* ADE-04.1 *&#47; … /* ADE-04.4 *&#47;):
   PyRun (Pyodide v0.26.4 worker) · JSRun (worker sandbox) ·
   Preview (sandboxed iframe) · Shell (virtual console) · ConsoleUI.
   The script tag already sits in its final load-order slot, so
   CH-04 lands as a pure file replacement — index.html never moves.
   ============================================================ */
"use strict";

const Exec = {
  ready: false, // flips true when CH-04 lands
  py: null,     // PyRun — CH-04
  js: null,     // JSRun — CH-04
  preview: null,// Preview — CH-04
  shell: null   // Shell — CH-04 (agent drives this same shell as a tool)
};

/* ============================================================
   js/vfs.js — VFS stub (CH-01) · full virtual file system lands
   at CH-02 (marker /* ADE-02.1 *&#47; — core CRUD + tree) and the
   File System Access linked folder at CH-03 (/* ADE-03.x *&#47;).
   CH-01 provides ONLY the minimal write path that ADE-01.5
   (attachments) needs: binary/zip attachments land as rows in
   the vfs store at /imports/… using the EXACT row shape CH-02's
   VFS will use — additive-only, no migration needed later.
   ============================================================ */
"use strict";

const VFS = {
  ready: false, // flips true when CH-02's full core replaces this stub

  /* norm — minimal ..-safe root normalization (full version: CH-02) */
  norm(p) {
    const parts = String(p || "/").split("/");
    const out = [];
    for (const seg of parts) {
      if (!seg || seg === ".") continue;
      if (seg === "..") { out.pop(); continue; }
      out.push(seg);
    }
    return "/" + out.join("/");
  },

  isTextName(name) { return U.isTextName(name); },

  /* parent path helper (row shape matches CH-02 spec exactly) */
  _row(path, kind, content, isText) {
    path = VFS.norm(path);
    const parent = path.replace(/\/[^/]*$/, "") || "/";
    return {
      path,
      kind,                                  // 'dir' | 'file'
      parent,
      isText: !!isText,
      content: content ?? "",                // string | ArrayBuffer
      size: content ? (content.byteLength || content.length) : 0,
      mtime: Date.now()
    };
  },

  /* mkdirp — create every missing dir row along the path */
  async mkdirp(path) {
    path = VFS.norm(path);
    if (path === "/" || !path) return;
    const segs = path.split("/").filter(Boolean);
    let cur = "";
    for (const seg of segs) {
      cur += "/" + seg;
      const existing = await DB.get(DB.STORES.VFS, cur);
      if (!existing) await DB.set(DB.STORES.VFS, VFS._row(cur, "dir", ""));
    }
  },

  /* put — write a file row (string or ArrayBuffer), dirs auto-created */
  async put(path, content, isText) {
    path = VFS.norm(path);
    await VFS.mkdirp(path.replace(/\/[^/]*$/, "") || "/");
    await DB.set(DB.STORES.VFS, VFS._row(path, "file", content, isText));
    return path;
  },

  get: (path) => DB.get(DB.STORES.VFS, VFS.norm(path))
};

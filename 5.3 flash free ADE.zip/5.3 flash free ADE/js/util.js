/* ============================================================
   js/util.js — ADE · utils · toasts · markdown · highlighter
   ADE-01.4 (markdown renderer + lightweight highlighter ported
   from Builder Ai, extended with pipe tables) · helpers shared
   by every module. No ES modules — global window.U / MD / HL.
   ============================================================ */
"use strict";

/* ── helpers ─────────────────────────────────────────────── */
const U = {
  uid() {
    return Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 9);
  },
  escapeHtml(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  },
  /* f4: per-message token estimates — chars/4 */
  estimateTokens(str) { return Math.ceil((str || "").length / 4); },
  fmtTokens(n) {
    if (n == null) return "—";
    if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "k";
    return String(n);
  },
  fmtBytes(b) {
    if (b == null) return "";
    if (b < 1024) return b + " B";
    if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " KB";
    return (b / (1024 * 1024)).toFixed(2) + " MB";
  },
  fmtTime(ts) {
    const d = new Date(ts);
    const today = new Date();
    const sameDay = d.toDateString() === today.toDateString();
    const hm = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (sameDay) return hm;
    return d.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + hm;
  },
  debounce(fn, ms) {
    let t = null;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), ms);
    };
  },
  /* is this mime/extension handled as text? (whitelist) */
  isTextName(name, mime) {
    if (mime && mime.startsWith("text/")) return true;
    if (/json|xml|javascript|yaml|x-sh|svg/.test(mime || "")) return true;
    return /\.(txt|md|markdown|py|js|mjs|ts|tsx|jsx|json|html|htm|css|scss|yml|yaml|xml|svg|sh|bash|zsh|env|ini|cfg|conf|toml|csv|tsv|sql|gitignore|dockerfile|makefile|flat\.txt|log|rb|go|rs|java|c|h|cpp|hpp|cs|php|lua|pl|r|m|bat|ps1)$/i
      .test(name || "");
  },
  async copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      U.toast("Copied", { kind: "ok", icon: "fa-check" });
      return true;
    } catch {
      U.toast("Copy failed — clipboard blocked", { kind: "err" });
      return false;
    }
  },
  downloadText(text, filename, mime) {
    const blob = new Blob([text], { type: mime || "text/plain;charset=utf-8" });
    U.downloadBlob(blob, filename);
  },
  downloadBlob(blob, filename) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename || "file.txt";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 400);
  },
  readTextFile(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result || ""));
      r.onerror = () => reject(r.error);
      r.readAsText(file);
    });
  },
  readArrayBuffer(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(r.error);
      r.readAsArrayBuffer(file);
    });
  },
  fileIcon(name) {
    const ext = (name.split(".").pop() || "").toLowerCase();
    if (["html", "htm"].includes(ext)) return "fa-brands fa-html5";
    if (["css", "scss"].includes(ext)) return "fa-brands fa-css3-alt";
    if (["js", "mjs", "ts", "jsx", "tsx", "json"].includes(ext)) return "fa-brands fa-js";
    if (ext === "py") return "fa-brands fa-python";
    if (["md", "txt"].includes(ext)) return "fa-regular fa-file-lines";
    if (["zip", "tar", "gz", "7z", "rar"].includes(ext)) return "fa-solid fa-file-zipper";
    if (["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp"].includes(ext)) return "fa-regular fa-file-image";
    return "fa-regular fa-file";
  }
};

/* ── toasts ──────────────────────────────────────────────── */
U.toast = function (title, opts = {}) {
  const c = document.getElementById("toast-container");
  if (!c) return;
  const el = document.createElement("div");
  el.className = "toast " + (opts.kind || "info");
  const icon = opts.icon || { ok: "fa-circle-check", err: "fa-circle-exclamation", info: "fa-circle-info" }[opts.kind || "info"];
  el.innerHTML = `<i class="fa-solid ${icon}"></i><div><div class="t-title">${U.escapeHtml(title)}</div>` +
    (opts.msg ? `<div class="t-msg">${U.escapeHtml(opts.msg)}</div>` : "") + `</div>`;
  c.appendChild(el);
  setTimeout(() => {
    el.style.transition = "opacity 0.3s";
    el.style.opacity = "0";
    setTimeout(() => el.remove(), 320);
  }, opts.ms || 3200);
};

/* ── lightweight syntax highlighter (ported from Builder Ai) ──
   Tokenizes raw code (before escaping) so it handles <, >, & in
   HTML/XML correctly; escapes each token on output.            */
const HL_KEYWORDS = {
  python: ["False","None","True","and","as","assert","async","await","break","class","continue","def","del","elif","else","except","finally","for","from","global","if","import","in","is","lambda","nonlocal","not","or","pass","raise","return","try","while","with","yield","self"],
  javascript: ["const","let","var","function","return","if","else","for","while","do","switch","case","break","continue","class","extends","new","this","typeof","instanceof","in","of","try","catch","finally","throw","async","await","yield","import","export","from","default","null","undefined","true","false","void","delete","static","get","set","super"],
  bash: ["if","then","else","elif","fi","for","in","do","done","while","case","esac","function","return","echo","export","local","set","exit"]
};
function normalizeLang(lang) {
  const l = (lang || "").toLowerCase().trim();
  const map = { py: "python", js: "javascript", jsx: "javascript", mjs: "javascript",
    ts: "typescript", tsx: "typescript", yml: "yaml", sh: "bash", shell: "bash",
    htm: "html", jsonc: "json" };
  return map[l] || l;
}
function hlRule(type, re) { return { type, re: new RegExp(re.source, re.flags + "y") }; }
function hlRulesFor(lang) {
  switch (lang) {
    case "python": return [
      hlRule("comment", /#[^\n]*/),
      hlRule("string", /("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*')/),
      hlRule("number", /\b\d+(\.\d+)?\b/),
      hlRule("keyword", new RegExp(`\\b(${HL_KEYWORDS.python.join("|")})\\b`)),
      hlRule("punct", /[()\[\]{}:,.]/)
    ];
    case "html": return [
      hlRule("comment", /<!--[\s\S]*?-->/),
      hlRule("tag", /<\/?[a-zA-Z][a-zA-Z0-9-]*/),
      hlRule("attr", /\s[a-zA-Z-:]+(?=\s*=)/),
      hlRule("string", /"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'/),
      hlRule("punct", /[<>=\/]/)
    ];
    case "css": return [
      hlRule("comment", /\/\*[\s\S]*?\*\//),
      hlRule("string", /"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'/),
      hlRule("attr", /[a-zA-Z-]+(?=\s*:)/),
      hlRule("number", /\b\d+(\.\d+)?(px|em|rem|%|vh|vw|s|ms)?\b/),
      hlRule("func", /[a-zA-Z-]+(?=\()/),
      hlRule("tag", /[.#]?[a-zA-Z][\w-]*(?=[\s,{:.#\[])/),
      hlRule("punct", /[{}();:,]/)
    ];
    case "yaml": return [
      hlRule("comment", /#[^\n]*/),
      hlRule("attr", /[A-Za-z_][\w.-]*(?=\s*:(\s|$))/),
      hlRule("string", /"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'/),
      hlRule("number", /\b\d+(\.\d+)?\b/),
      hlRule("keyword", /\b(true|false|null|yes|no)\b/i),
      hlRule("punct", /[:\-\[\]{}]/)
    ];
    case "javascript": case "typescript": case "json": return [
      hlRule("comment", /\/\/[^\n]*|\/\*[\s\S]*?\*\//),
      hlRule("string", /`(?:[^`\\]|\\.)*`|"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'/),
      hlRule("number", /\b\d+(\.\d+)?\b/),
      hlRule("func", /[A-Za-z_$][\w$]*(?=\()/),
      hlRule("keyword", new RegExp(`\\b(${HL_KEYWORDS.javascript.join("|")})\\b`)),
      hlRule("punct", /[{}()\[\];,.:]/)
    ];
    case "bash": return [
      hlRule("comment", /#[^\n]*/),
      hlRule("string", /"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'/),
      hlRule("keyword", new RegExp(`\\b(${HL_KEYWORDS.bash.join("|")})\\b`)),
      hlRule("punct", /[|&;()<>]/)
    ];
    default: return [
      hlRule("comment", /\/\/[^\n]*/),
      hlRule("string", /"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'/),
      hlRule("number", /\b\d+(\.\d+)?\b/)
    ];
  }
}
function highlightCode(code, lang) {
  const rules = hlRulesFor(normalizeLang(lang));
  let out = "";
  let i = 0;
  const len = code.length;
  while (i < len) {
    let matched = null;
    for (const rule of rules) {
      rule.re.lastIndex = i;
      const m = rule.re.exec(code);
      if (m && m.index === i && m[0].length > 0) { matched = { type: rule.type, text: m[0] }; break; }
    }
    if (matched) {
      out += `<span class="tok-${matched.type}">${U.escapeHtml(matched.text)}</span>`;
      i += matched.text.length;
    } else {
      out += U.escapeHtml(code[i]);
      i += 1;
    }
  }
  return out;
}
function downloadFilenameForLang(lang) {
  switch (normalizeLang(lang)) {
    case "html": return "index.html";
    case "yaml": return "configs.yaml";
    case "python": return "work.py";
    case "json": return "list.json";
    default: return null;
  }
}

/* ── markdown renderer (ported + pipe tables added, ADE-01.4) ──
   headings · lists · pipe tables · blockquotes · links ·
   bold/italic · inline code · fenced code blocks with lang
   badge + copy + download buttons                              */
function renderMarkdown(src) {
  if (!src) return "";
  // Extract fenced code blocks first (so their content isn't reformatted)
  const codeBlocks = [];
  src = src.replace(/```([\w-]*)\n?([\s\S]*?)```/g, (m, lang, code) => {
    const idx = codeBlocks.length;
    codeBlocks.push({ lang, code });
    return `\u0000CODE${idx}\u0000`;
  });
  let out = U.escapeHtml(src);
  // Headers
  out = out.replace(/^###\s+(.+)$/gm, "<h3>$1</h3>");
  out = out.replace(/^##\s+(.+)$/gm, "<h2>$1</h2>");
  out = out.replace(/^#\s+(.+)$/gm, "<h1>$1</h1>");
  // Bold + italic
  out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  out = out.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  // Inline code
  out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
  // Links
  out = out.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  // Lists (dash + numbered)
  out = out.replace(/^(\s*)-\s+(.+)$/gm, "$1<li>$2</li>");
  out = out.replace(/^(\s*)\d+\.\s+(.+)$/gm, "$1<li>$2</li>");
  out = out.replace(/(<li>[\s\S]+?<\/li>)(?!\s*<li>)/g, m => `<ul>${m}</ul>`);
  // Pipe tables — | a | b |  then  |---|---|  then rows (ADE-01.4)
  out = out.replace(/(^\|.+\|\s*\n\|[\s:|-]+\|\s*\n\|.*\|[\s\S]*?(?=\n\s*\n|\n(?!\\|)|$))/gm, (block) => {
    const rows = block.trim().split("\n").filter(r => r.includes("|"));
    if (rows.length < 2) return block;
    const cells = r => r.replace(/^\||\|\s*$/g, "").split("|").map(c => c.trim());
    const head = cells(rows[0]);
    let html = "<table><thead><tr>" + head.map(h => `<th>${h}</th>`).join("") + "</tr></thead><tbody>";
    for (let i = 2; i < rows.length; i++) {
      html += "<tr>" + cells(rows[i]).map(c => `<td>${c}</td>`).join("") + "</tr>";
    }
    return html + "</tbody></table>";
  });
  // Blockquotes
  out = out.replace(/^&gt;\s+(.+)$/gm, "<blockquote>$1</blockquote>");
  // Paragraphs (split by double newline, skip block elements)
  const blocks = out.split(/\n\n+/);
  // A plain lead-in paragraph directly in front of a code block swaps
  // after it, so code appears before its description (Builder Ai port).
  for (let bi = 0; bi < blocks.length - 1; bi++) {
    const cur = blocks[bi].trim();
    const next = blocks[bi + 1].trim();
    const curIsCode = /^\u0000CODE\d+\u0000$/.test(cur);
    const nextIsCode = /^\u0000CODE\d+\u0000$/.test(next);
    const curIsBlockEl = /^<(h[1-4]|ul|ol|li|blockquote|table)/.test(cur);
    if (cur && !curIsCode && !curIsBlockEl && nextIsCode) {
      const tmp = blocks[bi]; blocks[bi] = blocks[bi + 1]; blocks[bi + 1] = tmp;
    }
  }
  out = blocks.map(b => {
    const trimmed = b.trim();
    if (!trimmed) return "";
    if (/^<(h[1-4]|ul|ol|li|blockquote|pre|table)/.test(trimmed)) return trimmed;
    if (trimmed.startsWith("\u0000CODE")) return trimmed;
    return `<p>${trimmed.replace(/\n/g, "<br>")}</p>`;
  }).join("\n");
  // Restore code blocks — highlighted, footer toolbar pinned at bottom
  out = out.replace(/\u0000CODE(\d+)\u0000/g, (m, i) => {
    const b = codeBlocks[parseInt(i, 10)];
    const lang = normalizeLang(b.lang);
    const label = b.lang ? b.lang.trim() : "text";
    const highlighted = highlightCode(b.code, lang);
    const filename = downloadFilenameForLang(lang);
    const downloadBtn = filename
      ? `<button class="code-download-btn" data-filename="${U.escapeHtml(filename)}" title="Download as ${U.escapeHtml(filename)}"><i class="fa-solid fa-download"></i><span>${U.escapeHtml(filename)}</span></button>`
      : "";
    return `<div class="code-block">
      <pre><code class="hl">${highlighted}</code></pre>
      <div class="code-block-footer">
        <span class="code-lang">${U.escapeHtml(label)}</span>
        <div class="code-block-actions">
          ${downloadBtn}
          <button class="code-copy-btn" title="Copy code"><i class="fa-regular fa-copy"></i><span>Copy</span></button>
        </div>
      </div>
    </div>`;
  });
  return out;
}

/* ── delegated actions for rendered markdown ───────────────
   copy / download buttons on code blocks (one listener total) */
document.addEventListener("click", (e) => {
  const copyBtn = e.target.closest(".code-copy-btn");
  if (copyBtn) {
    const code = copyBtn.closest(".code-block")?.querySelector("pre code");
    if (code) U.copyText(code.textContent);
    return;
  }
  const dlBtn = e.target.closest(".code-download-btn");
  if (dlBtn) {
    const code = dlBtn.closest(".code-block")?.querySelector("pre code");
    if (code) U.downloadText(code.textContent, dlBtn.dataset.filename);
  }
});

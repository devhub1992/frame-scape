/* ============================================================
   js/main.js — ADE-01.1 · init + wiring + first-run seed
   boots db → state → UI; seeds the default GLM config (f3);
   wires sidebar / header / config select / settings / workspace.
   ADE_BUILD stamps the console about line (readme ↔ code).
   ============================================================ */
"use strict";

const ADE_BUILD = {
  version: "ade-s2-ch01",
  stamp: "SESSION 2 (ITERATION · CH-01) · 2026-10-30",
  chunk: "CH-01 — ADE core shell"
};

const Main = {
  async init() {
    await DB.init();

    // load state
    State.configs = await DB.allConfigs();
    State.corsKey = (await DB.getSetting(SK.CORS_KEY)) || "";
    State.activeConfigId = await DB.getSetting(SK.ACTIVE_CONFIG);

    // first-run seed — one default config (ADE-01.3)
    if (!State.configs.length) {
      const c = makeDefaultConfig();
      await DB.saveConfig(c);
      State.configs = [c];
      State.activeConfigId = c.id;
      await DB.setSetting(SK.ACTIVE_CONFIG, c.id);
      setTimeout(() => U.toast("Welcome to ADE", {
        kind: "info",
        msg: "Seeded config \"" + c.name + "\" — add your AiHubMix key in Settings → Configs, CorsProxy key in Proxy Setup.",
        ms: 6000
      }), 400);
    }
    if (!State.configs.find(c => c.id === State.activeConfigId)) {
      State.activeConfigId = State.configs[0]?.id || null;
    }

    // wire UI
    ChatUI.initComposer();
    SettingsUI.init();
    WSUI.init();

    document.getElementById("new-chat-btn").addEventListener("click", () => ChatUI.newConversation());
    document.getElementById("toggle-sidebar").addEventListener("click", () => this.toggleSidebar());
    document.getElementById("sidebar-backdrop").addEventListener("click", () => this.toggleSidebar(false));
    this.wireConfigSelect();

    // restore session
    const lastConv = await DB.getSetting(SK.ACTIVE_CONV);
    await ChatUI.renderSidebar();
    if (lastConv && State.convs.find(c => c.id === lastConv)) {
      await ChatUI.openConversation(lastConv);
    } else {
      ChatUI.renderThread();
    }
    const wsOpen = await DB.getSetting("ws_panel_open");
    if (wsOpen) WorkspaceUI.toggle(true);

    this.renderHeaderConfig();

    console.log(`%cADE %c${ADE_BUILD.version} · ${ADE_BUILD.stamp}`,
      "color:#d4893a;font-weight:bold", "color:#999490");
  },

  toggleSidebar(force) {
    const sb = document.getElementById("sidebar");
    const bd = document.getElementById("sidebar-backdrop");
    const collapsed = force !== undefined ? !force : !sb.classList.contains("collapsed");
    sb.classList.toggle("collapsed", collapsed);
    if (window.matchMedia("(max-width: 760px)").matches) {
      bd.classList.toggle("show", !collapsed);
    }
  },

  /* ── header config select (custom dropdown, ADE-01.3) ── */
  wireConfigSelect() {
    const wrap = document.getElementById("config-select");
    const trigger = document.getElementById("config-select-trigger");
    trigger.addEventListener("click", e => {
      e.stopPropagation();
      const existing = wrap.querySelector(".select-menu");
      if (existing) { existing.remove(); return; }
      const menu = document.createElement("div");
      menu.className = "select-menu";
      if (!State.configs.length) {
        menu.innerHTML = `<div class="select-option">No configs</div>`;
      }
      for (const c of State.configs) {
        const opt = document.createElement("div");
        opt.className = "select-option" + (c.id === State.activeConfigId ? " selected" : "");
        opt.innerHTML = `<span>${U.escapeHtml(c.name)}</span><span class="opt-model">${U.escapeHtml(c.model)}</span>`;
        opt.addEventListener("click", async () => {
          State.activeConfigId = c.id;
          await DB.setSetting(SK.ACTIVE_CONFIG, c.id);
          menu.remove();
          this.renderHeaderConfig();
          U.toast("Config switched", { kind: "ok", msg: c.name + " · " + c.model });
        });
        menu.appendChild(opt);
      }
      const manage = document.createElement("div");
      manage.className = "select-option";
      manage.innerHTML = `<span><i class="fa-solid fa-gear" style="font-size:10px"></i> Manage configs…</span>`;
      manage.addEventListener("click", () => { menu.remove(); SettingsUI.open("configs"); });
      menu.appendChild(manage);
      wrap.appendChild(menu);
    });
    document.addEventListener("click", () => {
      wrap.querySelector(".select-menu")?.remove();
    });
  },

  renderHeaderConfig() {
    const cfg = ChatUI.activeConfig();
    const label = document.getElementById("config-select-label");
    const badge = document.getElementById("header-config-badge");
    const badgeName = document.getElementById("header-config-name");
    label.textContent = cfg ? cfg.name : "No config";
    if (cfg) {
      badge.style.display = "";
      badge.classList.toggle("no-key", !cfg.apiKey);
      badgeName.textContent = cfg.model + (cfg.apiKey ? "" : " · no key");
    } else {
      badge.style.display = "none";
    }
  }
};

window.addEventListener("DOMContentLoaded", () => Main.init());

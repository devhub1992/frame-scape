/* ============================================================
   js/agent.js — agent loop STUB (CH-01).
   Filled at CH-05 (markers /* ADE-05.1 *&#47; … /* ADE-05.5 *&#47;):
   streamChat moves here from ui-chat.js and gains the 12-tool
   registry, agent loop, tool-trace, <<<TOOL>>> text-protocol
   fallback and context trim. CH-06 adds the ADE system prompt +
   budgets (/* ADE-06.x *&#47;).
   NOTE (m-22, routed ch-05.f6): the thinking VIEWER (click the
   agent's name → reasoning panel, rendered lazily so streaming
   never lags) ships with CH-05 — the SSE parser in ui-chat.js
   already captures reasoning_content into msg.reasoning.
   ============================================================ */
"use strict";

const Agent = {
  ready: false,   // flips true when CH-05 lands
  TOOLS: null,    // 12-tool registry — CH-05
  runAgent: null, // agent loop — CH-05
  buildSystemPrompt: null // CH-06
};

/* ============================================================
   js/ui-settings.js — ADE-01.3 · settings modal
   Configs tab: config CRUD (name · model · baseUrl · apiKey ·
   proxyUrl · temperature · maxTokens + NEW maxSteps · contextK ·
   forceProto), model preset chips, Test = 4-token ping through
   the proxy. Agent & Workspace tab: status + notes (controls
   land CH-06.f3). Proxy Setup tab: shared CorsProxy.io key.
   ============================================================ */
"use strict";

const SettingsUI = {
  editingId: null, // config currently open in the editor
  tab: "configs",

  open(tab) {
    document.getElementById("settings-modal").classList.add("open");
    if (tab) this.switchTab(tab);
    this.render();
  },

  close() {
    document.getElementById("settings-modal").classList.remove("open");
    this.editingId = null;
  },

  switchTab(tab) {
    this.tab = tab;
    document.querySelectorAll(".modal-tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    document.getElementById("modal-body-configs").style.display = tab === "configs" ? "flex" : "none";
    document.getElementById("modal-body-agent").style.display = tab === "agent" ? "flex" : "none";
    document.getElementById("modal-body-proxy").style.display = tab === "proxy" ? "flex" : "none";
  },

  init() {
    document.getElementById("open-settings-header").addEventListener("click", () => this.open());
    document.getElementById("open-settings-side").addEventListener("click", () => this.open());
    document.getElementById("settings-close").addEventListener("click", () => this.close());
    document.getElementById("settings-modal").addEventListener("click", e => {
      if (e.target === e.currentTarget) this.close();
    });
    document.querySelectorAll(".modal-tab").forEach(b => b.addEventListener("click", () => this.switchTab(b.dataset.tab)));
  },

  /* ══ Configs tab ═══════════════════════════════════════ */
  async render() {
    if (this.tab === "configs") await this.renderConfigs();
    else if (this.tab === "agent") this.renderAgent();
    else this.renderProxy();
  },

  async renderConfigs() {
    const body = document.getElementById("modal-body-configs");
    const editing = State.configs.find(c => c.id === this.editingId) || null;
    body.innerHTML = `
      <div class="two-key-banner">
        <i class="fa-solid fa-circle-info"></i>
        <div>
          <strong>Two separate API keys are needed.</strong>
          One from <a href="https://console.corsproxy.io" target="_blank" rel="noopener">CorsProxy.io</a> — tunnels requests around CORS, set once under the <strong>Proxy Setup</strong> tab.
          One from <a href="https://aihubmix.com" target="_blank" rel="noopener">AiHubMix</a> — pays for the AI replies, set per-config below.
        </div>
      </div>
      <div class="configs-row">
        <div class="modal-left">
          <button class="new-config-btn" id="new-config-btn"><i class="fa-solid fa-plus"></i> New config</button>
          <div class="config-list" id="config-list">
            ${State.configs.map(c => `
              <div class="config-item ${c.id === this.editingId ? "selected" : ""}" data-id="${c.id}">
                <div class="ci-name">${U.escapeHtml(c.name)} ${c.id === State.activeConfigId ? `<span class="ci-active">active</span>` : ""}</div>
                <div class="ci-model">${U.escapeHtml(c.model)}</div>
              </div>`).join("") || `<div class="conv-empty">No configs yet.</div>`}
          </div>
        </div>
        <div class="modal-right" id="modal-right">${editing ? this.editorHtml(editing) : `
          <div class="empty-state"><i class="fa-solid fa-gear"></i><p>Select a config on the left or create a new one.</p></div>`}
        </div>
      </div>`;

    body.querySelector("#new-config-btn").addEventListener("click", () => this.newConfig());
    body.querySelectorAll(".config-item").forEach(el =>
      el.addEventListener("click", () => { this.editingId = el.dataset.id; this.render(); }));
    if (editing) this.wireEditor(editing);
  },

  editorHtml(c) {
    const isDefaultModel = MODEL_PRESETS.includes(c.model);
    return `
      <div class="form-field">
        <label>Config name</label>
        <input id="f-name" type="text" value="${U.escapeHtml(c.name)}" placeholder="e.g. GLM 5.3 Flash Free" />
      </div>
      <div class="form-field">
        <label>Model (free text)</label>
        <input id="f-model" class="mono" type="text" value="${U.escapeHtml(c.model)}" placeholder="coding-glm-5.3-flash-free" />
        <div class="preset-chips">${MODEL_PRESETS.map(m =>
          `<button class="preset-chip ${m === c.model ? "active" : ""}${isDefaultModel ? "" : ""}" data-model="${m}">${m}</button>`).join("")}
        </div>
      </div>
      <div class="form-grid">
        <div class="form-field">
          <label>Base URL</label>
          <input id="f-baseurl" class="mono" type="text" value="${U.escapeHtml(c.baseUrl)}" placeholder="https://aihubmix.com/v1" />
        </div>
        <div class="form-field">
          <label>API key (AiHubMix)</label>
          <div class="input-with-action">
            <input id="f-apikey" class="mono" type="password" value="${U.escapeHtml(c.apiKey || "")}" placeholder="sk-…" />
            <button id="f-toggle-key" title="Show/hide"><i class="fa-solid fa-eye"></i></button>
          </div>
        </div>
      </div>
      <div class="form-field">
        <label>CORS proxy URL</label>
        <input id="f-proxyurl" class="mono" type="text" value="${U.escapeHtml(c.proxyUrl || "")}" placeholder="https://corsproxy.io/?key={corskey}&url={url}" />
        <div class="hint"><i class="fa-solid fa-circle-info"></i> Placeholders: <code>{url}</code> = target API call · <code>{corskey}</code> = your CorsProxy.io key (Proxy Setup tab). Empty = direct fetch.</div>
      </div>
      <div class="form-grid">
        <div class="form-field">
          <label>Temperature</label>
          <input id="f-temp" type="number" step="0.1" min="0" max="2" value="${U.escapeHtml(String(c.temperature ?? 0.6))}" />
        </div>
        <div class="form-field">
          <label>Max tokens</label>
          <input id="f-maxtok" type="number" step="256" min="256" value="${U.escapeHtml(String(c.maxTokens ?? 8192))}" />
        </div>
        <div class="form-field">
          <label>Max agent steps</label>
          <input id="f-maxsteps" type="number" step="1" min="1" max="100" value="${U.escapeHtml(String(c.maxSteps ?? 24))}" />
          <div class="hint"><i class="fa-solid fa-robot"></i> Tool-loop cap — used from CH-05.</div>
        </div>
        <div class="form-field">
          <label>Context budget (k tokens)</label>
          <input id="f-contextk" type="number" step="4" min="4" value="${U.escapeHtml(String(c.contextK ?? 24))}" />
          <div class="hint"><i class="fa-solid fa-gauge-high"></i> Trim budget — used from CH-05.</div>
        </div>
      </div>
      <div class="form-field">
        <label class="checkbox-row"><input id="f-forceproto" type="checkbox" ${c.forceProto ? "checked" : ""} />
          Force &lt;&lt;&lt;TOOL&gt;&gt;&gt; text protocol (skip native tool calling)</label>
        <div class="hint"><i class="fa-solid fa-circle-info"></i> For endpoints that reject the tools array — the agent falls back automatically anyway (CH-05).</div>
      </div>
      <div class="form-actions">
        <button class="btn" id="f-test"><i class="fa-solid fa-plug"></i> Test</button>
        <span class="test-result" id="f-test-result"></span>
        <span class="spacer"></span>
        <button class="btn danger" id="f-delete"><i class="fa-solid fa-trash"></i> Delete</button>
        <button class="btn" id="f-activate" ${c.id === State.activeConfigId ? "disabled" : ""}><i class="fa-solid fa-circle-check"></i> ${c.id === State.activeConfigId ? "Active" : "Set active"}</button>
        <button class="btn primary" id="f-save"><i class="fa-solid fa-floppy-disk"></i> Save</button>
      </div>`;
  },

  wireEditor(c) {
    const q = s => document.querySelector(s);
    q("#f-toggle-key").addEventListener("click", () => {
      const k = q("#f-apikey");
      k.type = k.type === "password" ? "text" : "password";
    });
    document.querySelectorAll(".preset-chip").forEach(chip =>
      chip.addEventListener("click", () => { q("#f-model").value = chip.dataset.model; this.render(); }));
    q("#f-save").addEventListener("click", () => this.saveEditor(c));
    q("#f-delete").addEventListener("click", () => this.deleteConfig(c));
    q("#f-activate").addEventListener("click", async () => {
      State.activeConfigId = c.id;
      await DB.setSetting(SK.ACTIVE_CONFIG, c.id);
      Main.renderHeaderConfig();
      U.toast("Active config set", { kind: "ok", msg: c.name });
      this.render();
    });
    q("#f-test").addEventListener("click", () => this.testConfig(c));
  },

  async saveEditor(c) {
    const q = s => document.querySelector(s);
    c.name = q("#f-name").value.trim() || "Untitled";
    c.model = q("#f-model").value.trim() || "coding-glm-5.3-flash-free";
    c.baseUrl = q("#f-baseurl").value.trim() || "https://aihubmix.com/v1";
    c.apiKey = q("#f-apikey").value.trim();
    c.proxyUrl = q("#f-proxyurl").value.trim();
    c.temperature = Math.min(2, Math.max(0, parseFloat(q("#f-temp").value) || 0.6));
    c.maxTokens = parseInt(q("#f-maxtok").value, 10) || 8192;
    c.maxSteps = Math.min(100, Math.max(1, parseInt(q("#f-maxsteps").value, 10) || 24));
    c.contextK = Math.max(4, parseInt(q("#f-contextk").value, 10) || 24);
    c.forceProto = q("#f-forceproto").checked;
    await DB.saveConfig(c);
    State.configs = await DB.allConfigs();
    Main.renderHeaderConfig();
    U.toast("Config saved", { kind: "ok", msg: c.name });
    this.render();
  },

  async deleteConfig(c) {
    if (State.configs.length <= 1) { U.toast("Cannot delete", { kind: "err", msg: "At least one config must remain." }); return; }
    if (!confirm(`Delete config "${c.name}"?`)) return;
    await DB.delConfig(c.id);
    State.configs = await DB.allConfigs();
    if (State.activeConfigId === c.id) {
      State.activeConfigId = State.configs[0]?.id || null;
      await DB.setSetting(SK.ACTIVE_CONFIG, State.activeConfigId);
      Main.renderHeaderConfig();
    }
    this.editingId = null;
    U.toast("Config deleted", { kind: "ok" });
    this.render();
  },

  async newConfig() {
    const c = makeDefaultConfig();
    c.name = "New config";
    c.apiKey = "";
    await DB.saveConfig(c);
    State.configs = await DB.allConfigs();
    this.editingId = c.id;
    this.render();
  },

  /* Test = 4-token ping through the resolved proxy (f3) */
  async testConfig(c) {
    const out = document.getElementById("f-test-result");
    out.className = "test-result";
    out.textContent = "pinging…";
    const t0 = performance.now();
    try {
      const url = await ChatUI.resolveUrl(c);
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": "Bearer " + c.apiKey },
        body: JSON.stringify({ model: c.model, messages: [{ role: "user", content: "ping" }], max_tokens: 4, stream: false })
      });
      const ms = Math.round(performance.now() - t0);
      if (res.ok) {
        out.className = "test-result ok";
        out.textContent = `OK · ${ms}ms · HTTP ${res.status}`;
      } else {
        let detail = "";
        try { detail = (await res.text()).slice(0, 160); } catch { /* ignore */ }
        out.className = "test-result err";
        out.textContent = `HTTP ${res.status} · ${ms}ms${detail ? " — " + detail : ""}`;
      }
    } catch (e) {
      out.className = "test-result err";
      out.textContent = "Network error — proxy down or key invalid (" + Math.round(performance.now() - t0) + "ms)";
    }
  },

  /* ══ Agent & Workspace tab (controls land CH-06.f3) ════ */
  renderAgent() {
    const cfg = ChatUI.activeConfig();
    const body = document.getElementById("modal-body-agent");
    body.innerHTML = `<div style="width:100%">
      <div class="agent-note">
        <i class="fa-solid fa-robot"></i>
        <div><strong>Agent runtime arrives in CH-05/CH-06.</strong> Step cap (<code>${cfg?.maxSteps ?? 24}</code>), context budget (<code>${cfg?.contextK ?? 24}k</code>) and the text-protocol toggle are already editable per-config in the <strong>Configs</strong> tab — the loop, tool registry and ADE system prompt consume them from CH-05 on.</div>
      </div>
      <div class="agent-note">
        <i class="fa-solid fa-folder-tree"></i>
        <div><strong>Workspace status.</strong> CH-01 ships the shell only; the IndexedDB VFS with full CRUD lands at CH-02, the linked work folder at CH-03, executors + shell at CH-04.</div>
      </div>
      <div class="kv-list">
        <div class="kv"><span class="k">indexeddb</span><span class="v ok">ade-db v1 · ${DB.STORES.VFS} + 5 stores</span></div>
        <div class="kv"><span class="k">vfs</span><span class="v dim">stub — CH-02</span></div>
        <div class="kv"><span class="k">fsa work folder</span><span class="v dim">CH-03</span></div>
        <div class="kv"><span class="k">executors</span><span class="v dim">CH-04 (pyodide · worker · iframe · shell)</span></div>
        <div class="kv"><span class="k">agent loop</span><span class="v dim">CH-05 (12 tools · trace · fallback)</span></div>
        <div class="kv"><span class="k">ade system prompt</span><span class="v dim">CH-06</span></div>
      </div>
    </div>`;
  },

  /* ══ Proxy Setup tab ═══════════════════════════════════ */
  renderProxy() {
    const body = document.getElementById("modal-body-proxy");
    body.innerHTML = `<div class="proxy-panel">
      <div class="proxy-section">
        <div class="title"><i class="fa-solid fa-key"></i> Your CorsProxy.io API key</div>
        <div class="desc">Shared across every config — fills the <code>{corskey}</code> placeholder in any Proxy URL automatically.</div>
        <div class="form-field">
          <div class="input-with-action">
            <input id="f-corskey" class="mono" type="password" placeholder="Get one free at console.corsproxy.io" value="${U.escapeHtml(State.corsKey || "")}" />
            <button id="f-toggle-corskey" title="Show"><i class="fa-solid fa-eye"></i></button>
          </div>
          <div class="hint"><i class="fa-solid fa-lock"></i> Stored in IndexedDB only — never sent anywhere except your proxy.</div>
        </div>
        Get a free key at <a href="https://console.corsproxy.io" target="_blank" rel="noopener">console.corsproxy.io</a> → Manage Domains → add the domain you host ADE on.
        <div class="form-actions"><button class="btn primary" id="f-save-corskey"><i class="fa-solid fa-floppy-disk"></i> Save key</button></div>
      </div>
      <div class="proxy-section">
        <div class="title"><i class="fa-solid fa-list"></i> Known-good proxy templates</div>
        <ul>
          <li><code>https://corsproxy.io/?key={corskey}&amp;url={url}</code> — default; free tier is a 7-day rolling window of 2500 requests / 500 MB</li>
          <li><code>https://api.allorigins.win/raw?url={url}</code> — unlimited, but may not pass auth headers reliably</li>
          <li><code>https://proxy.cors.sh/</code> — prefix-style; ADE appends the target URL</li>
          <li>Any local proxy that takes the full target URL as the path</li>
        </ul>
      </div>
    </div>`;
    body.querySelector("#f-toggle-corskey").addEventListener("click", () => {
      const k = body.querySelector("#f-corskey");
      k.type = k.type === "password" ? "text" : "password";
    });
    body.querySelector("#f-save-corskey").addEventListener("click", async () => {
      State.corsKey = body.querySelector("#f-corskey").value.trim();
      await DB.setSetting(SK.CORS_KEY, State.corsKey);
      Main.renderHeaderConfig();
      U.toast("CorsProxy key saved", { kind: "ok" });
    });
  }
};

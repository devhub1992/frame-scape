/* ============================================================================
   FRAME SCAPE — companions.js  (v0.8.0)
   ----------------------------------------------------------------------------
   Autonomous allies — NO energy upkeep, toggle in XMB → COMPANIONS:

     · COMBAT DRONE
         - hovers IN FRONT of you (~8 m), gentle sway
         - reticle-designated targeting — your crosshair picks its mark
         - engages hostiles on its own with its equipped weapon — but every
           shot is fed from YOUR ammo pools
         - has its own hull + regenerating shields (moddable in MOD·COMPANION)
         - acts as a RADAR UPLINK; dies → 30 s rebuild, no cost
         - HOLDS FIRE while you are cloaked
         - CH-04.4 FREEZE RAY weapon: CONTINUOUS near-silent siphon beam —
           saps shields first (flat % of max per tick), then chews hp while
           a stacking DEF-DOWN debuff makes the target take more damage
           from everything; drains your RIFLE pool per second (enemy hooks
           live in enemy.js: applySap / updateSap / damage vulnerability)

     · ZANUKA BEAST (quadruped, melee)
         - v0.8 FIX: no more running backwards — the model now faces its
           charge target correctly (the head is on local −Z, so the yaw
           math previously pointed it AWAY from the enemy)
         - CURSOR-LED: trots ~6 ft (1.9 m) ahead of you, in the direction
           your cursor/aim points; prefers your reticle-designated target
         - bites (staggers); BLOOD FOR SHIELD mod turns its kills + the
           drone's kills into shield for you
         - CH-05.2 SCAVENGER: point your reticle at a SUPPLY LOCKER (same
           ~9.5° cone as scanTargets) to designate it — the beast runs
           over, channels (SCAVENGE mod ramps 12 s → 2 s, CH-05.3) with a
           HUD progress ring, then swings the door open and spills
           ELITE-quality loot. COMBAT ALWAYS WINS — an enemy in aggro
           drops the channel. Lockers respawn on a world-side timer.
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js';
import { texGlow } from './textures.js';
/* CH-25.4 — companion weapons land through the ONE shared entry point */
import { applyDamage, typedHit, rollCrit } from './weapon.js';

const CP = ASSETS.companions;
const P = ASSETS.palette;

function panOf(game, pos) {
  const to = new THREE.Vector3().subVectors(pos, game.player.pos);
  const right = new THREE.Vector3(Math.cos(game.player.yaw), 0, -Math.sin(game.player.yaw));
  const d = to.length();
  return d > 0.1 ? Math.max(-1, Math.min(1, to.dot(right) / d)) * 0.8 : 0;
}

export class Companions {
  constructor(scene) {
    this.scene = scene;
    /* CH-44HF.4 — SENTINEL LOADOUT DEFAULT: drone ONLINE with the MARKSMAN
       weapon on every fresh state (assets.companions.drone.defaultOn /
       defaultWeapon). loadState() still overrides from ac-save-v1, so a
       stored docked drone / other weapon stays the user's choice.        */
    const D = ASSETS.companions.drone;
    const wIdx = D.weapons.findIndex((w) => w.id === D.defaultWeapon);
    this.droneEnabled = !!D.defaultOn;
    this.petEnabled = false;
    this.droneWeaponIdx = wIdx >= 0 ? wIdx : 0;
    this.drone = null;
    this.pet = null;
    this.droneRespawnT = -1;
    this.petRespawnT = -1;
    this._noAmmoT = 0;
    this._game = null;              // CH-04.4 — cached game ref for stopFreezeBeam
    this._frBeam = null;            // CH-04.4 — reused freeze-beam mesh
    this._frGlow = null;            // CH-04.4 — reused impact glow sprite
    /* CH-05.2 — beast locker-scavenge state */
    this.lockerDesignated = null;   // { locker, dist } — reticle-cone winner
    this.petChannelLocker = null;   // locker record the beast is channeling
    this.petChannelT = 0;           // channel seconds elapsed (HUD ring reads this)
    this.petChannelDur = 1;         // channel length at start (SCAVENGE-tuned)
    this._noBeastT = 0;             // teach-toast throttle (designation, no beast)
  }

  /* ======================================================================
     toggles (XMB)
     ====================================================================== */
  toggleDrone(game) {
    this.droneEnabled = !this.droneEnabled;
    if (this.droneEnabled) {
      this.spawnDrone(game);
      game.hud.toast('COMBAT DRONE ONLINE', 1400);
    } else {
      this.removeDrone();
      game.hud.toast('DRONE DOCKED', 1200);
    }
    game.sfx.droneBeep();
    return this.droneEnabled;
  }

  togglePet(game) {
    this.petEnabled = !this.petEnabled;
    if (this.petEnabled) {
      this.spawnPet(game);
      game.hud.toast('BEAST DEPLOYED', 1400);
    } else {
      this.removePet();
      game.hud.toast('BEAST KENNED', 1200);
    }
    game.sfx.growl();
    return this.petEnabled;
  }

  /* ======================================================================
     DRONE
     ====================================================================== */
  spawnDrone(game) {
    this.removeDrone();
    const g = new THREE.Group();
    const bodyM = new THREE.MeshLambertMaterial({ color: '#9aa4ae' });
    const darkM = new THREE.MeshLambertMaterial({ color: '#3c434b' });
    const eyeM = new THREE.MeshBasicMaterial({ color: P.energy });
    g.add(new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 8), bodyM));
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.028, 6, 16), darkM);
    ring.rotation.x = Math.PI / 2;
    g.add(ring);
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 6), eyeM);
    eye.position.set(0, 0, 0.14);
    g.add(eye);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: texGlow(P.energy), blending: THREE.AdditiveBlending,
      transparent: true, opacity: 0.8, depthWrite: false,
    }));
    glow.scale.setScalar(0.5);
    g.add(glow);
    this.scene.add(g);

    const D = CP.drone;
    this.drone = {
      group: g, eye, t: Math.random() * 9, timer: 1.2, burst: 0, burstT: 0,
      pos: game.player.pos.clone().add(new THREE.Vector3(1.5, 2, 2)),
      hp: D.hp, shield: D.shield, shieldHitT: -99, respawnT: -1,
      deadT: -1,
      ammoAcc: 0, sapT: 0,                        // CH-04.4 — freeze-ray siphon state
    };
    this.droneRespawnT = -1;
  }

  removeDrone() {
    if (!this.drone) return;
    this.scene.remove(this.drone.group);
    this.drone = null;
    this.stopFreezeBeam();                        // CH-04.4 — kill the siphon beam
  }

  damageDrone(amount, game) {
    const dr = this.drone;
    if (!dr || dr.deadT >= 0) return;
    dr.shieldHitT = game.time;
    if (dr.shield > 0) {
      dr.shield -= amount;
      if (dr.shield < 0) { dr.hp += dr.shield; dr.shield = 0; }
    } else {
      dr.hp -= amount;
    }
    game.weapon.spawnSpark(dr.pos, 'energy');
    if (dr.hp <= 0) {
      dr.deadT = 0;
      game.sfx.boomSmall(panOf(game, dr.pos));
      game.sfx.droneDown();
      for (let i = 0; i < 8; i++) game.weapon.spawnSpark(dr.pos, false, true);
      game.hud.toast('DRONE DOWN — REBUILDING', 1600);
    }
  }

  updateDrone(dt, game) {
    const dr = this.drone;
    const D = CP.drone;
    const pl = game.player;

    /* death anim → schedule rebuild */
    if (dr.deadT >= 0) {
      dr.deadT += dt;
      dr.group.position.y -= dt * 1.6;
      dr.group.rotation.z += dt * 7;
      if (dr.deadT > 0.8) {
        this.removeDrone();
        this.droneRespawnT = CP.respawn;
      }
      return;
    }

    dr.t += dt;

    /* shield regen */
    if (game.time - dr.shieldHitT > D.shieldDelay && dr.shield < D.shield) {
      dr.shield = Math.min(D.shield, dr.shield + D.shieldRegen * dt);
    }

    /* hover: drifts ON ITS OWN in FRONT of you, ~8 m out, gentle sway.
       (v0.7 — it used to trail behind your shoulder like a bodyguard.) */
    const yaw = pl.yaw;
    const fwd = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));   // ahead
    const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
    const off = fwd.multiplyScalar(D.followDist * 0.86)
      .add(right.multiplyScalar(Math.sin(dr.t * 0.8) * D.followDist * 0.22));
    const want = pl.pos.clone().add(off);
    want.y += D.hoverY + Math.sin(dr.t * 2.2) * D.bobAmp;
    this.clampToWorld(want);
    dr.pos.lerp(want, Math.min(1, dt * 2.2));
    /* hard leash: never more than followDist (8 m) from you */
    const away = new THREE.Vector3().subVectors(dr.pos, pl.pos); away.y = 0;
    const dd = away.length();
    if (dd > D.followDist) {
      away.multiplyScalar(D.followDist / dd);
      dr.pos.x = pl.pos.x + away.x;
      dr.pos.z = pl.pos.z + away.z;
    }
    dr.group.position.copy(dr.pos);
    dr.eye.material.color.setHSL(0.52, 1, 0.5 + Math.sin(dr.t * 6) * 0.15);

    /* engage: YOUR RETICLE picks the target (v0.7). Whatever your gun
       crosshair designates becomes the drone's mark; otherwise it picks
       the nearest hostile inside its own range. HOLD FIRE while cloaked. */
    let best = null;
    const cloaked = pl.invisT > 0;
    const cur = game.currentTarget && game.currentTarget.ref;
    if (!cloaked) {
      if (cur && cur.alive) {
        const d = cur.group.position.distanceTo(dr.pos);
        if (d < D.range * 1.6) best = cur;    // player-designated: longer leash
      }
      if (!best) {
        let bestD = D.range;
        for (const e of game.enemies) {
          if (!e.alive) continue;
          const d = e.group.position.distanceTo(dr.pos);
          if (d < bestD) { best = e; bestD = d; }
        }
      }
    }
    if (best) {
      dr.group.lookAt(best.group.position);
      const W = D.weapons[this.droneWeaponIdx];
      const pool = game.ammo;
      dr.timer -= dt;
      /* CH-04.4 — FREEZE RAY dispatch: a CONTINUOUS beam, not a shot —
         own path (siphon drain + sap ticks), never touches burst/timer */
      if (W.style === 'freeze') {
        this.updateDroneFreeze(dt, game, dr, best, W);
      } else if (dr.burst > 0) {
        dr.burstT -= dt;
        if (dr.burstT <= 0) {
          dr.burstT = 0.09;
          dr.burst--;
          if (pool[W.ammo] > 0) {
            pool[W.ammo] -= 1;
            this.droneShoot(game, dr, best, W, W.style);
          }
        }
      } else if (dr.timer <= 0) {
        if (pool[W.ammo] >= W.cost) {
          pool[W.ammo] -= W.cost;
          dr.timer = W.interval;
          if (W.style === 'burst') { dr.burst = 5; dr.burstT = 0; }
          else if (W.style === 'missile') {
            game.specials.live.push(this.makeDroneMissile(game, dr, best, W));
            game.sfx.missile(panOf(game, dr.pos) * 0.5);
          } else {
            this.droneShoot(game, dr, best, W, W.style);
          }
        } else if (this._noAmmoT <= 0) {
          this._noAmmoT = 5;
          game.hud.toast('DRONE: NO ' + ASSETS.ammoPools[W.ammo].label, 1400);
        }
      }
    } else {
      dr.group.rotation.y = yaw;
      this.stopFreezeBeam();                        // CH-04.4 — target lost → beam off
    }
  }

  /* ======================================================================
     CH-04.4 — FREEZE RAY (sentinel weapon, style 'freeze')
     Continuous siphon beam. Every frame with a locked target:
       · rifle rounds leave YOUR pool through a fractional accumulator
         (drainPerSec/s — no wasted partial rounds on short bursts)
       · beam mesh + impact glow are built ONCE and repositioned in place
         (no per-frame allocations, HD 3000 budget)
       · every W.tick seconds the target hooks enemy.applySap(): shield
         sap first, then hp tick + DEF-DOWN stack build (curve in
         ASSETS.companions.drone.defDown)
       · near-silent: one very low whisper-siphon loop while active
     ====================================================================== */
  updateDroneFreeze(dt, game, dr, best, W) {
    const pl = game.player;
    const pool = game.ammo;

    /* ammo siphon — drainPerSec rounds/s from your rifle pool */
    dr.ammoAcc += W.drainPerSec * dt;
    while (dr.ammoAcc >= 1) {
      if (pool.rifle <= 0) { dr.ammoAcc = 0; break; }
      pool.rifle -= 1;
      dr.ammoAcc -= 1;
    }
    const dry = pool.rifle <= 0;
    const active = !pl.dead && !dry &&
      best.group.position.distanceTo(dr.pos) <= W.range;

    /* dry-fire feedback — same 5 s throttle as the other drone weapons */
    if (dry && this._noAmmoT <= 0) {
      this._noAmmoT = 5;
      game.hud.toast('DRONE: NO ' + ASSETS.ammoPools[W.ammo].label, 1400);
    }

    this._game = game;                              // for stopFreezeBeam off-loop
    this.paintFreezeBeam(dr, best, W, active);
    if (active) {
      game.sfx.freezeStart();                       // idempotent whisper loop
      dr.sapT -= dt;
      if (dr.sapT <= 0) {
        dr.sapT = W.tick;
        best._hitBy = 'companion';                  // BLOOD FOR SHIELD tagging
        best.applySap(W, game);                     // enemy.js hook — shields → stacks
        /* CH-25.4 — the beam's hp chew was DOCUMENTED in CH-04.4 but never
           actually wired (applySap only drains shields); it now lands as a
           TYPED COLD tick through the shared pipeline. Armor applies — it
           is a siphon, not a lance — and DEF-DOWN stacks feed back into it. */
        applyDamage(best, { types: typedHit(W), crit: null, statusChance: 0 },
          game, { point: best.group.position, kind: 'freeze' });
      }
    } else {
      game.sfx.freezeStop();
    }
  }

  /* reuse one beam mesh + one impact glow — reposition, never reallocate */
  paintFreezeBeam(dr, best, W, active) {
    if (!this._frBeam) {
      this._frBeam = new THREE.Mesh(
        new THREE.BoxGeometry(1, 1, 1),
        new THREE.MeshBasicMaterial({
          color: '#a8e6ff', transparent: true, opacity: 0.55,
          blending: THREE.AdditiveBlending, depthWrite: false,
        })
      );
      this._frBeam.visible = false;
      this.scene.add(this._frBeam);
      this._frGlow = new THREE.Sprite(new THREE.SpriteMaterial({
        map: texGlow('#a8e6ff'), blending: THREE.AdditiveBlending,
        transparent: true, opacity: 0.85, depthWrite: false,
      }));
      this._frGlow.scale.setScalar(0.7);
      this._frGlow.visible = false;
      this.scene.add(this._frGlow);
    }
    if (!active) { this.stopFreezeBeam(); return; }
    const from = dr.pos, to = best.group.position;
    const len = from.distanceTo(to);
    this._frBeam.visible = true;
    this._frBeam.position.copy(from).add(to).multiplyScalar(0.5);
    this._frBeam.lookAt(to);
    this._frBeam.scale.set(
      0.035 + Math.sin(dr.t * 40) * 0.008,          // thin pulsing filament
      0.035 + Math.sin(dr.t * 40) * 0.008,
      len);
    this._frGlow.visible = true;
    this._frGlow.position.copy(to);
    this._frGlow.position.y += best.fly ? 0 : 0.7;
  }

  /* CH-04.4 — beam off + whisper loop off (idempotent, safe off-loop) */
  stopFreezeBeam() {
    if (this._frBeam) this._frBeam.visible = false;
    if (this._frGlow) this._frGlow.visible = false;
    if (this._game && this._game.sfx) this._game.sfx.freezeStop();
  }

  makeDroneMissile(game, dr, target, W) {
    target._hitBy = 'companion';     // BLOOD FOR SHIELD tagging
    const mesh = new THREE.Group();
    const body = new THREE.Mesh(game.specials.rGeo, game.specials.rMat);
    body.rotation.x = Math.PI / 2;
    mesh.add(body);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: texGlow('#ffb45e'), blending: THREE.AdditiveBlending,
      transparent: true, depthWrite: false,
    }));
    glow.scale.setScalar(0.35);
    mesh.add(glow);
    mesh.position.copy(dr.pos);
    this.scene.add(mesh);
    const vel = target.group.position.clone().sub(dr.pos).normalize().multiplyScalar(10);
    return {
      type: 'missile', mesh, vel, life: 4, dmg: W.dmg, target,
      speed: 15, trail: 0, execute: false, fromPlayer: false,
      /* CH-25.4 — typed drone missile (profile + per-missile crit) */
      hit: { types: typedHit(W), crit: rollCrit(W), statusChance: W.statusChance || 0 },
    };
  }

  /* CH-25.4 — W (the weapon def) rides in whole: typed profile + crit/
     status stats come from assets.companions.drone.weapons[n], same
     contract as your guns. Beam/bolt/burst all share this path.          */
  droneShoot(game, dr, enemy, W, style) {
    enemy._hitBy = 'companion';      // BLOOD FOR SHIELD tagging
    const from = dr.pos.clone();
    const to = enemy.group.position.clone();
    to.y += enemy.fly ? 0 : 0.7;
    if (style === 'beam') {
      const len = from.distanceTo(to);
      const beam = new THREE.Mesh(
        new THREE.BoxGeometry(0.025, 0.025, len),
        new THREE.MeshBasicMaterial({
          color: P.energy, transparent: true, opacity: 0.9,
          blending: THREE.AdditiveBlending, depthWrite: false,
        })
      );
      beam.position.copy(from).add(to).multiplyScalar(0.5);
      beam.lookAt(to);
      this.scene.add(beam);
      setTimeout(() => this.scene.remove(beam), 70);
      game.sfx.droneBeam();
      /* CH-25.4 — typed beam hit */
      applyDamage(enemy, { types: typedHit(W), crit: rollCrit(W), statusChance: W.statusChance || 0 },
        game, { point: to, kind: 'beam' });
      enemy.showBar(2.2);
    } else {
      game.weapon.spawnTracer(from, to);
      game.sfx.shot(0.35);
      /* CH-25.4 — typed bolt/burst hit */
      applyDamage(enemy, { types: typedHit(W), crit: rollCrit(W), statusChance: W.statusChance || 0 },
        game, { point: to, kind: 'bullet' });
      enemy.showBar(2.2);
    }
    game.weapon.spawnSpark(to, style === 'beam' ? 'energy' : true);
  }

  /* ======================================================================
     BEAST (Zanuka-style quadruped, melee only)
     ====================================================================== */
  spawnPet(game) {
    this.removePet();
    const g = new THREE.Group();
    const plateM = new THREE.MeshLambertMaterial({ color: '#6e757d' });
    const darkM  = new THREE.MeshLambertMaterial({ color: '#33383e' });
    const accentM = new THREE.MeshLambertMaterial({ color: '#b3542e' });
    const eyeM = new THREE.MeshBasicMaterial({ color: '#ff5340' });

    const body = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.4, 1.0), plateM);
    body.position.y = 0.62;
    g.add(body);
    const spine = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.14, 0.7), darkM);
    spine.position.y = 0.86;
    g.add(spine);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.3, 0.42), darkM);
    head.position.set(0, 0.74, -0.66);
    g.add(head);
    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.14, 0.24), accentM);
    snout.position.set(0, 0.66, -0.92);
    g.add(snout);
    for (const sx of [-0.09, 0.09]) {
      const eye = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.045, 0.02), eyeM);
      eye.position.set(sx, 0.8, -0.87);
      g.add(eye);
    }
    // blade legs
    this.petLegs = [];
    for (const [sx, sz] of [[-0.22, -0.34], [0.22, -0.34], [-0.22, 0.34], [0.22, 0.34]]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.55, 0.11), darkM);
      leg.position.set(sx, 0.3, sz);
      g.add(leg);
      this.petLegs.push(leg);
    }
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.07, 0.44), accentM);
    tail.position.set(0, 0.78, 0.66);
    tail.rotation.x = 0.5;
    g.add(tail);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: texGlow('#ff8a5e'), blending: THREE.AdditiveBlending,
      transparent: true, opacity: 0.35, depthWrite: false,
    }));
    glow.scale.setScalar(0.9);
    glow.position.y = 0.7;
    g.add(glow);

    const P0 = game.player.pos.clone().add(new THREE.Vector3(-1.5, 0, 2.5));
    g.position.copy(P0);
    this.scene.add(g);

    const S = CP.pet;
    this.pet = {
      group: g, body, t: Math.random() * 9, atkCd: 0, target: null,
      hp: S.hp, shield: S.shield, shieldHitT: -99, deadT: -1,
      phase: 0,
    };
    this.petRespawnT = -1;
  }

  removePet() {
    if (!this.pet) return;
    this.scene.remove(this.pet.group);
    this.pet = null;
    this._cancelLockerChannel();            // CH-05.2 — no beast, no channel
  }

  /* ======================================================================
     CH-05.2 — SUPPLY LOCKER SCAVENGE (beast-only)
     Designation: the reticle cone (same ~9.5° flat-dot math as main.js
     scanTargets) swept over world.lockers each frame — the winner lands
     in this.lockerDesignated for ecology.js (prompt) + hud.js (target
     info + ring) to read. The CHANNEL itself runs inside updatePet:
     run to locker.stand → channel pet.scavTime s → flip locker.opened
     (world.js swings the door + starts the respawn timer) and spill the
     elite cache via specials.spillLockerLoot. Combat/death/toggle/
     designation-loss all tear the channel down (combat-first beast).
     ====================================================================== */
  scanLockerDesignation(game) {
    this.lockerDesignated = null;
    const pl = game.player;
    if (!pl || pl.dead || !game.world || !game.world.lockers) return;
    const LK = ASSETS.lockers;
    const fwd = new THREE.Vector3();
    game.camera.getWorldDirection(fwd);
    const fwdFlat = new THREE.Vector3(fwd.x, 0, fwd.z).normalize();
    let best = 0.986;                       // ~9.5° cone — scanTargets parity
    for (const l of game.world.lockers) {
      if (l.opened) continue;
      const to = new THREE.Vector3(l.x - pl.pos.x, 0, l.z - pl.pos.z);
      const dist = to.length();
      if (dist > LK.designateR || dist < 0.001) continue;
      const dot = to.normalize().dot(fwdFlat);
      if (dot > best) { best = dot; this.lockerDesignated = { locker: l, dist }; }
    }
    /* teach-toast: designating with no beast out (throttled) */
    if (this.lockerDesignated && (!this.petEnabled || !this.pet || this.pet.deadT >= 0)
        && this._noBeastT <= 0) {
      this._noBeastT = 6;
      game.hud.toast('BEAST ONLY — DEPLOY THE ZANUKA TO OPEN LOCKERS', 2200);
    }
  }

  /* channel teardown — combat wins, death wins, toggle-off wins */
  _cancelLockerChannel() {
    this.petChannelLocker = null;
    this.petChannelT = 0;
    this.petChannelDur = 1;
  }

  /* the designated locker the beast will work — needs the beast enabled
     AND alive (CH-05.3) and the locker not already opened */
  _petLockerTarget() {
    const desig = this.lockerDesignated;
    if (!desig || !this.petEnabled || !this.pet || this.pet.deadT >= 0) return null;
    const l = desig.locker;
    return l.opened ? null : l;
  }

  damagePet(amount, game) {
    const pt = this.pet;
    if (!pt || pt.deadT >= 0) return;
    pt.shieldHitT = game.time;
    if (pt.shield > 0) {
      pt.shield -= amount;
      if (pt.shield < 0) { pt.hp += pt.shield; pt.shield = 0; }
    } else {
      pt.hp -= amount;
    }
    game.weapon.spawnSpark(pt.group.position, true);
    if (pt.hp <= 0) {
      pt.deadT = 0;
      game.sfx.whine();
      game.hud.toast('BEAST DOWN — REBUILDING', 1600);
    } else {
      game.sfx.yelp();
    }
  }

  updatePet(dt, game) {
    const pt = this.pet;
    const S = CP.pet;
    const pl = game.player;

    if (pt.deadT >= 0) {
      pt.deadT += dt;
      pt.group.rotation.z = Math.min(Math.PI / 2, pt.deadT * 3.2);
      this._cancelLockerChannel();                // CH-05.2 — dead beast drops the channel
      if (pt.deadT > 1.1) {
        this.removePet();
        this.petRespawnT = CP.respawn;
      }
      return;
    }

    pt.t += dt;
    pt.atkCd -= dt;
    if (game.time - pt.shieldHitT > S.shieldDelay && pt.shield < S.shield) {
      pt.shield = Math.min(S.shield, pt.shield + S.shieldRegen * dt);
    }

    const pos = pt.group.position;

    /* pick a target: your CURSOR designation first, then the nearest
       hostile within aggro of the beast. HOLD FIRE while cloaked. */
    let best = null;
    if (pl.invisT <= 0 && !pl.dead) {
      const cur = game.currentTarget && game.currentTarget.ref;
      if (cur && cur.alive &&
          cur.group.position.distanceTo(pos) < S.aggro * 1.4) best = cur;
      if (!best) {
        let bestD = S.aggro;
        for (const e of game.enemies) {
          if (!e.alive) continue;
          const d = e.group.position.distanceTo(pos);
          if (d < bestD) { best = e; bestD = d; }
        }
      }
    }
    pt.target = best;

    let moving = 0;
    if (best) {
      /* CH-05.2 — COMBAT WINS: an enemy in aggro drops any locker channel */
      if (this.petChannelLocker) this._cancelLockerChannel();
      /* charge — face the TARGET (head is on local −Z: yaw must point the
         model's −Z at the enemy, i.e. θ = atan2(px − tx, pz − tz).
         v0.8 fix: this used to run the beast BACKWARDS at the enemy) */
      const to = new THREE.Vector3().subVectors(best.group.position, pos);
      to.y = 0;
      const d = to.length();
      if (d > S.reach) {
        to.normalize().multiplyScalar(S.speed * dt);
        pos.add(to);
        moving = 1;
      } else if (pt.atkCd <= 0) {
        pt.atkCd = S.attackCd;
        best._hitBy = 'companion';       // BLOOD FOR SHIELD tagging
        /* CH-25.4 — typed bite: slash-heavy profile + crit/status from the
           pet def (wounds feed the CH-26 bleed procs later).             */
        applyDamage(best, { types: typedHit(S), crit: rollCrit(S), statusChance: S.statusChance || 0 },
          game, { point: best.group.position.clone(), kind: 'melee' });
        best.stagger = Math.max(best.stagger, S.biteStagger + 0.4);
        best.showBar(2.5);
        game.sfx.bite(panOf(game, pos));
        game.weapon.spawnSpark(best.group.position, true, true);
        /* lunge anim */
        pt.body.rotation.x = -0.3;
      }
      pt.group.rotation.y = Math.atan2(
        pos.x - best.group.position.x, pos.z - best.group.position.z);
    } else {
      /* CH-05.2 — SCAVENGE: the beast opens the reticle-designated locker.
         A running channel KEEPS GOING if the player looks away — the ring
         is the feedback; only combat / death / kennel / a NEW designation
         cancels it. */
      const LK = ASSETS.lockers;
      const lk = this._petLockerTarget() || this.petChannelLocker;
      if (!lk || lk.opened) {
        if (this.petChannelLocker) this._cancelLockerChannel();   // designation lost
      } else {
        if (this.petChannelLocker && this.petChannelLocker !== lk)
          this._cancelLockerChannel();                            // re-designated mid-channel
        const sp = lk.stand;
        const dx = sp.x - pos.x, dz = sp.z - pos.z;
        const d = Math.hypot(dx, dz);
        if (this.petChannelLocker !== lk) {
          if (d > 0.5) {
            /* run to the stand point (catch-up sprint, same curve as heel) */
            const spd = Math.min(16, Math.max(S.speed, d * 1.6));
            pos.x += (dx / d) * Math.min(spd, d * 4) * dt;
            pos.z += (dz / d) * Math.min(spd, d * 4) * dt;
            moving = 1;
          } else {
            /* channel start — SCAVENGE ramp (CH-05.3) tunes the length */
            this.petChannelLocker = lk;
            this.petChannelT = 0;
            this.petChannelDur = Math.max(0.5, CP.pet.scavTime);
            game.sfx.growl();
          }
        } else {
          /* channeling — hold position, nose-down dig at the door */
          this.petChannelT += dt;
          pt.body.rotation.x = 0.25;
          const frac = this.petChannelT / this.petChannelDur;
          if (frac >= 1) {
            /* OPEN — world.js swings the door + arms the respawn timer;
               the elite cache spills at the door face (CH-05.2) */
            lk.opened = true;
            lk.respT = LK.respawn[0] + Math.random() * (LK.respawn[1] - LK.respawn[0]);
            const fp = lk.front;
            game.specials.spillLockerLoot(new THREE.Vector3(
              fp.x + Math.sin(lk.ry) * LK.lootBack, 0.4,
              fp.z + Math.cos(lk.ry) * LK.lootBack), lk.level);
            game.hud.toast('LOCKER OPEN — ELITE CACHE SPILLED', 1600);
            game.sfx.pickup('ammo');
            this._cancelLockerChannel();
          }
        }
        /* face the locker the whole way (v0.8 yaw fix: −Z at the target) */
        pt.group.rotation.y = Math.atan2(pos.x - lk.x, pos.z - lk.z);
      }
    }
    if (!best && !this.petChannelLocker && !this._petLockerTarget()) {
      /* CURSOR-LED HEEL — trot ~6 ft ahead of you, in the direction your
         cursor (camera aim) points. Falls back to straight ahead when
         the aim is level at nothing in particular. */
      const aim = new THREE.Vector3();
      game.camera.getWorldDirection(aim);
      aim.y = 0;
      if (aim.lengthSq() < 0.04) aim.copy(pl.forward());
      aim.normalize();
      const want = pl.pos.clone().addScaledVector(aim, S.heelDist);
      /* slight side weave so it doesn't stand in your shots */
      const side = new THREE.Vector3(-aim.z, 0, aim.x);
      want.addScaledVector(side, Math.sin(pt.t * 1.4) * 0.55);
      this.clampToWorld(want);
      const to = new THREE.Vector3().subVectors(want, pos);
      to.y = 0;
      const d = to.length();
      if (d > 0.45) {
        /* sprint multiplier so a left-behind beast catches back up */
        const spd = Math.min(16, Math.max(S.speed, d * 1.6));
        to.normalize().multiplyScalar(Math.min(spd, d * 4) * dt);
        pos.add(to);
        moving = 1;
        /* face where it RUNS while sprinting; face your aim when close */
        if (d > 2.2) {
          pt.group.rotation.y = Math.atan2(-to.x, -to.z);
        } else {
          pt.group.rotation.y = Math.atan2(-aim.x, -aim.z);
        }
      } else {
        pt.group.rotation.y = Math.atan2(-aim.x, -aim.z);
      }
      if (pl.dead) pt.group.rotation.y += dt * 2;   // confused pacing
    }

    /* ground snap + bounds */
    const gy = game.world.floorHeightAt(pos.x, pos.z, pos.y + 1.2);
    pos.y = gy;
    this.clampToWorld(pos);

    /* leg animation */
    pt.phase += dt * (4 + moving * 9);
    const w = Math.sin(pt.phase) * 0.55 * moving;
    if (this.petLegs) {
      this.petLegs[0].rotation.x = w;
      this.petLegs[1].rotation.x = -w;
      this.petLegs[2].rotation.x = -w;
      this.petLegs[3].rotation.x = w;
    }
    pt.body.rotation.x += (0 - pt.body.rotation.x) * Math.min(1, dt * 6);
    pt.body.position.y = 0.62 + Math.abs(Math.sin(pt.phase)) * 0.03 * moving;
  }

  /* keep companions inside the built play space (corridor/hangar/valley/city
     + the v0.8 expanse wilds) */
  clampToWorld(v) {
    const EX = ASSETS.world.expanse;
    const zEnd = EX.z0 - EX.rows * EX.tileSize;
    v.z = Math.max(zEnd + 1, Math.min(1.4, v.z));
    if (v.z > ASSETS.world.hangar.mouthZ) v.x = Math.max(-2.6, Math.min(2.6, v.x));
    else if (v.z > ASSETS.world.valley.z0) v.x = Math.max(-16.4, Math.min(16.4, v.x));
    else if (v.z > ASSETS.world.city.z0) v.x = Math.max(-12.4, Math.min(12.4, v.x));
    else if (v.z > EX.z0) v.x = Math.max(-13.4, Math.min(13.4, v.x));
    else v.x = Math.max(-(EX.cols * EX.tileSize / 2 - 1), Math.min(EX.cols * EX.tileSize / 2 - 1, v.x));
  }

  /* ====================================================================== */
  update(dt, game) {
    this._game = game;              // CH-04.4 — keep the cached ref fresh
    this._noAmmoT -= dt;
    this._noBeastT -= dt;                          // CH-05.2 — toast throttle
    if (game.state === 'playing') this.scanLockerDesignation(game);  // CH-05.2

    /* respawns (only while enabled) */
    if (this.droneEnabled && !this.drone) {
      if (this.droneRespawnT > 0) {
        this.droneRespawnT -= dt;
        if (this.droneRespawnT <= 0) {
          this.spawnDrone(game);
          game.hud.toast('DRONE ONLINE', 1200);
          game.sfx.droneBeep();
        }
      }
    }
    if (this.petEnabled && !this.pet) {
      if (this.petRespawnT > 0) {
        this.petRespawnT -= dt;
        if (this.petRespawnT <= 0) {
          this.spawnPet(game);
          game.hud.toast('BEAST BACK ON ITS FEET', 1200);
        }
      }
    }

    if (this.drone) this.updateDrone(dt, game);
    if (this.pet) this.updatePet(dt, game);
  }

  /* run reset — companions rebuild fresh beside the spawn point */
  resetAll(game) {
    this._cancelLockerChannel();                   // CH-05.2 — fresh run, no channel
    this.removeDrone();
    this.removePet();
    this.droneRespawnT = -1;
    this.petRespawnT = -1;
    if (this.droneEnabled) this.spawnDrone(game);
    if (this.petEnabled) this.spawnPet(game);
  }
}

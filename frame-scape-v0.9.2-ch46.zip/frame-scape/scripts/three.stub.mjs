/* three.stub.mjs — CH-44 harness stub (test_ch47.mjs pattern): enough of
   three.js for buildWorld() to run end-to-end in Node with REAL data
   structures (scene graph, colliders, lights, batch stats) but zero GPU.
   Geometry attributes are minimal (1 vertex) — the merge math runs, the
   counts stay real. */

let UUID = 0;
const uid = () => 'stub-' + (++UUID);

class Vector3 {
  constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; }
  set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; }
  copy(v) { this.x = v.x; this.y = v.y; this.z = v.z; return this; }
}
class Vector2 { constructor(x = 0, y = 0) { this.x = x; this.y = y; } set(x, y) { this.x = x; this.y = y; return this; } }
class Euler { constructor() { this.x = 0; this.y = 0; this.z = 0; } set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } }
class Quaternion { setFromEuler() { return this; } identity() { return this; } }
class Matrix4 { compose() { return this; } identity() { return this; } }

class Attr {
  constructor(array, itemSize) { this.array = array; this.count = array.length / itemSize; this.itemSize = itemSize; }
}
class BufferAttribute extends Attr {}
class BufferGeometry {
  constructor() {
    this.uuid = uid();
    this.index = null;
    this.attributes = { position: new Attr(new Float32Array(3), 3), normal: new Attr(new Float32Array(3), 3), uv: new Attr(new Float32Array(2), 2) };
  }
  setAttribute(name, attr) { this.attributes[name] = attr; return this; }
  clone() { const g = new BufferGeometry(); g.uuid = this.uuid; return g; }
  applyMatrix4() { return this; }
  scale() { return this; }
  toNonIndexed() { return this; }
  dispose() {}
  computeBoundingSphere() {}
}
class BoxGeometry extends BufferGeometry {}
class PlaneGeometry extends BufferGeometry {}
class CylinderGeometry extends BufferGeometry {}
class ConeGeometry extends BufferGeometry {}
class IcosahedronGeometry extends BufferGeometry {}
class OctahedronGeometry extends BufferGeometry {}
class SphereGeometry extends BufferGeometry {}
class RingGeometry extends BufferGeometry {}
class TorusGeometry extends BufferGeometry {}
class CircleGeometry extends BufferGeometry {}
class Object3D {
  constructor() {
    this.uuid = uid();
    this.children = [];
    this.position = new Vector3();
    this.rotation = new Euler();
    this.scale = new Vector3(1, 1, 1);
    this.matrix = new Matrix4();
    this.matrixWorld = new Matrix4();
    this.matrixAutoUpdate = true;
    this.castShadow = false;
    this.receiveShadow = false;
    this.visible = true;
    this.userData = {};
  }
  add(...os) { for (const o of os) this.children.push(o); }
  remove(o) { const i = this.children.indexOf(o); if (i >= 0) this.children.splice(i, 1); }
  updateMatrix() {}
  updateMatrixWorld() {}
  traverse(fn) { fn(this); for (const c of this.children) c.traverse && c.traverse(fn); }
}
class Mesh extends Object3D {
  constructor(geo, mat) { super(); this.geometry = geo; this.material = mat; this.isMesh = true; }
}
class Group extends Object3D { constructor() { super(); this.isGroup = true; } }
class Scene extends Object3D {
  constructor() { super(); this.fog = null; this.background = null; }
}
class Light extends Object3D {
  constructor(color, intensity, distance = 0, decay = 2) {
    super();
    this.color = color; this.intensity = intensity;
    this.distance = distance; this.decay = decay;
    this.isLight = true;
  }
}
class PointLight extends Light { isPointLight = true; }
class SpotLight extends Light { isSpotLight = true; target = new Object3D(); }
class DirectionalLight extends Light { shadow = { mapSize: { set(){} }, camera: {}, bias: 0, normalBias: 0 }; }
class HemisphereLight extends Light {}

class Material { constructor(params = {}) { Object.assign(this, params); this.uuid = uid(); } }
class MeshBasicMaterial extends Material {}
class MeshLambertMaterial extends Material {}
class MeshPhongMaterial extends Material {}
class Color { constructor() { this.r = 0; this.g = 0; this.b = 0; } set() { return this; } setRGB() { return this; } lerp() { return this; } }
class Fog { constructor(c, n, f) { this.color = new Color(); this.near = n; this.far = f; } }

const DoubleSide = 2;
const SRGBColorSpace = 'srgb';
const PCFShadowMap = 1;

export {
  Vector2, Vector3, Euler, Quaternion, Matrix4,
  BufferGeometry, BufferAttribute, BoxGeometry, PlaneGeometry, CylinderGeometry, ConeGeometry,
  IcosahedronGeometry, OctahedronGeometry, SphereGeometry, RingGeometry,
  TorusGeometry, CircleGeometry,
  Object3D, Mesh, Group, Scene,
  PointLight, SpotLight, DirectionalLight, HemisphereLight,
  MeshBasicMaterial, MeshLambertMaterial, MeshPhongMaterial,
  Color, Fog, DoubleSide, SRGBColorSpace, PCFShadowMap,
};

/* ============================================================================
   FRAME SCAPE — ASSETS & CONFIG  ★ THE FILE YOU EDIT ★
   ----------------------------------------------------------------------------
   Everything visual / gameplay-tunable lives in this one file:
   palette, corridor + hangar + VALLEY layout, weapons & ammo pools, special
   slots, companions (drone / beast pet), abilities (air-jump / hover / VATS),
   enemy archetypes, drop chart, dual-currency economy (CREDITS + POWER),
   controller feel, audio mix, quality. Other js files only READ from here.

   Units: meters, seconds. Colors: hex strings.
   After editing: save + reload the page (no build step).
   ==========================================================================*/

export const ASSETS = {

  meta: {
    title: 'FRAME SCAPE',
    subtitle: 'a Halo/Warframe-inspired open-wilds browser shooter',
    version: '0.8.2',   /* CH-05 SHIPPED — phase 2 (Companions) complete: beast-opened
                           SUPPLY LOCKERS + the SCAVENGE mod. Visible in the XMB
                           footer + boot menu. Phase 3 (World, v0.9.0) is next. */
  },

  /* ------------------------------------------------------------------ */
  /* PALETTE — dark ship interior + the valley outside                   */
  /* ------------------------------------------------------------------ */
  palette: {
    fog:        '#0d1015',
    bg:         '#0d1015',
    wallA:      '#7d848c',
    wallB:      '#565c63',
    wallInset:  '#33383e',
    floor:      '#474d54',
    floorLine:  '#2e3237',
    ceiling:    '#5d646c',
    strip:      '#cfe6f2',
    stripGlow:  '#9fd4ee',
    lampCool:   '#bfd9ec',
    lampWarm:   '#e8a04e',
    hazardY:    '#d9b52f',
    hazardB:    '#15161a',
    crate:      '#4f5c45',
    crateDark:  '#3b4634',
    stencil:    '#b4bda9',
    /* CH-06.1 — barrels + chests (breakable containers) */
    barrelWood:    '#6e5434',
    barrelWoodDk:  '#4a3820',
    barrelMetal:   '#7a4034',
    barrelMetalDk: '#4a2c26',
    chest:         '#46505c',
    chestDk:       '#2e353d',
    plasma:     '#7dff4f',
    muzzle:     '#ffd9a0',
    gunmetal:   '#33383e',
    gunDark:    '#22262b',
    gunAccent:  '#5a6b47',
    led:        '#5affd0',
    shield:     '#4fc3ff',
    shieldLow:  '#ff5340',
    hudText:    '#bfe9ff',
    /* hangar */
    hWall:      '#6a7078',
    hWallDark:  '#43484f',
    hFloor:     '#3d4349',
    hTrim:      '#2a2e33',
    grate:      '#4a5056',
    containerR: '#8a3b34',
    containerB: '#33566b',
    exitDoor:   '#3c4249',
    beacons:    '#ff3b30',
    energy:     '#59f2ff',
    fire:       '#ff8b2a',
    missile:    '#d8dee6',
    eliteGold:  '#e8b53a',
    /* valley (outdoor dusk) */
    vRock:      '#5d564c',
    vRockDk:    '#3a352f',
    vGround:    '#4c4a38',
    vMoss:      '#5d6b46',
    vWood:      '#3d3229',
    vSky:       '#24333c',
    vFog:       '#18232a',
    vCrystal:   '#6ff2ff',
    vDusk:      '#e08a4e',
    power:      '#7df2ff',   // POWER currency orbs
    /* cityscape (night city beyond the valley) */
    cFacadeA:   '#2b3138',
    cFacadeB:   '#232a33',
    cWindow:    '#ffd98e',
    cWindowB:   '#8fd8ff',
    cAsphalt:   '#26292e',
    cNeonA:     '#ff4f9a',
    cNeonB:     '#4fffd8',
    cSky:       '#0a1220',
    cFog:       '#0b1420',
    /* wilderness expanse + ocean (v0.8) */
    wGrass:     '#4f6b35',
    wGrassDry:  '#8a8a4d',
    wLeaf:      '#3d6b30',
    wLeafDark:  '#2c4d24',
    wTrunk:     '#4a3a28',
    wSand:      '#cbb98a',
    wSandWet:   '#a99a72',
    wSnow:      '#dfe9f2',
    wRockMt:    '#6a6d72',
    wWater:     '#3d7a8c',
    wWaterDeep: '#1d4a63',
    wWaterShal: '#5fb2b8',
    wFlower:    '#d46a9e',
    wFlowerB:   '#e8c94f',
    wCactus:    '#4f7d4a',
  },

  /* ------------------------------------------------------------------ */
  /* QUALITY / PERFORMANCE — tuned for Intel HD 3000 (i3-2350M).         */
  /* ------------------------------------------------------------------ */
  quality: {
    mode: 'auto',
    shadows: true,
    resScale: 1.0,
    fpsFloor: 24,
    fpsCheck: 1.0,
    fallbackWidth: 480,
    maxPixelRatio: 1,
    antialias: false,
    maxPointLights: 5,
    fov: 78,
  },

  /* ------------------------------------------------------------------ */
  /* WORLD — corridor (0…-72) → HANGAR BAY 7 (-72.4…-116) → THE VALLEY.  */
  /* ------------------------------------------------------------------ */
  world: {
    corridor: {
      length: 72,
      width: 6,
      height: 3.2,
      segment: 4,
      alcoveSegments: [7, 12],
      lampEvery: 3,
      lampAlternateCoolWarm: true,
      hazardBandAt: [2, 16],
      barriers: [
        { x: -1.2, z: -33, ry:  0.5 },
        { x:  1.2, z: -53, ry: -0.5 },
      ],
      signs: [
        { seg: 3,  side:  1, text: 'SECTION 7-A' },
        { seg: 9,  side: -1, text: 'CARGO BAY →' },
        { seg: 15, side:  1, text: 'BAY 7 →' },
      ],
    },
    hangar: {
      /* CH-07.1 — BAY EXPANSION: width 34→42 (extra east bay strip), depth
         44→48 (open south bay), 6 high-bays, 3 side doors, 2 new pillars,
         corridor-style barricades, 2 new cargo containers. All prop/spawn
         placements re-verified clear of walls/pillars/dropship/lockers. */
      mouthZ: -72,
      mouthW: 3.6,
      mouthH: 3.3,
      width: 42,
      depth: 48,
      height: 11.4,
      highBays: [
        { x: -8, z: -86, warm: false },
        { x:  8, z: -94, warm: false },
        { x:  0, z: -110, warm: true },
        { x: -15, z: -98, warm: false },   /* CH-07.1 west/south bays */
        { x:  15, z: -110, warm: true },
        { x: -2, z: -118, warm: false },
      ],
      sideDoors: [
        { side: -1, z: -86 },
        { side:  1, z: -98 },
        { side:  1, z: -110 },   /* CH-07.1 east bay door */
      ],
      catwalk: {
        y: 5.2,
        x0: -21, x1: -13.2,      /* CH-07.1 gantry extended west to the new wall */
        z0: -118, z1: -76,       /* CH-07.1 and south into the new bay */
        ramp: { x0: -13.2, x1: -10.0, zTop: -76, zBot: -90 },
      },
      pillars: [
        { x: -6, z: -92 }, { x: 6, z: -92 },
        { x: -6, z: -106 }, { x: 6, z: -106 },
        { x: -11, z: -112 }, { x: 12, z: -112 },   /* CH-07.1 south-bay pillars */
      ],
      /* CH-07.1 — more cover: corridor-style barricades in the open bays */
      barriers: [
        { x: -2.5, z: -107, ry: 0.4 },
        { x:  3.5, z: -114, ry: -0.3 },
      ],
      containers: [
        { x: -9,  z: -80, ry: 0.12, tone: 'r', stacked: true },
        { x:  9.5,z: -104, ry: -0.08, tone: 'b' },
        { x: 12.5,z: -88, ry: 1.62, tone: 'r' },
        { x: -3,  z: -112, ry: 0.3,  tone: 'b' },
        { x: 17,  z: -92.5, ry: -1.5, tone: 'r' },   /* CH-07.1 east bay */
        { x: -8,  z: -116.5, ry: 0.1, tone: 'b' },   /* CH-07.1 south bay */
      ],
      /* crates MOVED — hangar crate placements now live in
         world.containers.zones.hangar (CH-06.2 per-zone mix). */
      dropship: { x: 7.5, z: -82, ry: 0.35 },
      exitDoor: { z: -120.4, width: 10, height: 7, openAt: 9 },  /* CH-07.2 deeper back wall */
    },
    /* THE VALLEY — dusk canyon approach beyond the hangar exit.        */
    valley: {
      z0: -121.4, z1: -156,   /* CH-07.2 — mouth follows the deeper hangar back wall */
      mouthW: 10,
      widthIn: 26, widthOut: 20,     // walls funnel from 26 m to 20 m
      wallH: 17,
      crystals: [                    // POWER crystal pickups (respawn on reset)
        { x: -6, z: -124 }, { x: 7,  z: -128.5 }, { x: -8, z: -136 },
        { x: 5.5,z: -141 }, { x: -3, z: -147 },   { x: 7.5,z: -152.5 },
      ],
      trees: [
        { x: -9,  z: -127, s: 1.0 }, { x: 8.5, z: -133, s: 1.25 },
        { x: -7,  z: -144, s: 0.85 }, { x: 4,   z: -150, s: 1.1 },
      ],
      rocks: [
        { x: -4,  z: -123, s: 2.0, ry: 0.4 }, { x: 6,  z: -123.5, s: 1.5, ry: -0.7 },  /* first boulder CH-07.2 z-121→-123 (old spot now inside hangar) */
        { x: 0.5, z: -132, s: 1.3, ry: 0.2 }, { x: -6, z: -139,  s: 1.8, ry: 0.9 },
        { x: 3,   z: -145, s: 1.2, ry: -0.3 },
      ],
      grass: [
        { x: -3, z: -122 }, { x: 4, z: -126 }, { x: -6.5, z: -131 }, { x: 2, z: -135 },
        { x: -1, z: -140 }, { x: 6, z: -143 }, { x: -4, z: -149 },   { x: 3, z: -154 },
      ],
    },
    /* THE CITYSCAPE — night streets beyond the valley (v0.7).           */
    city: {
      z0: -156.6, z1: -214,
      streetHalf: 11,               // drivable half-width
      laneZEvery: 6,                // dashed lane stripe spacing
      buildings: { seed: 9, gapMin: 3, gapMax: 6, depthMin: 11, depthMax: 17,
                   wMin: 13, wMax: 24, hMin: 9, hMax: 26 },
      lamps: [                      // street lamps (lit = real point light)
        { x: -10.4, z: -163, lit: true },
        /* CH-08.1 — two lamps re-placed clear of the corridor footprints
           (was -172 and -194, both landed inside connector fillers) */
        { x: 10.4, z: -169.5, lit: false },
        { x: -10.4, z: -183, lit: true },
        { x: 10.4, z: -199.5, lit: false },
        { x: -10.4, z: -205, lit: true },
      ],
      signs: [
        { x: -11.2, y: 5.0,  z: -166, text: 'SECTOR 9',      color: '#ff4f9a' },
        /* CH-08.1 — NIGHT MARKET re-placed south of connector A (its
           stanchions spanned the -177.5 gate line at the old -178 spot) */
        { x:  11.2, y: 6.0,  z: -180.5, text: 'NIGHT MARKET',  color: '#4fffd8' },
        { x: -11.2, y: 4.2,  z: -190, text: 'PAD 7 HOTEL',   color: '#ffd98e' },
        /* CH-08.3 — mid-road extraction beacon removed; the sign that
           pointed at it now reads toward the deep-ocean pier (the true
           extraction — the buoy win zone, untouched) */
        { x:  11.2, y: 5.2,  z: -202, text: 'OCEAN PIER →',  color: '#7df2ff' },
      ],
      cars: [                       // wrecked skimmer hulks (solid props)
        /* CH-08.1 — the -177 hulk re-placed into the mid block (it spanned
           the connector A gate line + pinch wall) */
        { x: -5.5, z: -185, ry: 0.42 }, { x: 6.8, z: -188, ry: -0.3 },
        { x: -4.5, z: -207, ry: 0.12 },
      ],
      planters: [
        { x: 8.5, z: -160 }, { x: -8.5, z: -170 }, { x: 8.5, z: -180 },
        /* CH-08.1 — the -199 planter re-placed clear of connector B's
           south gate (it also grazed the -200 crate at the old spot) */
        { x: -9.2, z: -203.5 }, { x: 8.5, z: -210 },
      ],
      /* ==================================================================
         CH-08.1 — CORRIDOR CONNECTORS joining the city blocks. Each
         segment encloses its stretch of street: pinch walls (±pass/2),
         solid fillers out to the boundary walls, a roofed span, gated
         end walls (center opening + side slabs — the expanse-gate
         recipe) with SLIDING DOORS that auto-open from either side, 2
         dim point lights (zone 'city' — the existing zone cull fades
         them) and one neon plate on the north gate face. Blocks stay
         open-air; the street reads: block · connector · block · …
         pass: clear inner half-width · roofY: slab underside
         doorW/H: sliding gate door · openAt: proximity trigger radius
         sign/text/color: neon plate on the z0 (north) gate face.       */
      corridors: [
        {
          z0: -171.5, z1: -177.5,
          pass: 12, roofY: 5.6, doorW: 12.4, doorH: 4.7, openAt: 7,
          sign: { text: 'SECTOR 9 WALK', color: '#ff4f9a' },
        },
        {
          z0: -192.5, z1: -198.5,
          pass: 12, roofY: 5.6, doorW: 12.4, doorH: 4.7, openAt: 7,
          sign: { text: 'TRANSIT LOOP', color: '#4fffd8' },
        },
      ],
      /* CH-08.2 — OPTIONAL TELEPORT ENTRIES: an express transit pair
         linking the north and south open blocks (skips both connectors).
         Stand on a pad 0.45 s → warp to its mate (companions ride
         along), 5 s cooldown, hud flash + synth chirp. Pads sit in OPEN
         blocks clear of gates so the drone/pet never strand behind a
         closed door.                                                  */
      transits: [
        { x: -3, z: -169.2, toX: -3, toZ: -200.8, label: 'SOUTH LOOP' },
        { x: -3, z: -200.8, toX: -3, toZ: -169.2, label: 'SECTOR 9' },
      ],
      /* crates MOVED — city crate placements now live in
         world.containers.zones.city (CH-06.2 per-zone mix). */
      crystals: [                   // POWER crystals held in the streets
        /* CH-08.1 — three crystals re-placed: (7,-171) sat on connector
           A's gate line AND grazed the L8 shielder arena, (-7.5,-186)
           now clears the re-placed skimmer hulk, (5.5,-198) sat in
           connector B's pinch + door sweep */
        { x: -6.5, z: -161 }, { x: 5.8, z: -169.8 }, { x: -8.6, z: -186 }, { x: 4.8, z: -197.5 },
      ],
      /* CH-08.3 — the mid-road EXTRACTION BEACON prop is GONE (user
         2026-10-28): the v0.7 landmark stood in the middle of the south
         block. STATED DECISION AT PATCH TIME: it was NEVER an extraction
         trigger — the city's win path is the deep-ocean BUOY (world.
         winZone reads expanse.buoy; this prop carried no collider and no
         trigger), so the post deletes CLEAN with no relocation, exactly
         as f3's delete branch prescribes. The extraction FLOW itself is
         untouched (H070 scope; CH-36 home-base rides the buoy). No other
         zone's extraction posts affected.                                */
    },

    /* CH-05.1 — SUPPLY LOCKERS. The BEAST opens these (CH-05.2 — only the
       beast: point the reticle at one, it runs over, channels, spills
       ELITE-quality loot). Coordinates are hand-placed in the CURRENT zones
       for now (corridor · hangar · valley · city) — the expanse/placement
       passes are CH-10's locker placement pass. ry = yaw of the door face
       (the door sits on the locker's local +Z side; the stand point the
       beast channels at is derived from it in world.js).                   */
    lockers: [
      { x:  2.5, z: -16.5,  ry: Math.PI },          // corridor — aft wall, before the first crates
      { x: -12.3, z: -79,   ry: Math.PI * 0.5 },    // hangar — beside the extended gantry edge (CH-07.2: was -13.5,-78, now clear of the deck footprint)
      { x:  19.5, z: -116,  ry: -Math.PI * 0.5 },   // hangar — right-back corner (CH-07.2: was 14.5,-110, wall moved to ±21)
      { x:  8.5, z: -125.5, ry: Math.PI * 0.75 },   // valley — entrance, right wall (CH-07.2: was -119.5, now clear of the deeper hangar)
      { x: -8.5, z: -153.5, ry: -Math.PI * 0.25 },  // valley — exit, left wall
      { x: -9.6, z: -160.5, ry: Math.PI * 0.5 },    // city — left sidewalk north
      { x:  9.6, z: -184.5, ry: -Math.PI * 0.5 },   // city — right sidewalk mid
      { x: -9.5, z: -211.5, ry: Math.PI * 0.5 },    // city — left sidewalk by the beacon
    ],

    /* ====================================================================
       CH-06.1/06.2 — BREAKABLE CONTAINERS: crates · barrels · chests.
       One config for every breakable prop: the per-zone MIX below is the
       single placement list (the old per-zone `crates` arrays moved into
       it unchanged), kinds resolve their material + HP pool, and each
       kind has its own spill table (CH-06.3).

       CH-06.4 — UNIVERSAL BREAK THRESHOLD (user 2026-10-28): crates,
       barrels and chests break from ANY damage type — no type gate,
       physical splits and elements alike. The mark is keyed to the RL-4
       per-shell damage: one rocket shell (≈breakThreshold) instant-breaks
       any prop, lesser hits keep chipping the same prop HP pool. Per-
       material HP stays ≤ the mark so "one rocket shell still kills"
       holds for every prop; props have no shields/armor — typed hits
       (CH-25 pipeline) apply their raw delivered totals.
       ==================================================================== */
    containers: {
      breakThreshold: 2000,   // ★ keyed to the RL-4 shell (rk-dmg mods still
                              //   overkill it → the ×3 loot cap, unchanged)
      materials: {            // per-material HP pools — ALL ≤ breakThreshold
        wood:  { hp: 150 },   // splinters fast under small arms / melee
        metal: { hp: 320 },   // drums take twice the pool + spark spray
      },
      kinds: {                // default material per kind (entry `mat` wins)
        crate:  { mat: 'wood' },   // legacy crates ride the FULL threshold pool
        barrel: { mat: 'metal' },
        chest:  { mat: 'metal' },
      },
      spill: {                // CH-06.3 — per-kind spill (crates keep the
                              // conversion table — see specials.spawnConversionLoot)
        barrel: { cr: [15, 30],  ammo: [['rifle', 12], ['pistol', 6], ['shell', 3]], modChance: 0 },
        chest:  { cr: [60, 120], ammo: [['sniper', 1], ['shell', 6]], modChance: 0.18 },
      },
      /* Per-zone mix — the ONE placement list per zone (CH-06.2).
         kind: crate | barrel | chest · mat: wood | metal (kinds default)
         · ry: yaw · stack: true → placed ON the previous prop of this zone
         list and chain-collapse with it like the stacked hangar containers.
         Crates below are the EXACT placements from the old per-zone lists
         (corridor/hangar/city) — zero world-layout drift. New barrels and
         chests are hand-placed clear of walls, barriers, pillars, the
         dropship, cars, planters, lockers and spawn arenas.               */
      zones: {
        corridor: [
          { kind: 'crate', x: -1.6, z: -20, s: 1.25, ry: 0.15 },
          { kind: 'crate', x:  1.7, z: -23, s: 1.0,  ry: -0.3 },
          { kind: 'crate', x:  0.0, z: -26, s: 1.5,  ry: 0.05 },
          { kind: 'chest',  x: -0.2, z: -41.5, ry: 0.15 },
          { kind: 'crate', x: -1.8, z: -38, s: 1.2,  ry: 0.5  },
          { kind: 'crate', x:  1.6, z: -44, s: 1.35, ry: -0.12 },
          { kind: 'crate', x:  0.0, z: -47, s: 1.0,  ry: 0.4  },
          { kind: 'barrel', mat: 'metal', x: 1.75, z: -50.5, ry: 0.2 },
          { kind: 'barrel', mat: 'metal', x: 1.75, z: -50.5, ry: 0.55, stack: true },
          { kind: 'crate', x: -1.5, z: -58, s: 1.25, ry: -0.2 },
          { kind: 'crate', x:  1.7, z: -62, s: 1.5,  ry: 0.25 },
          { kind: 'barrel', mat: 'metal', x: -1.7, z: -35.2, ry: 0.3 },
        ],
        hangar: [
          { kind: 'crate', x: 4,   z: -78,   s: 1.4, ry: 0.2 },
          { kind: 'crate', x: 5.6, z: -79.4, s: 1.0, ry: -0.4 },
          { kind: 'barrel', mat: 'metal', x: -4.5, z: -95.5, ry: 0.1 },
          { kind: 'barrel', mat: 'metal', x: -4.5, z: -95.5, ry: 0.45, stack: true },
          { kind: 'chest',  x: 2.2,  z: -100.5, ry: -0.25 },
          { kind: 'crate', x: -8,  z: -97,  s: 1.5, ry: 0.5 },
          { kind: 'barrel', mat: 'metal', x: -11.5, z: -86.5, ry: 0.7 },
          { kind: 'crate', x: 10,  z: -112, s: 1.2, ry: 0.1 },
          /* CH-07.1 — expanded-bay containers (old 8 kept byte-identical) */
          { kind: 'crate', x: 15.5, z: -100.5, s: 1.25, ry: 0.3 },
          { kind: 'barrel', mat: 'metal', x: 18.6, z: -106.5, ry: 0.5 },
          { kind: 'chest',  x: 14.8, z: -117.6, ry: 0.2 },
          { kind: 'crate', x: -4.2, z: -118.6, s: 1.35, ry: -0.25 },
          { kind: 'barrel', mat: 'metal', x: -11.5, z: -114.5, ry: 0.65 },
        ],
        valley: [
          { kind: 'barrel', mat: 'wood', x: -3.5,  z: -131,   ry: 0.4 },
          { kind: 'barrel', mat: 'wood', x: -4.35, z: -130.2, ry: -0.6 },
          { kind: 'chest',  x: 5.5,  z: -147.5, ry: -0.3 },
        ],
        city: [
          /* CH-08.1 — four props re-placed clear of the connector
             footprints (crate -174 → north block, crate -192 → south
             block, metal barrel -177.8 → just past gate A, the wood
             barrel pair -195.5/-196.3 → south block); the other eight
             placements are byte-identical to CH-06.2.                   */
          { kind: 'crate', x: -9,  z: -166, s: 1.3, ry: 0.3 },
          { kind: 'crate', x:  9,  z: -168.5, s: 1.0, ry: -0.2 },
          { kind: 'crate', x: -10, z: -182, s: 1.5, ry: 0.1 },
          { kind: 'crate', x:  8,  z: -200.5, s: 1.2, ry: 0.5 },
          { kind: 'barrel', mat: 'metal', x: 6.9, z: -178.6, ry: 0.5 },
          { kind: 'barrel', mat: 'wood', x: -6.8,  z: -201.5, ry: 0.8 },
          { kind: 'barrel', mat: 'wood', x: -7.65, z: -202.3, ry: -0.3 },
          { kind: 'crate', x: -8,  z: -200, s: 1.1, ry: -0.4 },
          { kind: 'crate', x: 10,  z: -205, s: 1.4, ry: 0.2 },
          { kind: 'crate', x:  4,  z: -167, s: 0.9, ry: 0.6 },
          { kind: 'chest',  x: 4.2, z: -203, ry: 0.35 },
          { kind: 'crate', x: -3,  z: -190, s: 1.2, ry: -0.1 },
        ],
      },
    },

    /* ====================================================================
       THE EXPANSE (v0.8) — beyond the city the world opens into a
       procedurally tiled WILDERNESS that auto-fills the map space
       (16,000+ m² — the 2000 m² goal is already cleared; grow
       cols/rows to keep expanding it automatically).

       · tileSize squares are stamped from the TILESETS table below
       · the layout grid is biome-aware: riverbank tiles flank the
         waterfall/forest, the beach ring sits between land and ocean,
         and the OCEAN tile set occupies the last 2 rows — 8 tiles,
         about 4× the area of any single other tile set
       · hostile level per tile set scales with distance from the city
       · kaiju: crossing the deep ocean can wake a LEVEL 80 one
       ==================================================================== */
    expanse: {
      z0: -216,                     // first tile row begins here
      tileSize: 24,
      cols: 4,                      // x: -48 … 48
      rows: 9,                      // 7 land rows + 2 OCEAN rows
      oceanRows: 2,                 // ← the ocean: 8 tiles ≈ 4,600 m² (~4× other sets)
      seed: 1337,
      /* biome layout, row by row (west → east). OCEAN = last 2 rows. */
      layout: [
        ['park',      'grassland', 'park',       'grassland'],
        ['grassland', 'trail',     'trail',      'steppe'],
        ['forest',    'forest',    'riverbank',  'steppe'],
        ['riverbank', 'forest',    'waterfall',  'mountain'],
        ['mountain',  'snowcap',   'snowcap',    'mountain'],
        ['desert',    'desert',    'steppe',     'mountain'],
        ['beach',     'oceanbay',  'oceanbay',   'beach'],
        ['ocean',     'ocean',     'ocean',      'ocean'],
        ['ocean',     'ocean',     'ocean',      'ocean'],
      ],
      /* hostile level per tile set (scales with distance from the city) */
      levels: {
        park: 10, grassland: 11, trail: 12, riverbank: 13, forest: 14,
        beach: 15, steppe: 16, waterfall: 18, mountain: 20, snowcap: 22,
        desert: 24, oceanbay: 26, ocean: 40,
      },
      kaiju: {
        hp: 480, shieldHp: 0, scale: 3.6, level: 80,
        chancePerSec: 0.015,        // while wading the deep ocean
        cooldown: 90,               // seconds before another can rise
        slamRadius: 6, slamDamage: 130,
        reward: { credits: 20000, power: 5000, mods: 2, weaponCopy: 1 },
      },
      buoy: { x: 0, z: -424 },      // deep-ocean extraction → WIN
    },
  },

  /* ------------------------------------------------------------------ */
  /* LOCKERS (CH-05) — the zanuka's scavenge targets. The beast opens
     them (never the player): designate with the reticle cone (same
     ~9.5° math as scanTargets), the beast runs to the stand point and
     CHANNELS for companions.pet.scavTime seconds (the SCAVENGE mod
     ramps that 12 s → 2 s across R0-R10), then the locker spills
     ELITE-quality loot (specials.spillLockerLoot: elite CR/PW + the
     elite mod-chip chance + a DOUBLE roll of the standard table).
     Opened lockers respawn after respawn[0..1] s (CH-05.3).            */
  /* ------------------------------------------------------------------ */
  lockers: {
    designateR: 24,         // max reticle-designation distance (player → locker)
    aggroR: 30,             // beast only chases a designation it can reach in a sprint
    channelDist: 1.7,       // stand-off from the door face where channeling starts
    respawn: [75, 120],     // opened → closed again after 75-120 s (harvest-style)
    openSwing: 1.9,         // door swing angle (rad)
    openTime: 0.8,          // seconds for the door swing
    lootBack: 0.9,          // loot spawns this far in front of the door face
  },

  /* ------------------------------------------------------------------ */
  /* DAY / NIGHT CYCLE — 120 min full day: dawn 15 · day 40 · dusk 15 · */
  /*   night 50. Clock runs on game time; lighting + fog tint follow.   */
  /* ------------------------------------------------------------------ */
  daycycle: {
    fullDay: 7200,     // 120 min
    dawn: 900,         // 15 min  (05:00 → 07:00)
    day: 2400,         // 40 min  (07:00 → 16:00)
    dusk: 900,         // 15 min  (16:00 → 18:00)
    night: 3000,       // 50 min  (18:00 → 05:00)
    start: 900,        // deploy at first light
    clockBase: 5,      // dawn begins at 05:00
  },

  /* ------------------------------------------------------------------ */
  /* CLOAK — invisibility skill: 5 s for 25 energy. Enemies lose you,   */
  /*   companions HOLD FIRE while cloaked, firing your gun decloaks.    */
  /* ------------------------------------------------------------------ */
  invis: { energy: 25, duration: 5, cd: 2 },

  /* OVERSHIELD — temporary extra shield layer on top of max shields.   */
  overshield: { energy: 35, amount: 75, duration: 12, cd: 8 },

  /* NIKANA — samurai draw-style melee weapon (XMB → ABILITY to wield). */
  nikana: {
    damage: 95, range: 2.9, arc: 2.2,          // ~126° slash cone
    cooldown: 0.9, lunge: 3.2, dur: 0.34, hitAt: 0.12,
    sellValue: 0,                               // the blade is not for sale
    /* CH-25.1/25.2 — the blade is a slash instrument with real crits.  */
    types: { slash: 0.60, puncture: 0.20, impact: 0.20 },
    critChance: 0.20, critMult: 2.2, statusChance: 0.18,
  },

  /* ------------------------------------------------------------------ */
  /* PLAYER                                                              */
  /*   airJumpBonus = % of normal jump height the FREE mid-air jump gets.*/
  /*   rank 0 of the JETPACK frame mod = 5 %, rank 10 = 200 %.           */
  /* ------------------------------------------------------------------ */
  player: {
    eyeHeight: 1.62,
    radius: 0.35,
    walkSpeed: 4.2,
    accel: 40,
    friction: 10,
    jumpVel: 4.7,
    gravity: 12.5,
    airJumpBonus: 5,       // % of jump height — JETPACK frame mod ramps 5→200
    knockResist: 0,        // % knockdown resist — STEADY FEET frame mod ramps 0→100
    shield: 100,
    shieldDelay: 3.5,
    shieldRegen: 35,
    health: 75,
    healthMax: 75,
    bobAmp: 0.035,
    bobFreq: 8.0,
  },

  /* knockdown — elite effects (fire nova / grenade / missile splash) and
     the kaiju slam fling you to the ground unless STEADY FEET resists. */
  knockdown: { time: 1.35, eye: 0.55, roll: 0.5 },

  energy: { max: 100, regen: 14, delay: 1.2 },

  /* ------------------------------------------------------------------ */
  /* ECONOMY — two currencies, both spent by XMB mod ranks:              */
  /*   CREDITS: kill bounties + salvage chips                            */
  /*   POWER:   rare enemy drops (15-20), elites (50), valley crystals   */
  /*   rank 1 = 10,000 CR + 5,000 PW · rank 10 = 1,200,000 CR + 30,000 PW*/
  /*   scrapping a mod refunds 60 % of everything it ever cost.          */
  /* ------------------------------------------------------------------ */
  credits: {
    start: 12000,          // recruit stipend — enough for one rank-1 expand
    perKill: { grunt: 1200, shielder: 1500, drone: 1000, elite: 5000 },
  },
  power: {
    start: 6000,           // matches the stipend
  },

  /* ------------------------------------------------------------------ */
  /* MODS — every node is one stat you expand rank-by-rank.              */
  /* kinds: 'mul' ×(1+per·r) · 'add' +per·r · 'red' ×(1−per·r)           */
  /*        'table' multiplies <field> on each entry at path             */
  /*        'ramp'  lerps min→max across ranks: v = min+(max−min)·r/10   */
  /* Values are deep-merged back into ASSETS by js/mods.js at runtime.   */
  /* ------------------------------------------------------------------ */
  mods: {
    maxRank: 10,
    costBase: 10000,      // CR to reach rank 1
    costTop: 1200000,     // CR to reach rank 10
    pwBase: 5000,         // POWER to reach rank 1
    pwTop: 30000,         // POWER to reach rank 10
    scrapRefund: 0.6,     // scrapped mods give back 60 % of all CR + PW spent
    /* CH-02.2 — every node carries a `pool` tag for drops.itemPool.
       col (XMB tab) is unchanged. Mapping: rifle = AR-60 + SRS-9 long
       guns · launcher = RL-4 + the ordnance family (frag/nova/vats) ·
       radar → frame (it ramps a player sensor) · beast+sentinel nodes
       → companion.                                                  */
    /* CH-04.1 — companion nodes ALSO carry a `type` tag shown as a chip in
       the XMB: 'sentinel' · 'beast' · 'both' (BLOOD FOR SHIELD procs on
       every companion kill). CH-04.2 moved the sets out of MOD·HEAVY into
       MOD·COMPANION + MOD·COMPANION WEAPON; CH-04.3: MOD·HEAVY keeps
       launcher ordnance only. Node IDS ARE PERMANENT — saved ac-meta-v3
       cards and legacy v2 rank banks adopt by id, so moving a node between
       columns never loses its rank (migration by id, no data rewrite).   */
    nodes: [
      /* — MOD · GUNS —————————————————————————————————————— */
      { id: 'ar-dmg', pool: 'rifle', col: 'guns', label: 'AR-60 DAMAGE',   paths: ['weapons.0.damage'], kind: 'mul', per: 0.08 },
      { id: 'ar-mag', pool: 'rifle', col: 'guns', label: 'AR-60 MAGAZINE', paths: ['weapons.0.mag'],    kind: 'add', per: 6 },
      { id: 'pi-dmg', pool: 'pistol', col: 'guns', label: 'M6-P DAMAGE',    paths: ['weapons.1.damage'], kind: 'mul', per: 0.08 },
      { id: 'pi-mag', pool: 'pistol', col: 'guns', label: 'M6-P MAGAZINE',  paths: ['weapons.1.mag'],    kind: 'add', per: 2 },
      { id: 'sn-dmg', pool: 'rifle', col: 'guns', label: 'SRS-9 DAMAGE',   paths: ['weapons.2.damage'], kind: 'mul', per: 0.08 },
      { id: 'sn-mag', pool: 'rifle', col: 'guns', label: 'SRS-9 MAGAZINE', paths: ['weapons.2.mag'],    kind: 'add', per: 1 },
      { id: 'sg-dmg', pool: 'shotgun', col: 'guns', label: 'CQS-8 DAMAGE',   paths: ['weapons.3.damage'], kind: 'mul', per: 0.08 },
      { id: 'sg-mag', pool: 'shotgun', col: 'guns', label: 'CQS-8 MAGAZINE', paths: ['weapons.3.mag'],    kind: 'add', per: 1 },
      { id: 'rk-dmg', pool: 'launcher', col: 'guns', label: 'RL-4 DAMAGE',    paths: ['weapons.4.damage'], kind: 'mul', per: 0.08 },
      { id: 'rk-spl', pool: 'launcher', col: 'guns', label: 'RL-4 BLAST',     paths: ['weapons.4.splash.damage'], kind: 'mul', per: 0.08 },
      /* — MOD · FRAME ————————————————————————————————————— */
      { id: 'sh-cap', pool: 'frame', col: 'frame', label: 'SHIELD CAPACITY', paths: ['player.shield'],      kind: 'mul', per: 0.08 },
      { id: 'sh-reg', pool: 'frame', col: 'frame', label: 'SHIELD REGEN',    paths: ['player.shieldRegen'], kind: 'mul', per: 0.10 },
      { id: 'vit',    pool: 'frame', col: 'frame', label: 'VITALITY',        paths: ['player.health', 'player.healthMax'], kind: 'mul', per: 0.08 },
      { id: 'en-cap', pool: 'frame', col: 'frame', label: 'ENERGY CAPACITY', paths: ['energy.max'],   kind: 'mul', per: 0.08 },
      { id: 'en-reg', pool: 'frame', col: 'frame', label: 'ENERGY REGEN',    paths: ['energy.regen'], kind: 'mul', per: 0.10 },
      { id: 'jp-air', pool: 'frame', col: 'frame', label: 'JETPACK AIR-JUMP', kind: 'ramp', min: 5, max: 200,
        paths: ['player.airJumpBonus'],
        desc: 'Mid-air jump height as % of a ground jump. R0 = 5 % (a stumble) → R10 = 200 % (skywalker).' },
      { id: 'steady', pool: 'frame', col: 'frame', label: 'STEADY FEET', kind: 'ramp', min: 0, max: 100,
        paths: ['player.knockResist'],
        desc: 'Resist knockdowns from elite fire novas, grenades, homing missiles and the kaiju slam. R1 = 10 % → R10 = 100 % (never fall).' },
      { id: 'servo',  pool: 'frame', col: 'frame', label: 'SERVO SPEED',     paths: ['player.walkSpeed'], kind: 'mul', per: 0.04 },
      { id: 'magnet', pool: 'frame', col: 'frame', label: 'PICKUP MAGNET',   kind: 'ramp', min: 1, max: 15,
        paths: ['drops.magnetR'],
        desc: 'Range at which loot glides to you. R0 = 1 m (walk over it) → R10 = 15 m (nothing escapes).' },
      /* — MOD · HEAVY (launcher ordnance ONLY — CH-04.3) —————— */
      { id: 'fr-yld', pool: 'launcher', col: 'heavy', label: 'FRAG YIELD',    paths: ['frag.damage'],      kind: 'mul', per: 0.08 },
      { id: 'nv-yld', pool: 'launcher', col: 'heavy', label: 'NOVA YIELD',    paths: ['nova.damage'],      kind: 'mul', per: 0.08 },
      { id: 'vt-wrh', pool: 'launcher', col: 'heavy', label: 'VATS WARHEADS', paths: ['vats.missileDmg'],  kind: 'mul', per: 0.08 },
      /* — MOD · COMPANION (CH-04.1/04.2 — survivability + utility) ———— */
      { id: 'dr-hp',  pool: 'companion', col: 'companion', type: 'sentinel', label: 'DRONE HULL',    paths: ['companions.drone.hp'], kind: 'mul', per: 0.12 },
      { id: 'dr-sh',  pool: 'companion', col: 'companion', type: 'sentinel', label: 'DRONE SHIELDS', paths: ['companions.drone.shield'], kind: 'mul', per: 0.12 },
      { id: 'dr-reg', pool: 'companion', col: 'companion', type: 'sentinel', label: 'DRONE REGEN',   paths: ['companions.drone.shieldRegen'], kind: 'mul', per: 0.10 },
      { id: 'dr-rng', pool: 'companion', col: 'companion', type: 'sentinel', label: 'DRONE RANGE',   paths: ['companions.drone.range'], kind: 'mul', per: 0.06 },
      { id: 'radar',  pool: 'frame', col: 'companion', type: 'sentinel', label: 'RADAR UPLINK',  kind: 'ramp', min: 10, max: 90,
        paths: ['companions.drone.radar'],
        desc: 'Drone uplink extends your motion tracker. R0 = 10 m → R10 = 90 m.' },
      { id: 'pt-hp',  pool: 'companion', col: 'companion', type: 'beast', label: 'BEAST HULL',    paths: ['companions.pet.hp'], kind: 'mul', per: 0.12 },
      { id: 'pt-sh',  pool: 'companion', col: 'companion', type: 'beast', label: 'BEAST SHIELDS', paths: ['companions.pet.shield'], kind: 'mul', per: 0.12 },
      { id: 'pt-blood', pool: 'companion', col: 'companion', type: 'both', label: 'BLOOD FOR SHIELD', kind: 'ramp', min: 0, max: 25,
        paths: ['companions.bloodShield'],
        desc: 'Every enemy killed by your DRONE or ZANUKA refills your shields: R1 = +2.5 → R10 = +25 per companion kill.' },
      /* CH-05.3 — SCAVENGE: beast locker-channel time, decreasing ramp.
         R0 = 12 s (the no-card baseline — the feature works without the
         card) → R10 = 2 s. Linear: −1 s per rank. Read live through
         companions.pet.scavTime by companions.js while channeling.      */
      { id: 'pt-scav', pool: 'companion', col: 'companion', type: 'beast', label: 'SCAVENGE', kind: 'ramp', min: 12, max: 2,
        paths: ['companions.pet.scavTime'],
        desc: 'CH-05.3 — the beast needs this long to open a SUPPLY LOCKER: point your reticle at one and the ZANUKA channels it open for ELITE loot. 12 s at R0 → 2 s at R10 (decreasing ramp, −1 s per rank).' },
      /* — MOD · COMPANION WEAPON (CH-04.2 — sentinel weapon table +
         beast bite/claws; the FREEZE RAY entry lives at index 4 of
         companions.drone.weapons — same numeric-path convention as the
         gun mods above)                                                  */
      { id: 'dr-out', pool: 'companion', col: 'compwep', type: 'sentinel', label: 'DRONE OUTPUT',  paths: ['companions.drone.weapons'], field: 'dmg', kind: 'table', per: 0.10 },
      { id: 'sr-cyc', pool: 'companion', col: 'compwep', type: 'sentinel', label: 'SENTINEL TRIGGER',
        paths: ['companions.drone.weapons'], field: 'interval', kind: 'table', per: -0.05,
        desc: 'Drone weapon cycle ×0.95 per rank — every drone weapon fires sooner. R10 = half the wait (×0.5).' },
      { id: 'fr-sap', pool: 'companion', col: 'compwep', type: 'sentinel', label: 'FREEZE RAY SAP',
        paths: ['companions.drone.weapons.4.sapShieldPct'], kind: 'mul', per: 0.06,
        desc: 'FREEZE RAY shield sap +6 % per rank — drains 7 % → 11.2 % of target max shields per tick at R10.' },
      { id: 'pt-dmg', pool: 'companion', col: 'compwep', type: 'beast', label: 'BEAST CLAWS',   paths: ['companions.pet.damage'], kind: 'mul', per: 0.12 },
      { id: 'pt-jaw', pool: 'companion', col: 'compwep', type: 'beast', label: 'BEAST JAWS', kind: 'ramp', min: 0.8, max: 2.4,
        paths: ['companions.pet.biteStagger'],
        desc: 'Bite stagger hold R0 = 0.8 s → R10 = 2.4 s — the beast pins a target for your aim.' },
    ],
  },

  /* slide — press A while ducked (LB+A): burst slide w/ camera roll      */
  slide: { speed: 7.5, duration: 0.6, cooldown: 1.2, eye: 0.9, fovKick: 5, minSpeed: 2.5 },

  /* duck on the ground (L1 / C / Ctrl — toggle; in the air L1 = VATS)    */
  crouch: { eye: 1.02, speedMult: 0.55 },

  /* melee (B / V) — rifle bash                                           */
  melee: {
    /* CH-25.1/25.2 — rifle bash: impact-weighted emergency swing.      */
    damage: 45, range: 1.9, cooldown: 0.8,
    types: { impact: 0.60, puncture: 0.15, slash: 0.25 },
    critChance: 0.10, critMult: 1.8, statusChance: 0.08,
  },

  /* hover — HOLD A in the air (drains energy); release = forward lunge.  */
  /* The air JUMP itself is free — its height is the JETPACK frame mod.   */
  jetpack: {
    hoverDrain: 12, hoverVy: 0.9,
    lungeImpulse: 7.5, lungeUp: 1.4, minSpeed: 2.0,
  },

  /* glide special — stay airborne without holding A (toggle via R2)      */
  glide: { drain: 9, vy: -0.9 },

  /* dash special — fast lunge forward                                    */
  dash: { impulse: 13, up: 0.6, duration: 0.22 },

  /* VATS-style mid-air targeting (L1/C/Ctrl while AIRBORNE)              */
  vats: {
    enterEnergy: 12, drain: 12, timeScale: 0.3,
    missileEnergy: 15, missileDmg: 90, executeFrac: 0.35,
    cone: 0.72, range: 45, maxLocks: 6,
  },

  /* blast nova — F radial burst (Mass Effect-lite)                       */
  nova: { energy: 40, cd: 3, radius: 7, damage: 70, knock: 5,
    /* CH-25.1/25.2 — typed blast profile (nv-yld keeps mulling the
       moddable scalar `nova.damage`; fractions ride along).             */
    types: { impact: 0.50, heat: 0.25, electric: 0.25 },
    critChance: 0.08, critMult: 2.0, statusChance: 0.10 },

  /* flashlight — L / D-padUp (Deadspace darkness)                        */
  flashlight: { color: '#eaf6ff', intensity: 2.6, distance: 26, angle: 0.46 },

  /* ------------------------------------------------------------------ */
  /* WEAPONS — 5-gun arsenal. Y/Q cycles, XMB equips, 1-5 hotkeys.       */
  /*   v0.7: you DEPLOY WITH THE M6-P ONLY — the other four unlock the   */
  /*   first time you scavenge their ammo type.                          */
  /*   ADS = M6P-style zoom (FOV cut, NO scope overlay) on every gun     */
  /*   except the SRS-9, which keeps its 4× scope. ADS cuts recoil.      */
  /* ------------------------------------------------------------------ */
  startWeapon: 'pistol',   // the only gun unlocked at deploy
  weapons: [
    {
      id: 'ar', pool: 'rifle', name: 'AR-60', type: 'auto', ammo: 'rifle',
      mag: 60, rpm: 650, damage: 12, range: 120,
      spreadBase: 0.004, spreadPerShot: 0.0022, spreadMax: 0.026,
      ads: { fov: 42, spreadMult: 0.45, recoilMult: 0.55, sensMult: 0.75,
             moveMult: 0.85, vmPos: [0, -0.212, -0.34] },
      recoil: { pitch: 0.0042, yaw: 0.0016, kick: 0.035 },
      reloadTime: 2.2,
      vmPos: [0.28, -0.26, -0.5],
      /* CH-25.1/25.2 — typed hit: `types` are FRACTIONS of the moddable
         scalar `damage` (weights sum to 1 — power mods that mul `damage`
         keep scaling the whole typed hit). crit/status are first-class
         stats (CH-25.2). AR-60: puncture-weighted service rifle.        */
      types: { puncture: 0.45, impact: 0.15, slash: 0.40 },
      critChance: 0.12, critMult: 2.0, statusChance: 0.06,
    },
    {
      id: 'pistol', pool: 'pistol', name: 'M6-P', type: 'semi', ammo: 'pistol',
      mag: 12, rpm: 220, damage: 30, range: 140,
      spreadBase: 0.0015, spreadPerShot: 0.003, spreadMax: 0.012,
      ads: { fov: 40, spreadMult: 0.3, recoilMult: 0.5, sensMult: 0.55,
             moveMult: 0.9 },
      recoil: { pitch: 0.006, yaw: 0.001, kick: 0.05 },
      reloadTime: 1.6,
      vmPos: [0.26, -0.28, -0.46],
      /* CH-25.1/25.2 — M6-P: impact-weighted sidearm, modest crits.     */
      types: { puncture: 0.30, impact: 0.40, slash: 0.30 },
      critChance: 0.16, critMult: 2.0, statusChance: 0.10,
    },
    {
      id: 'sniper', pool: 'rifle', name: 'SRS-9', type: 'semi', ammo: 'sniper',
      mag: 4, rpm: 45, damage: 130, range: 200,
      spreadBase: 0.001, spreadPerShot: 0.02, spreadMax: 0.05,
      ads: { fov: 20, spreadMult: 0.02, recoilMult: 0.45, sensMult: 0.35,
             moveMult: 0.6, scope: 'srs' },
      recoil: { pitch: 0.05, yaw: 0.004, kick: 0.16 },
      reloadTime: 2.8,
      vmPos: [0.24, -0.24, -0.55],
      /* CH-25.1/25.2 — SRS-9: the puncture/crit king — armor punching is
         its identity (puncture 1.25× vs armor).                         */
      types: { puncture: 0.50, impact: 0.20, slash: 0.30 },
      critChance: 0.30, critMult: 2.5, statusChance: 0.12,
    },
    {
      id: 'shotgun', pool: 'shotgun', name: 'CQS-8', type: 'pump', ammo: 'shell',
      mag: 6, rpm: 78, damage: 11, pellets: 8, range: 26,
      spreadBase: 0.05, spreadPerShot: 0.004, spreadMax: 0.085,
      ads: { fov: 46, spreadMult: 0.62, recoilMult: 0.7, sensMult: 0.85,
             moveMult: 0.8, vmPos: [0, -0.2, -0.32] },
      recoil: { pitch: 0.028, yaw: 0.006, kick: 0.12 },
      reloadTime: 2.6,
      vmPos: [0.27, -0.27, -0.48],
      /* CH-25.1/25.2 — CQS-8: slash-weighted pellets; statusChance is PER
         PELLET (8 rolls/pump) — the intended status-application machine. */
      types: { puncture: 0.15, impact: 0.35, slash: 0.50 },
      critChance: 0.08, critMult: 1.8, statusChance: 0.20,
    },
    {
      id: 'rocket', pool: 'launcher', name: 'RL-4', type: 'semi', ammo: 'heavy',
      mag: 1, rpm: 32, damage: 150, range: 150, projectile: 'rocket',
      splash: { radius: 5.5, damage: 150, selfMult: 0.45 },
      /* CH-25.1/25.2 — RL-4: blast profile = impact + heat payload; the
         ~2000 box-break mark (CH-06 universal threshold) reads this
         damage scalar, so power mods keep overkilling boxes.            */
      types: { puncture: 0.20, impact: 0.50, slash: 0.00, heat: 0.30 },
      critChance: 0.05, critMult: 2.0, statusChance: 0.10,
      spreadBase: 0.002, spreadPerShot: 0, spreadMax: 0.002,
      ads: { fov: 50, spreadMult: 1, recoilMult: 0.8, sensMult: 0.8,
             moveMult: 0.7, vmPos: [0, -0.22, -0.36] },
      recoil: { pitch: 0.045, yaw: 0.008, kick: 0.2 },
      reloadTime: 3.0,
      vmPos: [0.25, -0.3, -0.52],
    },
  ],

  ammoPools: {
    rifle:  { start: 0,   cap: 480, label: '7.62 RIFLE' },
    pistol: { start: 60,  cap: 120, label: '12.7 PISTOL' },
    shell:  { start: 0,   cap: 60,  label: '8-GA SHELL' },
    sniper: { start: 0,   cap: 24,  label: '14.5 AP' },
    heavy:  { start: 0,   cap: 6,   label: 'ROCKET' },
  },

  /* ------------------------------------------------------------------ */
  /* AMMO CONVERSION — the value of ONE rocket shell, expressed in       */
  /*   everything else (breaking a supply box spills this value):        */
  /*   1 ROCKET SHELL = 50 energy (2 plasma casts) = 2 sniper rounds     */
  /*                  = 25 rifle rounds = 10 pistol rounds               */
  /*   Power-mod damage (RL-4 DAMAGE/BLAST) overkills the box → the      */
  /*   spill multiplies by the overkill ratio (capped ×3).               */
  /* ------------------------------------------------------------------ */
  conversion: {
    energy: 50,            // = 2 plasma bolts (25 e each)
    plasmaCasts: 2,
    rifle: 25,
    pistol: 10,
    sniper: 2,
    rocketChance: 0.15,    // small chance the box also coughs up a shell
    maxMult: 3,
  },

  /* ------------------------------------------------------------------ */
  /* CH-25 — COMBAT CORE — the typed damage model everything fights      */
  /*   through. One shared entry point lives in weapon.js (applyDamage). */
  /* ------------------------------------------------------------------ */
  combat: {
    /* CH-25.1 — damage types. Physical split (PUNCTURE/IMPACT/SLASH) on
       every weapon; elementals are optional payloads. VOID is reserved
       for CH-26 (exotic status source — not a tunable here yet).        */
    types: ['puncture', 'impact', 'slash', 'heat', 'cold', 'electric', 'toxin'],
    /* type-vs-pool multipliers — stated curves (v0.8.2 CH-25):
         · shields: puncture 0.75 / slash 0.75 / heat 0.75 (shields resist
           heat) · electric 1.25 + cold 1.15 (shields conduct) · impact 1.0
         · health: heat 1.25 (health weak to heat) · toxin 0.75 (toxin is
           weaker vs health) · everything else 1.0
         · armor: puncture 1.25 (drills it), impact/heat 0.75 (blunts),
           SLASH 0 = IGNORES armor completely, rest 1.0
         · toxin shieldBypass: the toxin portion of any hit slips past the
           JACKAL gauntlet / shield pool entirely and lands on health.     */
    typeMultipliers: {
      puncture: { shield: 0.75, health: 1.00, armor: 1.25 },
      impact:   { shield: 1.00, health: 1.00, armor: 0.75 },
      slash:    { shield: 0.75, health: 1.00, armor: 0    },   // 0 = ignores armor
      heat:     { shield: 0.75, health: 1.25, armor: 0.75 },
      cold:     { shield: 1.15, health: 1.00, armor: 1.00 },
      electric: { shield: 1.25, health: 1.00, armor: 1.00 },
      toxin:    { shield: 1.00, health: 0.75, armor: 1.00, shieldBypass: true },
    },
    /* CH-25.2 — crit/status defaults for any def that omits them */
    crit: { defaultChance: 0.10, defaultMult: 2.0 },
    /* CH-25.3 — ARMOR → EHP CURVE (user-confirmed, unified BOTH sides —
       the player-side armor stat wires into the SAME numbers in CH-38.1):
         effective health = base health × (1 + armor / 300)
         300 armor = +100% base health (200% EHP) · 600 = +200% (300% EHP)
         900 = +300% (400% EHP). Equivalently a hit into armor loses
         1 / (1 + armor/300) of its damage, so armor NEVER multiplies past
         infinity. ehpMult()/mitigation() are the SHARED pure curve —
         enemy.js consumes them today, player.js (CH-38.1) tomorrow.      */
    armor: { base: 300 },
    ehpMult: (armor, base) => 1 + armor / (base || 300),
    /* factor = typeMultipliers[type].armor (0 → ignores armor completely) */
    mitigation: (armor, factor, base) =>
      (armor <= 0 || !factor) ? 1 : 1 / (1 + (armor / factor) / (base || 300)),
  },

  /* frag grenade — R2 special (uses its own counter)                     */
  frag: {
    start: 4, cap: 6, throwVel: 8.5, upVel: 3.2, fuse: 1.4,
    radius: 4.5, damage: 90, selfDamage: 40, cooldown: 0.6,
    /* CH-25.1/25.2 — frag profile + crit/status (rolled once per blast) */
    types: { impact: 0.50, heat: 0.30, slash: 0.20 },
    critChance: 0.05, critMult: 2.0, statusChance: 0.12,
  },

  /* ------------------------------------------------------------------ */
  /* SPECIAL SLOTS — R2 fires the ACTIVE slot. HOLD D-pad ◀ / ▶ (or      */
  /*   [ / ]) to cycle the four slots. Assign items in XMB → EQUIPMENT.  */
  /* ------------------------------------------------------------------ */
  specials: {
    slotCount: 4,
    defaultSlots: ['grenade', 'missiles', 'dash', 'pbolt'],
    cycleHold: 0.35,      // seconds of hold before the wheel starts spinning
    cycleStep: 0.26,      // seconds between steps while held
    list: [
      { id: 'grenade',  name: 'FRAG GRENADE',   glyph: '✦', energy: 0,
        cd: 0.6, desc: 'Arc throw · 1.4s fuse · big boom. Uses frag count.',
        /* CH-25.1/25.2 — the throw reads ASSETS.frag (typed there).      */ },
      { id: 'missiles', name: 'HOMING MISSILES', glyph: '⌖', energy: 30,
        cd: 4, desc: 'Twin shoulder missiles hunt the two nearest hostiles.',
        /* CH-25.1/25.2 — 90 per missile, rolled per missile.
           CH-25.5 — the scalar lives ON the def now (was a hard-coded 90
           in specials.js, which typedHit could not see → the typed
           missiles landed all-zero. Same class as the drone fix.        */
        damage: 90,
        types: { impact: 0.40, heat: 0.35, puncture: 0.25 },
        critChance: 0.10, critMult: 2.0, statusChance: 0.10 },
      { id: 'dash',     name: 'BLINK DASH',      glyph: '≫', energy: 20,
        cd: 1.6, desc: 'Violent lunge in your move direction. i-frame-ish speed.' },
      { id: 'glide',    name: 'GLIDE MODULE',   glyph: '≈', energy: 0,
        cd: 0.3, toggle: true, drain: 9,
        desc: 'Toggle: float mid-air without holding A. Drains energy while airborne.' },
      { id: 'pbolt',    name: 'PLASMA BOLT',    glyph: '●', energy: 25,
        cd: 2.5, desc: 'Launch a volatile orb — detonates on impact.',
        /* CH-25.1/25.2 — 60 detonation, heat-weighted plasma.
           CH-25.5 — scalar ON the def (was hard-coded 60 in specials.js
           → typed detonation landed all-zero).                           */
        damage: 60,
        types: { heat: 0.60, impact: 0.40 },
        critChance: 0.12, critMult: 2.0, statusChance: 0.15 },
      { id: 'shock',    name: 'SHOCKWAVE',      glyph: '◌', energy: 35,
        cd: 5, desc: 'Ground pulse: staggers + shoves everything nearby.',
        /* CH-25.1/25.2 — 20 pulse, electric-flavored.                     */
        types: { impact: 0.55, electric: 0.45 },
        critChance: 0.05, critMult: 1.5, statusChance: 0.10 },
      { id: 'firenova', name: 'FIRE NOVA',      glyph: '◉', energy: 45,
        cd: 8, desc: 'Ignite the ground for 4s. Burns AND staggers.',
        /* CH-25.1 — the 4/s burn tick is PURE HEAT (typed in specials.js). */
        types: { heat: 1.0 }, statusChance: 0.05 },
      { id: 'invis',    name: 'CLOAK',          glyph: '◌', energy: 25,
        cd: 2, desc: 'Vanish for 5 s — enemies lose you and companions hold fire. Firing decloaks you.' },
      { id: 'overshield', name: 'OVERSHIELD',   glyph: '⬤', energy: 35,
        cd: 8, desc: 'Boost +75 extra shields on top of max for 12 s. Burns energy to cast.' },
    ],
  },

  /* ------------------------------------------------------------------ */
  /* COMPANIONS — always available, NO energy upkeep, toggle in          */
  /*   XMB → COMPANIONS. Both eat your ammo-less attacks and both have   */
  /*   mods (XMB → MOD·COMPANION + MOD·COMPANION WEAPON — CH-04).        */
  /* ------------------------------------------------------------------ */
  companions: {
    respawn: 30,                    // seconds to rebuild after destruction
    bloodShield: 0,                 // shield per companion kill — BLOOD FOR SHIELD mod
    drone: {
      hp: 120, shield: 80, shieldDelay: 4, shieldRegen: 22,
      range: 24,                    // engagement range
      followDist: 8,                // hover distance from you (user spec ~8 m)
      hoverY: 1.8, bobAmp: 0.16,
      radar: 10,                    // base motion-tracker range (RADAR UPLINK mod → 90)
      weapons: [                    // pick in XMB → COMPANIONS — eats YOUR ammo
        /* CH-25.1/25.2 — every drone weapon is typed + crit/status rated
           the same way as your guns (fractions of the moddable dmg).
           CH-25.5 — the scalar key stays `dmg` (the dr-out table mod,
           the XMB rows and the pod all read it); typedHit() now accepts
           it as a fallback scalar so drone hits are no longer all-zero.  */
        { id: 'laser',  name: 'LASER LANCE', ammo: 'rifle',  cost: 1, interval: 0.5,  dmg: 12, style: 'beam',
          types: { puncture: 0.55, impact: 0.15, slash: 0.30 },
          critChance: 0.10, critMult: 2.0, statusChance: 0.06 },
        { id: 'homing', name: 'HOMING POD',  ammo: 'heavy',  cost: 1, interval: 4.0,  dmg: 90, style: 'missile',
          types: { impact: 0.40, heat: 0.40, puncture: 0.20 },
          critChance: 0.08, critMult: 2.0, statusChance: 0.12 },
        { id: 'single', name: 'MARKSMAN',    ammo: 'pistol', cost: 1, interval: 1.6,  dmg: 45, style: 'bolt',
          types: { puncture: 0.60, impact: 0.40 },
          critChance: 0.18, critMult: 2.2, statusChance: 0.08 },
        { id: 'auto',   name: 'MINIGUN',     ammo: 'rifle',  cost: 5, interval: 2.2,  dmg: 9,  style: 'burst',
          types: { impact: 0.55, puncture: 0.45 },
          critChance: 0.06, critMult: 1.8, statusChance: 0.10 },
        /* CH-04.4 — FREEZE RAY: continuous near-silent siphon beam.
           Feeds on YOUR rifle pool at drainPerSec (fractional accumulator,
           integer rounds leave the pool). Every `tick` seconds while the
           beam holds: shields −sapShieldPct of the target's MAX shields
           first (bypasses the JACKAL frontal gauntlet — the siphon wraps
           it), then tick dmg into hp while DEF-DOWN stacks build.         */
        { id: 'freeze', name: 'FREEZE RAY', ammo: 'rifle', cost: 0, interval: 0,
          dmg: 6, style: 'freeze', range: 28, drainPerSec: 3,
          tick: 0.25, sapShieldPct: 0.07,
          /* CH-25.1 — the hp chew is now TYPED COLD through the shared
             pipeline (it was documented in CH-04.4 but never actually
             wired — the CH-25.4 retrofit closes that gap).                 */
          types: { cold: 1.0 }, critChance: 0, statusChance: 0 },
      ],
      /* CH-04.4 — DEF-DOWN debuff constants (read by enemy.js hooks).
         Stated decision for the user ASSUMPTION (exact curve): stacks build
         stackPerSec while beamed, capped at maxStacks; each stack = +
         vulnPerStack (×100 = %) MORE damage taken by the target from ALL
         sources — so 5 stacks = +30 % — and the stack ladder DECAYS one
         stack per decayTime once contact ends (holdTime = grace window
         before decay starts). Beam vs bare-hp targets: tick dmg only.     */
      defDown: { stackPerSec: 1, maxStacks: 5, vulnPerStack: 0.06, decayTime: 2.5, holdTime: 0.6 },
    },
    pet: {                           // Zanuka-style beast — melee only (for now)
      hp: 160, shield: 60, shieldDelay: 4, shieldRegen: 18,
      damage: 38, attackCd: 0.9, aggro: 18, reach: 2.1,
      speed: 6.5, followDist: 6,    // cursor-led: trots ~6 ft (1.9 m) ahead of your aim
      heelDist: 1.9, biteStagger: 0.8,
      /* CH-25.1/25.2 — bite/claw profile: slash-heavy with respectable
         status (wounds feed the CH-26 bleed procs later).                */
      types: { slash: 0.60, puncture: 0.40 },
      critChance: 0.12, critMult: 2.0, statusChance: 0.15,
      /* CH-05.3 — SCAVENGE: seconds the beast needs to open a SUPPLY
         LOCKER. The pt-scav mod ramps it (kind 'ramp', min 12 → max 2
         across R0-R10); this 12 is the no-card / R0 baseline so the
         path exists even before Mods.apply() first writes it back.    */
      scavTime: 12,
    },
  },

  /* ------------------------------------------------------------------ */
  /* ENEMIES — archetypes + spawns. Dead hostiles respawn on a          */
  /*   5-MINUTE timer (respawnTime) once you step away from the point.   */
  /*   ZONE LEVELS: hallway = L2 · hangar = L5 · valley = L7 · city = L8,*/
  /*   then the EXPANSE tiles run L10 → L40 (ocean), kaiju = L80.        */
  /*   v0.8: FEWER base hostiles — a REINFORCEMENT wave pushes into a    */
  /*   neighboring tile every 15 s instead (reinforce{} below).          */
  /*   ELITES are RARE: only the catwalk elite is guaranteed; the other  */
  /*   elite spawns are chance-gated and waves rarely field one.         */
  /*   ELITE ABILITIES: each elite rolls 1-3 of fire nova / frag         */
  /*   grenades / homing missiles / blink dash / glide module — their    */
  /*   effects KNOCK YOU DOWN unless STEADY FEET resists. Some bring     */
  /*   their own pet hound.                                              */
  /* ------------------------------------------------------------------ */
  enemy: {
    boltSpeed: 15,
    boltLife: 3.0,
    respawnTime: 300,
    respawnClearDist: 14,   // won't pop back in your face
    /* 15-second neighbor-tile reinforcement waves */
    reinforce: {
      every: 15,            // seconds
      count: [1, 2],        // hostiles per wave
      cap: 26,              // max ALIVE hostiles (base spawns + waves)
      dist: [22, 38],       // spawn ring around the player
      eliteChance: 0.05,    // a wave rarely fields an elite
    },
    leveling: {
      perLevel: 0.22,       // hp / shield multiplier per level above 1
      zones: { corridor: 2, hangar: 5, valley: 7, city: 8 },
    },
    /* ELITE ability loadouts (each elite rolls 1-3 on spawn) */
    eliteAbilities: {
      pool: ['firenova', 'grenade', 'missiles', 'blink', 'glide'],
      roll: [1, 3],
      firenova: { cd: 11, radius: 5.5, dmg: 26, maxDist: 14, burn: 4 },
      grenade:  { cd: 9,  dmg: 55, radius: 4, minDist: 6, maxDist: 26 },
      missiles: { cd: 13, dmg: 42, minDist: 9, maxDist: 42 },
      blink:    { cd: 7,  dist: 7,  minDist: 4, maxDist: 20 },
      glide:    { cd: 16, time: 7, height: 2.6 },
      petChance: 0.4,       // some elites bring their own hound
    },
    archetypes: {
      grunt: {
        name: 'GRUNT', hp: 60, scale: 1,
        speed: 1.3, strafeSpeed: 1.8, aggro: 18,
        fireInterval: 1.7, burst: 3, burstGap: 0.18, keepDistance: 6,
        boltDamage: 22,
        armor: 40,   // CH-25.3 — light plating (EHP ×1.13 vs neutral types)
        colors: { armor: '#d97a2a', suit: '#55606a', mask: '#2c3138',
                  visor: '#7dff4f', gun: '#3a4046' },
        dropMult: 1,
      },
      shielder: {
        name: 'JACKAL', hp: 55, shieldHp: 90, scale: 1,
        speed: 1.6, strafeSpeed: 2.4, aggro: 20,
        fireInterval: 2.2, burst: 2, burstGap: 0.22, keepDistance: 5,
        boltDamage: 18,
        armor: 60,   // CH-25.3 — moderately plated regular
        colors: { armor: '#7a8a96', suit: '#42525e', mask: '#232a30',
                  visor: '#7db8ff', gun: '#3a4046', shield: '#4fa8ff' },
        dropMult: 1.1,
      },
      drone: {
        name: 'SENTINEL', hp: 35, scale: 0.8, fly: true, flyY: 2.2,
        speed: 2.2, strafeSpeed: 3.2, aggro: 24,
        fireInterval: 1.1, burst: 2, burstGap: 0.3, keepDistance: 8,
        boltDamage: 10,
        armor: 10,   // CH-25.3 — bare airframe; nearly negligible
        colors: { armor: '#8a939e', suit: '#565e66', mask: '#2a2f35',
                  visor: '#ff5340', gun: '#3a4046' },
        dropMult: 0.8,
      },
      elite: {
        name: 'ELITE', hp: 170, scale: 1.15, elite: true,
        speed: 2.0, strafeSpeed: 2.6, aggro: 24,
        fireInterval: 1.2, burst: 5, burstGap: 0.12, keepDistance: 7,
        boltDamage: 16,
        armor: 220,  // CH-25.3 — heavy plating (EHP ×1.73 vs neutral · slash ignores)
        colors: { armor: '#e8b53a', suit: '#6a5a2a', mask: '#2c3138',
                  visor: '#ff4f4f', gun: '#3a4046' },
        dropMult: 1.5,
      },
      /* elite's pet — fast hound that fights at its master's side */
      hound: {
        name: 'HAVOC HOUND', hp: 45, scale: 0.72,
        speed: 3.1, strafeSpeed: 3.4, aggro: 26,
        fireInterval: 1.5, burst: 2, burstGap: 0.2, keepDistance: 4,
        boltDamage: 8,
        armor: 80,   // CH-25.3 — banded hide
        colors: { armor: '#7a3528', suit: '#3a2620', mask: '#1c1512',
                  visor: '#ff8a4f', gun: '#2c2622' },
        dropMult: 0.5,
      },
      /* ocean kaiju — L80 deep-water horror (expanse.kaiju config) */
      kaiju: {
        name: 'KAIJU', hp: 480, scale: 3.6, elite: true, kaiju: true,
        speed: 1.7, strafeSpeed: 1.9, aggro: 70,
        fireInterval: 2.6, burst: 3, burstGap: 0.3, keepDistance: 7,
        boltDamage: 45,
        armor: 300,  // CH-25.3 — abyssal carapace (EHP ×2 vs neutral · slash ignores)
        colors: { armor: '#2e5a4a', suit: '#17332c', mask: '#0d1d18',
                  visor: '#8cff5e', gun: '#1e3a33' },
        dropMult: 0,           // kaiju rewards come from its own table
      },
    },
    spawns: [
      /* corridor — v0.8: thinned out (reinforcements refill over time) */
      { t: 'grunt',    x: -0.8, z: -24, patrol: 3 },
      { t: 'shielder', x: -1.0, z: -46, patrol: 3 },
      { t: 'grunt',    x:  0.6, z: -50, patrol: 2 },
      /* hangar floor */
      { t: 'grunt',    x: -8,  z: -84,  patrol: 4, arena: 10 },
      { t: 'shielder', x:  9,  z: -90,  patrol: 4, arena: 11 },
      { t: 'drone',    x: -9,  z: -100, patrol: 6, arena: 11, flyY: 2.7 },
      /* catwalk elite — guaranteed energy core + 50 power on death */
      { t: 'elite',    x: -15, z: -92,  patrol: 5, arena: 2, catwalk: true },
      /* CH-07.2 — expanded-bay spawns (hangar zone level L5 applies) */
      { t: 'grunt',    x: 15.5, z: -95,  patrol: 4, arena: 8 },
      { t: 'shielder', x: -1.5, z: -117.5, patrol: 3, arena: 5 },
      { t: 'drone',    x:  8,   z: -114, patrol: 5, arena: 9, flyY: 3.1 },
      /* valley (L7 approach canyon) — elite here is now RARE (35 %) */
      { t: 'grunt',    x: -5,  z: -126, patrol: 4, arena: 8, valley: true },
      { t: 'drone',    x:  0,  z: -142, patrol: 5, arena: 7, valley: true, flyY: 3.2 },
      { t: 'elite',    x:  3,  z: -150, patrol: 3, arena: 6, valley: true, chance: 0.35 },
      /* cityscape (L8 night streets) — elite here is now RARE (35 %) */
      { t: 'shielder', x:  7,  z: -170, patrol: 5, arena: 8, city: true },
      { t: 'drone',    x:  0,  z: -180.5, patrol: 6, arena: 10, city: true, flyY: 3.4 },
      { t: 'grunt',    x:  8,  z: -188, patrol: 4, arena: 8, city: true },
      /* CH-08.2 — connector garrisons: one hostile inside each corridor
         connector. Level resolves to city L8 automatically (levelForZ:
         z <= city.z0 → L8) — corridors are city ground, no new zone.
         Small arenas keep them patrolling the 12 m passage.              */
      { t: 'grunt',    x:  0,  z: -174.5, patrol: 2, arena: 3, city: true },
      { t: 'shielder', x:  0,  z: -196.5, patrol: 2, arena: 3, city: true },
      { t: 'elite',    x:  0,  z: -206, patrol: 4, arena: 6, city: true, chance: 0.35 },
      /* NOTE: expanse tile spawns are generated by world.js (fewer,
         level-scaled per tile set) — see buildExpanse() */
    ],
  },

  /* ------------------------------------------------------------------ */
  /* DROP CHART — v0.8 chance rolls + weighted table + LEVEL SCALING.    */
  /*   CREDITS: 60 % of kills spill 80–100 CR. POWER: 12 % spill cells.  */
  /*   The weighted table (minus the old credit/power rows) still rolls  */
  /*   for ammo / health / energy / grenades. Elites add their bonuses.  */
  /*   DROP-RATE CURVE (user spec): by L40 a good clear rate earns        */
  /*   1000 POWER/hr + 60,000 CREDITS/hr — the curve doubles that at      */
  /*   L60 and doubles again at L80 (hard cap). See dropRateMult().       */
  /*   BASIC MOD chips (free mod ranks) also drop from enemies, crates   */
  /*   and elites — chance tuned UP from v0.7 per request.                */
  /*   CH-02: mod-chip + weapon-copy picks roll the weighted itemPool     */
  /*   below (pistol+shotgun flood it; ammo/credit/health table unchanged).*/
  /* ------------------------------------------------------------------ */
  drops: {
    pickupLife: 25,
    magnetR: 1,             /* base pickup-magnet range — PICKUP MAGNET mod ramps 1→15 */
    collectR: 1.25,
    creditChance: 0.60,     // 60 % of kills
    creditN: [80, 100],
    powerChance: 0.12,      // 12 % of kills
    powerN: [15, 20],
    modChance: 0.05,        // ★ basic-mod chip from any kill (boosted)
    crateModChance: 0.18,   // ★ basic-mod chip from a broken supply box
    eliteModChance: 0.30,   // ★ elites chip in much more often
    nothingW: 12,
    table: [
      { t: 'ammo',    id: 'rifle',  w: 26, n: 60,  label: '+60 RIFLE AMMO' },
      { t: 'ammo',    id: 'pistol', w: 11, n: 12,  label: '+12 PISTOL AMMO' },
      { t: 'ammo',    id: 'shell',  w: 8,  n: 6,   label: '+6 SHELLS' },
      { t: 'ammo',    id: 'sniper', w: 5,  n: 2,   label: '+2 SNIPER ROUNDS' },
      { t: 'ammo',    id: 'heavy',  w: 3,  n: 1,   label: '+1 ROCKET' },
      { t: 'health',  id: 'medkit', w: 13, n: 30,  label: '+30 HEALTH' },
      { t: 'energy',  id: 'cell',   w: 15, n: 45,  label: '+45 ENERGY' },
      { t: 'grenade', id: 'frag',   w: 9,  n: 1,   label: '+1 FRAG GRENADE' },
    ],
    eliteBonus: { t: 'energy', id: 'core', n: 100, label: 'ELITE POWER CORE +100' },
    elitePower: { n: 50, label: 'ELITE CHARGE +50 POWER' },
    eliteCr:    { n: 2500, label: 'ELITE SALVAGE +2,500 CR' },
    crystal:    { t: 'power', id: 'crystal', n: [30, 60], label: 'CRYSTAL SHARD +', pw: true },
    /* drop-rate scaling curve — anchors: L1 0.25× · L40 1× · L60 2× · L80 4× (cap) */
    rateCurve: [
      { lvl: 1,  mult: 0.25 },
      { lvl: 40, mult: 1.0 },    // 1000 PW/hr + 60,000 CR/hr at a solid L40 clear
      { lvl: 60, mult: 2.0 },    // doubles at L60
      { lvl: 80, mult: 4.0 },    // doubles again at L80 — HARD CAP
    ],
    /* CH-03.1 — prebuilt mod chips add CARDS now (never free ranks):
       maxedRefund = legacy v0.8 auto-sale (superseded, kept for safety) ·
       duplicateSale = what ONE duplicate card sells for (CH-03.3) */
    modChip: { maxedRefund: 40000, duplicateSale: 40000, label: 'PREBUILT MOD' },
    /* CH-02.1 — the pool for mod-chip + weapon-copy rolls. pistol+shotgun
       flood it (80 combined — 40 each); rifle / frame / beast+sentinel
       (companion) / launcher are rare at 5 each. pickWeightedKey()
       NORMALISES, so these need not sum to 100. Verified in-console via
       AC.game.drops.sim(10000).                                          */
    itemPool: {
      pistol: 40, shotgun: 40,   // pistol+shotgun = 80 combined
      rifle: 5, frame: 5, companion: 5, launcher: 5,
    },
  },

  /* ------------------------------------------------------------------ */
  /* ECOLOGY — the wilds are alive: plants give materials, rocks hold    */
  /*   ore, rivers/lakes/ocean hold fish (fish with the rod — X), birds  */
  /*   circle overhead, small rodents scurry in the brush. Materials     */
  /*   sell in XMB → SALVAGE.                                            */
  /* ------------------------------------------------------------------ */
  ecology: {
    interactR: 2.4,          // harvest reach
    materials: {
      fiber:    { sell: 400,  label: 'FIBER' },
      herbs:    { sell: 600,  label: 'HERBS' },
      feather:  { sell: 500,  label: 'FEATHERS' },
      hide:     { sell: 800,  label: 'HIDE' },
      fish:     { sell: 1200, label: 'FISH' },
      ferrite:  { sell: 900,  label: 'FERRITE ORE' },
      titanium: { sell: 1600, label: 'TITANIUM ORE' },
      gallium:  { sell: 2400, label: 'GALLIUM ORE' },
      crystal:  { sell: 3200, label: 'RAW CRYSTAL' },
    },
    ores: ['ferrite', 'ferrite', 'titanium', 'titanium', 'gallium', 'crystal'],
    plants: ['fiber', 'fiber', 'herbs'],
    fishWait: [1.6, 3.6],    // cast → bite window
    fishBite: 0.95,          // seconds to hook the bite
    rodLabel: 'FISHING ROD',
  },

  /* selling (XMB) — weapons sell back for CR (they re-lock; ammo scavenged
     brings them back online). The M6-P starter and the NIKANA never sell. */
  sell: {
    ar: 18000, sniper: 24000, shotgun: 16000, rocket: 32000,
  },

  /* ------------------------------------------------------------------ */
  /* CONTROLS — Halo-CE layout. HOLD D-pad ◀/▶ cycles the 4 R2 slots.    */
  /* ------------------------------------------------------------------ */
  controls: {
    mouseSens: 0.0022,
    stickSens: 2.6,
    deadzone: 0.15,
    lookCurve: 1.6,
    invertY: false,
    bindings: {
      fire:        ['Mouse0', 5],                // LMB / R1
      special:     ['KeyE', 'KeyG', 7],          // E·G / R2
      ads:         ['Mouse2', 'KeyZ', 6],        // RMB / Z / L2
      duck:        ['KeyC', 'ControlLeft', 4],   // C·Ctrl / L1
      jump:        ['Space', 0],                 // Space / A
      reload:      ['KeyR', 2],                  // R / X — pad X yields to context interact (harvest/fish/locker in reach), else reloads
      swap:        ['KeyQ', 3],                  // Q / Y
      melee:       ['KeyV', 1],                  // V / B
      nova:        ['KeyF'],                     // F
      light:       ['KeyL', 12],                 // L / D-padUp
      interact:    ['KeyX', 13],                 // X / D-padDown — harvest · fish · loot · locker
      stow:        ['KeyH', 10],                 // H / L3 — holster / draw weapon
      specialPrev: ['BracketLeft', 14],          // [ / D-padLeft (HOLD = cycle)
      specialNext: ['BracketRight', 15],         // ] / D-padRight (HOLD = cycle)
      pause:       ['Escape', 'KeyP', 9],        // Esc / P / Start
    },
    weaponKeys: ['Digit1', 'Digit2', 'Digit3', 'Digit4', 'Digit5'],
  },

  audio: {
    master: 0.5,
    sfx: 1.0,
    ambient: 0.35,
    footstep: 0.25,
  },

  debug: {
    showFps: false,
    godMode: false,
  },
};

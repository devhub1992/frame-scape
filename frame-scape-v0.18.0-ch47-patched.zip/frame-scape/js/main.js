/* ============================================================================
   FRAME SCAPE — main.js  (v0.8.0)
   ----------------------------------------------------------------------------
   Boot, render loop, state machine (menu → playing → xmb / dead / win),
   VATS time-dilation + hover-missile execute, zone lighting/fog (corridor ⇄
   hangar ⇄ valley ⇄ city ⇄ THE EXPANSE ⇄ OCEAN), the sliding doors, the
   4-slot R2 wheel, companions, the 5-MINUTE hostile respawn queue, and:
     · DAY/NIGHT CYCLE — 120 min full day (dawn 15 · day 40 · dusk 15 ·
       night 50) tinting sky, fog and sun
     · REINFORCEMENTS — every 15 s a neighboring tile gets a few hostiles
     · KAIJU DIRECTOR — wading the deep ocean can wake an L80 kaiju
     · ECOLOGY — birds, rodents, fish, harvesting + the fishing rod
   Debug handle: window.AC  →  { game, assets }  (tinker from the console)
   ==========================================================================*/

import * as THREE from 'three';
import { ASSETS } from './assets.js';
import { buildWorld } from './world.js';
import { Player } from './player.js';
import { Weapon } from './weapon.js';
import { Grunt, updateBolts, clearBolts, spawnEliteEntourage } from './enemy.js';
import { Specials } from './specials.js';
import { Companions } from './companions.js';
import { Ecology } from './ecology.js';
import { Mods, dropRateMult } from './mods.js';   /* CH-47.4 — reward curve */
import { Hud } from './hud.js';
import { Input } from './input.js';
import { Sfx } from './audio.js';
import { applyDamage, typedHit, rollCrit } from './weapon.js';   // CH-25.4 — shared damage entry

const Q = ASSETS.quality;
const VATS = ASSETS.vats;
const NOVA = ASSETS.nova;
const SP = ASSETS.specials;

class Game {
  constructor() {
    /* renderer ----------------------------------------------------------- */
    this.renderer = new THREE.WebGLRenderer({
      canvas: document.getElementById('game'),
      antialias: Q.antialias,
      powerPreference: 'high-performance',
    });
    this.basePixelRatio = Math.min(window.devicePixelRatio || 1, Q.maxPixelRatio);
    this.resScale = Q.mode === 'low' ? 0.75 : Q.resScale;
    this.renderer.setPixelRatio(this.basePixelRatio * this.resScale);
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;

    /* scene / camera ------------------------------------------------------ */
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(ASSETS.palette.bg);
    this.scene.fog = new THREE.Fog(ASSETS.palette.fog, 12, 44);

    this.camera = new THREE.PerspectiveCamera(
      Q.fov, window.innerWidth / window.innerHeight, 0.05, 160
    );
    this.scene.add(this.camera);

    /* lights — v0.8: the day/night cycle now drives these outdoors */
    this.hemi = new THREE.HemisphereLight(0x9db8d4, 0x1c2126, 0.17);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xd8e6f8, 0.1);
    this.sun.position.set(4, 9, 3);
    this.sun.castShadow = Q.mode !== 'low' && Q.shadows;
    this.sun.shadow.mapSize.set(1024, 1024);
    const sc = this.sun.shadow.camera;
    sc.left = -8; sc.right = 8; sc.top = 8; sc.bottom = -8;
    sc.near = 1; sc.far = 30;
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.03;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
    this.bounce = new THREE.DirectionalLight(0x6d8299, 0.05);
    this.bounce.position.set(-3, -4, -2);
    this.scene.add(this.bounce);

    /* world / actors -------------------------------------------------------- */
    /* meta first: apply saved credit/power ranks to ASSETS before anything
       reads them (player shield/health, weapons, companions, radar range…) */
    this.mods = Mods;
    Mods.init();
    this.world = buildWorld(this.scene);
    this.player = new Player(this.camera);
    this.weapon = new Weapon(this.camera, this.scene);
    this.weapon.game = this;
    this.ammo = {};
    for (const k in ASSETS.ammoPools) this.ammo[k] = ASSETS.ammoPools[k].start;
    this.materials = {};                 // ecology materials (fiber/ore/fish…)
    this.specials = new Specials(this.camera, this.scene);
    this.companions = new Companions(this.scene);
    this.ecology = new Ecology(this.scene, this.world);
    this.enemies = [];
    this.spawnEnemies();

    /* systems ---------------------------------------------------------------- */
    this.sfx = new Sfx();
    this.input = new Input(document.getElementById('game'));
    this.input.init();
    this.input.onPadConnected = (id) => {
      this.hud.padChip(true, id);
      this.hud.toast('CONTROLLER CONNECTED');
    };
    this.hud = new Hud(this);

    /* flashlight (Deadspace darkness) ------------------------------------- */
    this.flashlightOn = false;
    this.torch = new THREE.SpotLight(
      ASSETS.flashlight.color, 0, ASSETS.flashlight.distance,
      ASSETS.flashlight.angle, 0.5, 1.4
    );
    this.torch.position.set(0.12, -0.08, 0);
    const torchTarget = new THREE.Object3D();
    torchTarget.position.set(0, 0, -6);
    this.camera.add(torchTarget);
    this.torch.target = torchTarget;
    this.camera.add(this.torch);

    /* state -------------------------------------------------------------------- */
    this.state = 'menu';           // menu | playing | xmb | dead | win | loading
    this.time = 0;
    this.timeScale = 1;
    this.currentTarget = null;
    this.vatsTargets = [];
    this.won = false;
    /* CH-36 — home base flow state */
    this.extracting = false;       // buoy touch → loading screen in flight
    this.lastField = null;         // zone the last extraction came from
    this.hubStation = null;        // station currently in interact reach
    /* CH-47.1 — MISSION DIRECTOR state (the warframe vertical slice):
       mission = the LIVE deployment record · lastMission = session
       console readout of the final result · _deployCounts feeds the
       per-deployment seed so redeployments vary (CH-47.3).           */
    this.mission = null;
    this.lastMission = null;
    this._deployCounts = {};
    this.targetFov = ASSETS.quality.fov;
    this.zone = 'corridor';
    this.novaCd = 0;
    this._vatsSide = 1;
    this.respawnQueue = [];        // { def, at } — 5-minute hostile rebuilds
    this._slotHoldT = 0;
    this._slotTick = 0;
    /* v0.8 systems */
    this.dcT = ASSETS.daycycle.start;     // day/night clock (s into the cycle)
    this.reinforceT = ASSETS.enemy.reinforce.every;
    this.kaijuCd = 25;                    // grace before the first kaiju can rise
    this._kaijuWasAlive = false;

    /* quality watchdog ---------------------------------------------------------- */
    this.fpsAvg = 60;
    this.fpsCheck = 0;
    this.qStage = 0;
    this.showFps = ASSETS.debug.showFps;

    this.bindEvents();
    this.hud.setState('menu');
    this.hud.drawRadar();

    /* debug handle */
    window.AC = { game: this, assets: ASSETS };

    this.renderer.setAnimationLoop(() => this.frame());
  }

  /* ------------------------------------------------------------------ */
  spawnEnemies() {
    for (const s of this.world.spawns) {
      /* chance-gated spawns keep elites RARE (valley/city elites 35 %) */
      if (s.chance && Math.random() > s.chance) continue;
      const e = new Grunt(s, this.scene);
      this.enemies.push(e);
      /* some elites bring their own pet hound */
      if (s.t === 'elite') spawnEliteEntourage(this, e);
    }
  }

  /* -- 5-minute hostile respawn queue ----------------------------------- */
  queueRespawn(def) {
    this.respawnQueue.push({ def, at: this.time + ASSETS.enemy.respawnTime });
  }

  processRespawns() {
    for (let i = this.respawnQueue.length - 1; i >= 0; i--) {
      const r = this.respawnQueue[i];
      if (this.time < r.at) continue;
      /* chance-gated elites re-roll their spawn chance */
      if (r.def.chance && Math.random() > r.def.chance) {
        r.at = this.time + 45;
        continue;
      }
      const dx = this.player.pos.x - r.def.x;
      const dz = this.player.pos.z - r.def.z;
      if (dx * dx + dz * dz < Math.pow(ASSETS.enemy.respawnClearDist, 2)) continue;
      const e = new Grunt(r.def, this.scene);
      this.enemies.push(e);
      if (r.def.t === 'elite') spawnEliteEntourage(this, e);
      this.respawnQueue.splice(i, 1);
    }
  }

  /* -- 15-second neighbor-tile reinforcement waves ------------------------- */
  updateReinforce(dt) {
    const R = ASSETS.enemy.reinforce;
    this.reinforceT -= dt;
    if (this.reinforceT > 0) return;
    this.reinforceT = R.every;
    const alive = this.enemies.reduce((s, e) => s + (e.alive ? 1 : 0), 0);
    if (alive >= R.cap) return;
    const n = Math.min(
      Math.round(R.count[0] + Math.random() * (R.count[1] - R.count[0])),
      R.cap - alive);
    const EXw = ASSETS.world.expanse;
    const zEnd = EXw.z0 - EXw.rows * EXw.tileSize;
    const pool = ['grunt', 'grunt', 'shielder', 'drone'];
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const d = R.dist[0] + Math.random() * (R.dist[1] - R.dist[0]);
      let x = this.player.pos.x + Math.cos(a) * d;
      let z = this.player.pos.z + Math.sin(a) * d;
      /* clamp into the play space */
      z = Math.max(zEnd + 1.5, Math.min(-2, z));
      if (z > ASSETS.world.hangar.mouthZ) x = Math.max(-2.6, Math.min(2.6, x));
      else if (z > ASSETS.world.valley.z0) x = Math.max(-16, Math.min(16, x));
      else if (z > ASSETS.world.city.z0) {
        x = Math.max(-12, Math.min(12, x));
        /* CH-08.2 — keep reinforcement drops out of the connector fillers:
           a point inside a corridor shell funnels into the 12 m passage */
        const cc = this.world.corridorAt(x, z);
        if (cc) x = Math.max(-cc.pass / 2 + 0.8, Math.min(cc.pass / 2 - 0.8, x));
      }
      else if (z > EXw.z0) x = Math.max(-13, Math.min(13, x));
      else x = Math.max(-(EXw.cols * EXw.tileSize / 2 - 1.5),
        Math.min(EXw.cols * EXw.tileSize / 2 - 1.5, x));
      const tile = this.world.tileAt(x, z);
      const lvl = tile ? tile.lvl : undefined;   // undefined → levelForZ fallback
      const t = Math.random() < R.eliteChance
        ? 'elite'
        : pool[Math.floor(Math.random() * pool.length)];
      const e = new Grunt({ t, x, z, patrol: 3, lvl, noRespawn: true }, this.scene);
      this.enemies.push(e);
      if (t === 'elite') spawnEliteEntourage(this, e);
    }
    this.hud.toast('REINFORCEMENTS MOVING IN', 1100);
  }

  /* -- kaiju director — wade the deep ocean at your own risk ---------------- */
  updateKaiju(dt) {
    const K = ASSETS.world.expanse.kaiju;
    const hasKaiju = this.enemies.some((e) => e.alive && e.arch.kaiju);
    if (this._kaijuWasAlive && !hasKaiju) {
      this.kaijuCd = K.cooldown;               // slain — start the next timer
    }
    this._kaijuWasAlive = hasKaiju;
    if (hasKaiju || this.kaijuCd > 0) {
      if (!hasKaiju) this.kaijuCd -= dt;
      return;
    }
    const zone = this.world.zoneAt(this.player.pos.z);
    if (zone !== 'ocean') return;
    if (Math.random() < K.chancePerSec * dt) {
      const a = Math.random() * Math.PI * 2;
      const d = 20 + Math.random() * 12;
      let x = this.player.pos.x + Math.cos(a) * d;
      let z = this.player.pos.z + Math.sin(a) * d;
      x = Math.max(-this.world.xHalf + 3, Math.min(this.world.xHalf - 3, x));
      z = Math.max(this.world.zEnd + 4, Math.min(this.world.oceanZ0 - 4, z));
      const kaiju = new Grunt({ t: 'kaiju', x, z, lvl: K.level, noRespawn: true, patrol: 0 }, this.scene);
      this.enemies.push(kaiju);
      this.sfx.tone({ type: 'sawtooth', f0: 160, f1: 38, dur: 1.8, gain: 0.5 });
      this.hud.toast('THE WATER DISPLACES… KAIJU · LVL ' + K.level, 3000);
      this.hud.setObjective('OBJECTIVE: SLAY THE KAIJU OR REACH THE BUOY');
    }
  }

  /* -- day / night cycle — 120 min: dawn 15 · day 40 · dusk 15 · night 50 --- */
  updateDaycycle(dt) {
    const DC = ASSETS.daycycle;
    this.dcT = (this.dcT + dt) % DC.fullDay;
    const p = this.dcT;
    const DAWN = DC.dawn, DAY = DC.day, DUSK = DC.dusk;
    const night = new THREE.Color(0.34, 0.4, 0.52);
    const warm = new THREE.Color(1.12, 0.8, 0.58);
    const day = new THREE.Color(1, 1, 1);
    const tint = new THREE.Color();
    let k = 0.18, phase = 'NIGHT';
    if (p < DAWN) {
      phase = 'DAWN';
      const q = p / DAWN;
      tint.copy(night).lerp(warm, q);
      k = 0.2 + q * 0.6;
    } else if (p < DAWN + DAY) {
      phase = 'DAY';
      const q = (p - DAWN) / DAY;
      tint.copy(warm).lerp(day, Math.min(1, Math.abs(q - 0.5) * 2.4));
      k = 1;
    } else if (p < DAWN + DAY + DUSK) {
      phase = 'DUSK';
      const q = (p - DAWN - DAY) / DUSK;
      tint.copy(day).lerp(warm, Math.min(1, q * 1.7));
      tint.lerp(night, Math.max(0, q - 0.5) * 2);
      k = 1 - q * 0.82;
    } else {
      phase = 'NIGHT';
      tint.copy(night);
      k = 0.18;
    }
    /* lights */
    this.hemi.intensity = 0.07 + k * 0.3;
    this.sun.intensity = 0.02 + k * 0.5;
    this.sun.color.copy(warm).lerp(day, Math.min(1, k * 1.2));
    this.bounce.intensity = 0.03 + k * 0.04;
    /* fog + sky tint (updateZone lerps toward the zone palette first —
       CH-08.2: connector roofs swap that for the indoor palette;
       we then pull toward the day-tinted version of the same palette) */
    const fx = this.world.zoneFxAt(this.player.pos.x, this.player.pos.z);
    if (fx) {
      const fogT = new THREE.Color(fx.fog).multiply(tint);
      const bgT = new THREE.Color(fx.bg).multiply(tint);
      this.scene.fog.color.lerp(fogT, Math.min(1, dt * 3));
      this.scene.background.lerp(bgT, Math.min(1, dt * 3));
    }
    /* clock chip — 1 real min = 12 game min, dawn breaks at 05:00 */
    const gameMin = (DC.clockBase * 60 + p * 0.2) % 1440;
    const hh = String(Math.floor(gameMin / 60)).padStart(2, '0');
    const mm = String(Math.floor(gameMin % 60)).padStart(2, '0');
    this.hud.setClock(phase, hh + ':' + mm);
  }

  resetRun() {
    for (const e of this.enemies) {
      this.scene.remove(e.group);
      this.scene.remove(e.blob);
    }
    this.enemies = [];
    this.respawnQueue = [];
    clearBolts(this);
    this.spawnEnemies();
    for (const k in ASSETS.ammoPools) this.ammo[k] = ASSETS.ammoPools[k].start;
    this.player.reset();
    this.weapon.resetAll();
    this.specials.resetAll(this);
    this.companions.resetAll(this);
    this.world.door.reset();
    this.world.door2.reset();
    this.world.resetCorridorDoors();   /* CH-08.2 — gates shut, pads cool */
    this.flashlightOn = false;
    this.torch.intensity = 0;
    this.timeScale = 1;
    this.player.vatsActive = false;
    this.time = 0;
    this.won = false;
    /* CH-36 — extraction flow + ramp door reset */
    this.extracting = false;
    this.lastField = null;
    this.hubStation = null;
    this.hud.cancelLoading();
    this.world.hub.rampDoor.reset();
    /* CH-47.1 — RESET RUN wipes any live deployment (no pay, no summary —
       a wipe is a wipe); field props clear with it.                */
    this.clearMissionProps();
    this.mission = null;
    this.lastSummary = null;
    this.novaCd = 0;
    this.targetFov = ASSETS.quality.fov;
    this.hud.setScope(null);
    this.zone = 'corridor';
    /* v0.8 system resets (materials persist — they're salvage, not run state) */
    this.dcT = ASSETS.daycycle.start;
    this.reinforceT = ASSETS.enemy.reinforce.every;
    this.kaijuCd = 25;
    this._kaijuWasAlive = false;
    this.hud.setClock('DAWN', '05:00');
  }

  /* -- state transitions ------------------------------------------------ */
  start() {
    this.sfx.ensure();
    this.resetRun();
    this.state = 'playing';
    this.hud.setState('playing');
    this.hud.setObjective('OBJECTIVE: FIGHT TO HANGAR BAY 7');
    this.input.requestLock();
    this.hud.toast('REACH HANGAR BAY 7');
  }

  openXmb() {
    if (this.state !== 'playing' && this.state !== 'paused') return;
    this.player.exitVats(this);
    this.state = 'xmb';
    this.hud.setState('xmb');
    this.hud.openXmb();
    this.input.releaseLock();
    this.sfx.regenStop();
  }

  closeXmb() {
    if (this.state !== 'xmb') return;
    this.hud.closeXmb();
    this.state = 'playing';
    this.hud.setState('playing');
    this._noAutoXmb = performance.now() + 900;  // ignore lock-bounce reopens
    this.input.requestLock();
  }

  pause() {
    if (this.state !== 'playing') return;
    this.state = 'paused';
    this.hud.setState('paused');
    this.input.releaseLock();
    this.sfx.regenStop();
  }

  resume() {
    if (this.state !== 'paused') return;
    this.state = 'playing';
    this.hud.setState('playing');
    this.input.requestLock();
  }

  onPlayerDeath() {
    /* CH-47.4 — PARTY WIPED is a mission failure state: partial pay
       per the assets table, applied once, props cleared.            */
    if (this.mission && this.mission.state === 'active') {
      this.failMission('PARTY WIPED');
    }
    this.state = 'dead';
    this.hud.setState('dead');
    this.input.releaseLock();
    this.sfx.regenStop();
  }

  win() {
    /* CH-36.3 — the terminal v0.7 win overlay is SUPERSEDED by the
       extraction loop: the buoy now routes through startExtraction()
       (loading screen → home base). Kept intact for the overlay path —
       nothing calls it while the CH-36 flow owns the beacon.            */
    if (this.won) return;
    this.won = true;
    this.state = 'win';
    this.hud.fillWinStats();
    this.hud.setState('win');
    this.input.releaseLock();
    this.sfx.uiConfirm();
  }

  /* -- CH-36 — home base flow (f1 loading screen · f3 integration) ------- */
  /* Touching the deep-ocean extraction buoy: state 'loading' pauses the
     sim while the shuttle-art loading screen plays, then the port lands
     the player at the hub dock. lastField remembers the extracted-from
     zone so the mission console / ramp can return the player to the
     field ("last zone or NAVIGATE choice" — f3).                        */
  startExtraction() {
    if (this.extracting || this.state !== 'playing') return;
    /* CH-47.4 — buoy touch mid-mission: a COMPLETE mission rides home
       to its reward summary; an ACTIVE one is abandoned (no pay).    */
    this._missionOnBuoyTouch();
    this.extracting = true;
    this.lastField = this.zone;
    this.hud.showLoading({
      port: () => this.arriveHub(),
    });
  }

  arriveHub() {
    const HUB = ASSETS.hub;
    this.extracting = false;
    const p = this.player;
    p.exitVats(this);
    p.pos.set(HUB.arrive.x, ASSETS.player.eyeHeight, HUB.arrive.z);
    p.vel.set(0, 0, 0);
    p.yaw = HUB.arrive.yaw; p.pitch = 0;      // facing the cockpit/windshield
    this.zone = 'hub';
    this.state = 'playing';
    this.hud.setState('playing');
    this.hud.setObjective('OBJECTIVE: HOME BASE — GEAR UP OR WALK THE RAMP');
    this.input.requestLock();
    this.hud.toast('HOME BASE — SHUTTLE INTERIOR', 2400);
    this.hud.toast('STATIONS: WALK UP AND PRESS X', 3000);
    /* CH-47.4 — a completed mission came home with us: the REWARD
       SUMMARY presents over the hub (reward applies once, paid flips,
       the dismissal hands control back to the shuttle).              */
    if (this.lastSummary) {
      this.presentMissionSummary();
    }
  }

  /* CH-36.3 — a console NAVIGATE hop (and CH-47 DEPLOY later): the same
     loading flow in reverse — hub → loading screen → field site.        */
  runNavHop(x, z, label) {
    if (this.state !== 'xmb' && this.state !== 'playing') return;
    this.hud.showLoading({
      title: 'DEPLOYMENT',
      sub: 'ORBITAL SHUTTLE · PELICUS-3',
      lines: ['COURSE PLOTTED — ' + label, 'RAMP CLEARANCE GRANTED', 'DROPPING TO SITE', 'SHUTTLE DEPARTING'],
      tip: 'THE SHUTTLE DROPS YOU AT THE SITE — EXTRACT FROM THE BEACON TO COME HOME',
      duration: 2.6,
      port: () => {
        this.player.exitVats(this);
        this.teleportTo(x, z);
        this.state = 'playing';
        this.hud.setState('playing');
        this.input.requestLock();
        this.hud.toast('DROPPED — ' + label, 2200);
      },
    });
  }

  /* ==================================================================
     CH-47 — MISSION DIRECTOR (the warframe vertical slice)
     One state machine: AVAILABLE (hub console) → DEPLOYED (loading
     screen → field) → OBJECTIVES ACTIVE → COMPLETE/FAILED → EXTRACTION
     → REWARD SUMMARY → HUB. Missions are DATA (assets.missions) — the
     machine consumes the existing zone/spawn/objective systems and
     never touches terrain (warframe.mission-rules). Seeded per deploy
     (CH-47.3): same seed ⇒ same encounter. Rewards roll from the
     EXISTING drop tables and apply ONCE (CH-47.4).
     ================================================================== */

  /* -- seeded RNG (mulberry32) + roll helpers — CH-47.3 seed discipline:
     the SAME seed must reproduce the SAME encounter (objective anchor,
     quota, cache layout, wave mixes, reward roll). Mirrors the
     specials pickWeightedKey contract (normalising, 0-weights skipped). */
  _rng(seed) {
    let s = seed >>> 0;
    return function () {
      s |= 0; s = (s + 0x6D2B79F5) | 0;
      let t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  _ri(rng, a, b) { return a + Math.floor(rng() * (b - a + 1)); }
  _pick(rng, arr) { return arr[Math.floor(rng() * arr.length)]; }
  _pickWeightedKey(weights, rng) {
    let total = 0;
    for (const k in weights) { const w = +weights[k]; if (w > 0) total += w; }
    if (total <= 0) return null;
    let roll = rng() * total, last = null;
    for (const k in weights) {
      const w = +weights[k];
      if (w <= 0) continue;
      roll -= w;
      if (roll <= 0) return k;
      last = k;
    }
    return last;
  }
  /* pool-weighted mod-node pick — the seeded mirror of
     specials._rollModNode (same itemPool, same uniform-within-pool) */
  _seedModNode(rng) {
    const nodes = ASSETS.mods.nodes;
    const pool = this._pickWeightedKey(ASSETS.drops.itemPool, rng);
    const inPool = pool ? nodes.filter((n) => n.pool === pool) : [];
    if (!inPool.length) return nodes[Math.floor(rng() * nodes.length)];
    return inPool[Math.floor(rng() * inPool.length)];
  }
  /* clear the field props (beacon / ring / generator / caches) */
  clearMissionProps() { this.world.setMissionProps([]); }

  /* -- nudge a point clear of colliders (caches/waves) — deterministic
     6-try x-spiral, the CH-10.1 pattern scaled down for small props   */
  _nudgeClear(x, z, margin = 0.9) {
    const cols = this.world.colliders;
    const hit = (px, pz) => cols.some((c) =>
      px > c.minX - margin && px < c.maxX + margin &&
      pz > c.minZ - margin && pz < c.maxZ + margin &&
      (c.y0 == null || c.y0 < 1.8));
    if (!hit(x, z)) return { x, z };
    for (let i = 1; i <= 6; i++) {
      const dx = (i % 2 ? 1 : -1) * i * 1.1;
      if (!hit(x + dx, z)) return { x: x + dx, z };
      if (!hit(x, z + dx)) return { x, z: z + dx };
    }
    return { x, z };   // bounded give-up — placement stays deterministic
  }

  /* -- CH-47.2 — DEPLOY: the console hands the mission def over. The
     loading flow (CH-36.1) runs in reverse — hub → loading → site —
     and the player lands with the equipped loadout + companions
     unchanged (one canonical state, ch-36.f6).                        */
  deployMission(m) {
    const MD = ASSETS.missionDirector;
    if (this.mission) {
      this.hud.toast('DEPLOYMENT ALREADY ACTIVE — FINISH OR ABORT IT FIRST', 2400);
      this.sfx.energyFail();
      return;
    }
    if (this.state !== 'xmb' && this.state !== 'playing') return;
    if (!m || !m.type || !ASSETS.missions.includes(m)) return;   // data-guard
    const n = (this._deployCounts[m.id] || 0);
    const seed = ((m.seedBase || 1) + n * 7919) >>> 0;
    this._deployCounts[m.id] = n + 1;
    this.mission = {
      id: m.id, name: m.name, type: m.type, zone: m.zone, lvl: m.lvl,
      band: m.band || ('LVL ' + m.lvl), site: m.site || m.name,
      seed, state: 'deploying', kills0: this.weapon.stats.kills,
      paid: false, reward: null, result: null,
    };
    this.sfx.uiConfirm();
    this.hud.showLoading({
      title: 'DEPLOYMENT — ' + m.name,
      sub: (m.type || 'MISSION').toUpperCase() + ' · ' + (m.site || '') + ' · ' +
        (m.band || '') + ' · SEED ' + seed,
      lines: MD.deployLines,
      tip: MD.deployTip,
      duration: MD.deployDuration,
      port: () => this.arriveMissionSite(m),
    });
  }

  /* -- landing at the site: build the objective from the seed --------- */
  arriveMissionSite(m) {
    const rec = this.mission;
    const MD = ASSETS.missionDirector;
    if (!rec || rec.id !== m.id) { this.mission = null; return; }  // stale port
    const rng = this._rng(rec.seed ^ 0x9E3779B9);
    this.player.exitVats(this);
    this.teleportTo(m.deploy.x, m.deploy.z);
    this.state = 'playing';
    this.hud.setState('playing');
    this.input.requestLock();
    /* pre-deploy hostiles never count toward quotas (CH-47.2) */
    for (const e of this.enemies) e._m47 = true;
    /* objective build — data-driven per type (GRACEFUL FALLBACK: a
       mission without a placeable anchor flags itself unavailable
       instead of booting the player into a broken objective)         */
    const anchors = Array.isArray(m.anchors) ? m.anchors : [];
    if ((m.type === 'holdout' || m.type === 'defense') && !anchors.length) {
      this.hud.toast('NO VALID SITE ANCHOR — MISSION UNAVAILABLE', 2600);
      this.mission = null;
      return;
    }
    if (m.type === 'holdout') {
      const a = this._pick(rng, anchors);
      const holdNeed = this._ri(rng, m.params.holdMin, m.params.holdMax);
      Object.assign(rec, { anchor: { x: a.x, z: a.z, label: a.label },
        holdT: 0, holdNeed, waveT: 2.5, waveIdx: 0 });
      this.world.setMissionProps([
        { kind: 'hold', x: a.x, z: a.z, r: MD.holdout.radius }]);
      this.hud.toast('HOLD THE ' + (a.label || 'RING') + ' — ' + holdNeed + 's', 3000);
    } else if (m.type === 'defense') {
      const a = this._pick(rng, anchors);
      const defendNeed = this._ri(rng, m.params.defendMin, m.params.defendMax);
      Object.assign(rec, { anchor: { x: a.x, z: a.z, label: a.label },
        defMax: m.params.genHp, defHp: m.params.genHp,
        defendT: 0, defendNeed, waveT: 2.5, waveIdx: 0 });
      this.world.setMissionProps([{ kind: 'generator', x: a.x, z: a.z }]);
      this.hud.toast('DEFEND THE ' + (a.label || 'GENERATOR') +
        ' — ' + defendNeed + 's', 3000);
    } else if (m.type === 'recovery') {
      const want = this._ri(rng, m.params.cachesMin, m.params.cachesMax);
      const pool = anchors.slice();
      /* seeded partial shuffle → pick `want` distinct anchors */
      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
      }
      rec.caches = pool.slice(0, want).map((a) => {
        const spot = this._nudgeClear(a.x, a.z);
        return { x: spot.x, z: spot.z, label: a.label, got: false };
      });
      this.world.setMissionProps(rec.caches.map((c) =>
        ({ kind: 'cache', x: c.x, z: c.z })));
      this.hud.toast('RECOVER ' + want + ' SALVAGE CACHES', 3000);
    } else {
      /* extermination — quota from the seed */
      rec.quota = this._ri(rng, m.params.quotaMin, m.params.quotaMax);
      rec.kills = 0;
      this.hud.toast('EXTERMINATE — ' + rec.quota +
        ' LVL ' + rec.lvl + ' HOSTILES', 3000);
    }
    rec.state = 'active';
    this._missionObjDirty = true;   // objective line refresh (throttled)
    this.sfx.navBig();
  }

  /* -- director waves: holdout/defense pressure + extermination supply —
     spawns ride the EXISTING enemy machinery (Grunt + spawnEliteEntourage,
     noRespawn — the reinforcement pattern), mixes derive from the seed.
     `origin` = anchor for ring missions, the PLAYER for supply waves. -- */
  _missionWave(rec, m, origin, cfg, spread) {
    const MD = ASSETS.missionDirector;
    const aliveMission = this.enemies.reduce((s, e) =>
      s + (e.alive && e._m47wave ? 1 : 0), 0);
    if (aliveMission >= MD.waveCap) return;
    const rng = this._rng((rec.seed ^ (rec.waveIdx * 0x2545F491)) >>> 0);
    const n = Math.min(this._ri(rng, cfg.count[0], cfg.count[1]),
      MD.waveCap - aliveMission);
    const pool = ['grunt', 'grunt', 'shielder', 'drone'];
    for (let i = 0; i < n; i++) {
      const a = rng() * Math.PI * 2;
      const d = spread[0] + rng() * (spread[1] - spread[0]);
      let x = origin.x + Math.cos(a) * d;
      let z = origin.z + Math.sin(a) * d;
      const SC = m.spawnClamp || {};
      x = Math.max(SC.xMin != null ? SC.xMin : -this.world.xHalf + 2,
        Math.min(SC.xMax != null ? SC.xMax : this.world.xHalf - 2, x));
      z = Math.max(SC.zMin != null ? SC.zMin : this.world.zEnd + 2,
        Math.min(SC.zMax != null ? SC.zMax : -2, z));
      const spot = this._nudgeClear(x, z, 1.2);
      const t = rng() < cfg.eliteChance ? 'elite'
        : this._pick(rng, pool);
      const e = new Grunt({ t, x: spot.x, z: spot.z, patrol: 3,
        lvl: rec.lvl, noRespawn: true }, this.scene);
      e._m47wave = true;              // director-spawned (wave cap counts)
      this.enemies.push(e);
      if (t === 'elite') spawnEliteEntourage(this, e);
    }
    rec.waveIdx++;
  }

  /* -- per-frame director upkeep (playing state, mission live) -------- */
  updateMission(dt) {
    const rec = this.mission;
    if (!rec || rec.state === 'deploying') return;
    const def = ASSETS.missions.find((x) => x.id === rec.id);
    if (!def) { this.mission = null; return; }   // config moved under us
    const MD = ASSETS.missionDirector;
    const p = this.player.pos;

    if (rec.state === 'active') {
      if (rec.type === 'extermination') {
        /* CH-47.2 — quota counts hostiles of the mission's level band
           dying AFTER deploy (public read on the enemy list — no
           enemy.js involvement, the files contract holds)            */
        for (const e of this.enemies) {
          if (!e.alive && !e._m47 && e.level === rec.lvl) {
            e._m47 = true;
            rec.kills = Math.min(rec.quota, (rec.kills || 0) + 1);
            this._missionObjDirty = true;
          }
        }
        if (rec.kills >= rec.quota) { this.completeMission('QUOTA MET'); return; }
        /* CH-47.3 — supply waves: keep the site populated so quotas
           never starve on the GLOBAL reinforcement cap (browser smoke
           found the corridor cap-26 starvation — this is the fix).    */
        rec.supplyT = (rec.supplyT === undefined ? 4 : rec.supplyT) - dt;
        if (rec.supplyT <= 0) {
          rec.supplyT = MD.supply.every;
          const inBand = this.enemies.reduce((s, e) =>
            s + (e.alive && e.level === rec.lvl ? 1 : 0), 0);
          if (inBand < MD.supply.keepAlive) {
            this._missionWave(rec, def, { x: p.x, z: p.z },
              MD.supply, MD.waveSpread);
            this.hud.toast('HOSTILE PATROL MOVING IN', 1100);
          }
        }
      } else if (rec.type === 'holdout') {
        const H = MD.holdout;
        const d = Math.hypot(p.x - rec.anchor.x, p.z - rec.anchor.z);
        if (d <= H.radius) {
          const prev = Math.floor(rec.holdT);
          rec.holdT += dt;
          if (Math.floor(rec.holdT) !== prev) this._missionObjDirty = true;
          if (rec.holdT >= rec.holdNeed) this.completeMission('HOLDOUT SURVIVED');
        } else {
          this._missionNudgeT = (this._missionNudgeT || 0) - dt;
          if (this._missionNudgeT <= 0) {
            this._missionNudgeT = 4;
            this.hud.toast('RETURN TO THE ' + (rec.anchor.label || 'HOLD RING'), 1600);
          }
        }
        rec.waveT -= dt;
        if (rec.waveT <= 0) {
          rec.waveT = H.waveEvery;
          this._missionWave(rec, def, rec.anchor, H, MD.waveSpread);
          this.hud.toast('HOSTILE WAVE INBOUND', 1200);
        }
      } else if (rec.type === 'defense') {
        const D = MD.defense;
        rec.defendT += dt;
        this._missionObjDirty = true;
        /* hostiles inside the perimeter drain the generator (director-
           side read — enemy AI is untouched, the files contract holds) */
        let drain = 0;
        for (const e of this.enemies) {
          if (!e.alive) continue;
          const g = e.group.position;
          if (Math.hypot(g.x - rec.anchor.x, g.z - rec.anchor.z) <= D.radius) {
            drain += D.drainPerEnemy;
          }
        }
        if (drain > 0) {
          rec.defHp -= drain * dt;
          if (rec.defHp <= 0) {
            rec.defHp = 0;
            this.failMission('TARGET LOST');
            return;
          }
        }
        if (rec.defendT >= rec.defendNeed) this.completeMission('GENERATOR SECURE');
        rec.waveT -= dt;
        if (rec.waveT <= 0) {
          rec.waveT = D.waveEvery;
          this._missionWave(rec, def, rec.anchor, D, MD.waveSpread);
          this.hud.toast('HOSTILE WAVE INBOUND', 1200);
        }
      } else if (rec.type === 'recovery') {
        for (const c of rec.caches) {
          if (c.got) continue;
          if (Math.hypot(p.x - c.x, p.z - c.z) <= MD.recovery.collectR) {
            c.got = true;
            this.sfx.uiConfirm();
            this.hud.pickup('SALVAGE CACHE SECURED — ' + c.label);
            this.world.setMissionProps(rec.caches.filter((x) => !x.got)
              .map((x) => ({ kind: 'cache', x: x.x, z: x.z })));
            this._missionObjDirty = true;
          }
        }
        if (rec.caches.every((c) => c.got)) this.completeMission('CACHES RECOVERED');
      }
    }

    /* CH-47.4 — objective complete → the extraction beacon lights at
       the anchor (objective missions) or the deploy point (exter-
       mination). Touch it to ride the CH-36.3 flow home.            */
    if (rec.state === 'complete' && !rec.extracting) {
      const ex = rec.extract;
      if (Math.hypot(p.x - ex.x, p.z - ex.z) <= MD.extractR) {
        rec.extracting = true;
        this.lastSummary = rec;            // summary presents on hub arrival
        this.mission = null;               // deployment concluded — ride home
        this.hud.showLoading({
          port: () => this.arriveHub(),      // CH-36.3 flow → hub → summary
        });
      }
    }

    /* throttled objective-line readout (CH-40 will own the HUD language;
       the existing objective line IS the game-window readout for now)  */
    if (this._missionObjDirty) {
      this._missionObjDirty = false;
      this.hud.setObjective(this.missionObjectiveLine(rec));
    }
  }

  missionObjectiveLine(rec) {
    if (rec.state === 'complete') {
      return 'OBJECTIVE COMPLETE — REACH THE EXTRACTION BEACON';
    }
    if (rec.type === 'extermination') {
      return 'EXTERMINATE — ' + (rec.kills || 0) + ' / ' + rec.quota +
        ' (LVL ' + rec.lvl + ' HOSTILES)';
    }
    if (rec.type === 'holdout') {
      return 'HOLD THE RING — ' + Math.max(0, Math.ceil(rec.holdNeed - rec.holdT)) +
        's (STAY INSIDE)';
    }
    if (rec.type === 'defense') {
      return 'DEFEND THE GENERATOR — ' + Math.max(0, Math.ceil(rec.defHp)) +
        ' HP · ' + Math.max(0, Math.ceil(rec.defendNeed - rec.defendT)) + 's';
    }
    if (rec.type === 'recovery') {
      const got = rec.caches.filter((c) => c.got).length;
      return 'RECOVER CACHES — ' + got + ' / ' + rec.caches.length;
    }
    return 'MISSION ACTIVE';
  }

  /* -- CH-47.4 — reward roll (seeded, stored, applied ONCE) ----------- */
  _rollMissionReward(def, rec) {
    const MD = ASSETS.missionDirector;
    const rng = this._rng((rec.seed ^ 0x51F15EED) >>> 0);
    const mult = dropRateMult(rec.lvl);       // the EXISTING L-curve
    const R = def.reward || {};
    const cr = Math.round(this._ri(rng, R.cr[0], R.cr[1]) * mult);
    const pw = Math.round(this._ri(rng, R.pw[0], R.pw[1]) * mult);
    const nChips = this._ri(rng, R.chips[0], R.chips[1]);
    const cards = [];
    for (let i = 0; i < nChips; i++) {
      const node = this._seedModNode(rng);
      const tally = cards.find((c) => c.id === node.id);
      if (tally) tally.n++;
      else cards.push({ id: node.id, label: node.label, n: 1 });
    }
    let proto = null;
    if (R.proto && rng() < MD.protoChance) {
      const locked = this.weapon.guns
        .map((g) => g.def)
        .filter((d) => !this.weapon.unlocked.has(d.id));
      if (locked.length) {
        const weights = {};
        for (const d of locked) weights[d.id] = +ASSETS.drops.itemPool[d.pool] || 0;
        const id = this._pickWeightedKey(weights, rng);
        const gun = locked.find((d) => d.id === id) || this._pick(rng, locked);
        proto = { gun: gun.id, name: gun.name };
      } else {
        proto = { cr: MD.protoFallbackCR };   // kaiju parity: the sale fallback
      }
    }
    return { cr, pw, cards, proto };
  }

  /* -- apply the rolled reward ONCE (the director's invariant) -------- */
  _applyMissionReward(rec) {
    if (rec.paid || !rec.reward) return;
    rec.paid = true;
    const r = rec.reward;
    if (r.cr > 0) Mods.add(r.cr);
    if (r.pw > 0) Mods.addPower(r.pw);
    for (const c of r.cards || []) {
      for (let i = 0; i < c.n; i++) Mods.acquireCard(c.id);
    }
    const MD = ASSETS.missionDirector;
    if (r.proto) {
      if (r.proto.gun) {
        this.weapon.unlocked.add(r.proto.gun);
        const g = this.weapon.guns.find((x) => x.def.id === r.proto.gun);
        if (g) this.ammo[g.def.ammo] = Math.max(this.ammo[g.def.ammo],
          Math.round(ASSETS.ammoPools[g.def.ammo].cap * MD.protoAmmoPct));
      } else if (r.proto.cr > 0) {
        Mods.add(r.proto.cr);
      }
    }
  }

  /* -- terminal states ------------------------------------------------- */
  completeMission(reason) {
    const rec = this.mission;
    if (!rec || rec.state !== 'active') return;
    rec.state = 'complete';
    const def = ASSETS.missions.find((x) => x.id === rec.id);
    rec.reward = this._rollMissionReward(def, rec);
    /* beacon at the anchor (objective missions) or the deploy point */
    const at = rec.anchor || (def ? def.deploy : { x: 0, z: -8 });
    rec.extract = { x: at.x, z: at.z };
    this.world.setMissionProps([{ kind: 'beacon', x: at.x, z: at.z }]);
    this._missionObjDirty = true;
    /* write the readout NOW — the updater's early return (supply waves)
       would otherwise hold the stale quota line for a frame */
    this.hud.setObjective('OBJECTIVE COMPLETE — REACH THE EXTRACTION BEACON');
    this.sfx.uiConfirm();
    this.hud.toast(reason + ' — EXTRACTION BEACON LIT', 3200);
    this.sfx.tone({ type: 'sine', f0: 320, f1: 720, dur: 0.5, gain: 0.22 });
  }

  failMission(reason, payFrac = null) {
    const rec = this.mission;
    if (!rec) return;
    const MD = ASSETS.missionDirector;
    const frac = payFrac == null ? MD.failPay : payFrac;
    const def = ASSETS.missions.find((x) => x.id === rec.id);
    if (!rec.reward) rec.reward = this._rollMissionReward(def, rec);
    const pay = {
      cr: Math.round(rec.reward.cr * frac),
      pw: Math.round(rec.reward.pw * frac),
    };
    if (pay.cr > 0) Mods.add(pay.cr);
    if (pay.pw > 0) Mods.addPower(pay.pw);
    /* chips + prototypes are LOST on failure (f4: partial/none) */
    rec.paid = true;
    rec.result = 'failed';
    rec.failReason = reason;
    this.lastMission = { name: rec.name, type: rec.type, result: 'failed',
      reason, cr: pay.cr, pw: pay.pw };
    this.clearMissionProps();
    this.mission = null;
    this.hud.toast('MISSION FAILED — ' + reason, 3000);
    if (pay.cr > 0 || pay.pw > 0) {
      this.hud.toast('PARTIAL PAY · +' + pay.cr.toLocaleString('en-US') +
        ' CR · +' + pay.pw + ' PW', 3000);
    }
    this.sfx.energyFail();
    this.hud.setObjective('OBJECTIVE: FREE ROAM — THE MISSION CONSOLE HAS MORE WORK');
  }

  /* -- console ABORT: ride the loading flow home, pay nothing --------- */
  abortMission() {
    const rec = this.mission;
    if (!rec || rec.state !== 'active') return;
    this.mission = null;
    this.clearMissionProps();
    this.lastMission = { name: rec.name, type: rec.type, result: 'aborted',
      reason: 'ABORTED', cr: 0, pw: 0 };
    this.hud.showLoading({
      title: 'RETURN TO BASE',
      sub: 'MISSION ABORTED · ORBITAL SHUTTLE · PELICUS-3',
      lines: ['ABORT ACKNOWLEDGED', 'BEACON DETACHED', 'RAMP CLEARANCE GRANTED', 'DOCKING — HOME BASE'],
      tip: 'ABORTED MISSIONS PAY NOTHING — THE CONSOLE LISTS THE MISSION AGAIN',
      duration: 2.4,
      port: () => this.arriveHub(),
    });
  }

  /* -- CH-47.4 — the summary presents over the hub after extraction;
     the reward APPLIES at presentation (paid flips once — quit mid-
     summary and the bank keeps it; re-entry can never double-pay). -- */
  presentMissionSummary() {
    const rec = this.lastSummary;
    if (!rec || rec.paid) return;
    this._applyMissionReward(rec);
    rec.result = 'success';
    this.lastMission = { name: rec.name, type: rec.type, result: 'success',
      reason: 'COMPLETE', cr: rec.reward.cr, pw: rec.reward.pw };
    this.hud.showMissionSummary(rec, () => {
      this.state = 'playing';
      this.hud.setState('playing');
      this.input.requestLock();
    });
  }

  /* -- ac-save-v1 idempotent extension (CH-47.1): the live record
     serialises as plain data; old saves without the key load clean — */
  _missionSave() {
    const r = this.mission;
    if (!r) return null;
    return {
      id: r.id, seed: r.seed, state: r.state, paid: !!r.paid,
      lvl: r.lvl, quota: r.quota || 0, kills: r.kills || 0, kills0: r.kills0,
      holdT: r.holdT || 0, holdNeed: r.holdNeed || 0,
      defendT: r.defendT || 0, defendNeed: r.defendNeed || 0,
      defHp: r.defHp || 0, defMax: r.defMax || 0,
      anchor: r.anchor || null, extract: r.extract || null,
      caches: (r.caches || []).map((c) => ({ x: c.x, z: c.z, label: c.label, got: c.got })),
      reward: r.reward, result: r.result,
    };
  }

  _missionLoad(saved) {
    if (!saved || !saved.id) return null;
    const def = ASSETS.missions.find((x) => x.id === saved.id);
    if (!def) return null;                       // config changed — drop it
    const rec = { ...saved, name: def.name, type: def.type, zone: def.zone,
      band: def.band, site: def.site };
    /* rebuild the field equipment deterministically from the record */
    if (rec.state === 'active') {
      for (const e of this.enemies) e._m47 = true;
      if (rec.type === 'holdout') {
        this.world.setMissionProps([
          { kind: 'hold', x: rec.anchor.x, z: rec.anchor.z,
            r: ASSETS.missionDirector.holdout.radius }]);
      } else if (rec.type === 'defense') {
        this.world.setMissionProps([{ kind: 'generator', x: rec.anchor.x, z: rec.anchor.z }]);
      } else if (rec.type === 'recovery') {
        this.world.setMissionProps(rec.caches.filter((c) => !c.got)
          .map((c) => ({ kind: 'cache', x: c.x, z: c.z })));
      }
    } else if (rec.state === 'complete') {
      this.world.setMissionProps([{ kind: 'beacon',
        x: rec.extract.x, z: rec.extract.z }]);
    }
    return rec;
  }

  /* -- buoy touch mid-mission: a COMPLETE mission rides the normal
     extraction home; an ACTIVE one is abandoned (no pay — the beacon
     is the success path, CH-47.4).                                   */
  _missionOnBuoyTouch() {
    const rec = this.mission;
    if (!rec) return false;
    if (rec.state === 'complete') {
      rec.extracting = true;
      this.lastSummary = rec;          // summary presents on hub arrival
      this.mission = null;
      return false;                    // let startExtraction proceed
    }
    this.mission = null;
    this.clearMissionProps();
    this.lastMission = { name: rec.name, type: rec.type, result: 'abandoned',
      reason: 'ABANDONED — EXTRACTION TAKEN', cr: 0, pw: 0 };
    this.hud.toast('MISSION ABANDONED — EXTRACTION TAKEN', 2600);
    return false;
  }

  /* CH-36.5 — hub station interact: opens the station's REAL system
     (its XMB column) — zero decorative buttons, zero duplicated logic. */
  enterStation(st) {
    this.sfx.uiConfirm();
    this.hud.openXmbAt(st.col);
  }

  /* CH-36.2/36.5 — per-frame hub play: ramp door + vista via world.updateHub,
     station proximity prompt + X-press routing (hub wins over ecology's
     harvest/fish context — there is nothing to harvest in the shuttle). */
  updateHubPlay(dt) {
    if (this.player.pos.z <= ASSETS.hub.z0) { this.hubStation = null; return; }
    this.world.updateHub(dt, this);
    /* nearest station in reach → prompt */
    let best = null, bestD = Infinity;
    for (const st of this.world.hub.stations) {
      const d = Math.hypot(st.x - this.player.pos.x, st.z - this.player.pos.z);
      const reach = st.reach || ASSETS.hub.interactR;
      if (d < reach && d < bestD) { best = st; bestD = d; }
    }
    this.hubStation = best;
    if (best) {
      this.hud.setPrompt(
        (this.input.usesPad ? 'X ' : 'PRESS X — ') + best.label);
    }
  }

  /* -- VATS ------------------------------------------------------------------ */
  setVats(on) {
    this.timeScale = on ? VATS.timeScale : 1;
    if (on) {
      this.sfx.vatsIn();
      this.weapon.closeZoom(this);
    } else {
      this.sfx.vatsOut();
    }
  }

  vatsFire() {
    const pl = this.player;
    if (!pl.vatsActive || pl.dead) return;
    if (!pl.canPay(VATS.missileEnergy)) { this.sfx.energyFail(); return; }
    const targets = this.specials.visibleTargets(this, VATS.cone, VATS.range, 1);
    const t = targets[0] || (this.currentTarget && this.currentTarget.ref) || null;
    if (!t) { this.hud.toast('NO TARGET IN CONE', 800); return; }
    pl.spend(VATS.missileEnergy);
    this._vatsSide *= -1;
    this.specials.launchMissile(this, t, 0.28 * this._vatsSide, VATS.missileDmg, { execute: true });
    this.sfx.missile();
  }

  /* -- abilities ----------------------------------------------------------------- */
  useNova() {
    if (this.state !== 'playing' || this.player.dead) return;
    if (this.novaCd > 0) return;
    if (!this.player.spend(NOVA.energy)) { this.sfx.energyFail(); return; }
    this.novaCd = NOVA.cd;
    this.sfx.nova();
    this.specials.spawnRing(this.player.pos, NOVA.radius, '#59f2ff');
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const to = new THREE.Vector3().subVectors(e.group.position, this.player.pos);
      to.y = 0;
      const d = to.length();
      if (d < NOVA.radius) {
        /* CH-25.4 — typed blast (FILE-SCOPE NOTE: main.js sits outside
           ch-25.files but this ability hit is part of the CH-25.1
           "abilities included" contract — unavoidable, same precedent
           as the CH-05 ecology.js touch).                                */
        applyDamage(e, { types: typedHit(NOVA), crit: rollCrit(NOVA), statusChance: NOVA.statusChance || 0 },
          this, { point: e.group.position.clone(), kind: 'splash' });
        e.stagger = Math.max(e.stagger, 1.4);
        if (d > 0.3 && !e.fly) e.group.position.add(to.normalize().multiplyScalar(NOVA.knock * 0.4));
      }
    }
  }

  toggleFlashlight() {
    this.flashlightOn = !this.flashlightOn;
    this.torch.intensity = this.flashlightOn ? ASSETS.flashlight.intensity : 0;
    this.sfx.navBig();
  }

  /* -- 4-slot R2 wheel (HOLD D-pad ◀▶ to cycle) ------------------------------ */
  updateSlotWheel(dt) {
    const inp = this.input;
    const pressL = inp.pressed('specialPrev');
    const pressR = inp.pressed('specialNext');
    const holdL = inp.down('specialPrev');
    const holdR = inp.down('specialNext');
    const S = this.specials;

    const step = (dir) => {
      S.cycleSlot(dir);
      this.sfx.nav();
      const def = SP.list.find((x) => x.id === S.equipped);
      this.hud.toast('SLOT ' + (S.slotIdx + 1) + ' · ' + (def ? def.name : ''), 900);
    };

    if (pressL) step(-1);
    if (pressR) step(1);

    if ((holdL || holdR) && !pressL && !pressR) {
      this._slotHoldT += dt;
      if (this._slotHoldT >= SP.cycleHold) {
        this._slotTick -= dt;
        if (this._slotTick <= 0) {
          this._slotTick = SP.cycleStep;
          step(holdL ? -1 : 1);
        }
      }
    } else if (!holdL && !holdR) {
      this._slotHoldT = 0;
      this._slotTick = 0;
    }
  }

  /* -- savestate ------------------------------------------------------------------- */
  saveState() {
    const p = this.player;
    const cp = this.companions;
    const data = {
      v: 3,
      pos: p.pos.toArray(), yaw: p.yaw, pitch: p.pitch,
      shield: p.shield, health: p.health, energy: p.energy,
      grenades: this.specials.grenades,
      slots: this.specials.slots.slice(),
      slotIdx: this.specials.slotIdx,
      droneEnabled: cp.droneEnabled, petEnabled: cp.petEnabled,
      droneWeaponIdx: cp.droneWeaponIdx,
      unlocked: [...this.weapon.unlocked],
      ammo: { ...this.ammo },
      materials: { ...this.materials },
      nikana: this.weapon.nikana,
      mags: this.weapon.guns.map((g) => g.mag),
      cur: this.weapon.cur,
      time: this.time, kills: this.weapon.stats.kills,
      light: this.flashlightOn,
      mission: this._missionSave(),   /* CH-47.1 — idempotent extension */
    };
    try {
      localStorage.setItem('ac-save-v1', JSON.stringify(data));
      this.hud.toast('STATE SAVED', 1200);
      this.sfx.uiConfirm();
    } catch { this.hud.toast('SAVE FAILED', 1200); }
  }

  loadState() {
    let data;
    try { data = JSON.parse(localStorage.getItem('ac-save-v1')); } catch { data = null; }
    if (!data) { this.hud.toast('NO SAVED STATE', 1200); return; }
    // fresh hostiles, world items cleared — the save is YOURS, the bay is not
    for (const e of this.enemies) {
      this.scene.remove(e.group);
      this.scene.remove(e.blob);
    }
    this.enemies = [];
    this.respawnQueue = [];
    clearBolts(this);
    this.spawnEnemies();
    this.weapon.resetAll();
    this.specials.resetAll(this);
    this.world.door.reset();
    this.world.door2.reset();
    this.world.resetCorridorDoors();   /* CH-08.2 — gates shut, pads cool */

    const p = this.player;
    p.reset();
    p.pos.fromArray(data.pos);
    p.yaw = data.yaw; p.pitch = data.pitch;
    p.shield = data.shield; p.health = data.health; p.energy = data.energy;
    this.ammo = { ...data.ammo };
    this.weapon.unlocked = new Set(data.unlocked && data.unlocked.length
      ? data.unlocked : [ASSETS.startWeapon || 'pistol']);
    this.weapon.guns.forEach((g, i) => { g.mag = data.mags[i]; g.drawLed(); });
    this.weapon.cur = (data.cur != null && this.weapon.isUnlocked(data.cur))
      ? data.cur
      : Math.max(0, this.weapon.guns.findIndex((g) => g.def.id === (ASSETS.startWeapon || 'pistol')));
    this.weapon.guns.forEach((g, i) => { g.group.visible = i === this.weapon.cur; });
    this.specials.grenades = data.grenades;
    if (data.slots) this.specials.slots = data.slots.slice();
    this.specials.slotIdx = data.slotIdx || 0;
    const cp = this.companions;
    cp.droneEnabled = !!data.droneEnabled;
    cp.petEnabled = !!data.petEnabled;
    cp.droneWeaponIdx = data.droneWeaponIdx || 0;
    cp.resetAll(this);
    this.weapon.stats.kills = data.kills;
    this.weapon.nikana = !!data.nikana;
    this.materials = data.materials ? { ...data.materials } : {};
    this.time = data.time;
    this.flashlightOn = !!data.light;
    this.torch.intensity = this.flashlightOn ? ASSETS.flashlight.intensity : 0;
    /* CH-47.1 — restore a live deployment (idempotent: old saves lack
       the key entirely; the record rebuilds its field props from the
       saved seed — same seed ⇒ same encounter).                      */
    this.clearMissionProps();
    this.mission = this._missionLoad(data.mission || null);
    this.state = 'playing';
    this.hud.setState('playing');
    this.hud.closeXmb();
    this.input.requestLock();
    this.hud.toast('STATE LOADED', 1200);
  }

  teleportSpawn() {
    this.teleportTo(0, -1.6);
  }

  teleportTo(x, z) {
    const p = this.player;
    p.exitVats(this);
    p.pos.set(x, ASSETS.player.eyeHeight, z);
    p.vel.set(0, 0, 0);
    this.hud.toast('TELEPORTED', 1000);
  }

  /* XMB → SALVAGE — sell a material stack */
  sellMaterial(id, all = true) {
    const n = this.materials[id] || 0;
    if (n <= 0) return 0;
    const value = Math.round(ASSETS.ecology.materials[id].sell * n);
    this.materials[id] = 0;
    Mods.add(value);
    return value;
  }

  /* -- events --------------------------------------------------------------- */
  bindEvents() {
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });

    document.addEventListener('pointerlockchange', () => {
      if (!this.input.locked && this.state === 'playing' &&
          performance.now() > (this._noAutoXmb || 0)) this.openXmb();
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.state === 'playing') this.pause();
    });

    const bind = (id, fn) => document.getElementById(id).addEventListener('click', fn);
    bind('btn-start', () => this.start());
    bind('btn-resume', () => this.resume());
    bind('btn-restart', () => this.start());
    bind('btn-again', () => this.start());
  }

  /* -- quality watchdog ------------------------------------------------------
     0 · native res + shadows
     1 · shadows off          ← biggest single win on Intel iGPUs
     2 · 75% resolution
     3 · 55% resolution
     4 · PSP MODE: fixed 480px-wide internal buffer (~480×272) */
  applyQuality() {
    if (this.qStage >= 1) this.sun.castShadow = false;
    const w = window.innerWidth;
    let scale = 1;
    if (this.qStage === 2) scale = 0.75;
    if (this.qStage === 3) scale = 0.55;
    if (this.qStage >= 4) scale = Math.min(1, Q.fallbackWidth / w);
    this.resScale = scale;
    this.renderer.setPixelRatio(this.basePixelRatio * scale);
    this.renderer.setSize(w, window.innerHeight);
  }

  watchdog(dt) {
    if (this.state !== 'playing' || Q.mode !== 'auto' || this.qStage >= 4) return;
    this.fpsAvg += (1 / Math.max(dt, 1e-4) - this.fpsAvg) * 0.08;
    this.fpsCheck += dt;
    if (this.fpsCheck < Q.fpsCheck) return;
    this.fpsCheck = 0;
    if (this.fpsAvg < Q.fpsFloor) {
      this.qStage++;
      this.applyQuality();
      if (this.qStage >= 4) this.hud.toast('PSP MODE · 480×272 · HANG IN THERE', 2400);
      else this.hud.toast('PERFORMANCE MODE ' + this.qStage, 1600);
    }
  }

  /* -- zone management (corridor ⇄ hangar ⇄ valley) ---------------------------- */
  updateZone(dt) {
    const z = this.world.zoneAt(this.player.pos.z);
    if (z !== this.zone) {
      this.zone = z;
      if (z === 'hangar') {
        this.hud.setObjective('OBJECTIVE: FORCE THE EXIT — THE VALLEY AWAITS');
        this.hud.toast('HANGAR BAY 7', 1800);
        if (!this.flashlightOn) this.hud.toast('HANGAR BAY 7 — PRESS L FOR LAMP', 2400);
      } else if (z === 'valley') {
        this.hud.setObjective('OBJECTIVE: PUSH THROUGH THE CANYON TO THE CITY');
        this.hud.toast('THE VALLEY', 1800);
      } else if (z === 'city') {
        this.hud.setObjective('OBJECTIVE: THROUGH THE WILD GATE — THE EXPANSE AWAITS');
        this.hud.toast('THE CITYSCAPE', 1800);
      } else if (z === 'expanse') {
        const tile = this.world.tileAt(this.player.pos.x, this.player.pos.z);
        this.hud.setObjective('OBJECTIVE: CROSS THE WILDS TO THE OCEAN');
        this.hud.toast('THE EXPANSE' + (tile ? ' · ' + tile.biome.toUpperCase() + ' · LVL ' + tile.lvl : ''), 2000);
      } else if (z === 'ocean') {
        this.hud.setObjective('OBJECTIVE: REACH THE DEEP EXTRACTION BUOY — MIND THE WATER');
        this.hud.toast('THE OCEAN — KAIJU WATERS', 2400);
      } else if (z === 'hub') {
        /* CH-36.2 — home base: safe zone, stations + ramp out */
        this.hud.setObjective('OBJECTIVE: HOME BASE — GEAR UP OR WALK THE RAMP');
        this.hud.toast('HOME BASE — SHUTTLE INTERIOR', 2200);
      } else {
        this.hud.setObjective('OBJECTIVE: FIGHT TO HANGAR BAY 7');
      }
    }
    // zone lights: fade in only the active zone's point lights
    /* CH-08.2 — under a connector roof the 'citycorridor' dim lights take
       over and the outdoor city wash fades out, exactly like the
       corridor/hangar indoor zone cull */
    const lz = this.world.corridorAt(this.player.pos.x, this.player.pos.z)
      ? 'citycorridor' : this.zone;
    for (const L of this.world.lights) {
      const target = L.zone === lz ? L.base : 0;
      L.light.intensity += (target - L.light.intensity) * Math.min(1, dt * 5);
    }
    // fog + sky: lerp toward this zone's palette (connector roofs swap in
    // the indoor corridor palette — CH-08.2 zoneFxAt)
    const fx = this.world.zoneFxAt(this.player.pos.x, this.player.pos.z);
    const fog = this.scene.fog;
    fog.near += (fx.near - fog.near) * Math.min(1, dt * 3);
    fog.far += (fx.far - fog.far) * Math.min(1, dt * 3);
    fog.color.lerp(new THREE.Color(fx.fog), Math.min(1, dt * 3));
    this.scene.background.lerp(new THREE.Color(fx.bg), Math.min(1, dt * 3));

    // bay door proximity (corridor → hangar)
    if (!this.world.door.open && this.player.pos.z < this.world.corridor.length - 4 &&
        this.zone === 'corridor') {
      this.world.door.trigger();
      this.sfx.doorOpen();
      this.hud.toast('BAY 7 DOOR CYCLING', 1600);
    }
    // exit door proximity (hangar → valley; opens from either side)
    if (!this.world.door2.open &&
        this.player.pos.z < this.world.hangar.exitDoor.z + ASSETS.world.hangar.exitDoor.openAt) {
      this.world.door2.trigger();
      this.sfx.doorOpen();
    }
    /* CH-08.2 — city connector gate doors auto-cycle from either side */
    for (const d of this.world.corridorDoors) {
      if (!d.open && Math.abs(this.player.pos.z - d.z) < d.openAt && d.trigger()) {
        this.sfx.doorOpen();
      }
    }
  }

  /* ------------------------------------------------------------------ */
  frame() {
    const dt = Math.min(0.05, this.clockDelta());
    this.input.poll(dt);

    if (this.input.keys.has('F3') && !this._f3) this.showFps = !this.showFps;
    this._f3 = this.input.keys.has('F3');

    switch (this.state) {
      case 'menu':
        if (this.input.consumeConfirm()) this.start();
        break;

      case 'playing': {
        this.time += dt;
        this.novaCd -= dt;

        // ADS sensitivity → player look
        this.player._zoomSens = this.weapon.adsSens();
        this.player.update(dt, this.input, this.world, this);
        this.weapon.update(dt, this.input, this);

        // 4-slot wheel: HOLD D-pad ◀▶ (or [ ])
        this.updateSlotWheel(dt);

        // VATS: R1 executes hover missiles; world runs slow-mo
        if (this.player.vatsActive) {
          if (this.input.pressed('fire')) this.vatsFire();
          this.scanTargets(true);
        } else {
          this.scanTargets(false);
        }

        // specials (R2 fires the ACTIVE slot) + nova (F)
        if (this.input.pressed('special') && !this.player.vatsActive) this.specials.use(this);
        if (this.input.pressed('nova')) this.useNova();
        if (this.input.pressed('light')) this.toggleFlashlight();
        /* CH-36.5 — a hub station in reach claims the interact press;
           otherwise X stays harvest/fish (ecology) */
        if (this.input.pressed('interact')) {
          if (this.hubStation) this.enterStation(this.hubStation);
          else this.ecology.interact(this);
        }

        // world sim on scaled dt (VATS slow-mo)
        const sdt = dt * this.timeScale;
        for (const e of this.enemies) e.update(sdt, this);
        this.enemies = this.enemies.filter((e) => !e.gone);
        updateBolts(sdt, this);
        this.specials.update(sdt, this);
        this.companions.update(sdt, this);
        this.ecology.update(sdt, this);
        this.world.update(this.time, dt);
        this.world.updateTransits(dt, this);   /* CH-08.2 — express pads */
        this.updateZone(dt);
        this.updateDaycycle(dt);
        this.processRespawns();
        this.updateReinforce(dt);
        this.updateKaiju(dt);

        /* CH-36.2 — hub upkeep + station prompts (no-op outside the hub) */
        this.updateHubPlay(dt);

        /* CH-47.1 — mission director upkeep (no-op without a deployment) */
        this.updateMission(dt);

        // extraction beacon → CH-36 loading screen → HOME BASE (was: win)
        const z = this.player.pos.z, x = this.player.pos.x;
        const wz = this.world.winZone;
        if (!this.extracting && z > wz.minZ && z < wz.maxZ && x > wz.minX && x < wz.maxX)
          this.startExtraction();

        if (this.input.pressed('pause')) this.openXmb();
        break;
      }

      case 'loading':
        /* CH-36.1 — the loading overlay's own rAF drives the shuttle art;
           the world sim is paused, the renderer keeps presenting. */
        break;

      case 'summary':
        /* CH-47.4 — REWARD SUMMARY: A/Enter (or B/Esc) dismisses; the
           reward applied at presentation, so dismissal is pure flow. */
        this.hud.summaryNav(this.input);
        break;

      case 'xmb':
        this.hud.xmbNav(this.input);
        break;

      case 'paused':
        if (this.input.pressed('pause') || this.input.consumeConfirm()) this.resume();
        break;

      case 'dead':
        if (this.input.consumeConfirm() || this.input.pressed('reload')) this.start();
        break;

      case 'win':
        if (this.input.consumeConfirm()) this.start();
        break;
    }

    // shadow light follows the player
    this.sun.position.set(this.player.pos.x + 4, 9, this.player.pos.z + 3);
    this.sun.target.position.set(this.player.pos.x, 0, this.player.pos.z);

    this.hud.update(dt);
    this.hud.showFps(this.showFps, this.fpsAvg);
    this.watchdog(dt);
    this.renderer.render(this.scene, this.camera);
  }

  clockDelta() {
    if (!this._last) this._last = performance.now();
    const now = performance.now();
    const d = (now - this._last) / 1000;
    this._last = now;
    return d;
  }

  /* -- crosshair target scan (+ VATS target list) -------------------------------- */
  scanTargets(vats) {
    const fwd = new THREE.Vector3();
    this.camera.getWorldDirection(fwd);
    const fwdFlat = new THREE.Vector3(fwd.x, 0, fwd.z).normalize();
    this.currentTarget = null;
    this.vatsTargets = [];
    let best = 0.986; // ~9.5° cone
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const to = new THREE.Vector3().subVectors(e.group.position, this.player.pos);
      const dist = to.length();
      to.y = 0;
      const dot = to.clone().normalize().dot(fwdFlat);
      if (dot > best) {
        best = dot;
        this.currentTarget = { name: e.arch.name, dist, ref: e, lvl: e.level };
      }
      if (vats) {
        const to3 = new THREE.Vector3().subVectors(
          e.group.position, this.camera.getWorldPosition(new THREE.Vector3()));
        if (to3.length() < VATS.range &&
            to3.normalize().dot(fwd) > VATS.cone) {
          this.vatsTargets.push(e);
        }
      }
    }
    if (vats) {
      this.vatsTargets.sort((a, b) =>
        a.group.position.distanceTo(this.player.pos) -
        b.group.position.distanceTo(this.player.pos));
      this.vatsTargets = this.vatsTargets.slice(0, 6);
    }
  }
}

/* -- boot ------------------------------------------------------------------ */
function webglOK() {
  try {
    const c = document.createElement('canvas');
    return !!(window.WebGLRenderingContext &&
      (c.getContext('webgl2') || c.getContext('webgl')));
  } catch { return false; }
}

window.addEventListener('DOMContentLoaded', () => {
  if (!webglOK()) {
    document.getElementById('webglerror').classList.remove('hidden');
    return;
  }
  /* CH-04b — visible diagnostics: if anything throws at boot or in the loop,
     say so ON SCREEN (XMB card when the menu is open) instead of dying quiet.
     The menu must never again look "gone" without naming a cause. */
  const showErr = (msg) => {
    console.error('[FRAME SCAPE]', msg);
    try {
      const xmb = document.getElementById('xmb');
      const t = document.getElementById('xmb-card-title');
      const d = document.getElementById('xmb-card-desc');
      if (xmb && !xmb.classList.contains('hidden') && t && d) {
        d.textContent = 'RUNTIME ERROR: ' + msg +
          ' — the game kept this message instead of dying silently.';
      }
    } catch { /* diagnostics must never throw */ }
  };
  window.addEventListener('error', (e) =>
    showErr((e.message || 'unknown') +
      ((e.filename ? ' @ ' + String(e.filename).split('/').pop() : '') +
       (e.lineno ? ':' + e.lineno : ''))));
  window.addEventListener('unhandledrejection', (e) =>
    showErr('promise: ' + ((e.reason && (e.reason.message || e.reason)) || 'unknown')));
  new Game();
});
